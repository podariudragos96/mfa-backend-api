package net.colt.sdwan.portal.mappers;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.model.versa.sase.api.PublishRequestApiV1;
import net.colt.sdwan.generated.model.versa.sase.api.TenantResponseApiV1;
import net.colt.sdwan.portal.model.PublishRequestV1;
import net.colt.sdwan.portal.model.SaseTenantResponseV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class SaseTenantMapper {

    private final ModelMapper modelMapper;

    public Optional<SaseTenantResponseV1> from(TenantResponseApiV1 tenant) {
        return Optional.of(modelMapper.map(tenant, SaseTenantResponseV1.class));
    }

    public PublishRequestApiV1 from(String initiatedUser, PublishRequestV1 publishRequestV1) {
        return modelMapper
                .map(publishRequestV1, PublishRequestApiV1.class)
                .initiatedUserId(initiatedUser);
    }
}
