package net.colt.sdwan.portal.client.model;

public enum AnalyticsMetricEnum {
    BANDWIDTH_IN("BANDWIDTH_IN"),

    BANDWIDTH_OUT("BANDWIDTH_OUT"),

    VOLUME_IN("VOLUME_IN"),

    VOLUME_OUT("VOLUME_OUT"),

    SESSIONS("SESSIONS"),

    DELAY("DELAY"),

    PACKET_LOSS_IN("PACKET_LOSS_IN"),

    PACKET_LOSS_OUT("PACKET_LOSS_OUT"),

    JITTER_IN("JITTER_IN"),

    JITTER_OUT("JITTER_OUT");

    private String value;

    AnalyticsMetricEnum(String value) {
        this.value = value;
    }

    public static AnalyticsMetricEnum fromValue(String text) {
        for (AnalyticsMetricEnum b : AnalyticsMetricEnum.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        throw new IllegalArgumentException("Unexpected value '" + text + "'");
    }
}
