package net.colt.sdwan.portal.services;

import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.model.CommandRequestModel;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.InterfaceResponseV1;

import java.util.List;
import java.util.Optional;

public interface InterfaceService {

    net.colt.sdwan.generated.model.service.InterfaceResponseV1 getApiInterfaceAndVerify(final String interfaceId);

    net.colt.sdwan.generated.model.service.InterfaceResponseV1 getByDeviceIdAndInterfaceIdAndVerify(final String deviceId, final String interfaceId);

    net.colt.sdwan.generated.model.service.InterfaceResponseV1 getByDeviceAndInterfaceIdAndVerify(
            final DeviceResponseV1 deviceResponse, final String interfaceId);

    List<InterfaceResponseV1> getInterfaceBySiteIdAndDeviceId(final String siteId, final String deviceId);

    Optional<net.colt.sdwan.generated.model.service.InterfaceResponseV1> filterInterfaceResponseFromSite(final SiteResponseV1 siteResponse, final String name);

    InterfaceResponseV1 getInterfaceBySiteIdAndDeviceIdAndInterfaceId(
            final String siteId, final String deviceId, final String interfaceId);

    CorrelationIdResponseV1 getPingOrTracerouteResponse(CommandRequestModel requestModel);

    CorrelationIdResponseV1 getStatsBySiteIdAndDeviceIdAndInterfaceIdAndStatName(
            final String siteId, final String deviceId, final String interfaceId, final String statsName);

    CorrelationIdResponseV1 updateStatsBySiteIdAndDeviceIdAndInterfaceIdAndStatName(
            String siteId, String deviceId, String interfaceId, String statName);

    CorrelationIdResponseV1 getInterfaceDynamicInfoBySiteIdAndDeviceIdAndInterfaceId(
            final String siteId, final String deviceId, final String interfaceId);

    CorrelationIdResponseV1 getShowInterfaceResponseBySiteIdAndDeviceIdAndInterfaceId(String siteId, String deviceId, String interfaceId);

    CorrelationIdResponseV1 getPppoeStatsResponseBySiteIdAndDeviceIdAndInterfaceId(String siteId, String deviceId, String interfaceId, String type);

    Optional<net.colt.sdwan.generated.model.service.InterfaceResponseV1> getInterfaceResponseFromSiteByName(final SiteResponseV1 siteResponse, final String name);

}
