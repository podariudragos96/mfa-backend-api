package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import jakarta.validation.Valid;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NetFlowRequest implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private String id;

    @JsonProperty("description")
    private String description;

    @JsonProperty("updated_dt")
    private LocalDateTime updatedDt;

    @JsonProperty("updated_by")
    private String updatedBy;

    @JsonProperty("collectors")
    @Valid
    private List<NetFlowCollectorRequest> collectors;

    @JsonProperty("rules")
    @Valid
    private List<NetFlowRuleRequest> rules;

    /**
     * Gets or Sets protocol
     */
    public enum ProtocolEnum {
        TCP("TCP"),

        UDP("UDP");

        private String value;

        ProtocolEnum(String value) {
            this.value = value;
        }

        @JsonCreator
        public static NetFlowRequest.ProtocolEnum fromValue(String text) {
            for (NetFlowRequest.ProtocolEnum b : NetFlowRequest.ProtocolEnum.values()) {
                if (String.valueOf(b.value).equals(text)) {
                    return b;
                }
            }
            throw new IllegalArgumentException("Unexpected value '" + text + "'");
        }

        @Override
        @JsonValue
        public String toString() {
            return String.valueOf(value);
        }
    }

}
