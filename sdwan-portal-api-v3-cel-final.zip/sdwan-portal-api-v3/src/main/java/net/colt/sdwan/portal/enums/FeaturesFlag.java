package net.colt.sdwan.portal.enums;

public enum FeaturesFlag {
    YES, NO
}
