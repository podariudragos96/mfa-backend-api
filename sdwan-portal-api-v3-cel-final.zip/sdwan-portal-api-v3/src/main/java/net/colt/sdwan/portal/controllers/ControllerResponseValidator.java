package net.colt.sdwan.portal.controllers;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Set;

@Slf4j
@Aspect
@RequiredArgsConstructor
@Component
public class ControllerResponseValidator {

    private final Validator validator;

    /**
     * Check that the controller response match the generated code response by swagger.
     *
     * <p>If it doesn't and error message is write in the log</p>
     *
     * @param joinPoint methode checked
     * @param result    reponse object
     */
    @AfterReturning(pointcut = "execution(* net.colt.sdwan.portal.controllers.*.*(..))", returning = "result")
    public void validateResponse(JoinPoint joinPoint, Object result) {
        if (result instanceof ResponseEntity<?>) {
            Object body = ((ResponseEntity<?>) result).getBody();
            if (Objects.nonNull(body)) {
                validateResponse(body);
            }
        }
    }

    private void validateResponse(Object body) {
        final Set<ConstraintViolation<Object>> validationResults = validator.validate(body);
        if (!validationResults.isEmpty()) {
            for (ConstraintViolation<Object> error : validationResults) {
                log.error("Swagger definition violation: {}.{} - {}", body.getClass().getCanonicalName(), error.getPropertyPath(), error.getMessage());
            }
        }
    }
}
