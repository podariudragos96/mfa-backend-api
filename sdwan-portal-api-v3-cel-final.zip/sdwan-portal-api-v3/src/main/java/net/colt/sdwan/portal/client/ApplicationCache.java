package net.colt.sdwan.portal.client;

import net.colt.sdwan.common.logging.service.LoggingService;
import net.colt.sdwan.portal.client.model.ApplicationResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;

import static net.colt.sdwan.portal.constant.Constants.SLASH;

@Component
public class ApplicationCache extends AbstractRestApiClient {

    @Value("${policy.api.base.url}")
    private String policyApiBaseUrl;

    public ApplicationCache(AuthHeaderGenerator authHeaderGenerator, RestTemplate restTemplate, LoggingService loggingService) {
        super(authHeaderGenerator, restTemplate, loggingService);
    }

    @Cacheable(value = "applications", key = "#versaInstance")
    public ApplicationResponse getApplicationsFromVersa(final String versaInstance) {
        ApplicationResponse result;
        final String path = SLASH + versaInstance + "/applications/";
        result = get(policyApiBaseUrl, path, new HashMap<>(), ApplicationResponse.class, getHttpEntity()).getBody();
        return result;
    }

    private HttpEntity<Object> getHttpEntity() {
        return new HttpEntity<>(authHeaderGenerator.createSDWANPolicyHeaders());
    }

}
