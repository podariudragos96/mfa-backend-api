package net.colt.sdwan.portal.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DynamicInfoConstants {

    // Feature definition
    public static final String DYNAMIC_INFO_FEATURE_NAME = "DYNAMIC_INFO";

}
