package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.model.InterfaceAdminStatusV1;
import net.colt.sdwan.portal.model.InterfaceOperationalStatusV1;
import net.colt.sdwan.portal.model.InterfaceResponseV1;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
public class InterfaceResponseMapper {

    public static final String FULL_DUPLEX = "full-duplex";
    public static final String HALF_DUPLEX = "half-duplex";
    public static final String AUTO_DUPLEX = "auto";

    public InterfaceResponseV1 mapToResponse(net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse) {
        if (Objects.nonNull(interfaceResponse)) {
            return new InterfaceResponseV1()
                    .id(interfaceResponse.getId().intValue())
                    .dhcp(interfaceResponse.getDhcp())
                    .duplex(mapToDuplexEnum(interfaceResponse.getDuplex()))
                    .circuitName(interfaceResponse.getCircuitName())
                    .circuitReference(interfaceResponse.getCircuitReference())
                    .friendlyName(interfaceResponse.getFriendlyName())
                    .network(interfaceResponse.getNetwork())
                    .ipv4Address(interfaceResponse.getIpv4Address())
                    .ipv6Address(interfaceResponse.getIpv6Address())
                    .operationalStatus(mapToOperationalStatusEnum(interfaceResponse.getOperationalStatus() != null ? interfaceResponse.getOperationalStatus().getValue() : null))
                    .adminStatus(mapToAdminStatusEnum(interfaceResponse.getAdminStatus() != null ? interfaceResponse.getAdminStatus().getValue() : null))
                    .macAddress(interfaceResponse.getMacAddress())
                    .name(interfaceResponse.getName())
                    .description(interfaceResponse.getDescription())
                    .shapingBw(interfaceResponse.getShapingBw() != null ? interfaceResponse.getShapingBw().toString() : null)
                    .speed(interfaceResponse.getSpeed())
                    .type(mapToTypeEnum(interfaceResponse.getType()))
                    .vrf(interfaceResponse.getVrf())
                    .vrrpIpv4(interfaceResponse.getVrrpIpv4())
                    .zone(interfaceResponse.getZone())
                    .bandwidthIn(interfaceResponse.getDownloadBw())
                    .bandwidthOut(interfaceResponse.getUploadBw())
                    .tunnelType(interfaceResponse.getTunnelType() != null ? InterfaceResponseV1.TunnelTypeEnum.valueOf(interfaceResponse.getTunnelType().getValue()) : null)
                    .addressType(interfaceResponse.getAddressType() != null ? InterfaceResponseV1.AddressTypeEnum.valueOf(interfaceResponse.getAddressType().getValue()) : null)
                    .destinationIp(interfaceResponse.getDestinationIp())
                    .sourceIp(interfaceResponse.getSourceIp())
                    .sourceInterface(interfaceResponse.getSourceInterface())
                    .interfaceType(InterfaceResponseV1.InterfaceTypeEnum.valueOf(interfaceResponse.getInterfaceType() == null ? "STANDARD" : interfaceResponse.getInterfaceType().getValue().toUpperCase()))
                    .configType(interfaceResponse.getConfigType() != null ? InterfaceResponseV1.ConfigTypeEnum.valueOf(interfaceResponse.getConfigType().getValue()) : null);
//                .wanConnectivityType(interfaceResponse.getIsWan())
        }
        return new InterfaceResponseV1();
    }

    public List<InterfaceResponseV1> fromList(final List<net.colt.sdwan.generated.model.service.InterfaceResponseV1> interfaceResponses) {
        if (CollectionUtils.isNotEmpty(interfaceResponses)) {
            return interfaceResponses.stream().map(this::mapToResponse).toList();
        }
        return new ArrayList<>();
    }

    private InterfaceResponseV1.DuplexEnum mapToDuplexEnum(final String duplex) {
        InterfaceResponseV1.DuplexEnum finalDuplex = null;
        if (FULL_DUPLEX.equalsIgnoreCase(duplex)) {
            finalDuplex = InterfaceResponseV1.DuplexEnum.FULL;
        } else if (HALF_DUPLEX.equalsIgnoreCase(duplex)) {
            finalDuplex = InterfaceResponseV1.DuplexEnum.HALF;
        } else if (AUTO_DUPLEX.equalsIgnoreCase(duplex)) {
            finalDuplex = InterfaceResponseV1.DuplexEnum.AUTO;
        }
        return finalDuplex;
    }

    private InterfaceOperationalStatusV1 mapToOperationalStatusEnum(final String operationalStatus) {
        InterfaceOperationalStatusV1 linkStatusEnum = null;
        if (StringUtils.isNotEmpty(operationalStatus)) {
            linkStatusEnum = InterfaceOperationalStatusV1.fromValue(operationalStatus.toUpperCase());
        }
        return linkStatusEnum;
    }

    private InterfaceAdminStatusV1 mapToAdminStatusEnum(final String adminStatus) {
         InterfaceAdminStatusV1 interfaceAdminStatus = null;
        if (StringUtils.isNotEmpty(adminStatus)) {
            interfaceAdminStatus = InterfaceAdminStatusV1.fromValue(adminStatus.toUpperCase());
        }
        return interfaceAdminStatus;
    }

    private InterfaceResponseV1.TypeEnum mapToTypeEnum(final String type) {
        InterfaceResponseV1.TypeEnum typeEnum = null;
        if (StringUtils.isNotEmpty(type)) {
            typeEnum = InterfaceResponseV1.TypeEnum.fromValue(type.toUpperCase());
        }
        return typeEnum;
    }

}
