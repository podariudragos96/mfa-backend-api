package net.colt.sdwan.portal.client.feign.sase;

import net.colt.sdwan.generated.controller.versa.sase.api.TenantApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "saseTenantApiFeign", url = "${sdwan.sase.api.baseurl}",
        configuration = SaseApiFeignConfiguration.class)
public interface SaseTenantFeign extends TenantApiApi {
}
