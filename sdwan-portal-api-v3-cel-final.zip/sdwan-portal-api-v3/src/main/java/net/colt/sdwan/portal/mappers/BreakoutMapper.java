package net.colt.sdwan.portal.mappers;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.model.SaseBreakoutRequestV1;
import net.colt.sdwan.portal.model.SaseBreakoutResponseV1;
import net.colt.sdwan.portal.model.ZScalerBreakoutRequestV1;
import net.colt.sdwan.sitesettings.api.generated.model.SaseBreakoutRequestApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.ZScalerBreakoutRequestApiV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
@Component
public class BreakoutMapper {

    private final ModelMapper modelMapper;

    public SaseBreakoutResponseV1 fromSaseBreakoutStatusToSaseBreakoutResponseV1(Boolean saseBreakoutStatus) {
        return SaseBreakoutResponseV1.builder().active(saseBreakoutStatus).build();
    }

    public SaseBreakoutRequestApiV1 fromSaseBreakoutRequestV1ToSaseBreakoutRequestApiV1(SaseBreakoutRequestV1 saseBreakoutRequestV1) {
        return modelMapper.map(saseBreakoutRequestV1, SaseBreakoutRequestApiV1.class);
    }

    public ZScalerBreakoutRequestApiV1 fromZScalerBreakoutRequestV1ToZScalerBreakoutRequestApiV1(ZScalerBreakoutRequestV1 zScalerBreakoutRequestV1) {
        return modelMapper.map(zScalerBreakoutRequestV1, ZScalerBreakoutRequestApiV1.class);
    }


}
