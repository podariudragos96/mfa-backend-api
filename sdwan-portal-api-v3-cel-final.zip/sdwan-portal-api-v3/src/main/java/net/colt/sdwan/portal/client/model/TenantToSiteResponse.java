package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TenantToSiteResponse {

    @JsonProperty("tenant_id")
    private Integer tenantId;

    @JsonProperty("site_id")
    private Integer siteId;

    @JsonProperty("versa_analytics_instance")
    private String versaAnalyticsName;
}