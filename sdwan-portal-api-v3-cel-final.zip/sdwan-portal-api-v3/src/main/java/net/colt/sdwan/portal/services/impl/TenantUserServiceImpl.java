package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.portal.client.feign.session.SessionApiFeign;
import net.colt.sdwan.portal.client.helper.TenantClientHelper;
import net.colt.sdwan.portal.client.helper.TenantUserClientHelper;
import net.colt.sdwan.portal.client.model.customerapi.*;
import net.colt.sdwan.portal.mappers.TenantUserMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.model.TenantUserPortalResponseV1;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.services.TenantUserService;
import net.colt.sdwan.portal.util.TenantUsernameUtils;
import net.colt.sdwan.session.api.generated.model.SdwanSessionsResponseV1;
import net.colt.sdwan.session.api.generated.model.SessionResponseV1;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static java.util.Objects.nonNull;

@RequiredArgsConstructor
@Service
@Slf4j
public class TenantUserServiceImpl implements TenantUserService {

    private final TenantUserClientHelper tenantUserClientHelper;
    private final TenantClientHelper tenantClientHelper;
    private final SessionApiFeign sessionApiFeign;
    private final SitesService sitesService;
    private final ModelMapper modelMapper;
    private TenantUserMapper tenantUserMapper;

    @Override
    public CreateTenantUserPortalResponseV1 addTenantUser(Integer tenantId,
                                                          CreateTenantUserPortalRequestV1 createTenantUserPortalRequestV1) {
        CreateTenantUserRequestV1 request = modelMapper.map(createTenantUserPortalRequestV1, CreateTenantUserRequestV1.class).tenantId(tenantId);
        CreateTenantUserResponseV1 body = tenantUserClientHelper.createTenantUser(tenantId, request);
        return modelMapper.map(body, CreateTenantUserPortalResponseV1.class);
    }

    @Override
    public void editTenantUser(Integer tenantUserId, EditTenantUserPortalRequestV1 editTenantUserPortalRequestV1) {
        EditTenantUserRequestV1 editTenantUserRequestV1 = modelMapper.map(editTenantUserPortalRequestV1, EditTenantUserRequestV1.class);
        tenantUserClientHelper.editTenantUser(tenantUserId, editTenantUserRequestV1);
        clearByUsername(generateUsername(tenantUserId));
    }

    @Override
    public TenantUsersPortalResponseV1 getTenantUsers(TenantUsersCriteriaV1 criteria, Integer pageNumber, Integer pageSize) {
        TenantUsersCriteriaApiV1 tenantUsersCriteriaApiV1 = tenantUserMapper.from(criteria);

        final ResponseEntity<TenantUsersResponseApiV1> response = tenantUserClientHelper.getTenantUsers(tenantUsersCriteriaApiV1, pageNumber, pageSize);



    }

    @Override
    public void deleteTenantUserById(Integer tenantUserId) {
        String username = generateUsername(tenantUserId);
        tenantUserClientHelper.deleteTenantUserByIdV1(tenantUserId);
        clearByUsername(username);
    }

    public String generateUsername(TenantUserResponseV1 tenantUserResponse, TenantResponseV1 tenantResponse) {
        String result = null;
        String username = null;
        String domain = null;

        // Get the tenantUser details from customer service
        if (nonNull(tenantUserResponse)) {
            username = tenantUserResponse.getUsername();

            if (nonNull(tenantResponse)) {
                domain = tenantResponse.getResellerDomain();
            }
        }
        if (StringUtils.isNoneEmpty(username) && StringUtils.isNoneEmpty(domain)) {
            result = TenantUsernameUtils.generateUsername(username, domain);
        }
        return result;
    }

    private String generateUsername(Integer tenantUserId) {
        // Get the tenantUser details from customer service
        TenantUserResponseV1 tenantUserResponse = tenantUserClientHelper.getTenantUserById(tenantUserId);
        TenantResponseV1 tenantResponse = tenantClientHelper.findById(tenantUserResponse.getTenantId());
        return this.generateUsername(tenantUserResponse, tenantResponse);
    }

    public void clearByUsername(String username) {
        if (nonNull(username)) {
            log.debug(
                    "Clearing user (locking sites and token) for the username {} after tenant user edition or deletion",
                    username);
            final List<String> siteIds = sitesService.getLockedSites(username);
            sitesService.unlockSites(siteIds, username);
            final SdwanSessionsResponseV1 sdwanSessionsV1 = sessionApiFeign.getSdwanSessionsV1().getBody();
            if (nonNull(sdwanSessionsV1)) {
                final List<SessionResponseV1> sessions = sdwanSessionsV1.getSessions();
                final SessionResponseV1 sessionV1 = sessions.stream()
                        .filter(session -> username.equals(session.getUsername()))
                        .findAny()
                        .orElse(null);

                if (nonNull(sessionV1)) {
                    sessionApiFeign.deleteSdwanSessionV1(sessionV1.getToken());
                }
            }
        }
    }

}
