package net.colt.sdwan.portal.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public abstract class Constants {

    public static final String DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    public static final String REGEX_DMZ = "DMZ?[0-9]+(-V[0-9]+){0,1}";
    public static final String REGEX_LAN = "LAN?[0-9]+[A-Z]{0,1}(-V[0-9]+){0,1}";
    public static final String REGEX_LAN_NNI = "LAN?[0-9]+(-NNI)";
    public static final String SLASH_API = "/api";
    public static final String X_VERSA_DIRECTOR_ID = "x-versa-director-id";

    public static final String LOCALHOST_IP_PORT = "0.0.0.0/0";
    public static final String ZSCALLER_DEFAULT_RULE = "CUST-LAN-ZSCALER-ALLOW";
    public static final String SASE_DEFAULT_RULE = "CUST-LAN-SASE-ALLOW";
    public static final String SLASH = "/";

    public static final String DEFAULT_RULE_PREFIX = "DEFAULT-";
    public static final String BESPOKE_RULE_PREFIX = "COLT-";

    public static final String DEVICE_PREFIX = "DEVICE_";
}
