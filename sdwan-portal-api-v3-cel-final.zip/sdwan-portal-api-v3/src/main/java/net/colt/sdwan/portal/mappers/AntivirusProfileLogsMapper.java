package net.colt.sdwan.portal.mappers;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.model.AntivirusProfileLogsResponseV1;
import net.colt.sdwan.security.api.generated.model.AntivirusProfileApiLogsResponseV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.LinkedList;
import java.util.List;

@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
@Component
public class AntivirusProfileLogsMapper {

    private final ModelMapper modelMapper;

    public List<AntivirusProfileLogsResponseV1> from(List<AntivirusProfileApiLogsResponseV1> antivirusProfileApiLogsResponseV1s) {

        final LinkedList<AntivirusProfileLogsResponseV1> response = new LinkedList<>();

        if (!antivirusProfileApiLogsResponseV1s.isEmpty()) {
            antivirusProfileApiLogsResponseV1s.stream()
                    .map(antivirusProfile -> modelMapper.map(antivirusProfile, AntivirusProfileLogsResponseV1.class))
                    .forEach(response::add);
        }

        return response;
    }
}
