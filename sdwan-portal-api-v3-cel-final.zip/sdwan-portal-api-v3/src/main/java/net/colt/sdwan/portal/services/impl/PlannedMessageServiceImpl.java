package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.portal.client.feign.PlannedMessageApiFeign;
import net.colt.sdwan.portal.mappers.PlannedMessageMapper;
import net.colt.sdwan.portal.model.PlannedMessageCriteriaV1;
import net.colt.sdwan.portal.model.PlannedMessagesResponseV1;
import net.colt.sdwan.portal.services.PlannedMessageService;
import net.colt.sdwan.system.api.generated.model.LocalDateTimeFilter;
import net.colt.sdwan.system.api.generated.model.PlannedMessageCriteriaApiV1;
import net.colt.sdwan.system.api.generated.model.PlannedMessagesResponseApiV1;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

import static java.util.Collections.emptyList;
import static java.util.Objects.nonNull;

@Service
@RequiredArgsConstructor
public class PlannedMessageServiceImpl implements PlannedMessageService {

    private final PlannedMessageApiFeign feign;
    private final PlannedMessageMapper mapper;

    @Override
    public PlannedMessagesResponseV1 getPlannedMessage(PlannedMessageCriteriaV1 criteria) {
        final PlannedMessageCriteriaApiV1 criteriaMapped = setCriteriaStartAndEndDate(criteria);
        final ResponseEntity<PlannedMessagesResponseApiV1> plannedMessage = feign.getPlannedMessagesV1(criteriaMapped, 0, 20, emptyList(), Pageable.unpaged());

        if (plannedMessage.getStatusCode().equals(HttpStatus.OK) && nonNull(plannedMessage.getBody())) {
            return mapper.map(plannedMessage.getBody());
        }

        throw new SdwanInternalServerErrorException("Couldn't get planned messages due to an problem on sdwan-system-api." + plannedMessage.getBody());
    }

    /**
     * Portal API will always receive all the active planned messages, meaning the ones that have their start date
     * before or at the time the call was made, and the end date after or at the time the call was made.
     */
    private PlannedMessageCriteriaApiV1 setCriteriaStartAndEndDate(PlannedMessageCriteriaV1 criteria) {
        final LocalDateTimeFilter startDate = LocalDateTimeFilter.builder().lessThanOrEqual(LocalDateTime.now()).build();
        final LocalDateTimeFilter endDate = LocalDateTimeFilter.builder().greaterThanOrEqual(LocalDateTime.now()).build();
        final PlannedMessageCriteriaApiV1 criteriaMapped = mapper.map(criteria);
        return criteriaMapped.startDate(startDate).endDate(endDate);
    }
}