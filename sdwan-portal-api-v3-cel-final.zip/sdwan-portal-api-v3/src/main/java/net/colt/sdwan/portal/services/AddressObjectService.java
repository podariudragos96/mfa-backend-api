package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.AddressObjectCriteria;
import net.colt.sdwan.portal.model.AddressesRequestV1;
import net.colt.sdwan.portal.model.AddressesResponseV1;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;

public interface AddressObjectService {
    AddressesResponseV1 getAddressesV1(String siteId, AddressObjectCriteria criteria, Integer pageNumber, Integer pageSize);

    CorrelationIdResponseV1 updateAddressV1(String siteId, AddressesRequestV1 addressesRequestV1);
}
