package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.FirewallAnalyticsRuleNameResponseV1;
import net.colt.sdwan.portal.model.FirewallRulesActionV1;
import net.colt.sdwan.portal.model.FirewallRulesNetworkResponseV1;
import net.colt.sdwan.portal.model.NetworkResponseV1;

import java.time.LocalDateTime;
import java.util.List;

public interface NetworksService {

    List<FirewallRulesNetworkResponseV1> getFirewallRulesByNetworkId(
            String networkId, FirewallRulesActionV1 action, LocalDateTime startDt, LocalDateTime endDt, Integer count);

    List<FirewallAnalyticsRuleNameResponseV1> getFirewallAnalyticsByRuleName(
            String ruleName, String networkId, FirewallRulesActionV1 action, LocalDateTime startDt, LocalDateTime endDt);

    List<NetworkResponseV1> getNetworks();
}
