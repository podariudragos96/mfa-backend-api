package net.colt.sdwan.portal.controllers.advice;

import net.colt.sdwan.common.exceptions.handler.CommonExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class RestExceptionHandler extends CommonExceptionHandler {
}
