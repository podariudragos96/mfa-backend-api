package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SlaMetricsTimeSeriesAnalyticsResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("data")
    @Valid
    private List<List<Long>> data = new ArrayList<>();

    @JsonProperty("label")
    private String label;

    @JsonProperty("name")
    private String name;

    public SlaMetricsTimeSeriesAnalyticsResponse data(List<List<Long>> data) {
        this.data = data;
        return this;
    }

    public SlaMetricsTimeSeriesAnalyticsResponse addDataItem(List<Long> dataItem) {
        this.data.add(dataItem);
        return this;
    }

    /**
     * Get data
     *
     * @return data
     */
    @ApiModelProperty(required = true, value = "")
    @NotNull

    @Valid

    public List<List<Long>> getData() {
        return data;
    }

    public void setData(List<List<Long>> data) {
        this.data = data;
    }

    public SlaMetricsTimeSeriesAnalyticsResponse label(String label) {
        this.label = label;
        return this;
    }

    /**
     * Get label
     *
     * @return label
     */
    @ApiModelProperty(example = "bps", required = true, value = "")
    @NotNull


    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public SlaMetricsTimeSeriesAnalyticsResponse name(String name) {
        this.name = name;
        return this;
    }

    /**
     * Get name
     *
     * @return name
     */
    @ApiModelProperty(example = "FRA009022,NV-WC2-FRA,MPLS-WAN1,MPLS-WAN,fc_nc", required = true, value = "")
    @NotNull


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SlaMetricsTimeSeriesAnalyticsResponse slaMetricsTimeSeriesAnalyticsResponse = (SlaMetricsTimeSeriesAnalyticsResponse) o;
        return Objects.equals(this.data, slaMetricsTimeSeriesAnalyticsResponse.data) &&
                Objects.equals(this.label, slaMetricsTimeSeriesAnalyticsResponse.label) &&
                Objects.equals(this.name, slaMetricsTimeSeriesAnalyticsResponse.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(data, label, name);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class SlaMetricsTimeSeriesAnalyticsResponseV1 {\n");

        sb.append("    data: ").append(toIndentedString(data)).append("\n");
        sb.append("    label: ").append(toIndentedString(label)).append("\n");
        sb.append("    name: ").append(toIndentedString(name)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

