package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import jakarta.validation.constraints.NotNull;

import java.io.Serializable;
import java.util.Objects;

public class SlaMetricsRowDataResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("sla_metric")
    private String slaMetric;

    @JsonProperty("local_site")
    private String localSite;

    @JsonProperty("remote_site")
    private String remoteSite;

    @JsonProperty("local_access_circuit")
    private String localAccessCircuit;

    @JsonProperty("remote_access_circuit")
    private String remoteAccessCircuit;

    @JsonProperty("forwarding_class")
    private String forwardingClass;

    @JsonProperty("delay")
    private String delay;

    @JsonProperty("fwd_delay")
    private String fwdDelay;

    @JsonProperty("rev_delay")
    private String revDelay;

    @JsonProperty("fwd_loss_ratio")
    private String fwdLossRatio;

    @JsonProperty("pdu_loss_ratio")
    private String pduLossRatio;

    @JsonProperty("rev_loss_ratio")
    private String revLossRatio;

    public SlaMetricsRowDataResponse slaMetric(String slaMetric) {
        this.slaMetric = slaMetric;
        return this;
    }

    /**
     * Get slaMetric
     *
     * @return slaMetric
     */
    @ApiModelProperty(example = "FRA000385,NV-WC1-FRA,MPLS-WAN2,MPLS-WAN,fc_nc", required = true, value = "")
    @NotNull


    public String getSlaMetric() {
        return slaMetric;
    }

    public void setSlaMetric(String slaMetric) {
        this.slaMetric = slaMetric;
    }

    public SlaMetricsRowDataResponse localSite(String localSite) {
        this.localSite = localSite;
        return this;
    }

    /**
     * Get localSite
     *
     * @return localSite
     */
    @ApiModelProperty(example = "FRA000385", required = true, value = "")
    @NotNull


    public String getLocalSite() {
        return localSite;
    }

    public void setLocalSite(String localSite) {
        this.localSite = localSite;
    }

    public SlaMetricsRowDataResponse remoteSite(String remoteSite) {
        this.remoteSite = remoteSite;
        return this;
    }

    /**
     * Get remoteSite
     *
     * @return remoteSite
     */
    @ApiModelProperty(example = "NV-WC1-FRA", required = true, value = "")
    @NotNull


    public String getRemoteSite() {
        return remoteSite;
    }

    public void setRemoteSite(String remoteSite) {
        this.remoteSite = remoteSite;
    }

    public SlaMetricsRowDataResponse localAccessCircuit(String localAccessCircuit) {
        this.localAccessCircuit = localAccessCircuit;
        return this;
    }

    /**
     * Get localAccessCircuit
     *
     * @return localAccessCircuit
     */
    @ApiModelProperty(example = "MPLS-WAN2", required = true, value = "")
    @NotNull


    public String getLocalAccessCircuit() {
        return localAccessCircuit;
    }

    public void setLocalAccessCircuit(String localAccessCircuit) {
        this.localAccessCircuit = localAccessCircuit;
    }

    public SlaMetricsRowDataResponse remoteAccessCircuit(String remoteAccessCircuit) {
        this.remoteAccessCircuit = remoteAccessCircuit;
        return this;
    }

    /**
     * Get remoteAccessCircuit
     *
     * @return remoteAccessCircuit
     */
    @ApiModelProperty(example = "MPLS-WAN", required = true, value = "")
    @NotNull


    public String getRemoteAccessCircuit() {
        return remoteAccessCircuit;
    }

    public void setRemoteAccessCircuit(String remoteAccessCircuit) {
        this.remoteAccessCircuit = remoteAccessCircuit;
    }

    public SlaMetricsRowDataResponse forwardingClass(String forwardingClass) {
        this.forwardingClass = forwardingClass;
        return this;
    }

    /**
     * Get forwardingClass
     *
     * @return forwardingClass
     */
    @ApiModelProperty(example = "fc_nc", required = true, value = "")
    @NotNull


    public String getForwardingClass() {
        return forwardingClass;
    }

    public void setForwardingClass(String forwardingClass) {
        this.forwardingClass = forwardingClass;
    }

    public SlaMetricsRowDataResponse delay(String delay) {
        this.delay = delay;
        return this;
    }

    /**
     * Get delay
     *
     * @return delay
     */
    @ApiModelProperty(example = "1245118", required = true, value = "")
    @NotNull


    public String getDelay() {
        return delay;
    }

    public void setDelay(String delay) {
        this.delay = delay;
    }

    public SlaMetricsRowDataResponse fwdDelay(String fwdDelay) {
        this.fwdDelay = fwdDelay;
        return this;
    }

    /**
     * Get fwdDelay
     *
     * @return fwdDelay
     */
    @ApiModelProperty(example = "1245118", required = true, value = "")
    @NotNull


    public String getFwdDelay() {
        return fwdDelay;
    }

    public void setFwdDelay(String fwdDelay) {
        this.fwdDelay = fwdDelay;
    }

    public SlaMetricsRowDataResponse revDelay(String revDelay) {
        this.revDelay = revDelay;
        return this;
    }

    /**
     * Get revDelay
     *
     * @return revDelay
     */
    @ApiModelProperty(example = "1245118", required = true, value = "")
    @NotNull


    public String getRevDelay() {
        return revDelay;
    }

    public void setRevDelay(String revDelay) {
        this.revDelay = revDelay;
    }

    public SlaMetricsRowDataResponse fwdLossRatio(String fwdLossRatio) {
        this.fwdLossRatio = fwdLossRatio;
        return this;
    }

    /**
     * Get fwdLossRatio
     *
     * @return fwdLossRatio
     */
    @ApiModelProperty(example = "1245118", required = true, value = "")
    @NotNull


    public String getFwdLossRatio() {
        return fwdLossRatio;
    }

    public void setFwdLossRatio(String fwdLossRatio) {
        this.fwdLossRatio = fwdLossRatio;
    }

    public SlaMetricsRowDataResponse pduLossRatio(String pduLossRatio) {
        this.pduLossRatio = pduLossRatio;
        return this;
    }

    /**
     * Get pduLossRatio
     *
     * @return pduLossRatio
     */
    @ApiModelProperty(example = "1245118", required = true, value = "")
    @NotNull


    public String getPduLossRatio() {
        return pduLossRatio;
    }

    public void setPduLossRatio(String pduLossRatio) {
        this.pduLossRatio = pduLossRatio;
    }

    public SlaMetricsRowDataResponse revLossRatio(String revLossRatio) {
        this.revLossRatio = revLossRatio;
        return this;
    }

    /**
     * Get revLossRatio
     *
     * @return revLossRatio
     */
    @ApiModelProperty(example = "1245118", required = true, value = "")
    @NotNull


    public String getRevLossRatio() {
        return revLossRatio;
    }

    public void setRevLossRatio(String revLossRatio) {
        this.revLossRatio = revLossRatio;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SlaMetricsRowDataResponse slaMetricsRowDataResponse = (SlaMetricsRowDataResponse) o;
        return Objects.equals(this.slaMetric, slaMetricsRowDataResponse.slaMetric) &&
                Objects.equals(this.localSite, slaMetricsRowDataResponse.localSite) &&
                Objects.equals(this.remoteSite, slaMetricsRowDataResponse.remoteSite) &&
                Objects.equals(this.localAccessCircuit, slaMetricsRowDataResponse.localAccessCircuit) &&
                Objects.equals(this.remoteAccessCircuit, slaMetricsRowDataResponse.remoteAccessCircuit) &&
                Objects.equals(this.forwardingClass, slaMetricsRowDataResponse.forwardingClass) &&
                Objects.equals(this.delay, slaMetricsRowDataResponse.delay) &&
                Objects.equals(this.fwdDelay, slaMetricsRowDataResponse.fwdDelay) &&
                Objects.equals(this.revDelay, slaMetricsRowDataResponse.revDelay) &&
                Objects.equals(this.fwdLossRatio, slaMetricsRowDataResponse.fwdLossRatio) &&
                Objects.equals(this.pduLossRatio, slaMetricsRowDataResponse.pduLossRatio) &&
                Objects.equals(this.revLossRatio, slaMetricsRowDataResponse.revLossRatio);
    }

    @Override
    public int hashCode() {
        return Objects.hash(slaMetric, localSite, remoteSite, localAccessCircuit, remoteAccessCircuit, forwardingClass, delay, fwdDelay, revDelay, fwdLossRatio, pduLossRatio, revLossRatio);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class SlaMetricsRowDataResponseV1 {\n");

        sb.append("    slaMetric: ").append(toIndentedString(slaMetric)).append("\n");
        sb.append("    localSite: ").append(toIndentedString(localSite)).append("\n");
        sb.append("    remoteSite: ").append(toIndentedString(remoteSite)).append("\n");
        sb.append("    localAccessCircuit: ").append(toIndentedString(localAccessCircuit)).append("\n");
        sb.append("    remoteAccessCircuit: ").append(toIndentedString(remoteAccessCircuit)).append("\n");
        sb.append("    forwardingClass: ").append(toIndentedString(forwardingClass)).append("\n");
        sb.append("    delay: ").append(toIndentedString(delay)).append("\n");
        sb.append("    fwdDelay: ").append(toIndentedString(fwdDelay)).append("\n");
        sb.append("    revDelay: ").append(toIndentedString(revDelay)).append("\n");
        sb.append("    fwdLossRatio: ").append(toIndentedString(fwdLossRatio)).append("\n");
        sb.append("    pduLossRatio: ").append(toIndentedString(pduLossRatio)).append("\n");
        sb.append("    revLossRatio: ").append(toIndentedString(revLossRatio)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

