package net.colt.sdwan.portal.database.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "RELEASE_NOTES")
public class ReleaseNotes extends BaseEntity {

    @Column(name = "VERSION", nullable = false)
    private String version;

    @Column(name = "RELEASE_DT", nullable = false)
    private LocalDateTime releaseDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "CONTENT_TYPE", nullable = false)
    private ContentTypeEnum contentType = null;

    @Column(name = "NOTE", nullable = false)
    @Lob
    private byte[] note;
}
