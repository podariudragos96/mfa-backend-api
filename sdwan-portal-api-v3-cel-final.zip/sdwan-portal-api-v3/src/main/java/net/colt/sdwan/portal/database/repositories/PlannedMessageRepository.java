package net.colt.sdwan.portal.database.repositories;

import net.colt.sdwan.portal.database.entities.PlannedMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PlannedMessageRepository extends JpaRepository<PlannedMessage, Integer> {
}
