package net.colt.sdwan.portal.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class SnmpConstants {

    // Feature definition
    public static final String SNMP_FEATURE_NAME = "SNMP";

    // Error messages
    public static final String SNMP_ONLY_AVAILABLE_ON_BRANCH_SITES = "SNMP is only available for sites of type branch";
    public static final String INTERFACE_NOT_PRESENT_ON_SITE_DEVICES = "The interface %s is not " +
            "present for all the devices of the Site[id=%s]";

    public static final String INTERFACE_NETWORK_NOT_PRESENT_ON_SITE_DEVICES = "The interface network %s is not " +
            "present for all the devices of the Site[id=%s]";
    public static final String INTERFACE_TYPE_SHOULD_BE_LAN_ON_SITE_DEVICES = "The interface %s is not " +
            "of type LAN for all the devices of the Site[id=%s]";

}
