package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.data.criteria.filter.BooleanFilter;
import net.colt.sdwan.common.data.criteria.filter.IntegerFilter;
import net.colt.sdwan.common.data.criteria.filter.StringFilter;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.common.exceptions.exception.SdwanUnauthorizedException;
import net.colt.sdwan.portal.client.feign.customer.ApiUserFeign;
import net.colt.sdwan.portal.client.model.customerapi.*;
import net.colt.sdwan.portal.mappers.ApiUserMapper;
import net.colt.sdwan.portal.mappers.UserModelMapper;
import net.colt.sdwan.portal.model.ApiUserKeyResponseModel;
import net.colt.sdwan.portal.model.ApiUserSessionResponseV1;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.ApiUserService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

import static java.util.Objects.isNull;
import static org.apache.commons.collections4.CollectionUtils.isEmpty;

@Slf4j
@Service
@RequiredArgsConstructor
public class ApiUserServiceImpl implements ApiUserService {

    private final ApiUserFeign apiUserFeign;

    private final ApiUserMapper apiUserMapper;

    private static boolean isKeyValid(ApiKey key) {
        return LocalDateTime.now().isBefore(key.getExpiresOn());
    }

    @Override
    public List<ApiUserSessionResponseV1> getApiUserDetails(UserResponseV3 userResponse) {
        log.debug("Building authentication session for userAuth: {}", userResponse.getUsername());
        final UserAuth userAuth=UserModelMapper.mapAuthUserFromUserResponseV3(userResponse);
        log.debug("Building session response for userAuth: {}", userAuth.getUsername());
        final IntegerFilter tenantIdFilter=new IntegerFilter();
        tenantIdFilter.setIn(userAuth.getAccessibleTenantIds());

        final BooleanFilter enabledApiConsumptionFilter=new BooleanFilter();
        enabledApiConsumptionFilter.setEquals(Boolean.TRUE);

        final ApiUserCriteria criteria=ApiUserCriteria.builder()
                .tenantId(tenantIdFilter)
                .enabledApiConsumption(enabledApiConsumptionFilter)
                .build();

        final ResponseEntity<List<ApiUserResponseV1>> apiUserDetailsV1=apiUserFeign.getApiUserDetailsV1(criteria);
        final List<ApiUserResponseV1> userResponseV1List=apiUserDetailsV1.getBody();

        if (isNull(apiUserDetailsV1.getBody()) || isEmpty(userResponseV1List)) {
            throw new SdwanNotFoundException(
                    "No API key found for tenantIds='%s'".formatted(userAuth.getAccessibleTenantIds()));
        }

        final List<ApiUserSessionResponseV1> result=userResponseV1List.stream()
                .filter(apiUserResponseV1 -> apiUserResponseV1.getApiKeys().stream()
                        .anyMatch(ApiUserServiceImpl::isKeyValid))
                .map(apiUserMapper::toApiUserSessionResponseV1)
                .toList();

        if (isEmpty(result)) {
            throw new SdwanNotFoundException(
                    "No set of valid API keys found for tenantIds='%s'".formatted(userAuth.getAccessibleTenantIds()));
        }
        return result;
    }

    @Override
    public List<ApiUserSessionResponseV1> renewApiKeyV1(UserResponseV3 userResponse, String apiUserAgent) {
        log.debug("Building authentication session for userAuth: {}", userResponse.getUsername());
        final UserAuth userAuth=UserModelMapper.mapAuthUserFromUserResponseV3(userResponse);
        log.debug("Building session response for userAuth: {}", userAuth.getUsername());
        ApiUserRenewRequestV1 requestV1=new ApiUserRenewRequestV1();
        requestV1.setUserAgent(apiUserAgent);
        requestV1.setAccessibleTenantIds(userAuth.getAccessibleTenantIds());
        final List<ApiUserResponseV1> apiUserResponseV1s=apiUserFeign.renewApiUserKeyV1(requestV1).getBody();

        if (isEmpty(apiUserResponseV1s)) {
            throw new SdwanInternalServerErrorException(
                    "Failed to process API key renew for userAgent='%s'"
                            .formatted(apiUserAgent));
        }
        return apiUserResponseV1s.stream()
                .map(apiUserMapper::toApiUserSessionResponseV1)
                .toList();
    }

    @Override
    public ApiUserKeyResponseModel getApiUserBasedOnKey(String apiKey, String apiUserAgent) {
        final StringFilter apiKeyFilter=new StringFilter();
        apiKeyFilter.setEquals(apiKey);

        final BooleanFilter enabledApiConsumptionFilter=new BooleanFilter();
        enabledApiConsumptionFilter.setEquals(Boolean.TRUE);

        final ApiUserCriteria criteria=ApiUserCriteria.builder()
                .apiKey(apiKeyFilter)
                .enabledApiConsumption(enabledApiConsumptionFilter)
                .build();

        final ResponseEntity<List<ApiUserResponseV1>> apiUserDetailsV1=apiUserFeign.getApiUserDetailsV1(criteria);
        final List<ApiUserResponseV1> apiUserResponseV1List=apiUserDetailsV1.getBody();

        if (isEmpty(apiUserResponseV1List)) {
            throw new SdwanNotFoundException("No API key found for the provided details [apiKey='%s']".formatted(apiKey));
        }

        final ApiUserResponseV1 apiUserResponseV1=apiUserResponseV1List.stream()
                .filter(response -> response.getUserAgent().equals(apiUserAgent))
                .findFirst()
                .orElseThrow(() -> new SdwanNotFoundException(
                        "No API key found for the provided details [apiUserAgent='%s']".formatted(apiUserAgent)));

        final boolean noneValidKey=apiUserResponseV1.getApiKeys().stream()
                .filter(key -> Objects.equals(apiKey, key.getValue()))
                .noneMatch(ApiUserServiceImpl::isKeyValid);

        if (noneValidKey) {
            throw new SdwanUnauthorizedException(
                    "The API key is not valid because it is past its expiration date [apiKey='%s']".formatted(apiKey));
        }

        return apiUserMapper.toApiUserKeyResponseModel(apiUserResponseV1);
    }
}
