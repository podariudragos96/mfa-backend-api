package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.common.exceptions.exception.SdwanException;
import net.colt.sdwan.generated.model.service.CgwResponseV1;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.PolicyApiClient;
import net.colt.sdwan.portal.client.ServiceApiClient;
import net.colt.sdwan.portal.enums.StatName;
import net.colt.sdwan.portal.mappers.InterfaceResponseMapper;
import net.colt.sdwan.portal.model.CommandRequestModel;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.InterfaceResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.DeviceService;
import net.colt.sdwan.portal.services.InterfaceService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.DeviceResponseValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.generated.model.service.InterfaceResponseV1.InterfaceTypeEnum.STANDARD;
import static net.colt.sdwan.generated.model.service.InterfaceResponseV1.InterfaceTypeEnum.TUNNEL;
import static net.colt.sdwan.portal.constant.Constants.SLASH;
import static net.colt.sdwan.portal.util.CGWUtil.isCloudGateway;
import static net.colt.sdwan.portal.util.CGWUtil.isGateway;
import static net.colt.sdwan.portal.validator.IPAddressValidator.isIpv4;
import static net.colt.sdwan.portal.validator.IPAddressValidator.isIpv6;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

@Slf4j
@RequiredArgsConstructor
@Service
public class InterfaceServiceImpl implements InterfaceService {

    private final SitesService sitesService;
    private final DeviceService deviceService;
    private final ServiceApiClient serviceApiClient;
    private final InterfaceResponseMapper interfaceResponseMapper;
    private final DeviceResponseValidator deviceResponseValidator;
    private final PolicyApiClient policyApiClient;
    private final SiteResponseValidator siteResponseValidator;

    @Override
    public net.colt.sdwan.generated.model.service.InterfaceResponseV1 getApiInterfaceAndVerify(String interfaceId) {
        if (isNotEmpty(interfaceId)) {
            return serviceApiClient.getInterfaceById(Long.valueOf(interfaceId));
        }
        throw new SdwanBadRequestException("Empty interface id.");
    }

    @Override
    public net.colt.sdwan.generated.model.service.InterfaceResponseV1 getByDeviceIdAndInterfaceIdAndVerify(final String deviceId, final String interfaceId) {
        if (StringUtils.isBlank(deviceId) || StringUtils.isBlank(interfaceId)) {
            throw new SdwanBadRequestException("Received empty device or interface id.");
        }
        List<net.colt.sdwan.generated.model.service.InterfaceResponseV1> interfaceResponses = serviceApiClient.getInterfacesByDeviceId(deviceId);
        if (CollectionUtils.isEmpty(interfaceResponses)) {
            throw new SdwanBadRequestException(String.format("Did not find any interface for device id '%s'.", deviceId));
        }
        return interfaceResponses.stream()
                .filter(interfaceResponse -> interfaceResponse.getId().equals(Long.valueOf(interfaceId)))
                .findAny()
                .orElseThrow(() -> new SdwanBadRequestException(String.format("Interface details missing for interface id '%s'.", interfaceId)));
    }

    @Override
    public net.colt.sdwan.generated.model.service.InterfaceResponseV1 getByDeviceAndInterfaceIdAndVerify(final DeviceResponseV1 deviceResponse, String interfaceId) {
        if (CollectionUtils.isEmpty(deviceResponse.getInterfaces()) || StringUtils.isBlank(interfaceId)) {
            throw new SdwanBadRequestException("Device has no interfaces or interface id is blank.");
        }
        return deviceResponse.getInterfaces().stream()
                .filter(interfaceResponse -> interfaceResponse.getId().equals(Long.valueOf(interfaceId)))
                .findAny()
                .orElseThrow(() -> new SdwanBadRequestException(String.format("Interface id %s does not belong to device id %s details missing",
                        interfaceId, deviceResponse.getId())));
    }

    public Optional<net.colt.sdwan.generated.model.service.InterfaceResponseV1> filterInterfaceResponseFromSite(final SiteResponseV1 siteResponse, final String name) {
        if (CollectionUtils.isNotEmpty(siteResponse.getDevices())) {
            Optional<DeviceResponseV1> deviceResponse = siteResponse.getDevices().stream().findFirst();
            if (deviceResponse.isPresent()) {
                List<net.colt.sdwan.generated.model.service.InterfaceResponseV1> interfaceResponses = deviceResponse.get().getInterfaces();
                Optional<net.colt.sdwan.generated.model.service.InterfaceResponseV1> interfaceResponse = interfaceResponses.stream()
                        .filter(interfResp -> nonNull(interfResp.getNetwork()) ? interfResp.getNetwork().equals(name) : interfResp.getFriendlyName().equals(name))
                        .findFirst();
                if (interfaceResponse.isPresent()) {
                    return interfaceResponse;
                }
            }
        }
        return Optional.empty();
    }

    /**
     * Retrieve the interfaces by:
     *
     * @param siteId
     * @param deviceId
     * @return the mapped to InterfaceResponse model as list
     */
    @Override
    public List<InterfaceResponseV1> getInterfaceBySiteIdAndDeviceId(final String siteId, final String deviceId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        List<net.colt.sdwan.generated.model.service.InterfaceResponseV1> interfaceResponseList = serviceApiClient.getInterfacesByDeviceId(deviceId);
        if (isCloudGateway(siteResponse.getSiteType().getValue())) {
            Optional<CgwResponseV1> cgwResponseV1s = siteResponse.getCgw().stream().filter(cgw -> cgw.getCgwName().equals(deviceResponse.getResourceName())).findAny();

            if (cgwResponseV1s.isPresent()) {
                String interfaceName = cgwResponseV1s.get().getCgwInterfaceName();
                List<net.colt.sdwan.generated.model.service.InterfaceResponseV1> interfaces = interfaceResponseList.stream()
                        .filter(net.colt.sdwan.generated.model.service.InterfaceResponseV1::getIsWan)
                        .collect(Collectors.toList());
                interfaces.addAll(interfaceResponseList.stream()
                        .filter(item -> !item.getIsWan() && item.getName().equals(interfaceName))
                        .toList());

                return interfaceResponseMapper.fromList(interfaces);
            }

        }

        if (isGateway(siteResponse.getSiteType().getValue())) {
            final List<net.colt.sdwan.generated.model.service.InterfaceResponseV1> interfaces = interfaceResponseList.stream()
                    .filter(net.colt.sdwan.generated.model.service.InterfaceResponseV1::getIsWan)
                    .collect(Collectors.toList());

            interfaces.addAll(interfaceResponseList.stream()
                    .filter(item -> !item.getIsWan() && item.getVersaOrgName().equals(siteResponse.getNetworkId()))
                    .toList());

            return interfaceResponseMapper.fromList(interfaces);
        }
        if (CollectionUtils.isNotEmpty(interfaceResponseList)) {
            return interfaceResponseMapper.fromList(interfaceResponseList);
        }
        return Collections.emptyList();
    }

    /**
     * Retrieve the interfaces by:
     *
     * @param siteId
     * @param deviceId
     * @param interfaceId
     * @return the mapped to InterfaceResponse model
     */
    @Override
    public InterfaceResponseV1 getInterfaceBySiteIdAndDeviceIdAndInterfaceId(String siteId, String deviceId, String interfaceId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        deviceService.getFromSiteIfPresent(siteResponse, deviceId);
        return interfaceResponseMapper.mapToResponse(serviceApiClient.getInterfaceById(Long.valueOf(interfaceId)));
    }

    /**
     * Ping or traceroute by interface ip, target ip, src ip, site id and device id
     * 1. Get Site Response by provide site Id
     * 2. Throw error if site response doesn't contain devices or the expected device - call device service that will check and return if
     * a matching device is found in siteResponse devuce set
     * 3. Use validator: Throw error if requested interface is WAN and target IP version IPv6
     *
     * @param requestModel
     * @return the correlation id for this call
     * @throws SdwanException
     */
    @Override
    public CorrelationIdResponseV1 getPingOrTracerouteResponse(final CommandRequestModel requestModel)
            throws SdwanException {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(requestModel.getSiteId());
        final DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, requestModel.getDeviceId());
        deviceResponseValidator.validateDevice(deviceResponse);
        final net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse =
                getByDeviceIdAndInterfaceIdAndVerify(deviceResponse.getId().toString(), requestModel.getInterfaceId());
        requestModel.setVrf(interfaceResponse.getVrf());
        log.debug("Policy Api Executor has started");

        if (isNull(interfaceResponse.getDhcp()) || Boolean.FALSE.equals(interfaceResponse.getDhcp())) {
            if (!interfaceResponse.getInterfaceType().equals(TUNNEL)) {
                manageSrcIp(requestModel, interfaceResponse);
            } else if (Boolean.TRUE.equals(siteResponse.getSiteFeatures().getSase().getIsEnabled())) {
                final net.colt.sdwan.generated.model.service.InterfaceResponseV1 lanInterface = deviceResponse.getInterfaces()
                        .stream()
                        .filter(
                                i -> !i.getIsWan() && STANDARD.equals(i.getInterfaceType()) && i.getVrf()
                                        .equals(interfaceResponse.getVrf()))
                        .findFirst()
                        .orElseThrow(() -> new SdwanBadRequestException("No LAN vrf interface was found for device '%s'".formatted(deviceResponse.getResourceName())));

                manageSrcIp(requestModel, lanInterface);
            }
        }

        policyApiClient.getPingOrTracerouteInterface(requestModel, deviceResponse, siteResponse.getVersaInstance(), interfaceResponse);
        log.debug("Policy Api Executor has finished");
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    private void manageSrcIp(CommandRequestModel requestModel,
                             net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse) {
        if (isNotEmpty(requestModel.getTargetIP()) && isIpv6(requestModel.getTargetIP())) {
            requestModel.setSrcIp(mapSrcIp(interfaceResponse.getIpv6Address()));
        } else if (isNotEmpty(requestModel.getTargetIP()) && isIpv4(requestModel.getTargetIP())) {
            requestModel.setSrcIp(mapSrcIp(interfaceResponse.getIpv4Address()));
        }
    }

    @Override
    public CorrelationIdResponseV1 getShowInterfaceResponseBySiteIdAndDeviceIdAndInterfaceId(String siteId, String deviceId, String interfaceId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse = getByDeviceIdAndInterfaceIdAndVerify(deviceId, interfaceId);
        policyApiClient.getShowInterfaceV1(siteResponse, deviceResponse, interfaceResponse);
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    @Override
    public CorrelationIdResponseV1 getPppoeStatsResponseBySiteIdAndDeviceIdAndInterfaceId(String siteId, String deviceId, String interfaceId, String type) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        policyApiClient.getPppoeStatsV1(siteResponse, deviceResponse, type);
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    @Override
    public Optional<net.colt.sdwan.generated.model.service.InterfaceResponseV1> getInterfaceResponseFromSiteByName(SiteResponseV1 siteResponse, String name) {

        if (CollectionUtils.isNotEmpty(siteResponse.getDevices())) {
            List<DeviceResponseV1> devices = siteResponse.getDevices().stream().toList();
            List<net.colt.sdwan.generated.model.service.InterfaceResponseV1> interfaceResponses = new ArrayList<>();
            if (!devices.isEmpty()) {
                devices.forEach(device -> interfaceResponses.addAll(device.getInterfaces()));

                return interfaceResponses.stream()
                        .filter(interfResp -> interfResp.getName().equals(name))
                        .findAny();
            }
        }
        return Optional.empty();
    }


    private String mapSrcIp(final String ip) { // 1.2.3.4/21
        return ip.contains(SLASH) ? ip.substring(0, ip.indexOf(SLASH)) : ip;
    }

    /**
     * Call stats by:
     *
     * @param siteId
     * @param deviceId
     * @param interfaceId
     * @param statName
     * @return the correlation id for this call
     * @throws SdwanException
     */
    @Override
    public CorrelationIdResponseV1 getStatsBySiteIdAndDeviceIdAndInterfaceIdAndStatName(
            String siteId, String deviceId, String interfaceId, String statName) throws SdwanException {
        StatName.fromValueWithValidation(statName);
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteIfPresent(siteResponse, deviceId);
        this.getApiInterfaceAndVerify(interfaceId);
        deviceResponseValidator.validateDevice(deviceResponse);
        executePolicyApiCall(siteResponse, deviceResponse, interfaceId, statName);
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    /**
     * Update interface statistics by the given input parameters.
     *
     * @param siteId
     * @param deviceId
     * @param interfaceId
     * @param statName
     * @return a new correlation id for this
     */

    @Override
    public CorrelationIdResponseV1 updateStatsBySiteIdAndDeviceIdAndInterfaceIdAndStatName(
            String siteId, String deviceId, String interfaceId, String statName) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        if (!siteResponseValidator.isSiteLocked(siteResponse)) {
            throw new SdwanBadRequestException(String.format("Site with site id '%s' is not properly locked.", siteId));
        }
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteIfPresent(siteResponse, deviceId);
        deviceResponseValidator.validateDevice(deviceResponse);

        net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse = getApiInterfaceAndVerify(interfaceId);

        StatName statNameEnum = StatName.fromWithUpdateValidation(statName);
        policyApiClient.updateInterfaceStats(statNameEnum, siteResponse, deviceResponse, interfaceResponse.getVrf());
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }


    /**
     * Execute dynamic info by:
     *
     * @param siteId
     * @param deviceId
     * @param interfaceId
     * @return the correlation id for this call
     */
    @Override
    public CorrelationIdResponseV1 getInterfaceDynamicInfoBySiteIdAndDeviceIdAndInterfaceId(
            String siteId, String deviceId, String interfaceId) throws SdwanException {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteIfPresent(siteResponse, deviceId);
        this.getApiInterfaceAndVerify(interfaceId);
        deviceResponseValidator.validateDevice(deviceResponse);
        executePolicyApiCall(siteResponse, deviceResponse, interfaceId, null);
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    /**
     * Common api calls execution by:
     *
     * @param siteResponse
     * @param deviceResponse
     * @param interfaceId
     */
    private void executePolicyApiCall(final SiteResponseV1 siteResponse,
                                      final DeviceResponseV1 deviceResponse,
                                      final String interfaceId,
                                      final String statName) {
        net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse =
                serviceApiClient.getInterfaceById(Long.valueOf(interfaceId));
        if (nonNull(interfaceResponse)) {
            policyApiClient.getDynamicStats(deviceResponse, siteResponse, interfaceResponse, statName);
        } else {
            log.error("Null interface response from ServiceApi: could not execute policyApiCall: getDynamicStats {}", interfaceId);
        }
    }

}
