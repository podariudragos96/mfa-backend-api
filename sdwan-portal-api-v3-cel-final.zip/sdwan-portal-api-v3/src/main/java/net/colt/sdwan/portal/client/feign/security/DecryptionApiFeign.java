package net.colt.sdwan.portal.client.feign.security;

import net.colt.sdwan.security.api.generated.api.DecryptionApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "decryptionApiClient", url = "${sdwan.security.api.baseurl}",
        configuration = SecurityApiFeignConfiguration.class)
public interface DecryptionApiFeign extends DecryptionApiApi {
}
