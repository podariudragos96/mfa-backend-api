package net.colt.sdwan.portal.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum SystemState {

    ENABLED("enabled"),
    DISABLED("disabled");

    private final String name;
}
