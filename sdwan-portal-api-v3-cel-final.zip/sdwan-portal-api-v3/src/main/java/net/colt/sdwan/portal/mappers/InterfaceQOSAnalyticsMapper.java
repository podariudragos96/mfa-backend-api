package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.client.model.AnalyticsLabelEnum;
import net.colt.sdwan.portal.client.model.QOSAnalyticsMetricEnum;
import net.colt.sdwan.portal.client.model.QOSAnalyticsTimeSeries;
import net.colt.sdwan.portal.client.model.QOSAnalyticsTimeSeriesData;
import net.colt.sdwan.portal.model.*;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.*;

@Component
public class InterfaceQOSAnalyticsMapper extends CommonMapper {
    private static final List<QOSAnalyticsMetricEnum> qosMetrics = Arrays.stream(QOSAnalyticsMetricEnum.values()).toList();

    public Optional<InterfaceQOSAnalyticsTimeSeriesDataResponseV1> mapFromQOSApiResponse(List<QOSAnalyticsTimeSeriesData> analyticsTimeSeriesDataList,
                                                                                         final String deviceName, final String interfaceCircuitName) {
        analyticsTimeSeriesDataList = analyticsTimeSeriesDataList.stream()
                .filter(timeSeriesData -> Objects.nonNull(filterQOSTimeSeriesData(timeSeriesData, deviceName, interfaceCircuitName)))
                .toList();
        analyticsTimeSeriesDataList = mergeLabels(analyticsTimeSeriesDataList);
        Map<String, List<QOSAnalyticsTimeSeriesData>> map = new HashMap<>();
        analyticsTimeSeriesDataList.forEach(seriesData -> {
            if (map.containsKey(seriesData.getCircuitName())) {
                map.get(seriesData.getCircuitName()).add(seriesData);
            } else {
                map.put(seriesData.getCircuitName(), new ArrayList<>(Collections.singletonList(seriesData)));
            }
        });
        return map.keySet().stream()
                .map(key -> mapInterfaceAnalyticsTimeSeriesDataResponse(key, map.get(key))).findAny();
    }

    private QOSAnalyticsTimeSeriesData filterQOSTimeSeriesData(QOSAnalyticsTimeSeriesData timeSeriesData, final String deviceName, String interfaceCircuitName) {
        QOSAnalyticsTimeSeries analyticsTimeSeries = timeSeriesData.getAnalyticsTimeSeries();
        final String circuitName = timeSeriesData.getCircuitName();
        if (interfaceCircuitName.equalsIgnoreCase(circuitName) && !circuitName.contains(deviceName)
                && qosMetrics.contains(analyticsTimeSeries.getMetric())) {
            timeSeriesData.setCircuitName(circuitName.substring(circuitName.indexOf(",") + 1));
            return timeSeriesData;
        }
        return null;
    }

    private InterfaceQOSAnalyticsTimeSeriesDataResponseV1 mapInterfaceAnalyticsTimeSeriesDataResponse(String key, List<QOSAnalyticsTimeSeriesData> analyticsTimeSeriesData) {
        return new InterfaceQOSAnalyticsTimeSeriesDataResponseV1()
                .circuitName(key)
                .metrics(mapMetricList(analyticsTimeSeriesData.stream().map(QOSAnalyticsTimeSeriesData::getAnalyticsTimeSeries).toList())
                );
    }

    private List<InterfaceQOSAnalyticsTimeSeriesAnalyticsResponseV1> mapMetricList(List<QOSAnalyticsTimeSeries> analyticsTimeSeriesList) {
        return analyticsTimeSeriesList.stream().map(this::mapMetric).toList();
    }

    private InterfaceQOSAnalyticsTimeSeriesAnalyticsResponseV1 mapMetric(QOSAnalyticsTimeSeries seriesData) {
        return new InterfaceQOSAnalyticsTimeSeriesAnalyticsResponseV1()
                .label(mapLabelFromClientEnum(seriesData.getLabel()))
                .metric(mapMetricFromClientEnum(seriesData.getMetric()))
                .data(mapDataFromList(seriesData.getData()));
    }

    private AnalyticsLabelV1 mapLabelFromClientEnum(AnalyticsLabelEnum label) {
        if (Objects.nonNull(label)) {
            return AnalyticsLabelV1.fromValue(label.name());
        }
        return null;
    }

    private AnalyticsQOSMetricV1 mapMetricFromClientEnum(QOSAnalyticsMetricEnum label) {
        if (Objects.nonNull(label)) {
            return AnalyticsQOSMetricV1.fromValue(label.name());
        }
        return null;
    }

    private List<InterfaceAnalyticsDataResponseV1> mapDataFromList(List<List<BigDecimal>> data) {
        return data.stream()
                .map(list -> new InterfaceAnalyticsDataResponseV1()
                        .value(list.get(0) == null ? 0 : list.get(0).doubleValue())
                        .time(list.get(1).longValue()))
                .toList();
    }

    private List<QOSAnalyticsTimeSeriesData> mergeLabels(final List<QOSAnalyticsTimeSeriesData> analyticsTimeSeriesDataList) {
        Set<QOSAnalyticsTimeSeriesData> analyticsTimeSeriesDataSet = new HashSet<>(analyticsTimeSeriesDataList);
        analyticsTimeSeriesDataList.forEach(seriesData ->
                analyticsTimeSeriesDataSet.stream().filter(seriesDataFromSet -> seriesDataFromSet.equals(seriesData))
                        .filter(seriesDataFromSet -> seriesDataFromSet.getAnalyticsTimeSeries().getData().addAll(seriesData.getAnalyticsTimeSeries().getData()))
        );
        return new ArrayList<>(analyticsTimeSeriesDataSet);
    }
}
