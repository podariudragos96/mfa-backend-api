package net.colt.sdwan.portal.services;


import net.colt.sdwan.portal.model.SaseTenantResponseV1;

import java.util.Optional;

public interface SaseTenantService {

    Optional<SaseTenantResponseV1> getTenantV1(String networkId);

}
