package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.client.model.NatRuleResponse;
import net.colt.sdwan.portal.client.model.NatRuleSet;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.util.PortStringSerializer;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
public class NatRulesResponseMapper extends CommonMapper {

    public NatRulesResponseV1 mapFromNatRuleResponse(NatRuleResponse natRuleResponse) {
        final NatRulesResponseV1 natRulesResponse = new NatRulesResponseV1();
        if (Objects.nonNull(natRuleResponse)) {
            natRulesResponse.setRuleSet(mapFromNatRulesSetResponse(natRuleResponse.getNatRuleSet()));
        }
        return natRulesResponse;
    }

    public List<NatRuleSetResponseV1> mapFromNatRulesSetResponse(final List<NatRuleSet> natRuleSet) {
        List<NatRuleSetResponseV1> natRuleSetResponses = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(natRuleSet)) {
            natRuleSetResponses.addAll(
                    natRuleSet.stream()
                            .map(this::mapFromNatRulesResponse)
                            .toList());
        }
        return natRuleSetResponses;
    }

    public List<NatRuleHistoryResponseV1> mapFromNatRulesSetResponseV2(final List<NatRuleSet> natRuleSet) {
        List<NatRuleHistoryResponseV1> natRuleSetResponses = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(natRuleSet)) {
            natRuleSetResponses.addAll(
                    natRuleSet.stream()
                            .map(this::mapFromNatRulesResponseV2)
                            .toList());
        }
        return natRuleSetResponses;
    }

    public NatRuleHistoryResponseV1 mapFromNatRulesResponseV2(final NatRuleSet natRuleSet) {
        return new NatRuleHistoryResponseV1()
                .description(mapNullableString(natRuleSet.getDescription()))
                .updatedDt(mapStrToLocalDateTime(natRuleSet.getLastUpdated()))
                .updatedBy(natRuleSet.getUpdatedBy());
    }

    public NatRuleSetResponseV1 mapFromNatRulesResponse(final NatRuleSet natRuleSet) {
        return new NatRuleSetResponseV1()
                .description(mapNullableString(natRuleSet.getDescription()))
                .updatedDt(mapStrToLocalDateTime(natRuleSet.getLastUpdated()))
                .updatedBy(natRuleSet.getUpdatedBy())
                .destinationNatRules(mapDestinationsNatRuleResponsesFromList(natRuleSet.getDestinationNatRuleResponseList()))
                .staticNatRules(mapFromStaticNatRuleResponse(natRuleSet.getStaticNatRuleResponseList()));
    }

    private List<DestinationNatRuleResponseV1> mapDestinationsNatRuleResponsesFromList(final List<net.colt.sdwan.portal.client.model.DestinationNatRuleResponse> clientDestinationNatRuleResponse) {
        final List<DestinationNatRuleResponseV1> destinationNatRuleResponses = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(clientDestinationNatRuleResponse)) {
            destinationNatRuleResponses.addAll(
                    clientDestinationNatRuleResponse.stream()
                            .map(this::mapFromDestinationNatRuleResponse)
                            .toList());
        }
        return destinationNatRuleResponses;
    }

    private DestinationNatRuleResponseV1 mapFromDestinationNatRuleResponse(final net.colt.sdwan.portal.client.model.DestinationNatRuleResponse destinationNatRuleResponse) {
        return new DestinationNatRuleResponseV1()
                .name(mapNullableString(destinationNatRuleResponse.getName()))
                .description(mapNullableString(destinationNatRuleResponse.getDescription()))
                .sourceNetwork(destinationNatRuleResponse.getSourceNetwork())
                .destinationNetwork(destinationNatRuleResponse.getDestinationNetwork())
                .ip(mapFromIpList(destinationNatRuleResponse))
                .port(mapFromDestNatRuleRespone(destinationNatRuleResponse))
                .editable(mapNullableBoolean(destinationNatRuleResponse.getEditable()))
                .protocol(mapProtocol(destinationNatRuleResponse.getProtocol()))
                .precedence(mapNullableString(destinationNatRuleResponse.getPrecedence()));
    }

    private DestinationNatRuleResponseV1.ProtocolEnum mapProtocol(final String protocol) {
        if (StringUtils.isNotEmpty(protocol)) {
            return DestinationNatRuleResponseV1.ProtocolEnum.fromValue(protocol.toUpperCase());
        }
        return DestinationNatRuleResponseV1.ProtocolEnum.ANY;
    }

    private List<StaticNatRuleResponseV1> mapFromStaticNatRuleResponse(final List<net.colt.sdwan.portal.client.model.StaticNatRuleResponse> clientStaticNatRuleResponse) {
        final List<StaticNatRuleResponseV1> staticNatRuleResponses = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(clientStaticNatRuleResponse)) {
            staticNatRuleResponses.addAll(
                    clientStaticNatRuleResponse.stream()
                            .map(this::mapFromStaticNatRuleResponse)
                            .toList());
        }
        return staticNatRuleResponses;
    }

    private StaticNatRuleResponseV1 mapFromStaticNatRuleResponse(final net.colt.sdwan.portal.client.model.StaticNatRuleResponse staticNatRuleResponse) {
        return new StaticNatRuleResponseV1()
                .name(staticNatRuleResponse.getName())
                .description(mapNullableString(staticNatRuleResponse.getDescription()))
                .ip(mapIpFromStaticNatRuleResponse(staticNatRuleResponse))
                .sourceNetwork(staticNatRuleResponse.getSourceNetwork())
                .destinationNetwork(staticNatRuleResponse.getDestinationNetwork())
                .editable(mapNullableBoolean(staticNatRuleResponse.getEditable()))
                .precedence(mapNullableString(staticNatRuleResponse.getPrecedence()));
    }

    private DestinationNatPortResponseV1 mapFromDestNatRuleRespone(final net.colt.sdwan.portal.client.model.DestinationNatRuleResponse destinationNatRuleResponse) {
        if (StringUtils.isNotBlank(destinationNatRuleResponse.getPublicPort())
                && StringUtils.isNotBlank(destinationNatRuleResponse.getPrivatePort())) {
            return new DestinationNatPortResponseV1()
                    .nat(PortStringSerializer.fromString(destinationNatRuleResponse.getPublicPort()))
                    .lan(PortStringSerializer.fromString(destinationNatRuleResponse.getPrivatePort()));
        }
        return null;
    }

    private DestinationNatIPResponseV1 mapFromIpList(final net.colt.sdwan.portal.client.model.DestinationNatRuleResponse destinationNatRuleResponse) {
        return new DestinationNatIPResponseV1()
                .nat(getIp(destinationNatRuleResponse.getNatIps()))
                .lan(getIp(destinationNatRuleResponse.getPrivateIps()));
    }


    private StaticNatIPResponseV1 mapIpFromStaticNatRuleResponse(final net.colt.sdwan.portal.client.model.StaticNatRuleResponse staticNatRuleResponse) {
        return new StaticNatIPResponseV1()
                .lan(getIp(staticNatRuleResponse.getPrivateIps()))
                .nat(getIp(staticNatRuleResponse.getNatIps()))
                .restrictedRemote(getIp(staticNatRuleResponse.getRestrictedRemoteIps()));
    }

    private String getIp(final List<String> ips) {
        String ip = null;
        if (CollectionUtils.isNotEmpty(ips)) {
            ip = ips.get(0);
        }
        return ip;
    }
}

