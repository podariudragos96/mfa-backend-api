package net.colt.sdwan.portal.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SecureLogForwardingConstants {

    public static final String THREAT_FEATURE_AVAILABLE_ON_BRANCH_SITES = "Secure Log Forwarding is only available for sites of type branch";

}
