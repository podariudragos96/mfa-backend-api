package net.colt.sdwan.portal.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum RoutingStatsType {
    route("route"),
    neighbor("neighbor"),
    statistics("statistics");

    private final String name;
}
