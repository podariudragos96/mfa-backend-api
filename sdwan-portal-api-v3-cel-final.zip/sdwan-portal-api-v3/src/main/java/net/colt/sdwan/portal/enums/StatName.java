package net.colt.sdwan.portal.enums;

import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;

import java.util.Arrays;

public enum StatName {
    ARP("arp"),
    //    ROUTE("route"),
//    NEIGHBOR("neighbour"),
//    STATISTICS("statistics"),
//    TX("tx"),
    RXTX("rxtx");

    private String value;

    StatName(String value) {
        this.value = value;
    }

    public static StatName fromValueWithValidation(final String value) {
        return Arrays.asList(StatName.values()).stream()
                .filter(e -> e.getValue().equalsIgnoreCase(value))
                .findFirst()
                .orElseThrow(() -> new SdwanNotFoundException("Invalid stat name: " + value));
    }

    public static StatName fromWithUpdateValidation(final String value) {
        return Arrays.asList(StatName.ARP)
                .stream().filter(e -> e.getValue().equalsIgnoreCase(value)).findFirst()
                .orElseThrow(() -> new SdwanNotFoundException("Invalid stat name: " + value));
    }

    public String getValue() {
        return this.value;
    }
}
