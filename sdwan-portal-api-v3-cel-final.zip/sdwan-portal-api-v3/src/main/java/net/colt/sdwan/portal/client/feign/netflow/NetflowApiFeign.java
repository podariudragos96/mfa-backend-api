package net.colt.sdwan.portal.client.feign.netflow;

import net.colt.sdwan.netflow.ipfix.api.generated.api.NetflowIpfixApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "netflowApiClient", url = "${sdwan.netflow.api.baseurl}",
        configuration = NetflowApiFeignFeignConfiguration.class)
public interface NetflowApiFeign extends NetflowIpfixApiApi {
}
