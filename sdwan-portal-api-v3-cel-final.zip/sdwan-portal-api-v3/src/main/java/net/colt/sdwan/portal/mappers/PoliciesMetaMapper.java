package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.metadata.api.generated.model.DnsProxyPatternV1;
import net.colt.sdwan.portal.model.MetaQueryPatternsPortalV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
@Component
public class PoliciesMetaMapper {

    private final ModelMapper modelMapper;

    public List<MetaQueryPatternsPortalV1> mapQueryPatternsResponseList(List<DnsProxyPatternV1> queryPatterns) {
        List<MetaQueryPatternsPortalV1> result = new ArrayList<>();
        for (DnsProxyPatternV1 metaOperatingSystemsV1 : queryPatterns) {
            result.add(modelMapper.map(metaOperatingSystemsV1, MetaQueryPatternsPortalV1.class));
        }
        return result;
    }
}
