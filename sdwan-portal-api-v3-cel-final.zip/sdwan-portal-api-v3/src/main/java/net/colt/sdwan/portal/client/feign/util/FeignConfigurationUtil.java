package net.colt.sdwan.portal.client.feign.util;

import feign.RequestTemplate;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import net.colt.sdwan.portal.security.AuthUserHelper;

import static net.colt.sdwan.portal.constant.Constants.*;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class FeignConfigurationUtil {

    public static RequestTemplate getRequestUri(RequestTemplate template) {
        return template
                .uri(getVersaInstance(template.feignTarget().url()).concat(SLASH_API).concat(template.url()))
                .header(X_VERSA_DIRECTOR_ID, AuthUserHelper.getAuthUser().getVersaInstance());
    }

    private static String getVersaInstance(String url) {
        if (url.contains("localhost") || url.contains("127.0.0.1")) {

            return "";
        }

        return SLASH + AuthUserHelper.getAuthUser().getVersaInstance();
    }
}
