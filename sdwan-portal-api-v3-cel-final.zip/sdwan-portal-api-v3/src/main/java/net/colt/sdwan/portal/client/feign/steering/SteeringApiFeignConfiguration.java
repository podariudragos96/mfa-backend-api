package net.colt.sdwan.portal.client.feign.steering;

import feign.RequestInterceptor;
import feign.auth.BasicAuthRequestInterceptor;
import net.colt.sdwan.portal.client.feign.util.FeignConfigurationUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

public class SteeringApiFeignConfiguration {

    protected String username;
    protected String password;

    public SteeringApiFeignConfiguration(
            @Value("${sdwan.steering.api.user}") String username,
            @Value("${sdwan.steering.api.pwd}") String password) {
        this.username = username;
        this.password = password;
    }

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        return new BasicAuthRequestInterceptor(username, password);
    }

    @Bean
    public RequestInterceptor requestUriInterceptor() {
        return FeignConfigurationUtil::getRequestUri;
    }
}
