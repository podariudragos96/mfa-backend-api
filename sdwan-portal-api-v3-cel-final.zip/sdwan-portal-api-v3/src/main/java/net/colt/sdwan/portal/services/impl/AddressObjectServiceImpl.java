package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.feign.sitesettings.CustomObjectApiFeign;
import net.colt.sdwan.portal.mappers.AddressObjectMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.AddressObjectService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.portal.validator.access.CustomObjectValidator;
import net.colt.sdwan.sitesettings.api.generated.model.AddressesResponseApiV1;
import org.slf4j.MDC;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import static java.lang.Integer.parseInt;
import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;


@Slf4j
@RequiredArgsConstructor
@Service
public class AddressObjectServiceImpl implements AddressObjectService {

    private final SitesService sitesService;
    private final ResponseEntityValidator responseEntityValidator;
    private final AddressObjectMapper addressObjectMapper;
    private final CustomObjectApiFeign customObjectApiFeign;
    private final SiteResponseValidator siteResponseValidator;
    public static final String UPDATE_ADDRESS_OBJECT = "customObjectApiFeign.updateAddressV1";

    @Override
    public AddressesResponseV1 getAddressesV1(String siteId, AddressObjectCriteria criteria, Integer pageNumber, Integer pageSize) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        CustomObjectValidator.validateAccess(siteResponse);
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        final ResponseEntity<AddressesResponseApiV1> response =
                customObjectApiFeign.getAddressV1(parseInt(siteId),
                        siteResponse.getNetworkId(),
                        addressObjectMapper.from(criteria),
                        addressObjectMapper.from(siteResponse.getSiteType()),
                        pageNumber, pageSize, Pageable.unpaged());
        return addressObjectMapper.from(response.getBody());
    }

    @Override
    public CorrelationIdResponseV1 updateAddressV1(String siteId, AddressesRequestV1 addressesRequestV1) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        CustomObjectValidator.validateAccess(siteResponse);
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        try {
            sitesService.updateOngoingAction(siteId, OnGoingActionV2.MODIFYING_ADDRESS_OBJECTS);
            final ResponseEntity<Void> responseEntity = customObjectApiFeign.updateAddressV1(
                    Integer.valueOf(siteId), siteResponse.getNetworkId(), AuthUserHelper.getAuthUser().getUsername(),
                    addressObjectMapper.from(siteResponse.getSiteType()), sitesService.getDeviceNamesFromSiteResponse(siteResponse),
                    addressObjectMapper.from(addressesRequestV1));
            responseEntityValidator.checkResponseEntity(responseEntity, UPDATE_ADDRESS_OBJECT);
        } catch (Exception ex) {
            log.error("Failed to updateAddressV1 for siteId='{}'.", siteId, ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }

        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }
}
