package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.SiteExportCriteria;
import net.colt.sdwan.portal.model.SupportedLanguageV1;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;

public interface SiteExportService {

    public ResponseEntity<Resource> exportSite(String accept,
                                               SupportedLanguageV1 acceptLanguage,
                                               SiteExportCriteria siteExportCriteria);
}
