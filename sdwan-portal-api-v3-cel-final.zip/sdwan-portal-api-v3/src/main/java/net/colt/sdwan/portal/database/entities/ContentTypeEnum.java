package net.colt.sdwan.portal.database.entities;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum ContentTypeEnum {
    HTML("HTML"),

    PDF("PDF"),
    DOCS("DOCS"),
    MARKDOWN("MARKDOWN");

    private String value;

    ContentTypeEnum(String value) {
        this.value = value;
    }

    @JsonCreator
    public static ContentTypeEnum fromValue(String text) {
        for (ContentTypeEnum b : ContentTypeEnum.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        throw new IllegalArgumentException("Unexpected value '" + text + "'");
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }
}
