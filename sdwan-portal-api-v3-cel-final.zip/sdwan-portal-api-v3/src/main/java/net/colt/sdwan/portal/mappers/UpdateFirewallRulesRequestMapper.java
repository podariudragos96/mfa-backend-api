package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.model.service.InterfaceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.model.FirewallRule;
import net.colt.sdwan.portal.client.model.FirewallRules;
import net.colt.sdwan.portal.client.model.FwAction;
import net.colt.sdwan.portal.enums.Direction;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.validator.FirewallRulesValidator;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;

import static net.colt.sdwan.portal.enums.FirewallRuleDirection.INBOUND;
import static net.colt.sdwan.portal.enums.FirewallRuleDirection.OUTBOUND;
import static net.colt.sdwan.portal.util.PortStringSerializer.toCSV;

@RequiredArgsConstructor
@Component
public class UpdateFirewallRulesRequestMapper extends SecurityCommonMapper {

    private final FirewallRulesValidator firewallRulesValidator;

    public FirewallRules mapFromFirewallRulesRequestV1(final FirewallRulesRequestV2 firewallRulesRequest, final SiteResponseV1 siteResponse, final InterfaceResponseV1 interfaceResponse) {
        final FirewallRules rules = new FirewallRules();
        rules.setCustomer(siteResponse.getNetworkId());
        rules.setSiteId(String.valueOf(siteResponse.getId()));
        rules.setLastUpdated(LocalDateTime.now(ZoneOffset.UTC).toString());
        rules.setUpdatedBy(AuthUserHelper.getAuthUser().getUsername());
        rules.setDescription(firewallRulesRequest.getRuleSet().get(0).getDescription());
        rules.setSdwanEnabled(firewallRulesRequest.getRuleSet().get(0).getSdwanFwEnabled());
        List<FirewallRule> firewallRules = firewallRulesRequest.getRuleSet().get(0).getRules()
                .stream()
                .map(fwRule -> mapFromFirewallRuleRequestV1(fwRule, siteResponse, interfaceResponse)).toList();
        rules.setFwRules(firewallRules);
        return rules;
    }

    private FirewallRule mapFromFirewallRuleRequestV1(final FirewallRuleRequestV2 fwRule, final SiteResponseV1 siteResponse, final InterfaceResponseV1 interfaceResponse) {
        final FirewallRule firewallRule = new FirewallRule();

        firewallRule.setAction(FwAction.valueOf(fwRule.getAction().name().toLowerCase()));

        firewallRule.setPriority(fwRule.getPriority());
        if (Objects.nonNull(fwRule.getAddressConfiguration())) {
            firewallRule.setSourceIp(Optional.ofNullable(fwRule.getAddressConfiguration().getSource()).map(NetworkAddressV1::getIps).map(ArrayList::new).orElseGet(ArrayList::new));
            firewallRule.setDestinationIp(Optional.ofNullable(fwRule.getAddressConfiguration().getDestination()).map(NetworkAddressV1::getIps).map(ArrayList::new).orElseGet(ArrayList::new));
        }
        if (Objects.nonNull(fwRule.getServiceConfiguration())) {
            firewallRule.setSourcePort(toCSV(fwRule.getServiceConfiguration().getSourcePort()));
            firewallRule.setDestinationPort(toCSV(fwRule.getServiceConfiguration().getDestinationPort()));
            if (fwRule.getServiceConfiguration().getType().equals(NetworkConfigTypeV1.MANUAL)) {
                firewallRule.setProtocol(mapProtocol(fwRule.getServiceConfiguration().getProtocol()));
            }
        }
        firewallRule.setSourceNetwork(constructNetworkString(fwRule.getSourceNetwork()));
        firewallRule.setDestinationNetwork(constructNetworkString(fwRule.getDestinationNetwork()));
        firewallRule.setLoggingEvent(fwRule.getLogging().toString());
        firewallRule.setRuleEnabled(fwRule.getEnabled());
        if (CollectionUtils.isEmpty(fwRule.getApplication())) {
            firewallRule.setApplications(null);
        } else {
            firewallRule.setApplications(fwRule.getApplication());
        }

        firewallRule.setActivations(null);
        final boolean isUserDefinedCGWRule = firewallRulesValidator.isNotCloudGatewayDefaultRuleV1(
                fwRule, siteResponse.getSiteType().getValue());
        generateSourceZoneV1(isUserDefinedCGWRule, fwRule, firewallRule, interfaceResponse);
        firewallRule.setName(fwRule.getName());
        firewallRule.setDescription(fwRule.getDescription());
        firewallRule.setAntivirusProfile(fwRule.getAntivirusProfile());
        firewallRule.setUrlFilteringProfile(fwRule.getUrlFilteringProfile());
        firewallRule.setPredefinedIpsProfile(fwRule.getPredefinedIpsProfile());
        firewallRule.setPredefinedIpsProfileOverride(fwRule.getPredefinedIpsProfileOverride());
        firewallRule.setUserDefinedIpsProfile(fwRule.getUserDefinedIpsProfile());
        firewallRule.setIpFilteringProfile(fwRule.getIpFilteringProfile());
        return firewallRule;
    }

    private void generateSourceZoneV1(final boolean isUserDefinedCGWRule, final FirewallRuleRequestV2 fwRule, final FirewallRule firewallRule, final InterfaceResponseV1 interfaceResponse) {

        final Direction direction = getDirection(fwRule.getSourceNetwork(), fwRule.getDestinationNetwork());

        if (isUserDefinedCGWRule && Objects.nonNull(direction)) {
            if (INBOUND.getName().equalsIgnoreCase(direction.name())) {
                firewallRule.setSourceZone(Collections.singletonList(interfaceResponse.getZone()));
                firewallRule.setDestinationZone(Collections.emptyList());
            }
            if (OUTBOUND.getName().equalsIgnoreCase(direction.name())) {
                firewallRule.setSourceZone(Collections.emptyList());
                firewallRule.setDestinationZone(Collections.singletonList(interfaceResponse.getZone()));
            }
        }
    }

    private String mapProtocol(final FirewallProtocol protocolEnum) {
        String protocol = "";
        if (!protocolEnum.equals(FirewallProtocol.ANY)) {
            protocol = protocolEnum.name();
        }
        return protocol;
    }
}
