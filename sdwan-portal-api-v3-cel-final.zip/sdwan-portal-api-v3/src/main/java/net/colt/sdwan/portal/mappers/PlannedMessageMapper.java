package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.model.PlannedMessageCriteriaV1;
import net.colt.sdwan.portal.model.PlannedMessagesResponseV1;
import net.colt.sdwan.system.api.generated.model.PlannedMessageCriteriaApiV1;
import net.colt.sdwan.system.api.generated.model.PlannedMessagesResponseApiV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class PlannedMessageMapper {

    private final ModelMapper modelMapper;

    public PlannedMessageCriteriaApiV1 map(PlannedMessageCriteriaV1 criteria) {
        return modelMapper.map(criteria, PlannedMessageCriteriaApiV1.class);
    }

    public PlannedMessagesResponseV1 map(PlannedMessagesResponseApiV1 response) {
        return modelMapper.map(response, PlannedMessagesResponseV1.class);
    }
}
