package net.colt.sdwan.portal.security;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.enums.COLTRoles;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.ColtOnlineAuthService;
import net.colt.sdwan.session.api.generated.model.SdwanSessionResponseV1;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;

import static net.colt.sdwan.portal.mappers.UserModelMapper.mapAuthUserFromApiUserResponseV1;
import static net.colt.sdwan.portal.mappers.UserModelMapper.mapAuthUserFromSessionResponseV1;

@RequiredArgsConstructor
@Component("customAuthenticationProvider")
public class CustomAuthenticationProvider implements AuthenticationProvider {

    private final ColtOnlineAuthService coltOnlineAuthService;

    @Override
    public Authentication authenticate(Authentication authentication) {
        UserAuth userAuth = coltOnlineAuthService.accessUserAuthorities(authentication.getName());
        return new UsernamePasswordAuthenticationToken(userAuth, "", userAuth.getRoles());
    }

    @Override
    public boolean supports(Class<?> arg0) {
        return true;
    }

    public Authentication createSecurityContext(SdwanSessionResponseV1 sessionResponseV1) {
        final UserAuth userAuth = mapAuthUserFromSessionResponseV1(sessionResponseV1.getSession().getUserInfo());
        Collection<? extends GrantedAuthority> authorities = userAuth.getRoles();
        final Authentication authentication = new UsernamePasswordAuthenticationToken(userAuth, "", authorities);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        return authentication;
    }

    public Authentication createApiUSerSecurityContext(String userAgent, List<Integer> tenantIds) {
        final UserAuth userAuth = mapAuthUserFromApiUserResponseV1(userAgent,
                List.of(COLTRoles.SD_WAN_READ_WRITE_ROLE.value(), COLTRoles.SD_WAN_READ_WRITE_FIREWALL.value()), tenantIds);
        Collection<? extends GrantedAuthority> authorities = userAuth.getRoles();
        final Authentication authentication = new UsernamePasswordAuthenticationToken(userAuth, "", authorities);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        return authentication;
    }

}
