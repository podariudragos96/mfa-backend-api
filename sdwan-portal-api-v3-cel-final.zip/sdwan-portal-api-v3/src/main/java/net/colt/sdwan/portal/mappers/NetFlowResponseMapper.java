package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.netflow.ipfix.api.generated.model.NetflowResponseApiV1;
import net.colt.sdwan.portal.model.NetFlowResponseV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@RequiredArgsConstructor
@Component
public class NetFlowResponseMapper {

    private final ModelMapper modelMapper;

    public NetFlowResponseV1 mapNetFlowResponseV1(NetflowResponseApiV1 netflowResponseV1) {
        return modelMapper.map(netflowResponseV1, NetFlowResponseV1.class);
    }
}