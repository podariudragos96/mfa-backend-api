package net.colt.sdwan.portal.client.feign.service;

import net.colt.sdwan.generated.controller.service.SiteApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "serviceApiSiteClient", url = "${sdwan.service.api.base.url}", configuration = ServiceFeignConfiguration.class)
public interface ServiceApiSiteFeign extends SiteApi {

}