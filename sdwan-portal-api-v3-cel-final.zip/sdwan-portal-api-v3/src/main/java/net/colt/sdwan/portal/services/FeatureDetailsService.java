package net.colt.sdwan.portal.services;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface FeatureDetailsService {

    List<String> findFeatureFlags(List<Integer> tenantIds);

    Map<Long, List<String>> getTenantsFeatureFlags(Set<Long> tenantIds);

}
