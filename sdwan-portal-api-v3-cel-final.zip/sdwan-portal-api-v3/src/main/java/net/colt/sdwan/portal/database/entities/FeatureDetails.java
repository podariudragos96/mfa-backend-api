package net.colt.sdwan.portal.database.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * @author Nasir
 * <p>
 * This domain class defines features specific to tenant.
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "FEATURE_FLAG_DETAILS")
public class FeatureDetails {

    @Id
    @GeneratedValue
    @Column(name = "ID")
    private Integer id;

    @Column(name = "TENANT_ID")
    private Integer tenantId;

    @Column(name = "FEATURE_NAME")
    private String featureName;

    @Column(name = "FEATURE_FLAG")
    private String featureFlag;
}
