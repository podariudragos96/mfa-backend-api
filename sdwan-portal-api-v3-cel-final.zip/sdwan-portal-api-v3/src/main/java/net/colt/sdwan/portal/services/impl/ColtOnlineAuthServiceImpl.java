package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.common.exceptions.exception.SdwanForbiddenException;
import net.colt.sdwan.portal.client.model.customerapi.CustomerSummaryResponseV1;
import net.colt.sdwan.portal.client.model.customerapi.UserResponseV3;
import net.colt.sdwan.portal.client.webservice.UserServicesWebserviceClient;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.ColtOnlineAuthService;
import net.colt.sdwan.portal.services.CustomerService;
import net.colt.sdwan.portal.services.UserService;
import net.colt.sdwan.portal.util.XColtHostUtil;
import net.colt.sdwan.portal.validator.NovitasAccessRoleValidator;
import net.colt.xml.ns.cum.v1.UserType;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.util.List;

import static java.util.Objects.nonNull;
import static org.apache.commons.collections4.CollectionUtils.isEmpty;
import static org.apache.commons.collections4.CollectionUtils.isNotEmpty;
import static org.apache.commons.lang3.StringUtils.isEmpty;

/**
 * This class is mainly use to promote the Authentication in SD-WAN Portal via API Key for PROD env.
 */
@Service
@RequiredArgsConstructor
@Slf4j
@ConditionalOnProperty(name = "colt-online.webservice.auth.enabled", havingValue = "true")
public class ColtOnlineAuthServiceImpl implements ColtOnlineAuthService {

    private final UserServicesWebserviceClient userServicesWebserviceClient;
    private final XColtHostUtil xColtHostUtil;
    private final UserService userService;
    private final CustomerService customerService;

    /**
     * Step 1. Authenticate user into the colt online platform
     * Step 2. Check if the user has the needed roles to access resources
     * Step 3. Handle the user customer OCN authorization use cases
     *
     * @return the SecurityCheck result
     */
    @Override
    public UserResponseV3 doAuthentication(String username, String password) {
        userServicesWebserviceClient.authenticate(username, password);
        final UserType userType = userServicesWebserviceClient.getUserType(username);

        log.info("Check for authorisation for authenticated Colt Online user: {}", username);
        List<String> ocns = userService.collectOcnList(userType);

        try {
            NovitasAccessRoleValidator.hasNovitasAccessRole(userType);
            List<String> validatedOcns = validateCustomerOcn(username, ocns);
            ocns = ocns.stream()
                    .filter(validatedOcns::contains)
                    .toList();

        } catch (AccessDeniedException ex) {
            throw new SdwanForbiddenException(
                    "No Access Role for user type '%s' and ocns '%s' while authenticating to Colt Online Webservice."
                            .formatted(userType, ocns), ex);

        } catch (SdwanBadRequestException ex) {
            throw new SdwanBadRequestException(
                    "An error has occurred when validating Access Role for user type '%s' and ocns '%s' while authenticating to Colt Online Webservice."
                            .formatted(userType, ocns), ex);
        }

        final UserResponseV3 user = userService.getUserByUsernameAndDomain(username, xColtHostUtil.getDefaultDomain());

        if (nonNull(user)) {
            userService.updateExistingUser(user, userType.getUserRoles().getRoleName(), ocns);

            final UserResponseV3 result = userService.getUserById(user.getUserId());
            // Add domain that is required for later use
            if (isEmpty(result.getDomain())) {
                result.setDomain(xColtHostUtil.getDefaultDomain());
            }
            // Add feature flags for auth purposes
            result.setFeatures(user.getFeatures());
            return result;

        } else {
            return userService.createUser(userType, ocns);
        }
    }

    private List<String> validateCustomerOcn(String userName, List<String> ocns) {
        List<CustomerSummaryResponseV1> customers = customerService.findAllByOcnList(ocns);

        if (isEmpty(customers)) {
            log.debug("No valid OCN found: {}", userName);
            throw new SdwanBadRequestException("No OCN found.");
        }

        return customers.stream()
                .map(CustomerSummaryResponseV1::getOcn)
                .toList();
    }


    /**
     * Retrieve the user roles from colt online and map them to spring security roles
     *
     * @return @authUser having the roles
     */
    @Override
    public UserAuth accessUserAuthorities(final String username) {
        final UserAuth userAuth = UserAuth.builder()
                .username(username)
                .build();

        final UserType userType = userServicesWebserviceClient.getUserType(username);

        if (nonNull(userType.getUserRoles())
                && isNotEmpty(userType.getUserRoles().getRoleName())) {

            userType.getUserRoles()
                    .getRoleName()
                    .forEach(userAuth::addNewRole);
        }

        return userAuth;
    }

}
