package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SecureAccessClientProfilesRequestV1;
import net.colt.sdwan.portal.model.SecureAccessClientProfilesResponseV1;

public interface SaseSecureAccessClientProfileService {

    SecureAccessClientProfilesResponseV1 getSecureAccessClientProfilesV1(String tenantUuid);

    CorrelationIdResponseV1 updateSecureAccessClientProfilesV1(String tenantUuid, SecureAccessClientProfilesRequestV1 secureAccessClientProfilesRequestV1);

}
