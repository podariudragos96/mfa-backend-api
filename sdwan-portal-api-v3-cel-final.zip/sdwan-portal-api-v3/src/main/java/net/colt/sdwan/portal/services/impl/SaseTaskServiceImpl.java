package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.versa.sase.api.TaskResponseApiV1;
import net.colt.sdwan.generated.model.versa.sase.api.TasksResponseApiV1;
import net.colt.sdwan.portal.client.feign.sase.SaseTaskFeign;
import net.colt.sdwan.portal.enums.SaseOperation;
import net.colt.sdwan.portal.mappers.SaseTaskMapper;
import net.colt.sdwan.portal.model.SaseTaskResponseV1;
import net.colt.sdwan.portal.model.SaseTasksResponseV1;
import net.colt.sdwan.portal.services.SaseTaskService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class SaseTaskServiceImpl implements SaseTaskService {

    private final SaseTaskFeign saseTaskFeign;
    private final SaseTaskMapper saseTaskMapper;
    private final ResponseEntityValidator responseEntityValidator;

    @Override
    public SaseTasksResponseV1 getTasksV1(String tenantUuid, Integer pageNumber, Integer pageSize) {
        log.info("Getting sase tasks via sase api for tenantUuid={}, pageNumber={}, pageSize={}", tenantUuid, pageNumber, pageSize);

        final ResponseEntity<TasksResponseApiV1> response = saseTaskFeign.getTasksV1(tenantUuid, pageNumber, pageSize);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.TASKS_GET.getName());

        log.info("Get sase tasks request completed successfully for tenantUuid={}.", tenantUuid);
        return saseTaskMapper.from(response.getBody());
    }

    @Override
    public SaseTaskResponseV1 getTaskV1(String tenantUuid, String taskUuid) {
        log.info("Getting sase task via sase api for tenantUuid={}, taskUuid={}", tenantUuid, taskUuid);

        final ResponseEntity<TaskResponseApiV1> response = saseTaskFeign.getTaskV1(tenantUuid, taskUuid);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.TASK_GET.getName());

        log.info("Get sase task request completed successfully for tenantUuid={}.", tenantUuid);
        return saseTaskMapper.from(response.getBody());
    }
}
