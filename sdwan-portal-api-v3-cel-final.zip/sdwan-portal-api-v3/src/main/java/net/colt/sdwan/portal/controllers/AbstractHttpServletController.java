package net.colt.sdwan.portal.controllers;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

import java.util.Objects;

@RequiredArgsConstructor
public abstract class AbstractHttpServletController {

    protected final HttpServletRequest request;

    protected String getHeaderValue(String headerName) {
        String value = null;
        if (Objects.nonNull(request)) {
            value = request.getHeader(headerName);
        }
        return value;
    }
}
