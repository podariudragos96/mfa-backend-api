package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.AnalyticsApiApi;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.services.AnalyticsService;
import net.colt.sdwan.portal.services.NetworksService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;
import java.util.List;

@RequiredArgsConstructor
@Controller
public class AnalyticsController implements AnalyticsApiApi {

    private final AnalyticsService analyticsService;
    private final NetworksService networksService;

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<DdosAnalyticsTimeSeriesResponseV1> getDdosAnalyticsTimeSeriesBySiteIdV1(
            String siteId,
            @RequestParam(value = "start_dt")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt) {
        return ResponseEntity.ok(analyticsService.getDdosAnalyticsTimeSeriesBySiteId(siteId, startDt, endDt));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<InterfaceAnalyticsTimeSeriesDataResponseV1> getInterfaceAnalyticsBySiteIdAndDeviceIdAndInterfaceIdV1(
            String siteId,
            String deviceId,
            String interfaceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt,
            @RequestParam(value = "metrics", required = false) List<AnalyticsMetricV1> metrics) {
        InterfaceAnalyticsTimeSeriesDataResponseV2 respV2 = analyticsService.getInterfaceAnalyticsBySiteIdAndDeviceIdAndInterfaceId(siteId, deviceId, interfaceId, startDt, endDt);
        InterfaceAnalyticsTimeSeriesDataResponseV1 respV1 = new InterfaceAnalyticsTimeSeriesDataResponseV1()
                .circuitName(respV2.getCircuitName());
        if (!CollectionUtils.isEmpty(respV2.getZones())) {
            respV1.setMetrics(respV2.getZones().get(0).getMetrics());
        }
        return ResponseEntity.ok(respV1);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<InterfaceAnalyticsTimeSeriesDataResponseV2> getInterfaceAnalyticsBySiteIdAndDeviceIdAndInterfaceIdV2(
            String siteId,
            String deviceId,
            String interfaceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt,
            @RequestParam(value = "metrics", required = false) List<AnalyticsMetricV1> metrics) {
        return ResponseEntity.ok(analyticsService.getInterfaceAnalyticsBySiteIdAndDeviceIdAndInterfaceId(
                siteId, deviceId, interfaceId, startDt, endDt));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<InterfaceAnalyticsTableDataResponseV1> getInterfaceAnalyticsTabularFormatBySiteIdAndDeviceIdAndInterfaceIdV1(
            String siteId,
            String deviceId,
            String interfaceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt) {
        return ResponseEntity.ok(analyticsService.getInterfaceAnalyticsTabularFormatBySiteIdAndDeviceIdV1(siteId, deviceId, interfaceId, startDt, endDt));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<InterfaceQOSAnalyticsTimeSeriesDataResponseV1> getInterfaceQosAnalyticsBySiteIdAndDeviceIdAndInterfaceIdV1(
            String siteId,
            String deviceId,
            String interfaceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt,
            @RequestParam(value = "metrics", required = false) List<AnalyticsQOSMetricV1> metrics
    ) {
        return ResponseEntity.ok(analyticsService.getInterfaceQOSAnalyticsBySiteIdAndDeviceIdAndInterfaceId(siteId, deviceId, interfaceId, startDt, endDt));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<InterfaceApplicationAnalyticsResponseV1>
    getInterfaceApplicationAnalyticsBySiteIdAndDeviceIdAndInterfaceIdV1(
            String siteId,
            String deviceId,
            String interfaceId,
            @RequestParam(value = "start_dt")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt,
            @RequestParam(value = "count", required = false) Integer count,
            @RequestParam(value = "applications", required = false) List<String> applications) {
        return ResponseEntity.ok(
                analyticsService.getInterfaceApplicationAnalyticsBySiteIdAndDeviceIdAndInterfaceId(
                        siteId, deviceId, interfaceId, startDt, endDt, count, applications));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<InterfaceApplicationAnalyticsTableResponseV1>
    getInterfaceApplicationAnalyticsTabularFormatBySiteIdAndDeviceIdAndInterfaceIdV1(
            String siteId,
            String deviceId,
            String interfaceId,
            @RequestParam(value = "start_dt")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt,
            @RequestParam(value = "count", required = false) Integer count,
            @RequestParam(value = "applications", required = false) List<String> applications) {
        return ResponseEntity.ok(
                analyticsService.getInterfaceApplicationAnalyticsTabularFormatBySiteIdAndDeviceIdAndInterfaceId(
                        siteId, deviceId, interfaceId, startDt, endDt, count, applications));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<FirewallAnalyticsRuleNameResponseV1>> getFirewallAnalyticsByRuleNameV1(
            String ruleName,
            String networkId,
            @RequestParam(value = "action", defaultValue = "null") FirewallRulesActionV1 action,
            @RequestParam(value = "start_dt")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt) {
        return ResponseEntity.ok(networksService.getFirewallAnalyticsByRuleName(ruleName, networkId, action, startDt, endDt));
    }

    @Override
    public ResponseEntity<SlaMetricsTimeSeriesDataResponseV1> getSlaMetricsTimeSeriesBySiteIdAndDeviceIdV1(
            String siteId,
            String deviceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate,
            @RequestParam(value = "remote_device_id", required = false) String remoteDeviceId,
            @RequestParam(value = "interface_id", required = false) String interfaceId,
            @RequestParam(value = "count", required = false) Integer count
    ) {

        return ResponseEntity.ok(analyticsService.getSlaMetricsTimeSeriesBySiteIdAndDeviceId(siteId, deviceId, startDate, endDate, remoteDeviceId, interfaceId, count));
    }

    @Override
    public ResponseEntity<SlaMetricsTableDataResponseV1> getSlaMetricsTableDataBySiteIdAndDeviceIdV1(
            String siteId,
            String deviceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate,
            @RequestParam(value = "remote_device_id", required = false) String remoteDeviceId,
            @RequestParam(value = "interface_id", required = false) String interfaceId,
            @RequestParam(value = "count", required = false) Integer count
    ) {
        return ResponseEntity.ok(analyticsService.getSlaMetricsTableDataBySiteIdAndDeviceId(siteId, deviceId, startDate, endDate, remoteDeviceId, interfaceId, count));
    }

    @Override
    public ResponseEntity<FirewallRulesAnalyticsTableDataResponseV1> getFirewallRulesAnalyticsTableDataByNetworkIdV1(
            String networkId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate,
            @RequestParam(value = "device_id", required = false) String deviceId,
            @RequestParam(value = "count", required = false) Integer count
    ) {
        return ResponseEntity.ok(analyticsService.getFirewallRulesAnalyticsTableDataByNetworkId(networkId, startDate, endDate, deviceId, count));
    }

    @Override
    public ResponseEntity<FirewallZonesAnalyticsTableDataResponseV1> getFirewallZonesAnalyticsTableDataByNetworkIdV1(
            String networkId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt,
            @RequestParam(value = "device_id", required = false) String deviceId,
            @RequestParam(value = "count", required = false) Integer count) {
        return ResponseEntity.ok(analyticsService.getFirewallZonesAnalyticsTableDataByNetworkId(networkId, startDt, endDt, deviceId, count));
    }

    @Override
    public ResponseEntity<FirewallRulesAnalyticsTimeSeriesDataResponseV1> getFirewallRulesAnalyticsTimeSeriesByNetworkIdV1(
            String networkId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate,
            @RequestParam(value = "device_id", required = false) String deviceId,
            @RequestParam(value = "count", required = false) Integer count
    ) {
        return ResponseEntity.ok(analyticsService.getFirewallRulesAnalyticsTimeSeriesByNetworkId(networkId, startDate, endDate, deviceId, count));
    }

    @Override
    public ResponseEntity<FirewallZonesAnalyticsTimeSeriesDataResponseV1> getFirewallZonesAnalyticsTimeSeriesByNetworkIdV1(
            String networkId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt,
            @RequestParam(value = "device_id", required = false) String deviceId,
            @RequestParam(value = "count", required = false) Integer count) {
        return ResponseEntity.ok(analyticsService.getFirewallZonesAnalyticsTimeSeriesByNetworkId(networkId, startDt, endDt, deviceId, count));
    }

    @Override
    public ResponseEntity<TopUsageResponseV1> getTopAccessCircuitsByNetworkIdV1(
            String networkId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate,
            @RequestParam(value = "count", required = false) Integer count
    ) {
        return ResponseEntity.ok(analyticsService.getTopAccessCircuitsByNetworkId(networkId, startDate, endDate, count));
    }

    @Override
    public ResponseEntity<TopUsageResponseV1> getTopDevicesByNetworkIdV1(
            String networkId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate,
            @RequestParam(value = "count", required = false) Integer count
    ) {
        return ResponseEntity.ok(analyticsService.getTopDevicesByNetworkId(networkId, startDate, endDate, count));
    }

    @Override
    public ResponseEntity<UsageByPathAnalyticsTableDataResponseV1> getUsageByPathAnalyticsTableDataBySiteIdAndDeviceIdV1(
            String siteId,
            String deviceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate,
            @RequestParam(value = "remote_device_id", required = false) String remoteDeviceId,
            @RequestParam(value = "interface_id", required = false) String interfaceId,
            @RequestParam(value = "count", required = false) Integer count
    ) {
        return ResponseEntity.ok(analyticsService.getUsageByPathAnalyticsTableDataBySiteIdAndDeviceId(siteId, deviceId, startDate, endDate, remoteDeviceId, interfaceId, count));
    }

    @Override
    public ResponseEntity<UsageByPathAnalyticsTimeSeriesDataResponseV1> getUsageByPathAnalyticsTimeSeriesBySiteIdAndDeviceIdV1(
            String siteId,
            String deviceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate,
            @RequestParam(value = "remote_device_id", required = false) String remoteDeviceId,
            @RequestParam(value = "interface_id", required = false) String interfaceId,
            @RequestParam(value = "count", required = false) Integer count
    ) {
        return ResponseEntity.ok(analyticsService.getUsageByPathAnalyticsTimeSeriesBySiteIdAndDeviceId(siteId, deviceId, startDate, endDate, remoteDeviceId, interfaceId, count));
    }

    @Override
    public ResponseEntity<UsersAnalyticsTableDataResponseV1> getUsersAnalyticsTableDataBySiteIdAndDeviceIdV1(
            String siteId,
            String deviceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate,
            @RequestParam(value = "interface_id", required = false) String interfaceId,
            @RequestParam(value = "count", required = false) Integer count
    ) {
        return ResponseEntity.ok(analyticsService.getUsersAnalyticsTableDataBySiteIdAndDeviceId(siteId, deviceId, startDate, endDate, interfaceId, count));
    }

    @Override
    public ResponseEntity<UsersAnalyticsTimeSeriesDataResponseV1> getUsersAnalyticsTimeSeriesBySiteIdAndDeviceIdV1(
            String siteId,
            String deviceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate,
            @RequestParam(value = "interface_id", required = false) String interfaceId,
            @RequestParam(value = "count", required = false) Integer count
    ) {
        return ResponseEntity.ok(analyticsService.getUsersAnalyticsTimeSeriesBySiteIdAndDeviceId(siteId, deviceId, startDate, endDate, interfaceId, count));
    }

    @Override
    public ResponseEntity<List<AntivirusDetectionEventResponseV1>> getAntivirusDetectionEventsV1(
            String siteId,
            String deviceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate,
            @RequestParam(value = "count", required = false) Integer count) {

        return ResponseEntity.ok(analyticsService.getAntivirusDetectionEvents(siteId, deviceId, startDate, endDate, count));

    }

    @Override
    public ResponseEntity<List<SystemAnalyticsTimeSeriesResponseV1>> getSystemAnalyticsTimeSeriesBySiteIdV1(
            String siteId,
            String deviceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt) {
        return ResponseEntity.ok(analyticsService.getSystemTimeSeriesAnalytics(siteId, deviceId, startDt, endDt));

    }

    @Override
    public ResponseEntity<List<VulnerabilityDetectionEventResponseV1>> getVulnerabilityDetectionEventsV1(
            String siteId,
            String deviceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt,
            @RequestParam(value = "count", required = false) Integer count) {
        return ResponseEntity.ok(analyticsService.getVulnerabilityDetectionEvents
                (siteId, deviceId, startDt, endDt, count));
    }

    @Override
    public ResponseEntity<List<IPFilteringDetectionEventResponseV1>> getIpFilteringDetectionEventsV1(
            String siteId,
            String deviceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt,
            @RequestParam(value = "count", required = false) Integer count) {
        return ResponseEntity.ok(analyticsService.getIpFilteringDetectionEvents
                (siteId, deviceId, startDt, endDt, count));
    }

    @Override
    public ResponseEntity<VrfTimeSeriesAnalyticsResponseV1> getVrfTimeSeriesAnalyticsV1(
            String siteId,
            String deviceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt,
            @RequestParam(value = "interface_id", required = false) String interfaceId,
            @RequestParam(value = "count", required = false) Integer count) {
        return ResponseEntity.ok(analyticsService.getVrfTimeSeriesAnalytics(siteId, deviceId, startDt, endDt, interfaceId, count));
    }

    @Override
    public ResponseEntity<VrfTableDataAnalyticsResponseV1> getVrfTableDataAnalyticsV1(
            String siteId,
            String deviceId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt,
            @RequestParam(value = "interface_id", required = false) String interfaceId,
            @RequestParam(value = "count", required = false) Integer count) {
        return ResponseEntity.ok(analyticsService.getVrfTableDataAnalytics(siteId, deviceId, startDt, endDt, interfaceId, count));
    }
}
