package net.colt.sdwan.portal.client.feign.security;

import net.colt.sdwan.security.api.generated.api.AntivirusApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "antivirusApiClient", url = "${sdwan.security.api.baseurl}",
        configuration = SecurityApiFeignConfiguration.class)
public interface AntivirusProfilesApiFeign extends AntivirusApiApi {
}
