package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class FirewallRulesNamesData {
    @JsonProperty("name")
    private String name;

    @JsonProperty("type")
    private String type;

    @JsonProperty("metric")
    private String metric;

    @JsonProperty("metricName")
    private String metricName;


    @JsonProperty("label")
    private String label;

    @JsonProperty("data")
    private List<List<Long>> data;
}
