package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicationAnalytics {

    @JsonProperty("device")
    private String device;

    @JsonProperty("interface")
    private String interfaceValue;

    @JsonProperty("start")
    private String start;

    @JsonProperty("end")
    private String end;

    @JsonProperty("sessions")
    private List<NameData> sessions;

    @JsonProperty("volume-rx")
    private List<NameData> volumeRx;

    @JsonProperty("volume-tx")
    private List<NameData> volumeTx;

    @JsonProperty("bw-rx")
    private List<NameData> bwRx;

    @JsonProperty("bw-tx")
    private List<NameData> bwTx;

}
