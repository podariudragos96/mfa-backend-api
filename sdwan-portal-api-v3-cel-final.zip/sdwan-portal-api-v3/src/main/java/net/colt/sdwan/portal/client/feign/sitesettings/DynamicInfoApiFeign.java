package net.colt.sdwan.portal.client.feign.sitesettings;

import net.colt.sdwan.sitesettings.api.generated.api.DynamicApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "dynamicInfoApiClient",
        url = "${sdwan.site.settings.api.baseurl}",
        configuration = SiteSettingsApiFeignConfiguration.class)
public interface DynamicInfoApiFeign extends DynamicApiApi {
}
