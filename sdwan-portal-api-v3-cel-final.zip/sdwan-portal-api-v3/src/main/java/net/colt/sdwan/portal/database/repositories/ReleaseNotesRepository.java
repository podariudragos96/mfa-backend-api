package net.colt.sdwan.portal.database.repositories;

import net.colt.sdwan.portal.database.entities.ReleaseNotes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReleaseNotesRepository extends JpaRepository<ReleaseNotes, Integer> {

    ReleaseNotes findTopByOrderByReleaseDate();
}
