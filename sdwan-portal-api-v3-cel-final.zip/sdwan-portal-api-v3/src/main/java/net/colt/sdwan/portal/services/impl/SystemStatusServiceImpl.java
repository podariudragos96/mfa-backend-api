package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.database.repositories.SystemStatusRepository;
import net.colt.sdwan.portal.enums.NovitasSystemStatus;
import net.colt.sdwan.portal.enums.SystemState;
import net.colt.sdwan.portal.model.SystemStatus;
import net.colt.sdwan.portal.services.SystemStatusService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class SystemStatusServiceImpl implements SystemStatusService {

    private final SystemStatusRepository systemStatusRepository;

    public List<SystemStatus> findByActiveSystemStatuses() {
        return systemStatusRepository.findByStatus(NovitasSystemStatus.ACTIVE);
    }

    /**
     * Check is system module is enabled by:
     *
     * @param module
     * @return true if enabled/false otherwise
     */
    public boolean isSystemModuleDisabled(String module) {
        SystemStatus systemStatus = systemStatusRepository.findByModuleAndStatus(module, NovitasSystemStatus.ACTIVE);
        return Objects.nonNull(systemStatus) && SystemState.DISABLED.equals(systemStatus.getState());
    }
}
