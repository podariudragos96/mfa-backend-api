package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.client.model.FWRuleLogEvents;
import net.colt.sdwan.portal.model.FirewallRuleLogsResponseV1;
import net.colt.sdwan.portal.model.SpecificNetworkAddressResponseV1;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import static net.colt.sdwan.portal.util.LocalDateTimeOperations.mapTimestamp;

@Component
public class FirewallRuleLogsResponseMappers extends CommonMapper {

    public List<FirewallRuleLogsResponseV1> mapFrom(final List<FWRuleLogEvents> fwRuleLogEvents) {
        List<FirewallRuleLogsResponseV1> firewallRuleLogsResponses = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(fwRuleLogEvents)) {
            firewallRuleLogsResponses = fwRuleLogEvents.stream()
                    .map(this::mapFromLogEvent)
                    .toList();
            firewallRuleLogsResponses = firewallRuleLogsResponses.stream()
                    .sorted(
                            Comparator.comparing(FirewallRuleLogsResponseV1::getTimestamp, Comparator.nullsLast(Comparator.naturalOrder())))
                    .toList();
        }
        return firewallRuleLogsResponses;
    }

    private FirewallRuleLogsResponseV1 mapFromLogEvent(final FWRuleLogEvents fwRuleLogEvents) {
        return new FirewallRuleLogsResponseV1()
                .action(mapActionFromString(fwRuleLogEvents.getAction()))
                .type(mapTypeFromString(fwRuleLogEvents.getType()))
                .timestamp(mapTimestamp(fwRuleLogEvents.getTimestamp()))
                .device(fwRuleLogEvents.getDevice())
                .protocol(mapProtocolFromString(fwRuleLogEvents.getProtocol()))
                .source(mapSourceNetworkAddressFromLogEvent(fwRuleLogEvents))
                .destination(mapDestinationNetworkAddressFromLogEvent(fwRuleLogEvents));
    }

    private FirewallRuleLogsResponseV1.ActionEnum mapActionFromString(final String action) {
        if (StringUtils.isNotEmpty(action)) {
            return FirewallRuleLogsResponseV1.ActionEnum.valueOf(action.toUpperCase());
        }
        return null;
    }

    private FirewallRuleLogsResponseV1.TypeEnum mapTypeFromString(final String type) {
        if (StringUtils.isNotEmpty(type)) {
            return FirewallRuleLogsResponseV1.TypeEnum.fromValue(type.toUpperCase());
        }
        return null;
    }

    private FirewallRuleLogsResponseV1.ProtocolEnum mapProtocolFromString(final String protocol) {
        if (StringUtils.isNotEmpty(protocol)) {
            return FirewallRuleLogsResponseV1.ProtocolEnum.fromValue(protocol.toUpperCase());
        }
        return null;
    }

    private SpecificNetworkAddressResponseV1 mapSourceNetworkAddressFromLogEvent(final FWRuleLogEvents fwRuleLogEvents) {
        return new SpecificNetworkAddressResponseV1().ip(fwRuleLogEvents.getSrcIP()).port(fwRuleLogEvents.getSrcPort().toString());
    }

    private SpecificNetworkAddressResponseV1 mapDestinationNetworkAddressFromLogEvent(final FWRuleLogEvents fwRuleLogEvents) {
        return new SpecificNetworkAddressResponseV1().ip(fwRuleLogEvents.getDstIP()).port(fwRuleLogEvents.getDstPort().toString());
    }
}
