package net.colt.sdwan.portal.services;

import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.DeviceResponseV1;

import java.util.List;

public interface DeviceService {

    net.colt.sdwan.generated.model.service.DeviceResponseV1 getApiDeviceAndVerify(final String deviceId);

    net.colt.sdwan.generated.model.service.DeviceResponseV1 getFromSiteIfPresent(final SiteResponseV1 siteResponse, final String deviceId);

    net.colt.sdwan.generated.model.service.DeviceResponseV1 getFromSiteAndValidate(final SiteResponseV1 siteResponse, final String deviceId);

    DeviceResponseV1 getSiteDeviceBySiteIdAndDeviceId(String siteId, String deviceId);

    List<DeviceResponseV1> getSiteDevicesBySiteId(String serviceId);

    List<net.colt.sdwan.generated.model.service.DeviceResponseV1> getApiDevicesFromSiteToDeviceList(final String siteId);

    CorrelationIdResponseV1 getExtensiveMOSSessionsResponseBySiteIdAndDeviceIdV1(String siteId, String deviceId);

    net.colt.sdwan.generated.model.service.DeviceResponseV1 getPrimaryDeviceFromSite(final SiteResponseV1 siteResponse);

    CorrelationIdResponseV1 getSiteDeviceDynamicInfoBySiteIdAndDeviceId(String siteId, String deviceId);
}
