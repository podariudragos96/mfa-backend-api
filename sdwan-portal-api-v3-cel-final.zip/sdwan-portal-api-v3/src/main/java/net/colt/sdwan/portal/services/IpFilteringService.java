package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.IPFilteringLogsResponseV1;
import net.colt.sdwan.portal.model.IPFilteringProfilesRequestV1;
import net.colt.sdwan.portal.model.IPFilteringProfilesResponseV1;

import java.util.List;

public interface IpFilteringService {

    IPFilteringProfilesResponseV1 getIpFilteringProfilesV1(String siteId);

    CorrelationIdResponseV1 updateIpFilteringProfilesV1(String siteId, IPFilteringProfilesRequestV1 ipFilteringProfilesRequestV1);

    List<IPFilteringLogsResponseV1> getIpFilteringProfileLogsV1(String siteId);
}
