package net.colt.sdwan.portal.controllers;

import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.SnmpApiApi;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SnmpRequestV1;
import net.colt.sdwan.portal.model.SnmpResponseV1;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.SnmpService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
@RequiredArgsConstructor
public class SnmpController implements SnmpApiApi {

    private final SnmpService snmpService;

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole', 'SD-WANReadWriteRole')")
    public ResponseEntity<SnmpResponseV1> getSnmpV1(String siteId) {
        return ResponseEntity.ok(snmpService.getSnmpV1(siteId));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/snmp")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateSnmpV1(String siteId,
                                                                @ApiParam(value = "Snmp request object to update snmp details") @RequestBody SnmpRequestV1 snmpRequestV1) {
        return ResponseEntity.ok(snmpService.updateSnmpV1(siteId, snmpRequestV1));
    }
}
