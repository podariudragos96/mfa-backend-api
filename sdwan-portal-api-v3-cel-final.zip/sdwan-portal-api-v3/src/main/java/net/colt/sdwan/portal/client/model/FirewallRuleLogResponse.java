package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FirewallRuleLogResponse {

    @JsonProperty("site")
    private String site;

    @JsonProperty("rule")
    private String rule;

    @JsonProperty("customer_rule_name")
    private String customerRuleName;

    @JsonProperty("start")
    private String start;

    @JsonProperty("end")
    private String end;

    @JsonProperty("events")
    private List<FWRuleLogEvents> events;
}
