package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@Builder
@AllArgsConstructor
public class DDoSRuleSetHistory {

    @JsonProperty("customer")
    private String customer;

    @JsonProperty("site")
    private String siteId;

    @JsonProperty("logger_type")
    private String loggerType;

    @Valid
    @NotNull(message = "ddos_rule_set can't be null.")
    @Size(min = 0, max = 1000, message = "Minimum and Maximum limit for ddos_rule_set is 1 to 1000.")
    @JsonProperty("ddos_rule_set")
    private List<DDoSRuleSet> ddosrulesSet;
}
