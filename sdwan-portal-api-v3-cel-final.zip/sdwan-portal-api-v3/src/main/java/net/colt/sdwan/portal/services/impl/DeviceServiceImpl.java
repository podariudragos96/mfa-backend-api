package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.PolicyApiClient;
import net.colt.sdwan.portal.client.ServiceApiClient;
import net.colt.sdwan.portal.client.feign.sitesettings.DynamicInfoApiFeign;
import net.colt.sdwan.portal.constant.DynamicInfoConstants;
import net.colt.sdwan.portal.mappers.DeviceResponseMapper;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.DeviceResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.DeviceService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;

@Service
@Slf4j
@RequiredArgsConstructor
public class DeviceServiceImpl implements DeviceService {

    private final ServiceApiClient serviceApiClient;
    private final DeviceResponseMapper deviceResponseMapper;
    private final SitesService sitesService;
    private final PolicyApiClient policyApiClient;
    private final DynamicInfoApiFeign dynamicInfoApiFeign;
    private final ResponseEntityValidator responseEntityValidator;


    /**
     * Get the dive from service api and throw an exception if it is not found/the device id is empty.
     *
     * @param deviceId
     * @return
     */
    @Override
    public net.colt.sdwan.generated.model.service.DeviceResponseV1 getApiDeviceAndVerify(String deviceId) {
        if (StringUtils.isNotEmpty(deviceId)) {
            return serviceApiClient.getDeviceDetailsById(deviceId);
        }
        throw new SdwanBadRequestException("Empty device id.");
    }

    /**
     * Try to search the device id in the gives ssite response, if not found, make a request to service for retrieving it.
     *
     * @param siteResponse
     * @param deviceId
     * @return
     */
    @Override
    public net.colt.sdwan.generated.model.service.DeviceResponseV1 getFromSiteIfPresent(final SiteResponseV1 siteResponse, final String deviceId) {
        if (StringUtils.isEmpty(deviceId)) {
            throw new SdwanBadRequestException("Empty device id.");
        }
        return siteResponse.getDevices().stream()
                .filter(device -> deviceId.equals(String.valueOf(device.getId())))
                .findFirst()
                .orElseGet(() -> getApiDeviceAndVerify(deviceId));
    }

    @Override
    public net.colt.sdwan.generated.model.service.DeviceResponseV1 getFromSiteAndValidate(final SiteResponseV1 siteResponse, final String deviceId) {
        if (CollectionUtils.isEmpty(siteResponse.getDevices())) {
            throw new SdwanBadRequestException(String.format("The site  with the id '%s' has an empty device set.", siteResponse.getId()));
        }
        return siteResponse.getDevices().stream()
                .filter(device -> deviceId.equals(String.valueOf(device.getId())))
                .findAny()
                .orElseThrow(() -> new SdwanBadRequestException(String.format("The device id '%s' is not mapped to the requested site id '%s'.",
                        deviceId, siteResponse.getId()))
                );
    }

    /**
     * Retrieve the device details by site id and device id from Service Api.
     *
     * @param siteId
     * @param deviceId
     * @return the device details
     */
    @Override
    public DeviceResponseV1 getSiteDeviceBySiteIdAndDeviceId(final String siteId, final String deviceId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        return deviceResponseMapper.mapToResponse(
                serviceApiClient.getDeviceDetailsById(deviceId), siteResponse.getCgw(), siteResponse.getSiteType().getValue(), siteResponse.getNetworkId());
    }

    /**
     * Retrieve the devices related to the input Service ID from Service Api.
     *
     * @param siteId site unique identifier
     * @return the ACTIVE devices list
     */
    @Override
    public List<DeviceResponseV1> getSiteDevicesBySiteId(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        return deviceResponseMapper.mapToResponseList(siteResponse);
    }

    /**
     * Retrieve the Devices from Service Api by siteId
     *
     * @param siteId
     * @return the list of client devices
     */
    @Override
    public List<net.colt.sdwan.generated.model.service.DeviceResponseV1> getApiDevicesFromSiteToDeviceList(final String siteId) {
        SiteResponseV1 site = serviceApiClient.getSiteDetailsById(siteId);
        return site.getDevices();
    }

    @Override
    public CorrelationIdResponseV1 getExtensiveMOSSessionsResponseBySiteIdAndDeviceIdV1(String siteId, String deviceId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        net.colt.sdwan.generated.model.service.DeviceResponseV1 deviceResponse = getFromSiteAndValidate(siteResponse, deviceId);
        policyApiClient.getExtensiveMOSSessions(deviceResponse, siteResponse);
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    /**
     * Retrieve the primary device from Site's device set
     *
     * @param siteResponse site response
     * @return primary device if Site is dual CPE or single device
     */
    @Override
    public net.colt.sdwan.generated.model.service.DeviceResponseV1 getPrimaryDeviceFromSite(SiteResponseV1 siteResponse) {
        final List<net.colt.sdwan.generated.model.service.DeviceResponseV1> devices = siteResponse.getDevices();

        if (CollectionUtils.isEmpty(devices)) {
            throw new SdwanBadRequestException(String.format("The site '%s' has empty device set.", siteResponse.getId()));
        }

        final boolean isDualCPE = siteResponse.getIsDualSite();

        if (isDualCPE) {
            final net.colt.sdwan.generated.model.service.DeviceResponseV1 deviceResponse = devices.stream()
                    .filter(device -> Objects.nonNull(device.getIsPrimary()) && device.getIsPrimary())
                    .findFirst()
                    .orElseThrow(() -> new SdwanBadRequestException(String.format("Failed to get primary device to site id '%s'.", siteResponse.getId())));

            log.debug("Site has dual CPE, and the primary device is {}.", deviceResponse.getId());
            return deviceResponse;
        }
        final net.colt.sdwan.generated.model.service.DeviceResponseV1 deviceResponse = devices.stream()
                .findFirst()
                .orElseThrow(() -> new SdwanBadRequestException(String.format("Failed to get device to site '%s'.", siteResponse.getId())));

        log.debug("Site has only one device {}.", deviceResponse.getId());
        return deviceResponse;
    }

    @Override
    public CorrelationIdResponseV1 getSiteDeviceDynamicInfoBySiteIdAndDeviceId(String siteId, String deviceId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        net.colt.sdwan.generated.model.service.DeviceResponseV1 deviceResponse = getFromSiteAndValidate(siteResponse, deviceId);

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        final ResponseEntity<Void> dynamicInfoResponseEntity = dynamicInfoApiFeign.getDynamicInfoV1(
                AuthUserHelper.getAuthUser().getUsername(),
                siteResponse.getNetworkId(),
                Integer.valueOf(siteId),
                deviceResponse.getResourceName());
        responseEntityValidator.checkResponseEntity(dynamicInfoResponseEntity, DynamicInfoConstants.DYNAMIC_INFO_FEATURE_NAME);

        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }
}
