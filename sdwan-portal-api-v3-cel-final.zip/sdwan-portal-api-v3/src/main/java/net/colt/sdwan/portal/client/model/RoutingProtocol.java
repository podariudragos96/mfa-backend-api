package net.colt.sdwan.portal.client.model;

public enum RoutingProtocol {

    STATIC("static"), OSPF("ospf"), BGP("bgp"), NEIGHBOR("neighbor"), STATISTICS("statistics");

    private final String value;

    RoutingProtocol(String v) {
        value = v;
    }

    public String getValue() {
        return value;
    }

}
