package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.model.*;
import net.colt.sdwan.portal.model.DdosRuleRequestV1;
import net.colt.sdwan.portal.model.DdosRuleSetRequestV1;
import net.colt.sdwan.portal.model.DdosRulesRequestV1;
import net.colt.sdwan.portal.model.FloodProtectionResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.validator.IPAddressValidator;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static net.colt.sdwan.portal.util.PortStringSerializer.toCSV;

@Component
public class UpdateDDoSRuleSetHistoryMapper {

    public DDoSRuleSetHistory mapFromDDoSRulesRequest(final DdosRulesRequestV1 ddosRulesRequest, final SiteResponseV1 siteResponse) {
        return DDoSRuleSetHistory.builder()
                .customer(siteResponse.getNetworkId())
                .siteId(siteResponse.getId().toString())
                .loggerType(siteResponse.getSiteFeatures().getSecurity().getLogging().getLoggingType())
                .ddosrulesSet(ddosRulesRequest.getRuleSet().stream()
                        .map(this::mapFromDDoSRuleSetRequest)
                        .toList())
                .build();
    }

    private DDoSRuleSet mapFromDDoSRuleSetRequest(DdosRuleSetRequestV1 ddosRules) {
        return DDoSRuleSet.builder()
                .lastUpdated(LocalDateTime.now(ZoneOffset.UTC).toString())
                .updatedBy(AuthUserHelper.getAuthUser().getUsername())
                .description(ddosRules.getDescription())
                .ddosRuleList(ddosRules.getRules().stream()
                        .map(this::mapFromDDoSRuleList)
                        .toList())
                .build();

    }

    private DDoSRule mapFromDDoSRuleList(DdosRuleRequestV1 ddosRules) {
        return DDoSRule.builder()
                .action(DDoSRule.Action.PROTECTED)
                .name(ddosRules.getName())
                .description(ddosRules.getDescription())
                .protocol(FloodProtocol.fromValue(ddosRules.getServiceConfiguration().getProtocol().getValue()))
                .destinationPort(toCSV(ddosRules.getServiceConfiguration().getDestinationPort()))
                .destinationIp(mapIpsWithValidation(new ArrayList<>(ddosRules.getAddressConfiguration().getDestination().getIps())))
                .sourceIp(mapIpsWithValidation(new ArrayList<>(ddosRules.getAddressConfiguration().getSource().getIps())))
                .logging(ddosRules.getLogging())
                .ruleEnabled(ddosRules.getEnabled())
                .thresholds(mapFromFloodProtectionResponse(ddosRules.getFloodProtection()))
                .sourceNegate(false)
                .build();
    }

    private List<String> mapIpsWithValidation(final List<String> ips) {
        if (CollectionUtils.isNotEmpty(ips)) {
            IPAddressValidator.validIpList(ips);
        }
        return ips;
    }

    private DDoSRuleThresholds mapFromFloodProtectionResponse(final FloodProtectionResponseV1 floodProtectionResponse) {
        DDoSRuleThresholds thresholds = DDoSRuleThresholds.builder().build();
        if (Objects.nonNull(floodProtectionResponse)) {
            thresholds = DDoSRuleThresholds.builder()
                    .activateRate(floodProtectionResponse.getActivateRate())
                    .alarmRate(floodProtectionResponse.getAlarmRate())
                    .dropPeriod(floodProtectionResponse.getDropPeriod())
                    .maximalRate(floodProtectionResponse.getMaximalRate())
                    .build();
        }
        return thresholds;
    }
}
