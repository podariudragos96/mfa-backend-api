package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class SslCertificateRequest {
    @JsonProperty("common_name")
    private String commonName;

    @JsonProperty("email_address")
    private String emailAddress;

    @JsonProperty("country_name")
    private String countryName;

    @JsonProperty("state_or_province_name")
    private String stateOrProvinceName;

    @JsonProperty("locality_name")
    private String localityName;

    @JsonProperty("organization_name")
    private String organizationName;

    @JsonProperty("organization_unit_name")
    private String organizationUnitName;

    @JsonProperty("private_key_length")
    private Integer privateKeyLength;

    @JsonProperty("days_valid")
    private Integer daysValid;
}
