package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.NetFlowHistoryResponseV1;
import net.colt.sdwan.portal.model.NetFlowRequestV1;
import net.colt.sdwan.portal.model.NetFlowResponseV1;

import java.util.List;

public interface NetFlowService {

    NetFlowResponseV1 getNetflowRuleSetV1(String siteId);

    List<NetFlowHistoryResponseV1> getNetflowRulesHistoryV2(String siteId);

    NetFlowResponseV1 getNetflowRulesHistoryByIdV1(String siteId, String ruleSetId);

    CorrelationIdResponseV1 getNetflowRulesStatisticsV1(String siteId, String deviceId, Integer collectorNumber);

    NetFlowResponseV1 rediscoverByNetworkIdAndSiteIdAndDeviceIdV1(String siteId, String networkId, String deviceId);

    CorrelationIdResponseV1 updateNetflowRulesV1(String siteId, NetFlowRequestV1 netFlowRequestV1);
}
