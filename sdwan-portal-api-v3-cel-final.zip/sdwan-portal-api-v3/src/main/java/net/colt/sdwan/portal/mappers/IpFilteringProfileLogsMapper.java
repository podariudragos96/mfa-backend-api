package net.colt.sdwan.portal.mappers;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.model.IPFilteringLogsResponseV1;
import net.colt.sdwan.security.api.generated.model.IPFilteringApiLogsResponseV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
@Component
public class IpFilteringProfileLogsMapper {

    private final ModelMapper modelMapper;

    public List<IPFilteringLogsResponseV1> from(List<IPFilteringApiLogsResponseV1> apiLogsResponseV1s) {
        final List<IPFilteringLogsResponseV1> response = new ArrayList<>();
        if (!apiLogsResponseV1s.isEmpty()) {
            apiLogsResponseV1s.stream()
                    .map(apiLogsResponseV1 -> modelMapper.map(apiLogsResponseV1, IPFilteringLogsResponseV1.class))
                    .forEach(response::add);
        }
        return response;
    }
}
