package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class NatRuleRequest {

    @JsonProperty("customer")
    private String customerName;

    @JsonProperty("site")
    private String siteId;

    @JsonProperty("rule_set")
    private List<NatRuleSet> natRuleSet;

    @JsonProperty("error")
    private String error;
}
