package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.PolicyApiClient;
import net.colt.sdwan.portal.client.model.StaticRoutesRequest;
import net.colt.sdwan.portal.enums.RoutingStatsType;
import net.colt.sdwan.portal.mappers.StaticRoutesRequestMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.services.DeviceService;
import net.colt.sdwan.portal.services.InterfaceService;
import net.colt.sdwan.portal.services.RoutesService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.DeviceResponseValidator;
import net.colt.sdwan.portal.validator.RoutingValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import java.util.List;

import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.generated.model.service.InterfaceResponseV1.InterfaceTypeEnum.TUNNEL;

@Slf4j
@Service
@RequiredArgsConstructor
public class RoutesServiceImpl implements RoutesService {

    private final DeviceResponseValidator deviceResponseValidator;
    private final SitesService sitesService;
    private final DeviceService deviceService;
    private final InterfaceService interfaceService;
    private final PolicyApiClient policyApiClient;
    private final StaticRoutesRequestMapper staticRoutesRequestMapper;
    private final RoutingValidator routingValidator;
    private final SiteResponseValidator siteResponseValidator;

    @Override
    public CorrelationIdResponseV1 getRouteResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocol(
            String siteId, String deviceId, String interfaceId, RoutingProtocolV1 routingProtocol,
            RoutingTypeV1 routingType, Boolean formatted) {
        RoutingCommandRequestModel requestModel = RoutingCommandRequestModel.builder()
                .statsType(RoutingStatsType.route)
                .routingProtocol(routingProtocol)
                .routingType(routingType)
                .formatted(formatted)
                .build();
        return getRoutingInfo(siteId, deviceId, interfaceId, requestModel);
    }

    @Override
    public CorrelationIdResponseV1 getNeighborResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocol(
            String siteId, String deviceId, String interfaceId, RoutingProtocolV1 routingProtocol, Boolean brief) {
        RoutingCommandRequestModel requestModel = RoutingCommandRequestModel.builder()
                .statsType(RoutingStatsType.neighbor)
                .routingProtocol(routingProtocol)
                .brief(brief)
                .build();
        return getRoutingInfo(siteId, deviceId, interfaceId, requestModel);

    }

    @Override
    public CorrelationIdResponseV1 getStatisticsResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocol(
            String siteId, String deviceId, String interfaceId, RoutingProtocolV1 routingProtocol, Boolean brief) {
        RoutingCommandRequestModel requestModel = RoutingCommandRequestModel.builder()
                .statsType(RoutingStatsType.statistics)
                .routingProtocol(routingProtocol)
                .brief(brief)
                .build();
        return getRoutingInfo(siteId, deviceId, interfaceId, requestModel);
    }

    private CorrelationIdResponseV1 getRoutingInfo(
            String siteId, String deviceId, String interfaceId, RoutingCommandRequestModel routingCommandRequestModel) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final net.colt.sdwan.generated.model.service.DeviceResponseV1 deviceResponse = deviceService.getApiDeviceAndVerify(deviceId);
        deviceResponseValidator.validateDevice(deviceResponse);
        routingValidator.validateGetRouting(routingCommandRequestModel);
        net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse = interfaceService.getApiInterfaceAndVerify(interfaceId);
        policyApiClient.getRoutingCommandDynamicStats(deviceResponse, siteResponse, interfaceResponse, routingCommandRequestModel);
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    @Override
    public CorrelationIdResponseV1 addRouteResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocol(String siteId, String deviceId, String interfaceId, RoutingProtocolV1 routingProtocol, List<RoutePatchDocumentV1> requestList) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (!siteResponseValidator.isSiteLocked(siteResponse)) {
            throw new SdwanBadRequestException("Site is not locked.");
        }

        final net.colt.sdwan.generated.model.service.DeviceResponseV1 deviceResponse = deviceService.getApiDeviceAndVerify(deviceId);
        deviceResponseValidator.validateDevice(deviceResponse);
        final net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse = interfaceService.getApiInterfaceAndVerify(interfaceId);

        if (TUNNEL.equals(interfaceResponse.getInterfaceType())) {
            throw new SdwanBadRequestException(
                    "The site with the id %s has SASE enabled, so no routes can  be added, modified or deleted."
                            .formatted(siteResponse.getId()));
        }

        routingValidator.validateRoutingRequest(requestList, routingProtocol);
        requestList.forEach(request -> doUpdateOrDelete(request, siteResponse, deviceResponse, interfaceResponse));
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    private void doUpdateOrDelete(final RoutePatchDocumentV1 request,
                                  final SiteResponseV1 siteResponseV1,
                                  final net.colt.sdwan.generated.model.service.DeviceResponseV1 deviceResponse,
                                  final net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse) {
        List<StaticRoutesRequest> staticRoutesRequest =
                staticRoutesRequestMapper.mapFromRoutePatchDocument(request, interfaceResponse);
        boolean isUpdate = request.getOp().equals(RoutePatchDocumentV1.OpEnum.ADD);
        policyApiClient.updateRoutesByDeviceId(siteResponseV1, deviceResponse, staticRoutesRequest,
                isUpdate);

    }

}
