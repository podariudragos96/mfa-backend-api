package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class StaticNatRuleResponse {

    @JsonProperty("name")
    private String name;

    @JsonProperty("description")
    private String description;

    @JsonProperty("source-network")
    private List<String> sourceNetwork;

    @JsonProperty("destination-network")
    private List<String> destinationNetwork;

    @JsonProperty("private_ip")
    private List<String> privateIps;

    @JsonProperty("nat_ip")
    private List<String> natIps;

    @JsonProperty("restricted_remote_ip")
    private List<String> restrictedRemoteIps;

    @JsonProperty("precedence")
    private String precedence;

    @JsonProperty("editable")
    private Boolean editable;

    @JsonProperty("protocol")
    private String protocol;
}

