package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.PolicyApiClient;
import net.colt.sdwan.portal.client.model.NatRuleRequest;
import net.colt.sdwan.portal.client.model.NatRuleResponse;
import net.colt.sdwan.portal.client.model.NatRuleSet;
import net.colt.sdwan.portal.constant.ErrorMessageConstants;
import net.colt.sdwan.portal.mappers.NatRulesResponseMapper;
import net.colt.sdwan.portal.mappers.UpdateNatRulesRequestMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.services.NatRulesService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.InterfaceResponseValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.portal.validator.model.NatRulesValidator;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import java.util.List;

import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.constant.SecurityConstants.NAT_RULES_ONLY_ALLOWED_FOR_BRANCH_AND_GATEWAY;
import static net.colt.sdwan.portal.model.OnGoingActionV2.MODIFYING_NAT_RULES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;
import static net.colt.sdwan.portal.util.CGWUtil.isBranch;
import static net.colt.sdwan.portal.util.CGWUtil.isCloudGateway;

@RequiredArgsConstructor
@Service
@Slf4j
public class NatRulesServiceImpl implements NatRulesService {

    private final SitesService sitesService;
    private final InterfaceResponseValidator interfaceResponseValidator;
    private final PolicyApiClient policyApiClient;
    private final SiteResponseValidator siteResponseValidator;
    private final NatRulesValidator natRulesValidator;
    private final NatRulesResponseMapper natRulesResponseMapper;
    private final UpdateNatRulesRequestMapper updateNatRulesRequestMapper;
    /**
     * Get NAT rules by site id Check that the site customer belongs to user's
     * customers. Try to findByOcn a cps peering interface Retrieve the NAT Rules
     * from policy and map them to the needed fromat.
     *
     * @param siteId
     * @return NatRulesResponse obtained from policy api and mapped
     */
    @SuppressWarnings({"java:S1123", "java:S1133"})
    @Deprecated(forRemoval = true)
    @Override
    public NatRulesResponseV1 getNatRulesBySiteId(String siteId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (!(isBranch(siteResponse.getSiteType().getValue()) || isCloudGateway(siteResponse.getSiteType().getValue()))) {
            throw new SdwanBadRequestException(NAT_RULES_ONLY_ALLOWED_FOR_BRANCH_AND_GATEWAY);
        }

        if (siteResponseValidator.hasValidTenantSiteValues(siteResponse)) {
            net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse = interfaceResponseValidator.getCpsPeeringInterface(siteResponse);
            NatRuleResponse narRuleResponse = policyApiClient.getNatRulesBySiteId(siteResponse, interfaceResponse);
            return natRulesResponseMapper.mapFromNatRuleResponse(narRuleResponse);
        }

        throw new SdwanNotFoundException(ErrorMessageConstants.CUSTOMER_OR_SITE_OR_DEVICE_NOT_FOUND_MESSAGE_TEMPLATE.formatted(siteId));
    }


    @Override
    public NatRuleSetResponseV1 getNatRulesBySiteIdV2(String siteId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (!(isBranch(siteResponse.getSiteType().getValue()) || isCloudGateway(siteResponse.getSiteType().getValue()))) {
            throw new SdwanBadRequestException(NAT_RULES_ONLY_ALLOWED_FOR_BRANCH_AND_GATEWAY);
        }

        if (siteResponseValidator.hasValidTenantSiteValues(siteResponse)) {
            net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse = interfaceResponseValidator.getCpsPeeringInterface(siteResponse);
            NatRuleSet narRuleResponse = policyApiClient.getNatRulesBySiteIdV2(siteResponse, interfaceResponse);
            return natRulesResponseMapper.mapFromNatRulesResponse(narRuleResponse);
        }
        throw new SdwanNotFoundException(ErrorMessageConstants.CUSTOMER_OR_SITE_OR_DEVICE_NOT_FOUND_MESSAGE_TEMPLATE.formatted(siteId));

    }


    @Override
    public List<NatRuleHistoryResponseV1> getNatRulesHistoryBySiteIdV2(String siteId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (!(isBranch(siteResponse.getSiteType().getValue()) || isCloudGateway(siteResponse.getSiteType().getValue()))) {
            throw new SdwanBadRequestException(NAT_RULES_ONLY_ALLOWED_FOR_BRANCH_AND_GATEWAY);
        }

        if (siteResponseValidator.hasValidTenantSiteValues(siteResponse)) {
            net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse = interfaceResponseValidator.getCpsPeeringInterface(siteResponse);
            List<NatRuleSet> narRuleResponse = policyApiClient.getNatRulesHistoryBySiteIdV2(siteResponse, interfaceResponse);
            return natRulesResponseMapper.mapFromNatRulesSetResponseV2(narRuleResponse);
        }
        throw new SdwanNotFoundException(ErrorMessageConstants.CUSTOMER_OR_SITE_OR_DEVICE_NOT_FOUND_MESSAGE_TEMPLATE.formatted(siteId));

    }


    @Override
    public NatRuleSetResponseV1 getNatRulesHistoryBySiteIdAndRuleSetIdV2(String siteId, String ruleSetId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (!(isBranch(siteResponse.getSiteType().getValue()) || isCloudGateway(siteResponse.getSiteType().getValue()))) {
            throw new SdwanBadRequestException(NAT_RULES_ONLY_ALLOWED_FOR_BRANCH_AND_GATEWAY);
        }

        if (siteResponseValidator.hasValidTenantSiteValues(siteResponse)) {
            net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse = interfaceResponseValidator.getCpsPeeringInterface(siteResponse);
            NatRuleSet narRuleResponse = policyApiClient.getNatRulesHistoryBySiteIdAndRuleSetIdV1(siteResponse, interfaceResponse, ruleSetId);
            return natRulesResponseMapper.mapFromNatRulesResponse(narRuleResponse);
        }
        throw new SdwanNotFoundException(ErrorMessageConstants.CUSTOMER_OR_SITE_OR_DEVICE_NOT_FOUND_MESSAGE_TEMPLATE.formatted(siteId));

    }

    /**
     * Retrieve the site response by id, check its customer to belong to user's
     * customers, try to findByOcn the cps peering interface and map the received
     * body to a policy api friendly format and execute update.
     *
     * @param siteId
     * @param rulesRequest
     * @return the correlation id corresponding to this update request
     */
    @SuppressWarnings({"java:S1123", "java:S1133"})
    @Deprecated(forRemoval = true)
    @Override
    public CorrelationIdResponseV1 updateNatRulesBySiteId(String siteId, NatRulesRequestV1 rulesRequest) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (!(isBranch(siteResponse.getSiteType().getValue()) || isCloudGateway(siteResponse.getSiteType().getValue()))) {
            throw new SdwanBadRequestException(NAT_RULES_ONLY_ALLOWED_FOR_BRANCH_AND_GATEWAY);
        }

        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        if (siteResponseValidator.hasValidTenantSiteValues(siteResponse)) {
            natRulesValidator.validateRules(rulesRequest.getRuleSet());
            natRulesValidator.hasValidIps(siteResponse, rulesRequest);
            final net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse = interfaceResponseValidator.getCpsPeeringInterface(siteResponse);
            try {
                sitesService.updateOngoingAction(siteId, MODIFYING_NAT_RULES);
                doUpdateNatRules(siteResponse, interfaceResponse, rulesRequest);
                return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
            } catch (Exception ex) {
                log.error("Failed to update Nat rules", ex);
                sitesService.updateOngoingAction(siteId, NONE);
                throw ex;
            }
        }
        throw new SdwanBadRequestException("Site has no valid customer values.");

    }

    @Override
    public CorrelationIdResponseV1 updateNatRulesBySiteIdV2(String siteId, NatRulesRequestV1 rulesRequest) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (!(isBranch(siteResponse.getSiteType().getValue()) || isCloudGateway(siteResponse.getSiteType().getValue()))) {
            throw new SdwanBadRequestException(NAT_RULES_ONLY_ALLOWED_FOR_BRANCH_AND_GATEWAY);
        }

        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        if (siteResponseValidator.hasValidTenantSiteValues(siteResponse)) {
            natRulesValidator.hasValidIps(siteResponse, rulesRequest);
            final net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse = interfaceResponseValidator.getCpsPeeringInterface(siteResponse);
            try {
                sitesService.updateOngoingAction(siteId, MODIFYING_NAT_RULES);
                doUpdateNatRulesV2(siteResponse, interfaceResponse, rulesRequest);
                return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
            } catch (Exception ex) {
                log.error("Failed to update Nat rules", ex);
                sitesService.updateOngoingAction(siteId, NONE);
                throw ex;
            }
        }
        throw new SdwanBadRequestException("Site has no valid customer values.");

    }

    @SuppressWarnings("java:S5738")
    private void doUpdateNatRules(final SiteResponseV1 siteResponse, final net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse,
                                  final NatRulesRequestV1 rulesRequest) {
        final NatRuleRequest natRuleRequest = updateNatRulesRequestMapper.mapFromClientNatRules(rulesRequest,
                siteResponse);
        policyApiClient.updateNatRules(siteResponse, interfaceResponse, natRuleRequest);
    }

    private void doUpdateNatRulesV2(final SiteResponseV1 siteResponse, final net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponse,
                                    final NatRulesRequestV1 rulesRequest) {
        final NatRuleRequest natRuleRequest = updateNatRulesRequestMapper.mapFromClientNatRules(rulesRequest,
                siteResponse);
        policyApiClient.updateNatRulesV2(siteResponse, interfaceResponse, natRuleRequest);
    }

}
