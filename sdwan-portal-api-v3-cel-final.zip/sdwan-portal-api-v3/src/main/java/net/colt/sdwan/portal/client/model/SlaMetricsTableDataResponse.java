package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SlaMetricsTableDataResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("sla_metrics")
    @Valid
    private List<SlaMetricsRowDataResponse> slaMetrics = new ArrayList<>();

    public SlaMetricsTableDataResponse slaMetrics(List<SlaMetricsRowDataResponse> slaMetrics) {
        this.slaMetrics = slaMetrics;
        return this;
    }

    public SlaMetricsTableDataResponse addSlaMetricsItem(SlaMetricsRowDataResponse slaMetricsItem) {
        this.slaMetrics.add(slaMetricsItem);
        return this;
    }

    /**
     * Get slaMetrics
     *
     * @return slaMetrics
     */
    @ApiModelProperty(required = true, value = "")
    @NotNull

    @Valid

    public List<SlaMetricsRowDataResponse> getSlaMetrics() {
        return slaMetrics;
    }

    public void setSlaMetrics(List<SlaMetricsRowDataResponse> slaMetrics) {
        this.slaMetrics = slaMetrics;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SlaMetricsTableDataResponse slaMetricsTableDataResponse = (SlaMetricsTableDataResponse) o;
        return Objects.equals(this.slaMetrics, slaMetricsTableDataResponse.slaMetrics);
    }

    @Override
    public int hashCode() {
        return Objects.hash(slaMetrics);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class SlaMetricsTableDataResponseV1 {\n");

        sb.append("    slaMetrics: ").append(toIndentedString(slaMetrics)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

