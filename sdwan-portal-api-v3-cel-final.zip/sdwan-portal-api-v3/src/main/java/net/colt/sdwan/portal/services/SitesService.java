package net.colt.sdwan.portal.services;

import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.OnGoingActionV2;
import net.colt.sdwan.portal.model.SiteRequestV1;
import net.colt.sdwan.portal.model.SiteResponseV3;

import java.util.List;
import java.util.Set;

public interface SitesService {

    List<SiteResponseV3> getAllSitesV3();

    SiteResponseV3 getSiteBySiteIdV3(final String siteId);

    SiteResponseV1 getApiSiteAndVerify(final String siteId);

    List<String> getLockedSites(String username);

    void unlockSites(List<String> siteIds, String userName);

    void updateSiteWithStatusOrFriendlyName(final String siteId, final SiteRequestV1 siteRequest);

    void updateOngoingAction(final String siteId, OnGoingActionV2 ongoingAction);

    CorrelationIdResponseV1 rediscoverBySiteId(final String siteId);

    List<SiteResponseV1> getAllByUserTenants();

    Set<SiteResponseV1> getAllUserSites();

    List<String> getDeviceNamesFromSiteResponse(SiteResponseV1 siteResponse);

    List<String> getDeviceUuidsFromSiteResponse(SiteResponseV1 siteResponse);

    void updateLoggingProfile(final String siteId, final String loggingProfile, final String loggingEvent);
}
