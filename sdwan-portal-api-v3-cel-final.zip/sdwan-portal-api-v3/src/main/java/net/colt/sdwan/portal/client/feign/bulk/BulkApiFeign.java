package net.colt.sdwan.portal.client.feign.bulk;

import net.colt.sdwan.portal.generated.bulkapi.controllers.BulkCopyApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "bulkApiClient", url = "${sdwan.bulk.api.baseurl}", configuration = BulkApiFeignConfiguration.class)
public interface BulkApiFeign extends BulkCopyApiApi {


}
