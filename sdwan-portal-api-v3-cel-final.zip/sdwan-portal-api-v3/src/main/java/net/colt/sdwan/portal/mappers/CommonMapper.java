package net.colt.sdwan.portal.mappers;

import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.InterfaceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.enums.Direction;
import net.colt.sdwan.portal.enums.Network;
import net.colt.sdwan.portal.model.SiteSubtypeV1;
import net.colt.sdwan.portal.model.SiteTypeV1;
import net.colt.sdwan.portal.util.StaticInfo;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static java.util.Objects.nonNull;
import static net.colt.sdwan.portal.constant.Constants.*;
import static net.colt.sdwan.portal.enums.Direction.*;
import static net.colt.sdwan.portal.util.CGWUtil.*;
import static net.colt.sdwan.portal.util.StaticInfo.*;

@Slf4j
@Component
public class CommonMapper {

    public static Direction getDirection(List<String> sourceNetworks, List<String> destinationNetworks) {
        if (sourceNetworks == null) {
            sourceNetworks = Collections.emptyList();
        }

        if (destinationNetworks == null) {
            destinationNetworks = Collections.emptyList();
        }

        Direction direction;
        if (sourceNetworks.contains(StaticInfo.INTERNET) || sourceNetworks.contains(SDWAN) || destinationNetworks.contains(CLOUD)) {
            direction = INBOUND;
        } else if (destinationNetworks.contains(StaticInfo.INTERNET) || destinationNetworks.contains(SDWAN) || sourceNetworks.contains(CLOUD)) {
            direction = OUTBOUND;
        } else if (sourceNetworks.stream().anyMatch(net -> net.matches(REGEX_DMZ) || net.matches(REGEX_LAN) || net.matches(REGEX_LAN_NNI) || net.equals(DMZ))
                && destinationNetworks.stream().anyMatch(net -> net.matches(REGEX_DMZ) || net.matches(REGEX_LAN) || net.matches(REGEX_LAN_NNI) || net.equals(DMZ))) {
            direction = EAST_WEST;
        } else {
            direction = NONE;
        }

        // To contemplate SD WAN to Internet traffic (Ex: CIB_BRANCH sites)
        if (sourceNetworks.contains(SDWAN) && destinationNetworks.contains(StaticInfo.INTERNET)) {
            direction = OUTBOUND;
        }

        return direction;
    }

    public static Network getNetwork(List<String> sourceNetworks, List<String> destinationNetworks) {
        if (sourceNetworks == null) {
            sourceNetworks = Collections.emptyList();
        }

        if (destinationNetworks == null) {
            destinationNetworks = Collections.emptyList();
        }

        Network network;
        if (sourceNetworks.contains(StaticInfo.INTERNET) || destinationNetworks.contains(StaticInfo.INTERNET)) {
            network = Network.INTERNET;
        } else if (sourceNetworks.contains(SDWAN) || destinationNetworks.contains(SDWAN)) {
            network = Network.SDWAN;
        } else if (sourceNetworks.contains(CLOUD) || destinationNetworks.contains(CLOUD)) {
            network = Network.CLOUD;
        } else if (sourceNetworks.stream().anyMatch(net -> net.matches(REGEX_DMZ) || net.matches(REGEX_LAN) || net.matches(REGEX_LAN_NNI) || net.equals(DMZ))
                && destinationNetworks.stream().anyMatch(net -> net.matches(REGEX_DMZ) || net.matches(REGEX_LAN) || net.matches(REGEX_LAN_NNI) || net.equals(DMZ))) {
            network = Network.EAST_WEST;
        } else {
            network = Network.NONE;
        }
        return network;
    }

    Integer mapToInteger(final String value) {
        Integer intValue = null;
        if (StringUtils.isNotBlank(value)) {
            intValue = Integer.parseInt(value);
        }
        return intValue;
    }

    String mapToString(final Integer value) {
        String valueStr = null;
        if (nonNull(value)) {
            valueStr = value.toString();
        }
        return valueStr;
    }

    Long mapToLong(final Integer value) {
        Long longVal = null;
        if (nonNull(value)) {
            longVal = value.longValue();
        }
        return longVal;
    }

    Long mapToLong(final String value) {
        Long longVal = null;
        if (nonNull(value)) {
            try {
                longVal = Long.parseLong(value);
            } catch (NumberFormatException ex) {
                log.error("Failed while parsing to long", ex);
                return longVal;
            }
        }
        return longVal;
    }

    List<String> mapNullableList(List<String> value) {
        if (Objects.isNull(value)) {
            value = Collections.emptyList();
        }
        return value;
    }

    String mapNullableString(String value) {
        if (StringUtils.isEmpty(value)) {
            value = "";
        }
        return value;
    }

    Boolean mapNullableBoolean(Boolean value) {
        if (Objects.isNull(value)) {
            value = Boolean.FALSE;
        }
        return value;
    }

    LocalDateTime mapStrToLocalDateTime(String timestamp) {
        if (StringUtils.isNotEmpty(timestamp)) {
            if (timestamp.contains(" ")) {
                timestamp = timestamp.replace(" ", "T");
            }
            if (timestamp.contains(".")) {
                timestamp = timestamp.substring(0, timestamp.indexOf("."));
            }
            return LocalDateTime.parse(timestamp);
        }
        return null;
    }

    LocalDateTime mapStrToTimestamp(final String timestamp) {
        if (StringUtils.isNotEmpty(timestamp)) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_PATTERN);
            return LocalDateTime.parse(timestamp, formatter);
        }
        return null;
    }

    public SiteTypeV1 mapSiteTypeEnum(final String siteType) {
        SiteTypeV1 finalSiteType = null;
        if (siteType == null) {
            return null;
        } else if (siteType.equalsIgnoreCase("branch")) {
            finalSiteType = SiteTypeV1.BRANCH;
        } else if (siteType.equalsIgnoreCase("cloud_gateway")) {
            finalSiteType = SiteTypeV1.CLOUD_GATEWAY;
        } else if (siteType.equalsIgnoreCase("gateway")) {
            finalSiteType = SiteTypeV1.GATEWAY;
        } else if (siteType.equalsIgnoreCase("dedicated_gateway")) {
            finalSiteType = SiteTypeV1.DEDICATED_GATEWAY;
        }

        return finalSiteType;
    }

    public SiteSubtypeV1 mapSiteSubtypeEnum(final net.colt.sdwan.generated.model.service.SiteSubtypeV1 siteSubtype) {
        try {
            return SiteSubtypeV1.valueOf(siteSubtype.name());

        } catch (Exception e) {
            return SiteSubtypeV1.STANDARD;
        }
    }

    List<String> mapNetwork(List<String> sourceNetwork, List<String> destinationNetwork, List<String> nets, final SiteResponseV1 siteResponse) {
        final Network network = getNetwork(sourceNetwork, destinationNetwork);

        if ((sourceNetwork.isEmpty() && destinationNetwork.isEmpty()) || Objects.isNull(siteResponse) || (nonNull(network) && Network.NONE.equals(network))) {
            return Collections.singletonList(NONE.name());
        }
        if ((isGateway(siteResponse.getSiteType().getValue()) && nonNull(network) && network.equals(Network.SDWAN))
                || (isCloudGateway(siteResponse.getSiteType().getValue()) && Network.CLOUD.equals(network))) {
            return nets;
        }

        final List<String> networkFromInterface = new ArrayList<>();
        nets.forEach(net -> {
            Optional<InterfaceResponseV1> interfaceResp = findInterfaceBasedOnVersaNameAndZone(net, siteResponse);
            interfaceResp.ifPresent(interfaceResponse ->
                    networkFromInterface.add(nonNull(interfaceResponse.getNetwork()) ? interfaceResponse.getNetwork() : interfaceResponse.getFriendlyName()));
        });

        if (!networkFromInterface.isEmpty())
            nets = networkFromInterface;

        return nets;
    }

    Optional<InterfaceResponseV1> findInterfaceBasedOnVersaNameAndZone(final String vpn, SiteResponseV1 siteResponse) {
        DeviceResponseV1 deviceResponse = null;
        if (CollectionUtils.isNotEmpty(siteResponse.getDevices())) {
            deviceResponse = siteResponse.getDevices().iterator().next();
        }
        Optional<InterfaceResponseV1> interfaceResponse = Optional.empty();
        if (isCloudGatewayOrGateway(siteResponse.getSiteType().getValue())
                && StringUtils.isNotBlank(vpn) && nonNull(deviceResponse)) {
            interfaceResponse = deviceResponse.getInterfaces()
                    .stream()
                    .filter(ir -> nonNull(ir.getIsWan()) && !ir.getIsWan() && nonNull(ir.getZone()) && ir.getZone().equals(vpn))
                    .findFirst();
        }
        return interfaceResponse;
    }

    public Map<DeviceResponseV1, InterfaceResponseV1> findInterfacesBasedOnVpn(final String vpn, SiteResponseV1 siteResponse) {
        Map<DeviceResponseV1, InterfaceResponseV1> interfacesResponse = new HashMap<>();
        if (nonNull(siteResponse) && CollectionUtils.isNotEmpty(siteResponse.getDevices())) {
            for (DeviceResponseV1 deviceResponse : siteResponse.getDevices()) {
                Optional<InterfaceResponseV1> interfaceResponse = deviceResponse.getInterfaces()
                        .stream().filter(ir -> nonNull(ir.getNetwork()) && ir.getNetwork().equals(vpn))
                        .findFirst();
                interfaceResponse.ifPresent(response -> interfacesResponse.put(deviceResponse, response));
            }
        }
        return interfacesResponse;
    }

}
