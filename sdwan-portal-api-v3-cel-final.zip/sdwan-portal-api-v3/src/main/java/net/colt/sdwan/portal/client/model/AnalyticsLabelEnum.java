package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum AnalyticsLabelEnum {
    BITS_PER_SECOND("BITS_PER_SECOND"),

    BYTES("BYTES"),

    PERCENTAGE("PERCENTAGE"),

    MILLISECONDS("MILLISECONDS"),

    COUNT("COUNT");

    private String value;

    AnalyticsLabelEnum(String value) {
        this.value = value;
    }

    @JsonCreator
    public static AnalyticsLabelEnum fromValue(String text) {
        for (AnalyticsLabelEnum b : AnalyticsLabelEnum.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        throw new IllegalArgumentException("Unexpected value '" + text + "'");
    }
}

