package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SnmpRequestV1;
import net.colt.sdwan.portal.model.SnmpResponseV1;

public interface SnmpService {

    SnmpResponseV1 getSnmpV1(final String siteId);

    CorrelationIdResponseV1 updateSnmpV1(final String siteId, final SnmpRequestV1 snmpRequestV1);

}
