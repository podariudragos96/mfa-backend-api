package net.colt.sdwan.portal.config;

import com.google.common.cache.CacheBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

@Configuration
@EnableCaching
public class CachingConfig {

    @Value("${sdwan.cache.expires-in-hours:24}")
    private Integer expiresInHours;

    @Bean
    public CacheManager cacheManager() {
        return new ConcurrentMapCacheManager("applications") {
            @Override
            protected Cache createConcurrentMapCache(final String name) {
                final ConcurrentMap<Object, Object> cacheBuilder = CacheBuilder.newBuilder()
                        .expireAfterWrite(expiresInHours, TimeUnit.HOURS).maximumSize(100).build().asMap();
                return new ConcurrentMapCache(name, cacheBuilder, false);
            }
        };
    }


}