package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.LanConfigurationRequestV1;

public interface LanConfigService {
    CorrelationIdResponseV1 updateLansConfigs(String siteId, LanConfigurationRequestV1 lanConfigurationRequestV1);
}
