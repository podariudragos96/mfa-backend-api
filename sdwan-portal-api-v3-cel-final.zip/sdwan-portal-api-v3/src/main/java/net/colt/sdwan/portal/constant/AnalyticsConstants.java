package net.colt.sdwan.portal.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class AnalyticsConstants {

    public static final String ANALYTIC_ONLY_AVAILABLE_FOR_CLOUD_GATEWAY_SITES = "This analytic is only available for Cloud Gateway Sites";

}
