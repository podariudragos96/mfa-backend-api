package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.LocalInternetBreakoutApiApi;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.LocalInternetBreakoutPreferencesV1;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.LIBService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

import static org.springframework.http.HttpStatus.OK;

@RequiredArgsConstructor
@Controller
public class LIBController implements LocalInternetBreakoutApiApi {

    private final LIBService libService;

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<LocalInternetBreakoutPreferencesV1>> getLIBPreferencesBySiteIdV1(String siteId) {
        return new ResponseEntity<>(libService.getLIBPreferences(siteId), OK);
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/local_internet_breakout")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateLIBBySiteIdV1(String siteId,
            @RequestBody List<LocalInternetBreakoutPreferencesV1> libPreferences) {
        return new ResponseEntity<>(libService.updateLIBPreferences(siteId, libPreferences), OK);
    }
}
