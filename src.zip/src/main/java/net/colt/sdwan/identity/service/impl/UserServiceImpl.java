package net.colt.sdwan.identity.service.impl;

import jakarta.ws.rs.core.Response;
import net.colt.sdwan.generated.model.identityaccess.UserApiV1;
import net.colt.sdwan.identity.service.UserService;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.RealmRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class UserServiceImpl implements UserService {

    private final Keycloak keycloak;

    public UserServiceImpl(Keycloak keycloak) {
        this.keycloak = keycloak;
    }

    @Override
    public UserApiV1 createUser(String userGroupId, UserApiV1 userApiV1) {
        if (userApiV1 == null) {
            throw new IllegalArgumentException("UserApiV1 body is required");
        }

        String realmName = resolveRealmNameByIdOrName(userGroupId);
        UsersResource usersResource = keycloak.realm(realmName).users();

        UserRepresentation userRep = new UserRepresentation();
        userRep.setUsername(userApiV1.getUsername());
        userRep.setEmail(userApiV1.getEmail());
        userRep.setFirstName(userApiV1.getFirstName());
        userRep.setLastName(userApiV1.getLastName());
        userRep.setEnabled(true);

        if (userApiV1.getEmail() != null) {
            userRep.setEmailVerified(false);
        }

        if (userApiV1.getPhoneNumber() != null && !userApiV1.getPhoneNumber().isBlank()) {
            userRep.setAttributes(Map.of("phone_number", List.of(userApiV1.getPhoneNumber().trim())));
        }

        Response response = usersResource.create(userRep);
        try {
            if (response.getStatus() >= 200 && response.getStatus() < 300) {
                String createdUserId = getCreatedIdFromResponse(response);

                if (userApiV1.getPassword() != null && !userApiV1.getPassword().isBlank()) {
                    CredentialRepresentation passwordCred = new CredentialRepresentation();
                    passwordCred.setType(CredentialRepresentation.PASSWORD);
                    passwordCred.setTemporary(false);
                    passwordCred.setValue(userApiV1.getPassword());
                    usersResource.get(createdUserId).resetPassword(passwordCred);
                } else {
                    usersResource.get(createdUserId)
                            .executeActionsEmail(Collections.singletonList("UPDATE_PASSWORD"));
                }

                UserApiV1 out = new UserApiV1();
                out.setId(createdUserId);
                out.setUsername(userApiV1.getUsername());
                out.setEmail(userApiV1.getEmail());
                out.setFirstName(userApiV1.getFirstName());
                out.setLastName(userApiV1.getLastName());
                out.setPhoneNumber(userApiV1.getPhoneNumber());
                out.setEmailVerified(false);
                out.setPassword(null);
                return out;
            }
            throw new RuntimeException("Failed to create user: HTTP " + response.getStatus());
        } finally {
            response.close();
        }
    }

    @Override
    public List<UserApiV1> listUsers(String userGroupId) {
        String realmName = resolveRealmNameByIdOrName(userGroupId);
        UsersResource usersResource = keycloak.realm(realmName).users();

        return usersResource.list().stream().map(this::toUserApiV1).toList();
    }

    @Override
    public UserApiV1 getUser(String userGroupId, String userId) {
        RealmResource realm = resolveRealmResource(userGroupId);

        String resolvedId = resolveUserIdByIdOrUsername(realm, userId);
        if (resolvedId == null) {
            throw new RuntimeException("User not found");
        }

        return toUserApiV1(realm.users().get(resolvedId).toRepresentation());
    }

    @Override
    public UserApiV1 updateUser(String userGroupId, String userId, UserApiV1 userApiV1) {
        if (userApiV1 == null) {
            throw new IllegalArgumentException("UserApiV1 body is required");
        }

        RealmResource realm = resolveRealmResource(userGroupId);

        String resolvedId = resolveUserIdByIdOrUsername(realm, userId);
        if (resolvedId == null) {
            throw new RuntimeException("User not found");
        }

        UserResource ur = realm.users().get(resolvedId);
        UserRepresentation rep = ur.toRepresentation();

        if (userApiV1.getUsername() != null) rep.setUsername(userApiV1.getUsername());
        if (userApiV1.getEmail() != null) rep.setEmail(userApiV1.getEmail());
        if (userApiV1.getFirstName() != null) rep.setFirstName(userApiV1.getFirstName());
        if (userApiV1.getLastName() != null) rep.setLastName(userApiV1.getLastName());

        Map<String, List<String>> attrs = rep.getAttributes();
        if (attrs == null) attrs = new HashMap<>();

        if (userApiV1.getPhoneNumber() != null) {
            String v = userApiV1.getPhoneNumber().trim();
            if (v.isEmpty()) {
                attrs.remove("phone_number");
            } else {
                attrs.put("phone_number", List.of(v));
            }
        }
        rep.setAttributes(attrs);

        ur.update(rep);

        if (userApiV1.getPassword() != null && !userApiV1.getPassword().isBlank()) {
            CredentialRepresentation cred = new CredentialRepresentation();
            cred.setType(CredentialRepresentation.PASSWORD);
            cred.setTemporary(false);
            cred.setValue(userApiV1.getPassword());
            ur.resetPassword(cred);
        }

        return toUserApiV1(ur.toRepresentation());
    }

    @Override
    public void deleteUser(String userGroupId, String userId) {
        RealmResource realm = resolveRealmResource(userGroupId);

        String resolvedId = resolveUserIdByIdOrUsername(realm, userId);
        if (resolvedId == null) {
            throw new RuntimeException("User not found");
        }

        realm.users().delete(resolvedId).close();
    }

    private RealmResource resolveRealmResource(String userGroupIdOrName) {
        String realmName = resolveRealmNameByIdOrName(userGroupIdOrName);
        return keycloak.realm(realmName);
    }

    private String resolveRealmNameByIdOrName(String userGroupIdOrName) {
        String v = (userGroupIdOrName == null) ? "" : userGroupIdOrName.trim();
        if (v.isEmpty()) throw new RuntimeException("user_group_id is required");

        for (RealmRepresentation r : keycloak.realms().findAll()) {
            if (r.getRealm() != null && r.getRealm().equalsIgnoreCase(v)) {
                return r.getRealm();
            }
        }

        for (RealmRepresentation r : keycloak.realms().findAll()) {
            if (r.getId() != null && r.getId().equalsIgnoreCase(v)) {
                return r.getRealm();
            }
        }

        throw new RuntimeException("Realm (user group) not found: " + v);
    }

    private String resolveUserIdByIdOrUsername(RealmResource realm, String userIdOrUsername) {
        String v = (userIdOrUsername == null) ? "" : userIdOrUsername.trim();
        if (v.isEmpty()) return null;

        try {
            UserRepresentation rep = realm.users().get(v).toRepresentation();
            if (rep != null && rep.getId() != null) return rep.getId();
        } catch (Exception ignored) {
        }

        try {
            List<UserRepresentation> users = realm.users().search(v, true);
            if (users == null) return null;

            for (UserRepresentation u : users) {
                if (u != null && u.getUsername() != null && v.equalsIgnoreCase(u.getUsername())) {
                    return u.getId();
                }
            }
        } catch (Exception ignored) {
        }

        return null;
    }

    private String getCreatedIdFromResponse(Response response) {
        String location = response.getHeaderString("Location");
        if (location == null || !location.contains("/")) {
            throw new RuntimeException("Cannot extract userId from Location header");
        }
        return location.substring(location.lastIndexOf('/') + 1);
    }

    private UserApiV1 toUserApiV1(UserRepresentation u) {
        UserApiV1 api = new UserApiV1();
        api.setId(u.getId());
        api.setUsername(u.getUsername());
        api.setEmail(u.getEmail());
        api.setFirstName(u.getFirstName());
        api.setLastName(u.getLastName());
        api.setEmailVerified(Boolean.TRUE.equals(u.isEmailVerified()));

        String phone = null;
        if (u.getAttributes() != null) {
            List<String> vals = u.getAttributes().get("phone_number");
            if (vals != null && !vals.isEmpty()) phone = vals.get(0);
        }
        api.setPhoneNumber(phone);
        api.setPassword(null);
        return api;
    }
}
