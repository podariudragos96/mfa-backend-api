package net.colt.sdwan.identity.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Attempt {

    private String sessionId;

    private String realm;
    private String username;
    private String userId;

    /**
     * Optional: only needed if you want to validate TOTP via direct-grant (password+totp).
     * Keep it short-lived (expiresAt) and set it only when required.
     */
    private String password;

    private Instant createdAt;
    private Instant expiresAt;

    // OTP (email / sms) state (hashed, never store plaintext)
    private String otpHash;
    private Instant otpExpiresAt;
    private boolean otpVerified;
    private int otpAttempts;
}
