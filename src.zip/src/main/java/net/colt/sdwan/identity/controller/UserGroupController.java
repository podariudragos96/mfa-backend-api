package net.colt.sdwan.identity.controller;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.controller.identityaccess.UserGroupApiApi;
import net.colt.sdwan.generated.model.identityaccess.UserGroupApiV1;
import net.colt.sdwan.generated.model.identityaccess.UserGroupCreateRequestApiV1;
import net.colt.sdwan.identity.service.UserGroupService;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class UserGroupController implements UserGroupApiApi {

    private final UserGroupService userGroupService;

    @Override
    public ResponseEntity<UserGroupApiV1> addUserGroupV1(
            @Valid @RequestBody(required = false) @Nullable UserGroupCreateRequestApiV1 req
    ) {
        UserGroupApiV1 created = userGroupService.createRealm(req);
        return ResponseEntity.status(201).body(created);
    }

    @Override
    public ResponseEntity<Void> deleteUserGroupByIdV1(
            @NotNull @PathVariable("user_group_id") String userGroupId
    ) {
        userGroupService.deleteUserGroupById(userGroupId);
        return ResponseEntity.noContent().build();
    }

    @Override
    public ResponseEntity<UserGroupApiV1> getUserGroupByIdV1(
            @NotNull @PathVariable("user_group_id") String userGroupId
    ) {
        return ResponseEntity.ok(userGroupService.getUserGroupById(userGroupId));
    }

    @Override
    public ResponseEntity<UserGroupApiV1> updateUserGroupV1(
            @NotNull @PathVariable("user_group_id") String userGroupId,
            @Valid @RequestBody(required = false) @Nullable UserGroupApiV1 userGroupApiV1
    ) {
        return ResponseEntity.ok(userGroupService.patchUserGroupById(userGroupId, userGroupApiV1));
    }

    @Override
    public ResponseEntity<List<UserGroupApiV1>> userGroupsLookupV1() {
        return ResponseEntity.ok(userGroupService.listUserGroups());
    }
}
