package net.colt.sdwan.identity.util;

import net.colt.sdwan.identity.dto.PhoneNumber;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class PhoneNumbersUtilTest {

    @Test
    void getPhoneNumber_shouldParseInternationalNumber() {
        Optional<PhoneNumber> pn = PhoneNumbersUtil.getPhoneNumber("+40123456789"); // +40 RO
        assertTrue(pn.isPresent());
        assertEquals(40, pn.get().getCountryCode());
        assertEquals(123456789L, pn.get().getNumber());
    }

    @Test
    void getPhoneNumber_shouldReturnEmptyForNonNumeric() {
        assertTrue(PhoneNumbersUtil.getPhoneNumber("+40ABC").isEmpty());
    }

    @Test
    void getPhoneNumber_shouldTrimSpacesAndPlus() {
        Optional<PhoneNumber> pn = PhoneNumbersUtil.getPhoneNumber(" +44 7123 456789 ");
        assertTrue(pn.isPresent());
        assertEquals(44, pn.get().getCountryCode());
        assertEquals(7123456789L, pn.get().getNumber());
    }
}
