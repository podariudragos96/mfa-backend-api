package net.colt.sdwan.identity.util;

import net.colt.sdwan.identity.dto.Attempt;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PendingMfaStoreTest {

    @Test
    void saveForSessionId_shouldTrimAndOverwrite() {
        PendingMfaStore store = new PendingMfaStore();

        store.saveForSessionId("  sid-1  ", "realm1", "Alice", "id1", "pw1");
        Attempt a1 = store.getBySessionId("sid-1");
        assertNotNull(a1);
        assertEquals("realm1", a1.getRealm());
        assertEquals("Alice", a1.getUsername());
        assertEquals("id1", a1.getUserId());

        // overwrite same session id
        store.saveForSessionId("sid-1", "realm2", "ALICE", "id2", "pw2");
        Attempt a2 = store.getBySessionId("  sid-1 ");
        assertNotNull(a2);
        assertEquals("realm2", a2.getRealm());
        assertEquals("id2", a2.getUserId());
        assertEquals("pw2", a2.getPassword());
    }

    @Test
    void getBySessionId_shouldReturnNull_whenBlankOrMissing() {
        PendingMfaStore store = new PendingMfaStore();
        assertNull(store.getBySessionId(null));
        assertNull(store.getBySessionId("   "));
        assertNull(store.getBySessionId("sid-missing"));
    }

    @Test
    void removeBySessionId_shouldRemove() {
        PendingMfaStore store = new PendingMfaStore();
        store.saveForSessionId("sid-1", "realm", "bob", "id", "pw");
        assertNotNull(store.getBySessionId("sid-1"));

        store.removeBySessionId("  sid-1  ");
        assertNull(store.getBySessionId("sid-1"));
    }

    @Test
    void stateMapping_shouldStoreAndReturnSessionId() {
        PendingMfaStore store = new PendingMfaStore();

        store.putStateMapping("state-1", "sid-1");
        assertEquals("sid-1", store.getSessionIdByState("state-1"));

        // ignore blanks
        store.putStateMapping("   ", "sid-x");
        assertNull(store.getSessionIdByState("   "));
    }
}
