package net.colt.sdwan.identity.service.impl;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.identity.dto.PhoneNumber;
import net.colt.sdwan.identity.dto.SmsRequest;
import net.colt.sdwan.identity.dto.SmsResponse;
import net.colt.sdwan.identity.util.PhoneNumbersUtil;
import org.apache.commons.lang3.StringUtils;
import net.colt.sdwan.identity.service.SmsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Locale;
import java.util.Optional;

import static java.util.Collections.emptyMap;
import static java.util.Objects.requireNonNull;
import static reactor.netty.Metrics.SUCCESS;

@Slf4j
@Service
@NoArgsConstructor(force = true)
@AllArgsConstructor
public class SmsServiceImpl implements SmsService {

    @Autowired
    private MessageSource messageSource;

    @Autowired
    @Qualifier("customRestTemplate")
    private RestTemplate restTemplate;

    @Value("${sms.api.url}")
    private String smsApiUrl;

    @Value("${sms.api.security.token}")
    private String smsApiSecurityToken;

    private boolean wasSmsSent;

    @Override
    public void sendSms(String mobileNumber, String siteName, String siteAddress, String status, Locale locale) {
        final String message = messageSource.getMessage(status, new Object[]{siteAddress}, locale);
        wasSmsSent = sendMessage(mobileNumber, message);
    }

    @Override
    public boolean wasSmsSent() {
        return this.wasSmsSent;
    }

    private boolean sendMessage(String mobileNumber, String text) {
        if (StringUtils.isBlank(mobileNumber)) {
            return false;
        }

        final Optional<PhoneNumber> phoneNumberOptional = PhoneNumbersUtil.getPhoneNumber(mobileNumber);

        if (phoneNumberOptional.isPresent()) {
            final PhoneNumber phoneNumber = phoneNumberOptional.get();
            final SmsRequest smsRequest = new SmsRequest(smsApiSecurityToken, phoneNumber.getCountryCodeAsString(), phoneNumber.getNumberAsString(), text);
            return executePost(smsApiUrl, smsRequest);
        } else {
            return false;
        }
    }


    private boolean executePost(String url, SmsRequest request) {
        final HttpHeaders headers = getHttpHeaders();
        final HttpEntity<SmsRequest> requestEntity = new HttpEntity<>(request, headers);
        try {
            final HttpEntity<SmsResponse> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, SmsResponse.class, emptyMap());
            return SUCCESS.equalsIgnoreCase(requireNonNull(response.getBody()).getStatus());
        } catch (Exception e) {
            log.error("The following exception was thrown ", e);
            return false;
        }
    }

    private HttpHeaders getHttpHeaders() {
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return headers;
    }


}
