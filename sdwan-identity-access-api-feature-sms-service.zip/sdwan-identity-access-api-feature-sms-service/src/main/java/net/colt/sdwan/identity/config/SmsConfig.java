package net.colt.sdwan.identity.config;

import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import net.colt.sdwan.identity.service.SmsService;
import net.colt.sdwan.identity.service.impl.SmsServiceImpl;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
@ComponentScan(basePackages = "net.colt.sdwan.identity")
@PropertySource("classpath:application.properties")
public class SmsConfig {

    @Bean
    public SmsService smsService() {
        return new SmsServiceImpl();
    }

    @Bean("customRestTemplate")
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        final CloseableHttpClient httpClient = HttpClients.custom()
                .build();

        final HttpComponentsClientHttpRequestFactory customRequestFactory = new HttpComponentsClientHttpRequestFactory();
        customRequestFactory.setHttpClient(httpClient);

        return builder.requestFactory(() -> customRequestFactory).build();
    }
}
