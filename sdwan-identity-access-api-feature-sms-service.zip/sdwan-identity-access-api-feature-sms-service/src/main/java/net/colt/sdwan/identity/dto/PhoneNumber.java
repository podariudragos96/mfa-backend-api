package net.colt.sdwan.identity.dto;

import lombok.*;

//TODO: Move this to common to maybe???

@Getter
@Setter
@Builder
@EqualsAndHashCode
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class PhoneNumber {

    private String isoCode;
    private int countryCode;
    private long number;

    public String getCountryCodeAsString() {
        return String.valueOf(countryCode);
    }

    public String getNumberAsString() {
        return String.valueOf(number);
    }
}