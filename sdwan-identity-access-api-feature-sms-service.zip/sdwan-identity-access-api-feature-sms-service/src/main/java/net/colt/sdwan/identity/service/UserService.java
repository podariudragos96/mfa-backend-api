package net.colt.sdwan.identity.service;

import net.colt.sdwan.generated.model.identityaccess.UserApiV1;
import net.colt.sdwan.identity.dto.ExportUserDto;

import java.util.List;

public interface UserService {

    UserApiV1 createUser(String realm, net.colt.sdwan.generated.model.identityaccess.UserApiV1 userApiV1);

    List<UserApiV1> listUsers(String userGroupId);

    UserApiV1 getUser(String userGroupId, String userId);

    UserApiV1 updateUser(String userGroupId, String userId, UserApiV1 userApiV1);

    void deleteUser(String userGroupId, String userId);

    void sendResetPasswordEmail(String realm, String userId);

    void sendVerifyEmail(String realm, String userId);

    List<ExportUserDto> exportUsers(String realm);
}
