package net.colt.sdwan.identity.service;

import net.colt.sdwan.identity.service.impl.DirectGrantServiceImpl;

public interface DirectGrantService {

    DirectGrantServiceImpl.DagResult validateCredentialsDetailed(String realm, String username, String password,
                                                                 String overrideClientId, String overrideClientSecret);

    boolean validateCredentials(String realm, String username, String password);

    boolean validateCredentialsWithTotp(String realm, String username, String password, String totp);
}
