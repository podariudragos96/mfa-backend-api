package net.colt.sdwan.identity.controller;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.controller.identityaccess.UserGroupApiApi;
import net.colt.sdwan.generated.model.identityaccess.UserGroupApiV1;
import net.colt.sdwan.generated.model.identityaccess.UserGroupCreateRequestApiV1;
import net.colt.sdwan.identity.service.UserGroupService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/userGroups")
@RequiredArgsConstructor
public class UserGroupController implements UserGroupApiApi {

    private final UserGroupService userGroupService;

    @Override
    public ResponseEntity<UserGroupApiV1> addUserGroupV1(UserGroupCreateRequestApiV1 userGroupCreateRequestApiV1) {
        userGroupService.createRealm(userGroupCreateRequestApiV1);
        return ResponseEntity.status(201).build();
    }

    @Override
    public ResponseEntity<Void> deleteUserGroupByIdV1(String userGroupId) {
        return UserGroupApiApi.super.deleteUserGroupByIdV1(userGroupId);
    }

    @Override
    public ResponseEntity<UserGroupApiV1> getUserGroupByIdV1(String userGroupId) {
        return ResponseEntity.ok(userGroupService.getUserGroupById(userGroupId));
    }

    @Override
    public ResponseEntity<UserGroupApiV1> updateUserGroupV1(String userGroupId, UserGroupApiV1 userGroupApiV1) {
        return ResponseEntity.ok(userGroupService.patchUserGroupById(userGroupId, userGroupApiV1));

    }

    @Override
    public ResponseEntity<List<UserGroupApiV1>> userGroupsLookupV1() {
        return ResponseEntity.ok(userGroupService.listUserGroups());
    }
}
