package net.colt.sdwan.identity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SdwanIdentityAccessV1Application {
    public static void main(String[] args) {
        SpringApplication.run(SdwanIdentityAccessV1Application.class, args);
    }
}