package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.BreakoutApiApi;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SaseBreakoutRequestV1;
import net.colt.sdwan.portal.model.SaseBreakoutResponseV1;
import net.colt.sdwan.portal.model.ZScalerBreakoutRequestV1;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.BreakoutService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;

@Controller
@RequiredArgsConstructor
public class BreakoutController implements BreakoutApiApi {

    private final BreakoutService breakoutService;

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole', 'SD-WANReadWriteRole')")
    public ResponseEntity<SaseBreakoutResponseV1> getSaseBreakoutV1(String siteId) {
        return ResponseEntity.ok(breakoutService.getSaseBreakoutV1(siteId));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/sase_breakout")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateSaseBreakoutV1(String siteId, SaseBreakoutRequestV1 saseBreakoutRequestV1) {
        return ResponseEntity.ok(breakoutService.updateSaseBreakoutV1(siteId, saseBreakoutRequestV1));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/zscaler_breakout")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateZScalerBreakoutV1(String siteId, ZScalerBreakoutRequestV1 zscalerBreakoutRequestV1) {
        return ResponseEntity.ok(breakoutService.updateZScalerBreakoutV1(siteId, zscalerBreakoutRequestV1));
    }

}
