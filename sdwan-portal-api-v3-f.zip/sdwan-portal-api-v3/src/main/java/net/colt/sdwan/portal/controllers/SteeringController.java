package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.SteeringPoliciesApiApi;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SteeringHistoryResponseV1;
import net.colt.sdwan.portal.model.SteeringPolicyRequestV1;
import net.colt.sdwan.portal.model.SteeringPolicyResponseV1;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.SteeringService;
import net.colt.sdwan.portal.validator.model.SteeringRequestV1Validator;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class SteeringController implements SteeringPoliciesApiApi {

    private final SteeringService steeringService;
    private final SteeringRequestV1Validator validator;


    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setValidator(validator);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SteeringPolicyResponseV1> getSteeringPoliciesBySiteIdV1(String siteId) {

        return ResponseEntity.ok(steeringService.getSteeringPoliciesV1(siteId));
    }


    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SteeringPolicyResponseV1> getSteeringPoliciesHistoryBySiteIdAndRuleSetIdV1(String siteId,String id) {
        return ResponseEntity.ok(steeringService.getSteeringPoliciesHistoryByIdV1(siteId, id));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<List<SteeringHistoryResponseV1>> getSteeringPoliciesHistoryBySiteIdV1(String siteId) {
        return ResponseEntity.ok(steeringService.getSteeringPoliciesHistoryV1(siteId));
    }


    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/steering/policies")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateSteeringPoliciesBySiteIdV1(String siteId,
                                                                                    @RequestBody SteeringPolicyRequestV1 steeringPolicyRequestV1) {
        return ResponseEntity.ok(steeringService.updateSteeringPoliciesV1(siteId, steeringPolicyRequestV1));
    }
}
