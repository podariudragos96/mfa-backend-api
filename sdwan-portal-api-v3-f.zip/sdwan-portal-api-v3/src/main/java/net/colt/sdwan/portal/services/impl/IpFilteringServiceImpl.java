package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.service.SecurityResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.feign.security.IpFilteringProfilesApiFeign;
import net.colt.sdwan.portal.mappers.IpFilteringMapper;
import net.colt.sdwan.portal.mappers.IpFilteringProfileLogsMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.IpFilteringService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.IPFilteringValidator;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.security.api.generated.model.IPFilteringApiLogsResponseV1;
import net.colt.sdwan.security.api.generated.model.IPFilteringProfilesRequestApiV1;
import net.colt.sdwan.security.api.generated.model.IPFilteringProfilesResponseApiV1;
import net.colt.sdwan.security.api.generated.model.LoggerType;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.constant.SecurityConstants.IP_FILTERING_PROFILES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.MODIFYING_IP_FILTERING_PROFILES_RULES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;

@Service
@Slf4j
@RequiredArgsConstructor
public class IpFilteringServiceImpl implements IpFilteringService {

    private final SitesService sitesService;
    private final SiteResponseValidator siteResponseValidator;
    private final IpFilteringMapper ipFilteringMapper;
    private final IPFilteringValidator ipFilteringValidator;
    private final IpFilteringProfilesApiFeign ipFilteringProfilesApiFeign;
    private final IpFilteringProfileLogsMapper logsMapper;
    private final ResponseEntityValidator responseEntityValidator;

    @Override
    public IPFilteringProfilesResponseV1 getIpFilteringProfilesV1(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final SecurityResponseV1 security = siteResponse.getSiteFeatures().getSecurity();
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(security.getFirewall().getValue());

        siteResponseValidator.validateSecurityProfileFeatureSupport(hasAdvancedFirewall, security.getIpFilteringEnabled());
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final ResponseEntity<IPFilteringProfilesResponseApiV1> ipFilteringProfilesV1 =
                ipFilteringProfilesApiFeign.getIPFilteringProfilesV1(siteResponse.getNetworkId(), Integer.parseInt(siteId));

        responseEntityValidator.checkResponseEntity(ipFilteringProfilesV1, IP_FILTERING_PROFILES);
        return ipFilteringMapper.from(ipFilteringProfilesV1.getBody());
    }

    @Override
    public CorrelationIdResponseV1 updateIpFilteringProfilesV1(String siteId, IPFilteringProfilesRequestV1 ipFilteringProfilesRequestV1) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final SecurityResponseV1 security = siteResponse.getSiteFeatures().getSecurity();
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(security.getFirewall().getValue());

        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        siteResponseValidator.validateSecurityProfileFeatureSupport(hasAdvancedFirewall, security.getIpFilteringEnabled());

        final List<IPFilteringProfileV1> validIpFilteringProfiles =
                ipFilteringValidator.validateIpFilteringProfiles(ipFilteringProfilesRequestV1.getIpFilteringProfiles());

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final IPFilteringProfilesRequestApiV1 ipFilteringProfilesRequestApiV1 =
                ipFilteringMapper.from(validIpFilteringProfiles);
        ipFilteringProfilesRequestApiV1.setLoggerType(LoggerType.fromValue(siteResponse.getSiteFeatures().getSecurity().getLogging().getLoggingType()));

        final List<String> deviceNames = new ArrayList<>(sitesService.getDeviceNamesFromSiteResponse(siteResponse));
        UserAuth userAuth = AuthUserHelper.getAuthUser();

        try {
            sitesService.updateOngoingAction(siteId, MODIFYING_IP_FILTERING_PROFILES_RULES);
            final ResponseEntity<Void> responseEntity = ipFilteringProfilesApiFeign.updateIPFilteringProfilesV1(
                    siteResponse.getNetworkId(), Integer.parseInt(siteId),
                    userAuth.getUsername(), deviceNames, ipFilteringProfilesRequestApiV1);

            responseEntityValidator.checkResponseEntity(responseEntity, IP_FILTERING_PROFILES);
            return new CorrelationIdResponseV1(MDC.get(CORRELATION_ID));
        } catch (Exception ex) {
            log.error("Failed to update IP Filtering Security Profiles", ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }
    }

    @Override
    public List<IPFilteringLogsResponseV1> getIpFilteringProfileLogsV1(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final SecurityResponseV1 security = siteResponse.getSiteFeatures().getSecurity();
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(security.getFirewall().getValue());

        siteResponseValidator.validateSecurityProfileFeatureSupport(hasAdvancedFirewall, security.getIpFilteringEnabled());
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final List<String> deviceNames = sitesService.getDeviceNamesFromSiteResponse(siteResponse);
        final List<String> deviceUuids = sitesService.getDeviceUuidsFromSiteResponse(siteResponse);

        final ResponseEntity<List<IPFilteringApiLogsResponseV1>> responseEntity = ipFilteringProfilesApiFeign.getIpFilteringProfileLogsV1(
                siteResponse.getNetworkId(), Integer.parseInt(siteId), deviceNames, deviceUuids);
        responseEntityValidator.checkResponseEntity(responseEntity, IP_FILTERING_PROFILES);

        return logsMapper.from(requireNonNull(responseEntity.getBody()));
    }
}
