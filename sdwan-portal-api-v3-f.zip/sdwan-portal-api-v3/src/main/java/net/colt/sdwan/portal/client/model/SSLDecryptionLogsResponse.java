package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class SSLDecryptionLogsResponse {

    @JsonProperty("receive_time")
    private String receiveTime;

    @JsonProperty("device_name")
    private String deviceName;

    @JsonProperty("rule_name")
    private String ruleName;

    @JsonProperty("domain")
    private String domain;

    @JsonProperty("action")
    private SSLDecryptionLogsAction action;

    @JsonProperty("action_type")
    private String actionType;

    @JsonProperty("protocol")
    private String protocol;

    @JsonProperty("ssl_protocol_version")
    private String sslProtocolVersion;

    @JsonProperty("cipher")
    private String cipher;

    @JsonProperty("public_key_length")
    private Integer publicKeyLength;

    @JsonProperty("source")
    private SSLDecryptionLogsOriginResponse source;

    @JsonProperty("destination")
    private SSLDecryptionLogsOriginResponse destination;
}
