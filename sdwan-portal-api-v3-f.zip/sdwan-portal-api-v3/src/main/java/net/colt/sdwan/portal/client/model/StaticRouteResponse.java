package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class StaticRouteResponse {

    @JsonProperty("device")
    private String device;

    @JsonProperty("versa_org")
    private String versaOrg;

    @JsonProperty("vrf")
    private String vrf;

    @JsonProperty("route_type")
    private RoutingProtocol routeType;

    @JsonProperty("bgp_type")
    private String bgpType;

    @JsonProperty("route")
    private StaticRoute route;

}
