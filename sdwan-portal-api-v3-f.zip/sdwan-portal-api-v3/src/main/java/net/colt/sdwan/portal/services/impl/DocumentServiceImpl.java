package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.portal.database.entities.Documents;
import net.colt.sdwan.portal.database.repositories.DocumentsRepository;
import net.colt.sdwan.portal.services.DocumentService;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.sql.rowset.serial.SerialBlob;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class DocumentServiceImpl implements DocumentService {

    private static final String STATUS_ACTIVE = "Active";

    private final DocumentsRepository documentsRepository;

    public ResponseEntity<Resource> getDocument(String type, String userLanguage) {
        try {
            List<Documents> documentsList = documentsRepository.findAll();
            Blob blob = null;
            if (CollectionUtils.isNotEmpty(documentsList) && Objects.nonNull(userLanguage) && Objects.nonNull(type)) {

                // Filter
                Optional<Documents> document = documentsList.stream().filter(documents -> userLanguage.equalsIgnoreCase(documents.getLanguage())
                        && STATUS_ACTIVE.equalsIgnoreCase(documents.getStatus()) && type.equalsIgnoreCase(documents.getDocumentType())).findFirst();

                if (document.isPresent() && Objects.nonNull(document.get().getContent())) {
                    blob = new SerialBlob(document.get().getContent());

                    HttpHeaders headers = new HttpHeaders();
                    headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + type);
                    headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE);

                    return ResponseEntity
                            .ok()
                            .headers(headers)
                            .body(new InputStreamResource(blob.getBinaryStream()));
                }
            }
        } catch (SQLException e) {
            log.error("Couldn't serialize response for content type ", e);
            throw new SdwanInternalServerErrorException("Couldn't serialize response for content type ", e);
        }
        throw new SdwanNotFoundException("Document not found");
    }
}
