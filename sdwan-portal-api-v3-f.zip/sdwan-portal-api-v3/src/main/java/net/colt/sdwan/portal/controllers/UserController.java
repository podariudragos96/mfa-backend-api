package net.colt.sdwan.portal.controllers;

import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.UserApiApi;
import net.colt.sdwan.portal.mappers.SdwanUserMapper;
import net.colt.sdwan.portal.model.UpdateUserRequestV1;
import net.colt.sdwan.portal.model.UserResponseV1;
import net.colt.sdwan.portal.services.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RestController
public class UserController implements UserApiApi {

    private final SdwanUserMapper sdwanUserMapper;
    private final UserService userService;

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole', 'SD-WANRWWLTenantRole', 'SD-WANInstallManagerRole')")
    public ResponseEntity<UserResponseV1> getUserV1() {
        return new ResponseEntity<>(sdwanUserMapper.mapToResponse(), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> updateUserV1(@ApiParam(value = "UpdateUser") @RequestBody UpdateUserRequestV1 body) {
        userService.save(body.getCustomisation(), body.getPreferredLanguage());
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
