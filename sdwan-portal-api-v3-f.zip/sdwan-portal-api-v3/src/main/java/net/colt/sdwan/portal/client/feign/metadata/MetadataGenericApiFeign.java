package net.colt.sdwan.portal.client.feign.metadata;

import net.colt.sdwan.metadata.api.generated.api.MetadataApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "metadataGenericApiClient", url = "${sdwan.metadata.api.baseurl}",
        configuration = MetadataFeignConfiguration.class)
public interface MetadataGenericApiFeign extends MetadataApiApi {
}
