package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.model.ServiceObjectCriteria;
import net.colt.sdwan.portal.model.ServicesRequestV1;
import net.colt.sdwan.portal.model.ServicesResponseV1;
import net.colt.sdwan.sitesettings.api.generated.model.ServiceObjectCriteriaApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.ServicesRequestApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.ServicesResponseApiV1;
import org.mapstruct.Mapper;

@Mapper
public interface ServiceObjectMapper extends CommonObjectMapper {

    ServiceObjectCriteriaApiV1 from(ServiceObjectCriteria criteria);

    ServicesResponseV1 from(ServicesResponseApiV1 response);

    ServicesRequestApiV1 from(ServicesRequestV1 request);

}
