package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.metadata.api.generated.model.UrlCategoriesResponseV1;
import net.colt.sdwan.metadata.api.generated.model.*;
import net.colt.sdwan.portal.client.feign.metadata.MetadataGenericApiFeign;
import net.colt.sdwan.portal.client.feign.metadata.MetadataPoliciesApiFeign;
import net.colt.sdwan.portal.client.feign.metadata.MetadataSecurityProfilesApiFeign;
import net.colt.sdwan.portal.mappers.FileTypeMapper;
import net.colt.sdwan.portal.mappers.PoliciesMetaMapper;
import net.colt.sdwan.portal.mappers.SecurityProfilesMetaMapper;
import net.colt.sdwan.portal.mappers.UrlCategoryDetailsMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.services.MetaService;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.Collections.emptyList;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.collections4.CollectionUtils.isNotEmpty;

@RequiredArgsConstructor
@Service
@Slf4j
public class MetaServiceImpl implements MetaService {

    private final UrlCategoryDetailsMapper urlCategoryDetailsMapper;
    private final FileTypeMapper fileTypeMapper;
    private final MetadataSecurityProfilesApiFeign metadataSecurityProfilesApiFeign;
    private final MetadataGenericApiFeign metadataGenericApiFeign;
    private final MetadataPoliciesApiFeign metadataPoliciesApiFeign;
    private final SecurityProfilesMetaMapper securityProfilesMetaMapper;
    private final PoliciesMetaMapper policiesMetaMapper;
    private final ModelMapper modelMapper;

    @Override
    public List<MetaApplicationPortalV1> getAllApplications() {
        List<MetaApplicationV1> applications = extractBody(metadataGenericApiFeign.getApplicationsV1());
        return Arrays.asList(modelMapper.map(applications, MetaApplicationPortalV1[].class));
    }

    @Override
    public UrlPredefinedCategoriesResponseV1 getAllURLCategories(MetadataCriteria criteria, Integer pageNumber, Integer pageSize) {
        final UrlCategoriesResponseV1 urlCategories = extractBody(metadataGenericApiFeign.getUrlCategoriesV1(urlCategoryDetailsMapper.from(criteria), pageNumber, pageSize, PageRequest.of(pageNumber, pageSize)));
        return urlCategoryDetailsMapper.from(urlCategories);
    }

    @Override
    public List<FileTypeDetailsV1> getAllFileTypes() {
        final FileTypesResponseV1 fileTypes = extractBody(metadataGenericApiFeign.getFileTypesV1());
        return fileTypeMapper.mapToResponse(fileTypes);
    }

    @Override
    public MetadataExceptionSignaturesPortalResponseV1 getVulnerabilityExceptionSignaturesV1(Integer offset, Integer limit, String search) {
        return modelMapper.map(extractBody(metadataSecurityProfilesApiFeign.getVulnerabilityExceptionSignaturesV1(offset, limit, search)), MetadataExceptionSignaturesPortalResponseV1.class);
    }

    @Override
    public Map<String, String> getVulnerabilityExceptionSignaturesByIdsV1(List<String> signatureIds) {
        Map<String, String> response = new HashMap<>();
        MetadataExceptionSignaturesResponseV1 signaturesResponseV1 = null;

        if (isNotEmpty(signatureIds)) {
            signaturesResponseV1 = extractBody(metadataSecurityProfilesApiFeign.getVulnerabilityExceptionSignaturesByIdsV1(signatureIds));

            if (nonNull(signaturesResponseV1) && isNotEmpty(signaturesResponseV1.getExceptionSignatures())) {
                response = signaturesResponseV1.getExceptionSignatures().stream()
                        .collect(Collectors
                                .toMap(MetaExceptionSignaturesV1::getId, MetaExceptionSignaturesV1::getDescription));
            }
        }

        return response;
    }

    @Override
    public List<String> getVulnerabilityPredefinedProfileNamesV1() {
        return extractBody(metadataSecurityProfilesApiFeign.getVulnerabilityPredefinedProfileNamesV1());
    }

    @Override
    public List<String> getVulnerabilityUserDefinedApplicationsV1() {
        return extractBody(metadataSecurityProfilesApiFeign.getVulnerabilityUserDefinedApplicationsV1());
    }

    @Override
    public List<String> getVulnerabilityUserDefinedClassTypesV1() {
        return extractBody(metadataSecurityProfilesApiFeign.getVulnerabilityUserDefinedClassTypesV1());
    }

    @Override
    public List<MetaOperatingSystemsPortalV1> getVulnerabilityUserDefinedOperatingSystemsV1() {
        return securityProfilesMetaMapper
                .mapVulnerabilityOSResponseListToMetaOS(extractBody(metadataSecurityProfilesApiFeign.getVulnerabilityUserDefinedOperatingSystemsV1()));
    }

    @Override
    public List<MetaProductPortalV1> getVulnerabilityUserDefinedProductsV1() {
        return securityProfilesMetaMapper
                .mapVulnerabilityProductResponseListToMetaProduct(extractBody(metadataSecurityProfilesApiFeign.getVulnerabilityUserDefinedProductsV1()));
    }

    @Override
    public List<MetaReferencePortalV1> getVulnerabilityUserDefinedReferencesV1() {
        return securityProfilesMetaMapper
                .mapVulnerabilityReferenceResponseListToMetaReference(extractBody(metadataSecurityProfilesApiFeign.getVulnerabilityUserDefinedReferencesV1()));
    }

    @Override
    public List<Integer> getVulnerabilityUserDefinedCveYearsV1() {
        return extractBody(metadataSecurityProfilesApiFeign.getVulnerabilityUserDefinedCveYearsV1());
    }

    @Override
    public List<MetaGeoIpCountryPortalV1> getIpFilteringGeoIpCountriesV1() {
        return securityProfilesMetaMapper
                .mapIpFilteringGeoIpCountryResponseListToMetaGeoIpCountry(extractBody(metadataSecurityProfilesApiFeign.getIpFilteringGeoIpCountriesV1()));
    }

    @Override
    public List<MetaQueryPatternsPortalV1> getMetaQueryPatternsV1() {
        final DnsProxyPatternsResponseV1 dnsProxyPatternsResponseV1 = extractBody(metadataPoliciesApiFeign.getDnsProxyPatternsV1());
        return policiesMetaMapper
                .mapQueryPatternsResponseList(dnsProxyPatternsResponseV1 != null ? dnsProxyPatternsResponseV1.getPatterns() : emptyList());
    }

    @Override
    public List<String> getIpFilteringReputationsV1() {
        return extractBody(metadataSecurityProfilesApiFeign.getIpFilteringReputationsV1());
    }

    @Override
    public void validateVulnerabilityPredefinedProfileNamesV1(MetadataValidateListRequestV1 metadataValidateListRequestV1) {
        if (nonNull(metadataValidateListRequestV1)
                && isNotEmpty(metadataValidateListRequestV1.getData()))
            metadataSecurityProfilesApiFeign.validateVulnerabilityPredefinedProfileNamesV1(metadataValidateListRequestV1);
    }

    @Override
    public void validateVulnerabilityExceptionSignaturesV1(MetadataValidateListRequestV1 metadataValidateListRequestV1) {
        if (nonNull(metadataValidateListRequestV1)
                && isNotEmpty(metadataValidateListRequestV1.getData()))
            metadataSecurityProfilesApiFeign.validateVulnerabilityExceptionSignaturesV1(metadataValidateListRequestV1);
    }

    @Override
    public void validateVulnerabilityUserDefinedClassTypesV1(MetadataValidateListRequestV1 metadataValidateListRequestV1) {
        if (nonNull(metadataValidateListRequestV1)
                && isNotEmpty(metadataValidateListRequestV1.getData()))
            metadataSecurityProfilesApiFeign.validateVulnerabilityUserDefinedClassTypesV1(metadataValidateListRequestV1);
    }

    @Override
    public void validateVulnerabilityUserDefinedApplicationsV1(MetadataValidateListRequestV1 metadataValidateListRequestV1) {
        if (nonNull(metadataValidateListRequestV1)
                && isNotEmpty(metadataValidateListRequestV1.getData()))
            metadataSecurityProfilesApiFeign.validateVulnerabilityUserDefinedApplicationsV1(metadataValidateListRequestV1);
    }

    @Override
    public void validateVulnerabilityUserDefinedProductsV1(MetadataValidateProductRequestV1 metadataValidateProductRequestV1) {
        if (nonNull(metadataValidateProductRequestV1)
                && isNotEmpty(metadataValidateProductRequestV1.getProducts()))
            metadataSecurityProfilesApiFeign.validateVulnerabilityUserDefinedProductsV1(metadataValidateProductRequestV1);
    }

    @Override
    public void validateVulnerabilityUserDefinedOperatingSystemsV1(MetadataValidateOSRequestV1 metadataValidateOSRequestV1) {
        if (nonNull(metadataValidateOSRequestV1)
                && isNotEmpty(metadataValidateOSRequestV1.getOperatingSystems()))
            metadataSecurityProfilesApiFeign.validateVulnerabilityUserDefinedOperatingSystemsV1(metadataValidateOSRequestV1);
    }

    @Override
    public void validateVulnerabilityUserDefinedReferencesV1(MetadataValidateReferenceRequestV1 metadataValidateReferenceRequestV1) {
        if (nonNull(metadataValidateReferenceRequestV1)
                && isNotEmpty(metadataValidateReferenceRequestV1.getReferences()))
            metadataSecurityProfilesApiFeign.validateVulnerabilityUserDefinedReferencesV1(metadataValidateReferenceRequestV1);
    }

    @Override
    public void validateVulnerabilityUserDefinedCveYearsV1(MetadataValidateIntListRequestV1 metadataValidateIntListRequestV1) {
        if (nonNull(metadataValidateIntListRequestV1)
                && isNotEmpty(metadataValidateIntListRequestV1.getData()))
            metadataSecurityProfilesApiFeign.validateVulnerabilityUserDefinedCveYearsV1(metadataValidateIntListRequestV1);
    }

    @Override
    public void validateIpFilteringGeoIpCountriesV1(MetadataValidateListRequestV1 metadataValidateListRequestV1) {
        if (nonNull(metadataValidateListRequestV1)
                && isNotEmpty(metadataValidateListRequestV1.getData()))
            metadataSecurityProfilesApiFeign.validateIPFilteringGeoIpCountriesV1(metadataValidateListRequestV1);
    }

    @Override
    public void validateIpFilteringReputationsV1(MetadataValidateListRequestV1 metadataValidateListRequestV1) {
        if (nonNull(metadataValidateListRequestV1)
                && isNotEmpty(metadataValidateListRequestV1.getData()))
            metadataSecurityProfilesApiFeign.validateIPFilteringReputationsV1(metadataValidateListRequestV1);
    }

    private <T> T extractBody(ResponseEntity<T> response) {
        HttpStatusCode status = null;
        T body = null;
        if (nonNull(response)) {
            status = response.getStatusCode();
            body = response.getBody();
        }

        if (!HttpStatus.OK.equals(status) || isNull(body)) {
            log.debug("Call was not successful for the following http status: {} and body: {}.", status, body);
        }

        return body;
    }
}
