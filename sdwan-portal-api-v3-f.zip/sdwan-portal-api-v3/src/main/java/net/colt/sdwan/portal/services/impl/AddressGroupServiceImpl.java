package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.mappers.AddressGroupMapper;
import net.colt.sdwan.portal.model.AddressGroupObjectCriteria;
import net.colt.sdwan.portal.model.AddressGroupsRequestV1;
import net.colt.sdwan.portal.model.AddressGroupsResponseV1;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.AddressGroupService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.portal.validator.access.CustomObjectValidator;
import net.colt.sdwan.sitesettings.api.generated.api.CustomObjectApiApi;
import net.colt.sdwan.sitesettings.api.generated.model.AddressGroupObjectCriteriaApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.AddressGroupsRequestApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.AddressGroupsResponseApiV1;
import org.slf4j.MDC;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

import static java.lang.Integer.parseInt;
import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.constant.CustomObjectConstants.ADDRESS_GROUP_NAME;
import static net.colt.sdwan.portal.model.OnGoingActionV2.MODIFYING_ADDRESS_GROUP_OBJECTS;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;

@Slf4j
@RequiredArgsConstructor
@Service
public class AddressGroupServiceImpl implements AddressGroupService {

    private final SitesService sitesService;
    private final SiteResponseValidator siteResponseValidator;
    private final ResponseEntityValidator responseEntityValidator;
    private final CustomObjectApiApi feign;
    private final AddressGroupMapper mapper;

    @Override
    public AddressGroupsResponseV1 getAddressGroupsV1(String siteId, AddressGroupObjectCriteria criteria, Integer pageNumber, Integer pageSize) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        CustomObjectValidator.validateAccess(siteResponse);

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final AddressGroupObjectCriteriaApiV1 criteriaApi = mapper.from(criteria);
        final ResponseEntity<AddressGroupsResponseApiV1> response = feign.getAddressGroupsV1(parseInt(siteId),
                siteResponse.getNetworkId(), criteriaApi, mapper.from(siteResponse.getSiteType()), pageNumber, pageSize, Pageable.unpaged());

        responseEntityValidator.checkResponseEntity(response, ADDRESS_GROUP_NAME);

        return mapper.from(response.getBody());
    }

    @Override
    public CorrelationIdResponseV1 updateAddressGroupsV1(String siteId, AddressGroupsRequestV1 request) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        CustomObjectValidator.validateAccess(siteResponse);

        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final AddressGroupsRequestApiV1 addressGroupsRequestApi = mapper.from(request);

        try {
            final List<String> deviceNamesFromSiteResponse = sitesService.getDeviceNamesFromSiteResponse(siteResponse);
            sitesService.updateOngoingAction(siteId, MODIFYING_ADDRESS_GROUP_OBJECTS);

            final ResponseEntity<Void> addressGroupsResponseEntity = feign.updateAddressGroupsV1(
                    Integer.valueOf(siteId), siteResponse.getNetworkId(), AuthUserHelper.getAuthUser().getUsername(),
                    mapper.from(siteResponse.getSiteType()), deviceNamesFromSiteResponse, addressGroupsRequestApi);

            responseEntityValidator.checkResponseEntity(addressGroupsResponseEntity, ADDRESS_GROUP_NAME);
        } catch (Exception ex) {
            log.error("Failed to update " + ADDRESS_GROUP_NAME + " for site with id {}", siteId, ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }

        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }
}
