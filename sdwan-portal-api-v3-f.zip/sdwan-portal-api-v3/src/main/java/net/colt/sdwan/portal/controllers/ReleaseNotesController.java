package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.ReleaseNotesApiApi;
import net.colt.sdwan.portal.model.ReleaseNotesResponseV1;
import net.colt.sdwan.portal.services.ReleaseNotesService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequiredArgsConstructor
@RestController
public class ReleaseNotesController implements ReleaseNotesApiApi {

    private final ReleaseNotesService releaseNotesService;

    @Override
    public ResponseEntity<List<ReleaseNotesResponseV1>> getReleaseNotesV1() {
        return ResponseEntity.ok(releaseNotesService.getReleaseNotes());
    }
}
