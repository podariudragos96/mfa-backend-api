package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.client.model.customerapi.UserResponseV3;
import net.colt.sdwan.portal.model.ApiUserKeyResponseModel;
import net.colt.sdwan.portal.model.ApiUserSessionResponseV1;

import java.util.List;

public interface ApiUserService {

    List<ApiUserSessionResponseV1> getApiUserDetails(UserResponseV3 userResponse);

    List<ApiUserSessionResponseV1> renewApiKeyV1(UserResponseV3 userResponse, String apiUserAgent);

    ApiUserKeyResponseModel getApiUserBasedOnKey(String apiKey, String userAgent);
}
