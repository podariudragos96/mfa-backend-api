package net.colt.sdwan.portal.client.helper;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.common.async.utils.ThreadUtils;
import net.colt.sdwan.portal.client.feign.customer.TenantFeign;
import net.colt.sdwan.portal.client.model.customerapi.EditTenantRequestV1;
import net.colt.sdwan.portal.client.model.customerapi.TenantResponseV1;
import net.colt.sdwan.portal.util.CompletableFutureUtil;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

@RequiredArgsConstructor
@Component
public class TenantClientHelper {

    private final TenantFeign tenantFeign;

    public List<Integer> getCustomerIdsByTenantIds(List<Integer> tenantIds) {
        List<TenantResponseV1> tenantsResponses = findAllByIdList(tenantIds);
        return tenantsResponses.stream().map(TenantResponseV1::getCustomerId).distinct().toList();
    }

    public List<TenantResponseV1> findAllByIdList(List<Integer> tenantIds) {
        List<CompletableFuture<ResponseEntity<TenantResponseV1>>> tenants = tenantIds.stream()
                .map(tenantId -> CompletableFuture.supplyAsync(ThreadUtils.withMdc(() -> tenantFeign.getTenantByIdV1(tenantId))))
                .toList();

        final Set<ResponseEntity<TenantResponseV1>> tenantsResponses = CompletableFutureUtil.getCompletableFutureValues(tenants);

        return tenantsResponses.stream().filter(tenant -> HttpStatus.OK.equals(tenant.getStatusCode()))
                .map(HttpEntity::getBody).toList();
    }

    public List<TenantResponseV1> getTenantByParams(Integer customerId, String domain, String versaOrg) {
        List<TenantResponseV1> result = null;
        ResponseEntity<List<TenantResponseV1>> response = tenantFeign.getTenantByParamsV1(customerId, domain, versaOrg);
        if (Objects.nonNull(response) && HttpStatus.OK.equals(response.getStatusCode())) {
            result = response.getBody();
        } else {
            result = new ArrayList<>();
        }
        return result;
    }

    /**
     * Get tenant response from id by calling customer-api.
     *
     * @param tenantId requested identifier
     * @return the tenant response or null if tenant id doesn't exist.
     */
    public TenantResponseV1 findById(Integer tenantId) {
        TenantResponseV1 result = null;

        ResponseEntity<TenantResponseV1> response = tenantFeign.getTenantByIdV1(tenantId);

        if (Objects.nonNull(response) && HttpStatus.OK.equals(response.getStatusCode())) {
            result = response.getBody();
        }
        return result;
    }

    public void editTenant(Integer tenantId, EditTenantRequestV1 request) {
        tenantFeign.editTenantV1(tenantId, request);
    }

}
