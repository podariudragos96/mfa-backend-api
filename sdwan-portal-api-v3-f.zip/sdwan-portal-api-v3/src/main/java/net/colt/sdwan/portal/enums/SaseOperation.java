package net.colt.sdwan.portal.enums;

public enum SaseOperation {

    // Tenant operations
    TENANT_GET("Get Sase Tenant"),
    TENANT_PUBLISH("Tenant Publish"),

    // Authentication Profiles operations
    AUTHENTICATION_PROFILE_GET("Get Sase Authentication Profile"),

    // Tasks operations
    TASKS_GET("Get Sase Tasks"),
    TASK_GET("Get Sase Task"),

    // Internet Protection Operations
    INTERNET_PROTECTION_RULES_GET("Get Internet Protection Rules"),

    // Secure Access Client operations
    SECURE_ACCESS_CLIENT_RULES_GET("Get Sase Secure Access Client Rules"),
    SECURE_ACCESS_CLIENT_PROFILES("Get Sase Secure Access Client Profiles"),

    // Site to Site Tunnel operations
    SITE_TO_SITE_TUNNELS_GET("Get Site to Site Tunnels"),

    // Catalog operations
    CATALOG_GEOIP_COUNTRIES_GET("Get GeoIp Countries Catalog"),
    CATALOG_URL_CATEGORIES_GET("Get Url Categories Catalog"),
    CATALOG_URL_REPUTATIONS_GET("Get Url Reputations Catalog"),
    CATALOG_APPLICATIONS_GET("Get Applications Catalog"),
    CATALOG_APPLICATION_CATEGORIES_GET("Get Application Categories Catalog"),
    CATALOG_APPLICATION_GROUPS_GET("Get Application Groups Catalog"),
    CATALOG_SERVICES_GET("Get Services Catalog"),
    CATALOG_SECURITY_PROFILES_GET("Get Services Catalog"),
    CATALOG_STATIC_ZONES_GET("Get Static Zones Catalog"),
    CATALOG_ENDPOINT_PROTECTIONS_GET("Get Endpoint Protections Catalog"),
    CATALOG_OPERATING_SYSTEMS_GET("Get Operating Systems Catalog"),
    CATALOG_SASE_APPLICATIONS_GET("Get Sase Applications Catalog");

    private final String name;

    SaseOperation(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
