package net.colt.sdwan.portal.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SiteConstants {
    public static final String SITE_EXPORT_INVALID_SITE = "Invalid site : Site export requires an existing site";
}
