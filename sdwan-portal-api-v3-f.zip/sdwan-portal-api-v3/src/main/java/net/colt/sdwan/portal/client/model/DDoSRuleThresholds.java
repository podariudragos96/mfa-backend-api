package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.*;


@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DDoSRuleThresholds {

    @NotNull(message = "activate-rate can't be null")
    @Max(value = 100000, message = "Active Rate max values is 100000")
    @Min(value = 1, message = "Active Rate minimum values is 1")
    @JsonProperty("activate-rate")
    private Integer activateRate;

    @NotNull(message = "alarm-rate can't be null")
    @Max(value = 100000, message = "Alarm Rate max values is 100000")
    @Min(value = 1, message = "Alarm Rate minimum values is 1")
    @JsonProperty("alarm-rate")
    private Integer alarmRate;

    @NotNull(message = "maximal-rate can't be null")
    @Max(value = 100000, message = "Maximal Rate max values is 100000")
    @Min(value = 1, message = "Maximal Rate minimum values is 1")
    @JsonProperty("maximal-rate")
    private Integer maximalRate;

    @NotNull(message = "drop-period can't be null")
    @Max(value = 18000, message = "Drop Rate max values is 18000")
    @Min(value = 1, message = "Drop Rate minimum values is 1")
    @JsonProperty("drop-period")
    private Integer dropPeriod;
}
