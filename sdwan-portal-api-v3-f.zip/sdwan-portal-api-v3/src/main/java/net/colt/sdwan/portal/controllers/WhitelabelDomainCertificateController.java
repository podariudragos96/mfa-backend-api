package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.WhitelabelDomainCertificateApiApi;
import net.colt.sdwan.portal.services.WhitelabelDomainCertificateService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class WhitelabelDomainCertificateController implements WhitelabelDomainCertificateApiApi {

    private final WhitelabelDomainCertificateService whitelabelDomainCertificateService;

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANRWWLTenantRole')")
    public ResponseEntity<Void> uploadCertificates(String domain, List<MultipartFile> files) {
        whitelabelDomainCertificateService.uploadCertificates(domain, files);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
