package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.MfaApiApi;
import net.colt.sdwan.portal.model.FinalTokenResponseV1;
import net.colt.sdwan.portal.model.SendEmailRequestV1;
import net.colt.sdwan.portal.model.SendSmsRequestV1;
import net.colt.sdwan.portal.model.StartTotpSessionRequestV1;
import net.colt.sdwan.portal.model.StartTotpSessionResponseV1;
import net.colt.sdwan.portal.model.VerifyEmailRequestV1;
import net.colt.sdwan.portal.model.VerifySmsReqApiV1;
import net.colt.sdwan.portal.model.VerifyTotpRequestV1;
import net.colt.sdwan.portal.services.MfaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

@RequiredArgsConstructor
@Controller
public class MfaController implements MfaApiApi {

    private final MfaService mfaService;

    @Override
    public ResponseEntity<Void> sendMfaEmailV1(SendEmailRequestV1 sendEmailRequestV1) {
        mfaService.sendMfaEmail(sendEmailRequestV1);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @Override
    public ResponseEntity<FinalTokenResponseV1> verifyMfaEmailV1(VerifyEmailRequestV1 verifyEmailRequestV1) {
        return ResponseEntity.ok(mfaService.verifyMfaEmail(verifyEmailRequestV1));
    }

    @Override
    public ResponseEntity<Void> sendMfaSmsV1(SendSmsRequestV1 sendSmsRequestV1) {
        mfaService.sendMfaSms(sendSmsRequestV1);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @Override
    public ResponseEntity<FinalTokenResponseV1> verifyMfaSmsV1(VerifySmsReqApiV1 verifySmsReqApiV1) {
        return ResponseEntity.ok(mfaService.verifyMfaSms(verifySmsReqApiV1));
    }

    @Override
    public ResponseEntity<StartTotpSessionResponseV1> startTotpSessionV1(StartTotpSessionRequestV1 startTotpSessionRequestV1) {
        return ResponseEntity.ok(mfaService.startTotpSession(startTotpSessionRequestV1));
    }

    @Override
    public ResponseEntity<FinalTokenResponseV1> verifyTotpV1(VerifyTotpRequestV1 verifyTotpRequestV1) {
        return ResponseEntity.ok(mfaService.verifyTotp(verifyTotpRequestV1));
    }

    @Override
    public ResponseEntity<Void> deleteTotpConfigsV1(DeleteTotpRequestV1 deleteTotpRequestV1) {
        mfaService.deleteTotpConfigs(deleteTotpRequestV1);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}