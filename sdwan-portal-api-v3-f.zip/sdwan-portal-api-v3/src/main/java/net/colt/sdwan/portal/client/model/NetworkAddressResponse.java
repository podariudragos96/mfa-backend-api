package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * NetworkAddressResponseV1
 */
@Setter
@Getter
@NoArgsConstructor
public class NetworkAddressResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("ip")
    @Valid
    private List<String> ip = null;

    @JsonProperty("port")
    @Valid
    private List<Range> port = null;
}

