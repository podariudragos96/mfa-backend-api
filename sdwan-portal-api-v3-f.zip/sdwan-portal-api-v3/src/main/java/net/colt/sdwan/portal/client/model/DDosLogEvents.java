package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DDosLogEvents {

    @JsonProperty("receive_time")
    private String receiveTime;

    @JsonProperty("thread_type")
    private String threadType;

    @JsonProperty("attacker_name")
    private String attackerName;

    @JsonProperty("attacker")
    private String attacker;

    @JsonProperty("victim")
    private String victim;

    @JsonProperty("scan_ports_count")
    private int scanPortsCount;

    @JsonProperty("action")
    private String action;

    @JsonProperty("from_zone")
    private String fromZone;

    @JsonProperty("to_zone")
    private String toZone;

    @JsonProperty("severity_level")
    private String severityLevel;

    @JsonProperty("vsn_id")
    private int vsnId;

    @JsonProperty("appliance_name")
    private String applianceName;

}
