package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.model.versa.sase.api.SecureAccessClientRulesRequestApiV1;
import net.colt.sdwan.generated.model.versa.sase.api.SecureAccessClientRulesResponseApiV1;
import net.colt.sdwan.portal.model.SaseSecureAccessClientRulesRequestV1;
import net.colt.sdwan.portal.model.SaseSecureAccessClientRulesResponseV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SaseSecureAccessClientRuleMapper {

    private final ModelMapper modelMapper;

    public SaseSecureAccessClientRulesResponseV1 from(SecureAccessClientRulesResponseApiV1 rulesResponseApiV1) {
        return modelMapper.map(rulesResponseApiV1, SaseSecureAccessClientRulesResponseV1.class);
    }

    public SecureAccessClientRulesRequestApiV1 from(SaseSecureAccessClientRulesRequestV1 rulesRequestV1) {
        return modelMapper.map(rulesRequestV1, SecureAccessClientRulesRequestApiV1.class);
    }

}
