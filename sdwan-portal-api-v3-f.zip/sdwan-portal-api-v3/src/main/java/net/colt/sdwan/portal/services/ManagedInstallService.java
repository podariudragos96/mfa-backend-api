package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.ManagedInstallPatchRequestV1;
import net.colt.sdwan.portal.model.ManagedInstallResponseV1;

import java.util.List;

public interface ManagedInstallService {

    List<ManagedInstallResponseV1> getAllManagedInstallOrders();

    ManagedInstallResponseV1 patchManagedInstallOrders(String id, ManagedInstallPatchRequestV1 managedInstallPatchRequest);

    ManagedInstallResponseV1 getManagedInstallOrderById(String id);
}
