package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.model.NetworkAddressResponseV1;
import net.colt.sdwan.portal.util.CGWUtil;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import static net.colt.sdwan.portal.util.PortStringSerializer.fromCSV;
import static net.colt.sdwan.portal.util.StaticInfo.*;

public class SecurityCommonMapper extends CommonMapper {

    protected NetworkAddressResponseV1 buildNetworkAddressResponse(List<String> destinationIps, String destinationPort) {
        return new NetworkAddressResponseV1()
                .ip(destinationIps)
                .port(fromCSV(destinationPort));
    }


    protected boolean isDefaultRule(final String ruleName, final SiteResponseV1 siteResponse) {
        return Arrays.asList(DEFAULT_DENY_RULE_FOR_INTERNET_ACCESS, DEFAULT_SDWAN_DENY_INBOUND, DEFAULT_SDWAN_DENY_OUTBOUND).contains(ruleName)
                || (Objects.nonNull(siteResponse) && CGWUtil.isCloudGateway(siteResponse.getSiteType().getValue()) && CGW_DEFAULT_RULES.contains(ruleName)
                || (Objects.nonNull(siteResponse) && CGWUtil.isGateway(siteResponse.getSiteType().getValue()) && GW_DEFAULT_FW_RULES.contains(ruleName)));
    }

    protected List<String> constructNetworkString(final List<String> networks) {
        if (!networks.isEmpty()) {

            return networks.stream()
                    .map(network -> {
                        if (network.equalsIgnoreCase("sdwan")) {
                            return SDWAN;
                        } else {
                            return StringUtils.upperCase(network.toLowerCase());
                        }
                    })
                    .toList();

        }
        return networks;
    }
}
