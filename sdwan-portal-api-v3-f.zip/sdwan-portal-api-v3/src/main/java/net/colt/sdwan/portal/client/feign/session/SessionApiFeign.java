package net.colt.sdwan.portal.client.feign.session;

import net.colt.sdwan.session.api.generated.api.SdwanSessionApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "sessionApiClient", url = "${sdwan.session.api.baseurl}",
        configuration = SessionApiFeignConfiguration.class)
public interface SessionApiFeign extends SdwanSessionApiApi {
}
