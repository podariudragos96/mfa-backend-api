package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@NoArgsConstructor
public class FirewallRulesNamesNetworkApiResponse {
    @JsonProperty("qTime")
    private Integer qTime;
    @JsonProperty("data")
    private List<FirewallRulesNamesData> data;
}
