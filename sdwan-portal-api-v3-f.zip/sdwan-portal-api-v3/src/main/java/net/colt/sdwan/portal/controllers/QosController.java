package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.QoSApiApi;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.QosService;
import net.colt.sdwan.portal.validator.model.QoSPolicyPortalRequestV1Validator;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

import static org.springframework.http.HttpStatus.OK;

@RequiredArgsConstructor
@Controller
public class QosController implements QoSApiApi {

    private final QosService qosService;
    private final QoSPolicyPortalRequestV1Validator validator;

    @InitBinder("QoSPolicyPortalRequestV1")
    public void initBinderQoSPolicyPortalRequest(WebDataBinder binder) {
        binder.setValidator(validator);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<QoSPolicyPortalResponseV1> getQoSPoliciesBySiteIdV1(String siteId) {
        return ResponseEntity.ok(qosService.getQosPoliciesV1(siteId));
    }


    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<QoSPolicyPortalResponseV1> getAppQoSPoliciesBySiteIdV1(String siteId) {
        return ResponseEntity.ok(qosService.getAppQosPoliciesV1(siteId));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<List<QoSPolicyPortalHistoryResponseV1>> getAppQoSPoliciesHistoryBySiteIdV2(String siteId) {
        return ResponseEntity.ok(qosService.getAppQosPoliciesHistoryV2(siteId));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<QoSPolicyPortalResponseV1> getAppQoSPoliciesHistoryBySiteIdAndRuleSetIdV1(String siteId,
                                                                                                    String id) {
        return ResponseEntity.ok(qosService.getAppQosPoliciesHistoryByIdV1(siteId, id));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/qos/app_qos_policies")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateAppQoSPoliciesBySiteIdV1(String siteId,
                                                                                  @RequestBody QoSPolicyPortalRequestV1 qoSPolicyPortalRequestV1) {
        return ResponseEntity.ok(qosService.updateQosPoliciesV1(siteId, qoSPolicyPortalRequestV1));
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole', 'SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> getQosPoliciesStatsV1(
            String siteId,
            String deviceId) {
        return ResponseEntity.ok(qosService.getQosPoliciesStatsV1(siteId, deviceId));
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole', 'SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> getAppQosPoliciesStatsV1(
            String siteId,
            String deviceId) {
        return ResponseEntity.ok(qosService.getAppQosPoliciesStatsV1(siteId, deviceId));
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole', 'SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> getQosMappingStatsV1(
            String siteId,
            String deviceId) {
        return ResponseEntity.ok(qosService.getQosMappingStatsV1(siteId, deviceId));
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> getQosInterfacesStatsV1(
            String siteId,
            String deviceId,
            String interfaceId,
            String type) {
        return new ResponseEntity<>(qosService.getQosInterfacesStats(siteId, deviceId, interfaceId, type), OK);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<QosBusinessClassesResponseV1> getQosBusinessClassesV1(String siteId) {
        return ResponseEntity.ok(qosService.getQosBusinessClassesV1(siteId));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/qos/business_classes")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateQosBusinessClassesV1(String siteId, QoSBusinessClassesRequestV1 qoSBusinessClassesRequestV1) {
        return ResponseEntity.ok(qosService.updateQosBusinessClassesV1(siteId, qoSBusinessClassesRequestV1));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<QoSInterfacesStatusResponseV1> getQosInterfacesStatusV1(String siteId) {
        return ResponseEntity.ok(qosService.getQosInterfacesStatusV1(siteId));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/qos/qos_interfaces_status")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateQosInterfacesStatusV1(String siteId, QoSInterfacesStatusRequestV1 qoSInterfacesStatusRequestV1) {
        return ResponseEntity.ok(qosService.updateQosInterfacesStatusV1(siteId, qoSInterfacesStatusRequestV1));
    }
}
