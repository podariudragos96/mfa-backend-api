package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import jakarta.validation.Valid;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * NetFlowRuleResponse
 */
@Setter
@Getter
@NoArgsConstructor
public class NetFlowRuleResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("priority")
    private Integer priority;

    @JsonProperty("name")
    private String name;

    @JsonProperty("destination")
    @Valid
    private List<NetworkAddressResponse> destination = new ArrayList<>();

    @JsonProperty("source")
    @Valid
    private List<NetworkAddressResponse> source = new ArrayList<>();

    @JsonProperty("applications")
    @Valid
    private List<String> applications = null;
    @JsonProperty("log_at")
    private LogAtEnum logAt;

    /**
     * Gets or Sets logAt
     */
    public enum LogAtEnum {
        START_AND_END("START_AND_END"),

        INTERIM("INTERIM");

        private String value;

        LogAtEnum(String value) {
            this.value = value;
        }

        @JsonCreator
        public static LogAtEnum fromValue(String text) {
            for (LogAtEnum b : LogAtEnum.values()) {
                if (String.valueOf(b.value).equals(text)) {
                    return b;
                }
            }
            throw new IllegalArgumentException("Unexpected value '" + text + "'");
        }

        @Override
        @JsonValue
        public String toString() {
            return String.valueOf(value);
        }
    }
}

