package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.*;

import java.time.LocalDateTime;
import java.util.List;

public interface DecryptionService {
    List<SSLDecryptionLogsResponseV1> getSSLDecryptionLogsBySiteIdV1(final String siteId, LocalDateTime startDt,
                                                                     LocalDateTime endDt);

    DecryptionRuleSetResponseV1 getDecryptionRulesBySiteIdV2(String siteId);

    CorrelationIdResponseV1 updateDecryptionRulesBySiteIdV2(String siteId,
                                                            DecryptionRulesRequestV1 decryptionRulesRequestV1);

    DecryptionRuleSetResponseV1 getDecryptionRulesHistoryBySiteIdAndRulesSetIdV2(String siteId, String ruleSetId);

    List<DecryptionRulesHistoryResponseV1> getDecryptionRulesHistoryBySiteIdV2(String siteId);
}
