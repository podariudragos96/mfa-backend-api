package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.qos.api.generated.model.*;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class QosMapper {

    private final ModelMapper modelMapper;

    public QoSPolicyPortalResponseV1 mapQoSPolicyResponseV1(QoSPolicyApiResponseV1 qoSPolicyResponseV1) {
        return modelMapper.map(qoSPolicyResponseV1, QoSPolicyPortalResponseV1.class);
    }

    public QosBusinessClassesResponseV1 from(QosBusinessClassesApiResponseV1 qosBusinessClasses, SiteResponseV1 siteResponse) {
        QosBusinessClassesResponseV1 response = modelMapper.map(qosBusinessClasses, QosBusinessClassesResponseV1.class);
        response.setEditable(!siteResponse.getSiteFeatures().getQos().getMplsQosEnabled());
        return response;
    }

    public QosBusinessClassesApiRequestV1 from(QoSBusinessClassesRequestV1 qosBusinessClasses) {
        return modelMapper.map(qosBusinessClasses, QosBusinessClassesApiRequestV1.class);
    }

    public QoSInterfacesStatusResponseV1 from(QoSInterfacesStatusResponseApiV1 qoSInterfacesStatus) {
        return modelMapper.map(qoSInterfacesStatus, QoSInterfacesStatusResponseV1.class);
    }

    public QoSInterfacesStatusRequestApiV1 from(QoSInterfacesStatusRequestV1 qoSInterfacesStatusRequest) {
        return modelMapper.map(qoSInterfacesStatusRequest, QoSInterfacesStatusRequestApiV1.class);
    }
}
