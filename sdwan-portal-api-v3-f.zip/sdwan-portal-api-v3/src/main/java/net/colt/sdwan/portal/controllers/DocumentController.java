package net.colt.sdwan.portal.controllers;

import io.swagger.annotations.ApiParam;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.DocumentApiApi;
import net.colt.sdwan.portal.services.DocumentService;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RestController
public class DocumentController implements DocumentApiApi {

    private final DocumentService documentService;

    @Override
    public ResponseEntity<Resource> getDocumentV1(
            @ApiParam(value = "type of document required", required = true) @Valid
            @RequestParam(value = "type") String type,
            @ApiParam(value = "user preferred language", required = true)
            @RequestParam(value = "language") String language) {
        return documentService.getDocument(type, language);
    }
}
