package net.colt.sdwan.portal.security.factory;

import feign.FeignException;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.portal.client.feign.session.SessionApiFeign;
import net.colt.sdwan.portal.client.model.customerapi.UserResponseV3;
import net.colt.sdwan.portal.mappers.UserModelMapper;
import net.colt.sdwan.portal.model.SessionResponseV1;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.session.api.generated.model.CreateSessionResponseV1;
import net.colt.sdwan.session.api.generated.model.SdwanSessionRequestV1;
import net.colt.sdwan.session.api.generated.model.SdwanSessionResponseV1;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.List;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static net.colt.sdwan.portal.security.TokenFilter.X_AUTH_TOKEN;
import static org.apache.commons.lang3.StringUtils.isEmpty;

@RequiredArgsConstructor
@Component
@Slf4j
public class SecuritySessionFactory {

    private final SessionApiFeign sessionApiFeign;
    private final SitesService sitesService;

    /**
     * Register the successful authentication inside spring security
     *
     * @param user of type UserAuth
     */
    private void createSpringSession(final UserAuth user) {
        final Authentication authentication = new UsernamePasswordAuthenticationToken(user, "", user.getRoles());
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    /**
     * Refresh the authentication token for the given user
     *
     * @param user of type UserAuth
     * @return CreateSessionResponseV1 model
     */
    private CreateSessionResponseV1 refreshUserToken(final UserAuth user) {
        final SdwanSessionRequestV1 request = new SdwanSessionRequestV1()
                .userInfo(UserModelMapper.mapSessionResponseV1ToUserAuth(user));
        return sessionApiFeign.createSdwanSessionV1(request).getBody();
    }

    /**
     * Remove the authentication session for the currently logged in user
     */
    public void destroySession() {
        final ServletRequestAttributes servletRequestAttributes = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes());
        if (isNull(servletRequestAttributes)) {
            throw new SdwanBadRequestException("Unable to get request attributes from Context.");
        }

        final HttpServletRequest request = servletRequestAttributes.getRequest();
        final String token = request.getHeader(X_AUTH_TOKEN);
        if (isEmpty(token)) {
            throw new SdwanBadRequestException("Token not received.");
        }
        try {
            final SdwanSessionResponseV1 sessionV1 = sessionApiFeign.getSdwanSessionV1(token).getBody();
            if (nonNull(sessionV1)) {
                final String username = sessionV1.getSession().getUsername();
                log.debug("Attempting to delete the authentication session for user: {}", username);
                final List<String> siteIds = sitesService.getLockedSites(username);
                sitesService.unlockSites(siteIds, username);
                sessionApiFeign.deleteSdwanSessionV1(token);
            }
        } catch (FeignException fe) {
            log.error("Failed to process operations for SD-WAN token: {}", fe.getMessage());
        } finally {
            SecurityContextHolder.getContext().setAuthentication(null);
        }
    }

    /**
     * This method asks to sessionFactory to factory the authentication session for spring security
     * and then it builds the needed corresponding response for the user.
     *
     * @param userResponse of UserResponseV2
     * @return SessionResponse
     */
    public SessionResponseV1 getSession(UserResponseV3 userResponse) {
        log.debug("Building authentication session for userAuth: {}", userResponse.getUsername());
        final UserAuth userAuth = UserModelMapper.mapAuthUserFromUserResponseV3(userResponse);
        createSpringSession(userAuth);
        log.debug("Building session response for userAuth: {}", userAuth.getUsername());
        final CreateSessionResponseV1 sessionResponseV1 = refreshUserToken(userAuth);

        if (sessionResponseV1 != null) {
            return new SessionResponseV1().token(sessionResponseV1.getToken());
        } else {
            throw new SdwanInternalServerErrorException("Unable to get session for user=" + userAuth.getUsername());
        }
    }
}
