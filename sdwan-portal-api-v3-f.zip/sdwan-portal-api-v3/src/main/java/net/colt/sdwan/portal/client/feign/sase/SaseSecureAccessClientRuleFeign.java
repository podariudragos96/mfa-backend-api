package net.colt.sdwan.portal.client.feign.sase;

import net.colt.sdwan.generated.controller.versa.sase.api.SecureAccessClientRuleApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "saseSecureAccessClientRuleFeign", url = "${sdwan.sase.api.baseurl}",
        configuration = SaseApiFeignConfiguration.class)
public interface SaseSecureAccessClientRuleFeign extends SecureAccessClientRuleApiApi {
}
