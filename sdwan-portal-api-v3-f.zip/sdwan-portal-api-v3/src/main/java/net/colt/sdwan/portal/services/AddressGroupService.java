package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.AddressGroupObjectCriteria;
import net.colt.sdwan.portal.model.AddressGroupsRequestV1;
import net.colt.sdwan.portal.model.AddressGroupsResponseV1;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;

public interface AddressGroupService {

    AddressGroupsResponseV1 getAddressGroupsV1(String siteId, AddressGroupObjectCriteria criteria, Integer pageSize, Integer pageSize1);

    CorrelationIdResponseV1 updateAddressGroupsV1(String siteId, AddressGroupsRequestV1 request);
}
