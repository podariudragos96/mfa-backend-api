package net.colt.sdwan.portal.services.impl;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.utils.SdwanExceptionUtils;
import net.colt.sdwan.generated.model.versa.sase.api.SecureAccessClientRulesResponseApiV1;
import net.colt.sdwan.portal.client.feign.sase.SaseSecureAccessClientRuleFeign;
import net.colt.sdwan.portal.enums.SaseOperation;
import net.colt.sdwan.portal.mappers.SaseSecureAccessClientRuleMapper;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SaseSecureAccessClientRulesRequestV1;
import net.colt.sdwan.portal.model.SaseSecureAccessClientRulesResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.SaseSecureAccessClientRuleService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;

@Service
@RequiredArgsConstructor
@Slf4j
public class SaseSecureAccessClientRuleServiceImpl implements SaseSecureAccessClientRuleService {

    private final ResponseEntityValidator responseEntityValidator;
    private final SaseSecureAccessClientRuleMapper mapper;
    private final SaseSecureAccessClientRuleFeign feign;

    @Override
    public SaseSecureAccessClientRulesResponseV1 getSecureAccessClientRulesV1(String tenantUuid) {
        log.info("Getting Secure Access Client Rules via sase api for tenantUuid={}", tenantUuid);
        final ResponseEntity<SecureAccessClientRulesResponseApiV1> response = feign
                .getSecureAccessClientRulesV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.SECURE_ACCESS_CLIENT_RULES_GET.getName());
        log.info("Get Secure Access Client Rules request completed successfully for tenantUuid={}", tenantUuid);
        return mapper.from(response.getBody());
    }

    @Override
    public CorrelationIdResponseV1 updateSecureAccessClientRulesV1(
            String tenantUuid,
            SaseSecureAccessClientRulesRequestV1 saseSecureAccessClientRulesRequestV1) {
        log.info("Updating Secure Access Client Rules for tenantUuid={} ...", tenantUuid);
        try {
            final UserAuth userAuth = requireNonNull(AuthUserHelper.getAuthUser());
            feign.updateSecureAccessClientRulesV1(userAuth.getUsername(), tenantUuid, mapper.from(saseSecureAccessClientRulesRequestV1));
        } catch (FeignException e) {
            final String errorMsg = String.format("Failed to update Secure Access Client Rules for tenantUuid=%s", tenantUuid);
            throw SdwanExceptionUtils.buildSdwanException(e.status(), errorMsg);
        }
        log.info("Update Secure Access Client Rules was completed successfully for tenantUuid={}", tenantUuid);
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

}
