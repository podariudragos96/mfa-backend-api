package net.colt.sdwan.portal.services.impl;

import feign.FeignException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.coltonlinemock.api.generated.model.ColtOnlineMockCountryCode;
import net.colt.sdwan.coltonlinemock.api.generated.model.ColtOnlineMockUserResponseV1;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.portal.client.feign.security.UserFeign;
import net.colt.sdwan.portal.client.model.customerapi.*;
import net.colt.sdwan.portal.mappers.UpdateUserRequestMapper;
import net.colt.sdwan.portal.model.SupportedLanguageV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.FeatureDetailsService;
import net.colt.sdwan.portal.services.UserService;
import net.colt.sdwan.portal.util.XColtHostUtil;
import net.colt.xml.ns.cum.v1.PartyType;
import net.colt.xml.ns.cum.v1.UserType;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.util.Objects.nonNull;
import static net.colt.sdwan.portal.client.model.customerapi.UserStatus.ACTIVE;
import static net.colt.sdwan.portal.constant.ErrorMessageConstants.FAILED_TO_CREATE_USER;
import static org.apache.commons.collections4.CollectionUtils.isNotEmpty;
import static org.apache.commons.lang3.StringUtils.*;


@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class UserServiceImpl implements UserService {

    private final XColtHostUtil xColtHostUtil;
    private final UserFeign userFeign;
    private final UpdateUserRequestMapper updateUserRequestMapper;
    private final FeatureDetailsService featureDetailsService;

    /**
     * Get the sdwan user by email
     *
     * @param username
     * @param customerId
     * @return Return the sdwan db entity
     */
    @Override
    public UserSummaryResponseV2 getUserSummaryByUsernameAndCustomerId(final String username, Integer customerId) {
        ResponseEntity<List<UserSummaryResponseV2>> userSummaryResponses = userFeign.getUserSummaryV3(username, ACTIVE);
        final List<UserSummaryResponseV2> body = userSummaryResponses.getBody();
        if (userSummaryResponses.getStatusCode().equals(HttpStatus.OK) && isNotEmpty(body)) {
            return body.get(0);
        }
        return null;
    }

    @Override
    public UserSummaryResponseV2 getUserSummaryByUsernameAndDomain(final String username, String domain) {
        ResponseEntity<List<UserSummaryResponseV2>> userSummaryResponses = userFeign.getUserSummaryV3(username, ACTIVE);
        Optional<UserSummaryResponseV2> result = Optional.empty();
        final List<UserSummaryResponseV2> body = userSummaryResponses.getBody();
        if (userSummaryResponses.getStatusCode().equals(HttpStatus.OK) && isNotEmpty(body)) {
            result = body.stream().filter(u -> isDomainEquivalent(u.getDomain(), domain)).findAny();
        }

        return result.orElse(null);
    }

    private boolean isDomainEquivalent(String userDomain, String requestDomain) {
        trimAndLowerCase(userDomain);

        userDomain = trimAndLowerCase(userDomain);
        requestDomain = trimAndLowerCase(requestDomain);
        String coltDomain = xColtHostUtil.getDefaultDomain();

        boolean result = isAllBlank(userDomain, requestDomain);
        result |= isBlank(userDomain) && StringUtils.equals(coltDomain, requestDomain);
        result |= isBlank(requestDomain) && StringUtils.equals(coltDomain, userDomain);
        result |= StringUtils.equals(userDomain, requestDomain);
        return result;
    }

    private String trimAndLowerCase(String value) {
        if (nonNull(value)) {
            value = value.toLowerCase().trim();
        }
        return value;
    }

    @Override
    public UserResponseV3 getUserByUsernameAndDomain(String username, String domain) {
        UserResponseV3 user = null;
        UserSummaryResponseV2 userSummary = getUserSummaryByUsernameAndDomain(username, domain);
        if (nonNull(userSummary)) {
            user = getUserById(userSummary.getUserId());
            user.setFeatures(featureDetailsService.findFeatureFlags(user.getAccessibleTenantIds()));
        }
        return user;
    }

    @Override
    public UserResponseV3 getUserById(final Integer userId) {
        ResponseEntity<UserResponseV3> userResponse = userFeign.getUserByIdV3(userId);
        if (userResponse.getStatusCode().equals(HttpStatus.OK)) {
            return userResponse.getBody();
        }
        String body = "";
        UserResponseV3 respBody = userResponse.getBody();
        if (userResponse.hasBody() && respBody != null) {
            body = respBody.toString();
        }
        log.debug("Error response received from CustomerApi: {} {}", userResponse.getStatusCode(), body);
        return null;
    }


    @Override
    public UserResponseV3 createUser(String generatedUsername, TenantUserApiV1 tenantUser, String domain, List<Integer> tenantIds) {
        CreateUserRequestV3 user = new CreateUserRequestV3()
                .title("MR(S).")
                .username(generatedUsername)
                .name(tenantUser.getUsername())
                .domain(domain)
                .email(tenantUser.getUsername() + "@" + domain + "." + tenantUser.getTenantId())
                .roles(tenantUser.getRoles().stream().map(TenantRole::getValue).toList())
                .tenantIds(tenantIds)
                .preferredLanguage(SupportedLanguage.EN)
                .status(ACTIVE)
                .countryCode(CountryCode.GB);
        return createUser(user);
    }

    private UserResponseV3 createUser(CreateUserRequestV3 user) {
        ResponseEntity<CreateUserResponseV2> createUserResponse;
        try {
            createUserResponse = userFeign.createUserV3(user);
        } catch (FeignException fe) {
            log.error(FAILED_TO_CREATE_USER, fe);
            throw fe;
        } catch (Exception e) {
            log.error(FAILED_TO_CREATE_USER, e);
            throw new SdwanInternalServerErrorException(FAILED_TO_CREATE_USER, e);
        }
        if (createUserResponse.getStatusCode().value() == HttpStatus.CREATED.value()) {
            final CreateUserResponseV2 createBody = createUserResponse.getBody();
            if (createBody != null) {
                ResponseEntity<UserResponseV3> userResponse = userFeign
                        .getUserByIdV3(createBody.getUserId());
                if (userResponse.getStatusCode().equals(HttpStatus.OK)) {
                    return userResponse.getBody();
                }
            }
            return null;
        }
        throw new SdwanInternalServerErrorException("Couldn't create user, received error from CustomerApi: " + createUserResponse.getBody());
    }

    /**
     * Create a new User for Colt Online Mock flow (non-prod env)
     *
     * @param coltOnlineMockUser Colt Online Mock Response
     * @param ocns               list of accessible customers
     * @return the created user
     */
    @Override
    public UserResponseV3 createUser(ColtOnlineMockUserResponseV1 coltOnlineMockUser, List<String> ocns) {
        final String countryCode = Optional.ofNullable(coltOnlineMockUser.getCountryCode())
                .map(ColtOnlineMockCountryCode::getValue)
                .orElse("");

        final String firstName = Optional.ofNullable(coltOnlineMockUser.getFirstName()).orElse("");
        final String lastName = Optional.ofNullable(coltOnlineMockUser.getLastName()).orElse("");

        final CreateUserRequestV3 user = new CreateUserRequestV3()
                .title(coltOnlineMockUser.getTitle())
                .name(firstName.concat(SPACE).concat(lastName))
                .username(coltOnlineMockUser.getUserId())
                .domain(xColtHostUtil.getDefaultDomain())
                .email(coltOnlineMockUser.getEmailAddress())
                .roles(coltOnlineMockUser.getRoles())
                .ocns(ocns)
                .preferredLanguage(SupportedLanguage.EN)
                .status(ACTIVE)
                .countryCode(getCountryCode(countryCode));

        return createUser(user);
    }

    /**
     * Create a new User for Colt Online Auth flow (prod env)
     *
     * @param userType Colt Online WS Auth Response
     * @param ocns     list of accessible customers
     * @return the created user
     */
    @Override
    public UserResponseV3 createUser(UserType userType, List<String> ocns) {

        final String firstName = Optional.ofNullable(userType.getFirstName()).orElse("");
        final String lastName = Optional.ofNullable(userType.getLastName()).orElse("");

        CreateUserRequestV3 user = new CreateUserRequestV3()
                .title(userType.getTitle())
                .name(firstName.concat(SPACE).concat(lastName))
                .username(userType.getUserId())
                .domain(xColtHostUtil.getDefaultDomain())
                .email(userType.getEmailAddress())
                .roles(userType.getUserRoles().getRoleName())
                .ocns(ocns)
                .preferredLanguage(SupportedLanguage.EN)
                .status(ACTIVE)
                .countryCode(getCountryCode(userType.getCountry()));
        return createUser(user);
    }

    private CountryCode getCountryCode(String countryCode) {
        if (isNotBlank(countryCode)) {
            try {
                return CountryCode.fromValue(countryCode);
            } catch (IllegalArgumentException exception) {
                log.warn("No matching country code found for.. {}", countryCode);
            }
        }
        // default country code
        return CountryCode.GB;
    }

    /**
     * Save a sdwan user entity
     *
     * @param userId
     * @param user
     * @return the saved entity
     */
    @Override
    public void save(Integer userId, final UpdateUserRequestV3 user) {
        ResponseEntity<Void> createUserResponseV2 = userFeign.updateUserV3(userId, user);
        if (!createUserResponseV2.getStatusCode().equals(HttpStatus.OK)) {
            throw new SdwanInternalServerErrorException("Couldn't create user, received error from CustomerApi: " + createUserResponseV2.getBody()
            );
        }
    }

    /**
     * Save a new customization and language for the loggedin user
     *
     * @param customization
     * @param language
     */
    @Override
    public void save(String customization, SupportedLanguageV1 language) {
        UserAuth userAuth = AuthUserHelper.getAuthUser();
        if (nonNull(language)) {
            userAuth.setPreferredLanguage(SupportedLanguage.fromValue(language.name().toLowerCase()));
        }
        if (nonNull(customization)) {
            userAuth.setCustomisation(customization);
        }
        save(userAuth.getUserId(), updateUserRequestMapper.mapFromResponse(userAuth));
    }

    public void updateExistingUser(
            final UserResponseV3 user, List<String> roles, List<String> validatedOcns) {
        UpdateUserRequestV3 request = updateUserRequestMapper.mapFromResponse(user);
        // accessible tenant ids from ocns
        request.tenantIds(null);
        request.setOcns(validatedOcns);
        request.roles(roles);
        request.setLastLoggedInDt(LocalDateTime.now());
        save(user.getUserId(), request);
    }

    /**
     * Collect Ocn List for a Colt Online User through Mock flow (non-prod env)
     *
     * @param coltOnlineMockUser Colt Online Mock Response
     * @return ocns list
     */
    public List<String> collectOcnList(final ColtOnlineMockUserResponseV1 coltOnlineMockUser) {
        List<String> ocns = new ArrayList<>();

        if (nonNull(coltOnlineMockUser.getPrimaryOcn())) {
            ocns.add(coltOnlineMockUser.getPrimaryOcn());
        }

        if (isNotEmpty(coltOnlineMockUser.getOcns())) {
            ocns.addAll(coltOnlineMockUser.getOcns().stream()
                    .filter(StringUtils::isNotBlank)
                    .distinct()
                    .toList());
        }

        return ocns;
    }

    /**
     * Collect Ocn List for a Colt Online User through Auth flow (prod env)
     *
     * @param userType Colt Online WS Auth Response
     * @return ocns list
     */
    public List<String> collectOcnList(final UserType userType) {
        List<String> ocns = new ArrayList<>();

        if (nonNull(userType.getPrimaryOcn())) {
            ocns.add(userType.getPrimaryOcn());
        }

        if (nonNull(userType.getUserPermissions())
                && isNotEmpty(userType.getUserPermissions().getAccessiblePartyAccount())) {

            ocns.addAll(
                    userType.getUserPermissions().getAccessiblePartyAccount().stream()
                            .map(PartyType::getOCN)
                            .filter(StringUtils::isNotBlank)
                            .distinct()
                            .toList());
        }

        return ocns;
    }

}
