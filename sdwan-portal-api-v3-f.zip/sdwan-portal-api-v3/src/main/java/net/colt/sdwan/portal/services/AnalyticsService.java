package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.*;

import java.time.LocalDateTime;
import java.util.List;

public interface AnalyticsService {

    InterfaceAnalyticsTimeSeriesDataResponseV2 getInterfaceAnalyticsBySiteIdAndDeviceIdAndInterfaceId(
            String siteId, String deviceId, String interfaceId, LocalDateTime startDate, LocalDateTime endDate);

    InterfaceAnalyticsTableDataResponseV1 getInterfaceAnalyticsTabularFormatBySiteIdAndDeviceIdV1(String siteId, String deviceId, String interfaceId, LocalDateTime startDt, LocalDateTime endDt);

    InterfaceApplicationAnalyticsResponseV1 getInterfaceApplicationAnalyticsBySiteIdAndDeviceIdAndInterfaceId(
            String siteId, String deviceId, String interfaceId, LocalDateTime startDate, LocalDateTime endDate, Integer count, List<String> applications);

    DdosAnalyticsTimeSeriesResponseV1 getDdosAnalyticsTimeSeriesBySiteId(
            String siteId, LocalDateTime startDate, LocalDateTime endDate);

    InterfaceApplicationAnalyticsTableResponseV1 getInterfaceApplicationAnalyticsTabularFormatBySiteIdAndDeviceIdAndInterfaceId(
            String siteId, String deviceId, String interfaceId, LocalDateTime startDate, LocalDateTime endDate, Integer count, List<String> applications);

    InterfaceQOSAnalyticsTimeSeriesDataResponseV1 getInterfaceQOSAnalyticsBySiteIdAndDeviceIdAndInterfaceId(String siteId, String deviceId, String interfaceId, LocalDateTime startDt, LocalDateTime endDt);

    SlaMetricsTimeSeriesDataResponseV1 getSlaMetricsTimeSeriesBySiteIdAndDeviceId(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, String remoteDeviceId, String interfaceId, Integer count);

    SlaMetricsTableDataResponseV1 getSlaMetricsTableDataBySiteIdAndDeviceId(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, String remoteDeviceId, String interfaceId, Integer count);

    FirewallRulesAnalyticsTableDataResponseV1 getFirewallRulesAnalyticsTableDataByNetworkId(String networkId, LocalDateTime startDate, LocalDateTime endDate, String deviceId, Integer count);

    FirewallZonesAnalyticsTableDataResponseV1 getFirewallZonesAnalyticsTableDataByNetworkId(String networkId, LocalDateTime startDate, LocalDateTime endDate, String deviceId, Integer count);

    FirewallRulesAnalyticsTimeSeriesDataResponseV1 getFirewallRulesAnalyticsTimeSeriesByNetworkId(String networkId, LocalDateTime startDate, LocalDateTime endDate, String deviceId, Integer count);

    FirewallZonesAnalyticsTimeSeriesDataResponseV1 getFirewallZonesAnalyticsTimeSeriesByNetworkId(String networkId, LocalDateTime startDate, LocalDateTime endDate, String deviceId, Integer count);

    TopUsageResponseV1 getTopAccessCircuitsByNetworkId(String networkId, LocalDateTime startDate, LocalDateTime endDate, Integer count);

    TopUsageResponseV1 getTopDevicesByNetworkId(String networkId, LocalDateTime startDate, LocalDateTime endDate, Integer count);

    UsageByPathAnalyticsTableDataResponseV1 getUsageByPathAnalyticsTableDataBySiteIdAndDeviceId(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, String remoteDeviceId, String interfaceId, Integer count);

    UsageByPathAnalyticsTimeSeriesDataResponseV1 getUsageByPathAnalyticsTimeSeriesBySiteIdAndDeviceId(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, String remoteDeviceId, String interfaceId, Integer count);

    UsersAnalyticsTableDataResponseV1 getUsersAnalyticsTableDataBySiteIdAndDeviceId(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, String interfaceId, Integer count);

    UsersAnalyticsTimeSeriesDataResponseV1 getUsersAnalyticsTimeSeriesBySiteIdAndDeviceId(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, String interfaceId, Integer count);

    List<AntivirusDetectionEventResponseV1> getAntivirusDetectionEvents(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, Integer count);

    List<SystemAnalyticsTimeSeriesResponseV1> getSystemTimeSeriesAnalytics(String siteId, String deviceId, LocalDateTime startDt, LocalDateTime endDt);

    List<VulnerabilityDetectionEventResponseV1> getVulnerabilityDetectionEvents(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, Integer count);

    List<IPFilteringDetectionEventResponseV1> getIpFilteringDetectionEvents(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, Integer count);

    VrfTimeSeriesAnalyticsResponseV1 getVrfTimeSeriesAnalytics(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, String interfaceId, Integer count);

    VrfTableDataAnalyticsResponseV1 getVrfTableDataAnalytics(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, String interfaceId, Integer count);

}
