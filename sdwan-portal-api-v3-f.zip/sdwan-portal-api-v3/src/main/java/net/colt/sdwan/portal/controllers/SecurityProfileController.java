package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.SecurityProfilesApiApi;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.AntivirusService;
import net.colt.sdwan.portal.services.IpFilteringService;
import net.colt.sdwan.portal.services.UrlFilteringService;
import net.colt.sdwan.portal.services.VulnerabilityService;
import net.colt.sdwan.portal.validator.model.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class SecurityProfileController implements SecurityProfilesApiApi {

    private final AntivirusService antivirusService;
    private final UrlFilteringService urlFilteringService;
    private final VulnerabilityService vulnerabilityService;
    private final IpFilteringService ipFilteringService;
    private final AntivirusProfilesRequestV1Validator antivirusValidator;
    private final URLFilteringProfilesRequestV1Validator urlFilteringValidator;
    private final UserDefinedVulnerabilityProfilesRequestV1Validator userDefinedVulnerabilityValidator;
    private final PredefinedOverrideVulnerabilityProfilesRequestV1Validator predefinedOverrideVulnerabilityValidator;
    private final IPFilteringProfilesRequestV1Validator ipFilteringValidator;

    @InitBinder("AntivirusProfilesRequestV1")
    public void initBinderAntivirus(WebDataBinder binder) {
        binder.setValidator(antivirusValidator);
    }

    @InitBinder("URLFilteringProfilesRequestV1")
    public void initBinderUrlFiltering(WebDataBinder binder) {
        binder.setValidator(urlFilteringValidator);
    }

    @InitBinder("UserDefinedVulnerabilityProfilesRequestV1")
    public void initBinderUserDefinedVulnerability(WebDataBinder binder) {
        binder.setValidator(userDefinedVulnerabilityValidator);
    }

    @InitBinder("PredefinedOverrideVulnerabilityProfilesRequestV1")
    public void initBinderPredefinedOverrideVulnerability(WebDataBinder binder) {
        binder.setValidator(predefinedOverrideVulnerabilityValidator);
    }

    @InitBinder("IPFilteringProfilesRequestV1")
    public void initBinderIpFiltering(WebDataBinder binder) {
        binder.setValidator(ipFilteringValidator);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole', 'SD-WANRWFirewallRole')")
    public ResponseEntity<AntivirusProfileResponseV1> getAntivirusProfilesV1(String siteId) {
        return ResponseEntity.ok(antivirusService.getAntivirusProfilesBySiteIdV1(siteId));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/security/profiles/antivirus")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateAntivirusProfilesV1(String siteId,
                                                                             @RequestBody AntivirusProfilesRequestV1 antivirusProfilesRequestV1) {
        return ResponseEntity.ok(antivirusService.updateAntivirusProfilesBySiteIdV1(siteId, antivirusProfilesRequestV1));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole', 'SD-WANRWFirewallRole')")
    public ResponseEntity<List<AntivirusProfileLogsResponseV1>> getAntivirusProfileLogsV1(String siteId, String profileName) {
        return ResponseEntity.ok(antivirusService.getAntivirusProfileLogsV1(siteId, profileName));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<URLFilteringProfileResponseV1> getURLFilteringProfilesV1(String siteId) {
        return ResponseEntity.ok(urlFilteringService.getProfilesBySiteId(siteId));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/security/profiles/url_filtering")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateURLFilteringProfilesV1(String siteId,
                                                                                @RequestBody URLFilteringProfilesRequestV1 urLFilteringProfilesRequestV1) {
        return ResponseEntity.ok(urlFilteringService.updateProfilesBySiteId(siteId, urLFilteringProfilesRequestV1));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<UserDefinedVulnerabilityProfilesResponseV1> getVulnerabilityUserDefinedProfilesV1(String siteId) {
        return ResponseEntity.ok(vulnerabilityService.getVulnerabilityUserDefinedProfilesV1(siteId));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/security/profiles/idp_vulnerability/user_defined")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateVulnerabilityUserDefinedProfilesV1(String siteId,
                                                                                            @RequestBody UserDefinedVulnerabilityProfilesRequestV1 userDefinedVulnerabilityProfilesRequestV1) {
        return ResponseEntity.ok(vulnerabilityService.updateVulnerabilityUserDefinedProfilesV1(siteId, userDefinedVulnerabilityProfilesRequestV1));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<PredefinedOverrideVulnerabilityProfilesResponseV1> getVulnerabilityPredefinedOverrideProfilesV1(String siteId) {
        return ResponseEntity.ok(vulnerabilityService.getVulnerabilityPredefinedOverrideProfilesV1(siteId));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/security/profiles/idp_vulnerability/predefined_override")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateVulnerabilityPredefinedOverrideProfilesV1(String siteId,
                                                                                                   @RequestBody PredefinedOverrideVulnerabilityProfilesRequestV1 predefinedOverrideVulnerabilityProfilesRequestV1) {
        return ResponseEntity.ok(vulnerabilityService.updateVulnerabilityPredefinedOverrideProfilesV1(siteId, predefinedOverrideVulnerabilityProfilesRequestV1));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole', 'SD-WANRWFirewallRole')")
    public ResponseEntity<List<VulnerabilityProfileLogsResponseV1>> getVulnerabilityProfileLogsV1(String siteId) {
        return ResponseEntity.ok(vulnerabilityService.getVulnerabilityProfileLogsV1(siteId));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<IPFilteringProfilesResponseV1> getIPFilteringProfilesV1(String siteId) {
        return ResponseEntity.ok(ipFilteringService.getIpFilteringProfilesV1(siteId));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/security/profiles/ip_filtering")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateIPFilteringProfilesV1(String siteId,
                                                                               @RequestBody IPFilteringProfilesRequestV1 ipFilteringProfilesRequestV1) {
        return ResponseEntity.ok(ipFilteringService.updateIpFilteringProfilesV1(siteId, ipFilteringProfilesRequestV1));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole', 'SD-WANRWFirewallRole')")
    public ResponseEntity<List<IPFilteringLogsResponseV1>> getIpFilteringProfileLogsV1(String siteId) {
        return ResponseEntity.ok(ipFilteringService.getIpFilteringProfileLogsV1(siteId));
    }
}
