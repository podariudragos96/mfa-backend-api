package net.colt.sdwan.portal.client.feign.security;

import net.colt.sdwan.security.api.generated.api.DdosApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "securityDdosApiFeign", url = "${sdwan.security.api.baseurl}",
        configuration = SecurityApiFeignConfiguration.class)
public interface SecurityDdosApiFeign extends DdosApiApi {
}
