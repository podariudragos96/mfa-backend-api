package net.colt.sdwan.portal.mappers;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.model.AntivirusProfileResponseV1;
import net.colt.sdwan.portal.model.AntivirusProfileV1;
import net.colt.sdwan.security.api.generated.model.AntivirusProfileApiV1;
import net.colt.sdwan.security.api.generated.model.AntivirusProfilesApiRequestV1;
import net.colt.sdwan.security.api.generated.model.AntivirusProfilesApiResponseV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
@Component
public class AntivirusProfileMapper {

    private final ModelMapper modelMapper;

    public AntivirusProfileResponseV1 from(AntivirusProfilesApiResponseV1 antivirusProfilesApi) {
        return modelMapper.map(antivirusProfilesApi, AntivirusProfileResponseV1.class);
    }

    public AntivirusProfilesApiRequestV1 from(List<AntivirusProfileV1> antivirusProfileV1) {
        final AntivirusProfilesApiRequestV1 antivirusProfilesApiResponse = new AntivirusProfilesApiRequestV1();

        if (!antivirusProfileV1.isEmpty()) {
            antivirusProfileV1.stream()
                    .map(antivirusProfile -> modelMapper.map(antivirusProfile, AntivirusProfileApiV1.class))
                    .forEach(antivirusProfilesApiResponse::addAntivirusProfilesItem);
        }
        return antivirusProfilesApiResponse;
    }
}
