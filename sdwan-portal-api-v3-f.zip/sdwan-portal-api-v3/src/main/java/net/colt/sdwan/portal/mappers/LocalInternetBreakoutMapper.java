package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.model.LocalInternetBreakoutPreferencesV1;
import net.colt.sdwan.sitesettings.api.generated.model.LocalInternetBreakoutPreferencesApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.LocalInternetBreakoutRequestApiV1;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface LocalInternetBreakoutMapper {

    default LocalInternetBreakoutRequestApiV1 from(List<LocalInternetBreakoutPreferencesV1> interfacesLIBPreferences) {
        return new LocalInternetBreakoutRequestApiV1()
                .localInternetBreakoutPreferences(interfacesLIBPreferences.stream().map(this::from).toList());
    }
    LocalInternetBreakoutPreferencesApiV1 from(LocalInternetBreakoutPreferencesV1 preference);

}
