package net.colt.sdwan.portal.services.impl;

import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.feign.security.SecurityFirewallsApiFeign;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.SecurityFirewallService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.util.CGWUtil;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.security.api.generated.model.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;
import java.util.Objects;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.portal.util.StaticInfo.SDWAN_INT_DENY;

@Service
@Slf4j
@RequiredArgsConstructor
public class SecurityFirewallServiceImpl implements SecurityFirewallService {

    private final SitesService sitesService;
    private final SecurityFirewallsApiFeign securityFirewallsApiFeign;
    private final ResponseEntityValidator responseEntityValidator;

    @Override
    public FirewallRuleSetResponseV2 getFirewallRulesBySiteIdV2(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        String siteType = siteResponse.getSiteType().getValue();
        requireNonNull(siteType);

        ResponseEntity<FirewallRuleSetResponseV2> response = securityFirewallsApiFeign.getFirewallRulesByNetworkAndSiteIdV2(
                siteResponse.getNetworkId(), siteId, mapSiteTypeEnum(siteType));

        checkResponse(response);

        return response.getBody();
    }

    @Override
    public List<FirewallRuleSetResponseV1> getFirewallRulesHistoryV1(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        ResponseEntity<List<FirewallRuleSetResponseV1>> response = securityFirewallsApiFeign
                .getFirewallRulesHistoryV1(siteId, siteResponse.getNetworkId(), SiteTypeV1.fromValue(siteResponse.getSiteType().getValue()));

        checkResponse(response);

        return response.getBody();
    }

    @Override
    public FirewallRuleSetResponseV2 getFirewallRulesHistoryByIdV2(String siteId, String ruleSetId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        ResponseEntity<FirewallRuleSetResponseV2> response = securityFirewallsApiFeign
                .getFirewallRulesHistoryByIdV2(siteId, siteResponse.getNetworkId(), ruleSetId, SiteTypeV1.fromValue(siteResponse.getSiteType().getValue()));

        checkResponseV2(response);

        return response.getBody();
    }

    @Override
    public void updateFirewallRulesByNetworkAndSiteIdV2(
            String siteId,
            List<String> deviceNames,
            String siteType,
            FirewallRulesRequestV2 firewallRulesRequestV2) {

        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final SiteTypeV1 siteTypeEnum = mapSiteTypeEnum(siteType);
        requireNonNull(siteTypeEnum);
        if (CGWUtil.isDedicatedGatewayOrGateway(siteType)) {
            checkRequestV2(firewallRulesRequestV2);
        }

        firewallRulesRequestV2.setInitiatedUserId(AuthUserHelper.getAuthUser().getUsername());
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        securityFirewallsApiFeign.updateFirewallRulesByNetworkAndSiteIdV2(
                siteResponse.getNetworkId(),
                siteId,
                deviceNames,
                mapSiteTypeEnum(siteResponse.getSiteType().getValue()),
                firewallRulesRequestV2);
    }

    private void checkRequestV2(FirewallRulesRequestV2 firewallRulesRequestV2) {
        if (Objects.nonNull(firewallRulesRequestV2)) {
            // Get last rule
            FirewallRuleRequestV2 lastRule =
                    firewallRulesRequestV2.getRuleSet().get(0).getRules().stream()
                            .reduce((rule1, rule2) -> rule2)
                            .orElse(null);

            if ((lastRule != null && !lastRule.getName().equals(SDWAN_INT_DENY))) {
                throw new SdwanBadRequestException("Bad request");
            }
        }
    }

    private void checkResponse(ResponseEntity<?> responseEntity) {
        responseEntityValidator.checkResponseEntity(responseEntity, "Firewall rules");
        Object body = responseEntity.getBody();
        if (body != null && ((body instanceof Collection &&
                ((Collection<?>) body).isEmpty())
                ||
                (responseEntity.getBody() instanceof FirewallRuleSetResponseV1 &&
                        isEmpty(((FirewallRuleSetResponseV1) body).getId())))) {
            throw new SdwanNotFoundException(HttpStatus.NOT_FOUND.getReasonPhrase());
        }
    }

    private void checkResponseV2(ResponseEntity<?> responseEntity) {
        responseEntityValidator.checkResponseEntity(responseEntity, "Firewall rules");
        final Object body = responseEntity.getBody();
        if (body != null && ((body instanceof Collection &&
                ((Collection<?>) body).isEmpty())
                ||
                (responseEntity.getBody() instanceof FirewallRuleSetResponseV1 &&
                        isEmpty(((FirewallRuleSetResponseV1) body).getId())))) {
            throw new SdwanNotFoundException(HttpStatus.NOT_FOUND.getReasonPhrase());
        }
    }

    private @NotNull SiteTypeV1 mapSiteTypeEnum(final String siteType) {
        SiteTypeV1 result;
        if (siteType.equalsIgnoreCase("branch")) {
            result = SiteTypeV1.BRANCH;
        } else if (siteType.equalsIgnoreCase("cloud_gateway")) {
            result = SiteTypeV1.CLOUD_GATEWAY;
        } else if (siteType.equalsIgnoreCase("gateway")) {
            result = SiteTypeV1.GATEWAY;
        } else if (siteType.equalsIgnoreCase("dedicated_gateway")) {
            result = SiteTypeV1.DEDICATED_GATEWAY;
        } else {
            throw new SdwanInternalServerErrorException("Invalid site type.");
        }

        return result;
    }

    private boolean isEmpty(String field) {
        return
                Objects.isNull(field) || field.equals("");
    }

}
