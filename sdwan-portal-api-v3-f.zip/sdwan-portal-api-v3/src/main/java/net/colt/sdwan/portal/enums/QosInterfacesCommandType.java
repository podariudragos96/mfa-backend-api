package net.colt.sdwan.portal.enums;

public enum QosInterfacesCommandType {

    BRIEF("brief"), DETAIL("detail"), EXTENSIVE("extensive"), SUMMARY("summary");

    private String value;

    QosInterfacesCommandType(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }

    public QosInterfacesCommandType findByValue(String value) {

        for (QosInterfacesCommandType val : QosInterfacesCommandType.values()) {
            if (val.getValue().equals(value)) {
                return val;
            }
        }

        return null;

    }
}
