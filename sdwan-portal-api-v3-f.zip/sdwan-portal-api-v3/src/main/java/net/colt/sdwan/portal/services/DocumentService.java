package net.colt.sdwan.portal.services;

import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;

public interface DocumentService {

    ResponseEntity<Resource> getDocument(String type, String userLanguage);
}
