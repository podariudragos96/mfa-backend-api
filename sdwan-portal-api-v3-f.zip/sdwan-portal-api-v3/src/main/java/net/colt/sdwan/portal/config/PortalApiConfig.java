package net.colt.sdwan.portal.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.portal.client.model.customerapi.TenantResponseV1;
import net.colt.sdwan.portal.client.model.customerapi.TenantRole;
import net.colt.sdwan.portal.model.TenantPortalResponseV1;
import net.colt.sdwan.portal.security.TokenFilter;
import org.modelmapper.AbstractConverter;
import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@RequiredArgsConstructor
@Configuration
@EnableCaching
@Slf4j
public class PortalApiConfig implements WebMvcConfigurer {

    private final ApplicationContext context;

    @Bean
    public ModelMapper modelMapper() {
        final ModelMapper modelMapper = new ModelMapper();

        // Converter from string to ColtOnlineRole
        final Converter<String, TenantRole> toEnum = new AbstractConverter<>() {
            protected TenantRole convert(String source) {
                try {
                    return TenantRole.fromValue(source);
                } catch (IllegalArgumentException iae) {
                    log.error("ModelMapper: converting to ColtOnlineRole failed", iae);
                    throw new SdwanBadRequestException(String.format("ModelMapper: converting to ColtOnlineRole failed because %s.", iae.getMessage()), iae);
                }
            }
        };
        modelMapper.addConverter(toEnum);

        final PropertyMap<TenantResponseV1, TenantPortalResponseV1> versaOrgMap = new PropertyMap<>() {
            @Override
            protected void configure() {
                map().setNetworkName(source.getVersaOrg());
            }
        };
        modelMapper.addMappings(versaOrgMap);

        return modelMapper;
    }

    @SuppressWarnings("deprecation")
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                        .allowedMethods("HEAD", "GET", "PUT", "POST", "DELETE", "PATCH");
            }
        };
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(context.getBean(TokenFilter.class))
                .addPathPatterns("/**");
    }
}
