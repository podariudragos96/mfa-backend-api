package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.LocalInternetBreakoutPreferencesV1;

import java.util.List;

/**
 * Local Internet Breakout service
 */
public interface LIBService {

    List<LocalInternetBreakoutPreferencesV1> getLIBPreferences(final String siteId);

    CorrelationIdResponseV1 updateLIBPreferences(final String siteId, final List<LocalInternetBreakoutPreferencesV1> libPreferences);
}
