package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.client.model.customerapi.TenantUsersCriteriaApiV1;
import net.colt.sdwan.portal.model.TenantUsersCriteriaV1;

public interface TenantUserMapper extends CommonObjectMapper{

    TenantUsersCriteriaApiV1 from (TenantUsersCriteriaV1 criteria);
}
