package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class SiteToDeviceResponse {

    @JsonProperty("site_id")
    private Integer siteId;

    @JsonProperty("device_id")
    private Integer deviceId;

    @JsonProperty("basic_firewall")
    private Boolean basicFirewall;

    @JsonProperty("advanced_firewall")
    private Boolean advancedFirewall;

}
