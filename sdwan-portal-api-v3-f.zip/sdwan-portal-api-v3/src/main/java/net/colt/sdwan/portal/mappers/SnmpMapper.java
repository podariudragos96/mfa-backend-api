package net.colt.sdwan.portal.mappers;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.InterfaceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.model.SnmpRequestV1;
import net.colt.sdwan.portal.model.SnmpResponseV1;
import net.colt.sdwan.sitesettings.api.generated.model.SnmpRequestApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.SnmpResponseApiV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;


@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
@Component
public class SnmpMapper {

    private final ModelMapper modelMapper;

    public SnmpResponseV1 from(SnmpResponseApiV1 snmpResponseApiV1) {
        return modelMapper.map(snmpResponseApiV1, SnmpResponseV1.class);
    }

    public SnmpRequestApiV1 from(SnmpRequestV1 snmpRequestV1, SiteResponseV1 site) {
        SnmpRequestApiV1 snmpRequestApiV1 = modelMapper.map(snmpRequestV1, SnmpRequestApiV1.class);
        mapConnectionInterfaceNetwork(snmpRequestApiV1, site);

        return snmpRequestApiV1;
    }

    private void mapConnectionInterfaceNetwork(SnmpRequestApiV1 snmpRequestApiV1, SiteResponseV1 site) {
        snmpRequestApiV1.getConnections().forEach(connection -> {
            List<DeviceResponseV1> deviceSet = site.getDevices();
            List<InterfaceResponseV1> interfaceResponseList = deviceSet.stream().iterator().next().getInterfaces();

            Optional<InterfaceResponseV1> interfaceResponse = interfaceResponseList
                    .stream()
                    .filter(intf -> intf.getName().equals(connection.getInterfaceName()))
                    .findFirst();
            interfaceResponse.ifPresent(response -> connection.setInterfaceNetwork(response.getNetwork()));
        });
    }

}
