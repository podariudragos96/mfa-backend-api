package net.colt.sdwan.portal.config;

import net.colt.xml.ns.cumf.v1.UserService;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class UserServiceWebserviceConfig {

    @Value("${colt-online.webservice.baseurl}")
    private String address;

    @Bean("userService")
    public UserService userService() {
        JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
        jaxWsProxyFactoryBean.setServiceClass(UserService.class);
        jaxWsProxyFactoryBean.setAddress(address);
        jaxWsProxyFactoryBean.setWsdlLocation("classpath:wsdl/userService.wsdl");
        return (UserService) jaxWsProxyFactoryBean.create();
    }

}