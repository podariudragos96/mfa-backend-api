package net.colt.sdwan.portal.client.feign.security;

import net.colt.sdwan.security.api.generated.api.FirewallApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "securityFirewallsApiClient", url = "${sdwan.security.api.baseurl}",
        configuration = SecurityApiFeignConfiguration.class)
public interface SecurityFirewallsApiFeign extends FirewallApiApi {
}
