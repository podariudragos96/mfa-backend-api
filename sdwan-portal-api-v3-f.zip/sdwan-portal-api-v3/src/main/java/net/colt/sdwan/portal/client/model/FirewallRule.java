package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Setter
@Getter
@ToString
@Builder
@JsonInclude(Include.NON_NULL)
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FirewallRule {

    @JsonProperty("priority")
    private Integer priority;

    @JsonProperty("name")
    private String name;

    @JsonProperty("description")
    private String description;

    @JsonProperty("app-name")
    private String appName;

    @Builder.Default
    @JsonProperty("source-ip")
    private List<String> sourceIp = new ArrayList<>();

    @Builder.Default
    @JsonProperty("source-negate")
    private Boolean sourceNegate = false;

    @Builder.Default
    @JsonProperty("destination-ip")
    private List<String> destinationIp = new ArrayList<>();

    @Builder.Default
    @JsonProperty("destination-negate")
    private Boolean destinationNegate = false;

    @JsonProperty("action")
    private FwAction action;

    @JsonProperty("protocol")
    private String protocol;

    @JsonProperty("source-port")
    private String sourcePort;

    @JsonProperty("destination-port")
    private String destinationPort;

    @JsonProperty("rule-enabled")
    private Boolean ruleEnabled;

    @JsonProperty("activations")
    @JsonInclude(Include.NON_EMPTY)
    private RuleActivations activations;

    @JsonProperty("logging_event")
    private String loggingEvent;

    @JsonProperty("editable")
    private Boolean editable;

    @JsonProperty("difference")
    private String difference;

    @Builder.Default
    @JsonProperty("applications")
    private List<String> applications = null;

    @Builder.Default
    @JsonProperty("url_categories")
    private List<String> urlCategories = null;

    @Builder.Default
    @JsonProperty("source_network")
    private List<String> sourceNetwork = null;

    @Builder.Default
    @JsonProperty("destination_network")
    private List<String> destinationNetwork = null;

    @Builder.Default
    @JsonInclude(Include.NON_EMPTY)
    @JsonProperty("dnat_destination_ip")
    private List<String> dnatDestinationIp = new ArrayList<>();

    @JsonInclude(Include.NON_EMPTY)
    @JsonProperty("dnat_destination_port")
    private String dnatDestinationPort;

    @JsonProperty("source_zone")
    private List<String> sourceZone;

    @JsonProperty("destination_zone")
    private List<String> destinationZone;

    @JsonProperty("antivirus_profile")
    private String antivirusProfile;

    @JsonProperty("url_filtering_profile")
    private String urlFilteringProfile;

    @JsonProperty("predefined_ips_profile")
    private String predefinedIpsProfile;

    @JsonProperty("predefined_ips_profile_override")
    private String predefinedIpsProfileOverride;

    @JsonProperty("user_defined_ips_profile")
    private String userDefinedIpsProfile;

    @JsonProperty("ip_filtering_profile")
    private String ipFilteringProfile;

    @JsonProperty("custom-services")
    private Set<String> customServices = new HashSet<>();

    @JsonProperty("custom-source-addresses")
    private Set<String> customSourceAddresses = new HashSet<>();

    @JsonProperty("custom-destination-addresses")
    private Set<String> customDestinationAddresses = new HashSet<>();

    @JsonProperty("custom-source-address-groups")
    private Set<String> customSourceAddressGroups = new HashSet<>();

    @JsonProperty("custom-destination-address-groups")
    private Set<String> customDestinationAddressGroups = new HashSet<>();
}
