package net.colt.sdwan.portal.client.feign.service;

import feign.auth.BasicAuthRequestInterceptor;
import net.colt.sdwan.common.data.criteria.config.AbstractCriteriaApiFeignConfiguration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

public class ServiceFeignConfiguration extends AbstractCriteriaApiFeignConfiguration {

    protected String username;
    protected String password;

    public ServiceFeignConfiguration(
            @Value("${sdwan.service.api.username}") String username,
            @Value("${sdwan.service.api.password}") String password) {
        this.username = username;
        this.password = password;
    }

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        return new BasicAuthRequestInterceptor(username, password);
    }
}
