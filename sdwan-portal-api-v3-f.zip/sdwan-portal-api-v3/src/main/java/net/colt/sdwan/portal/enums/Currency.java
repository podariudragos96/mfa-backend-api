package net.colt.sdwan.portal.enums;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum Currency {

    GBP, EUR, CHF, USD, JPY;

    public static Currency validate(String value) {
        try {
            return Currency.valueOf(value);
        } catch (Exception e) {
            log.error("Invalid currency value", e);
            return null;
        }
    }

}
