package net.colt.sdwan.portal.database.repositories;

import net.colt.sdwan.portal.database.entities.FeatureDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FeatureDetailsRepository extends JpaRepository<FeatureDetails, Integer> {

    List<FeatureDetails> findByTenantIdInAndFeatureFlag(final List<Integer> tenantId, final String flag);

}
