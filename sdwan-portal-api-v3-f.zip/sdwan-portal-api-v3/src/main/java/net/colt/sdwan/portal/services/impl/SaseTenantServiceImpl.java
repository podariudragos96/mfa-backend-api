package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.versa.sase.api.TenantResponseApiV1;
import net.colt.sdwan.portal.client.feign.sase.SaseTenantFeign;
import net.colt.sdwan.portal.mappers.SaseTenantMapper;
import net.colt.sdwan.portal.model.SaseTenantResponseV1;
import net.colt.sdwan.portal.services.SaseTenantService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static net.colt.sdwan.portal.enums.SaseOperation.TENANT_GET;

@Service
@RequiredArgsConstructor
@Slf4j
public class SaseTenantServiceImpl implements SaseTenantService {

    private final SaseTenantFeign saseTenantFeign;
    private final SaseTenantMapper saseTenantMapper;
    private final ResponseEntityValidator responseEntityValidator;

    @Override
    public Optional<SaseTenantResponseV1> getTenantV1(String networkId) {
        log.info("Getting sase tenant details from database via sase api for tenant={} ...", networkId);
        final ResponseEntity<TenantResponseApiV1> saseApiResp = saseTenantFeign.getTenantV1(networkId);
        responseEntityValidator.checkResponseEntity(saseApiResp, TENANT_GET.getName());
        log.info("Get request completed successfully for tenant={}.", networkId);
        return saseTenantMapper.from(saseApiResp.getBody());
    }

}
