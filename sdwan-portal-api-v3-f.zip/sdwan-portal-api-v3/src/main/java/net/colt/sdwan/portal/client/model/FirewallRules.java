package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@AllArgsConstructor
public class FirewallRules {

    @JsonProperty("id")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String id;

    @JsonProperty("customer")
    private String customer;

    @JsonProperty("site")
    private String siteId;

    @JsonProperty("last_updated")
    private String lastUpdated;

    @JsonProperty("updated_by")
    private String updatedBy;

    @JsonProperty("fw-rules")
    private List<FirewallRule> fwRules = null;

    @JsonProperty("description")
    private String description;

    @JsonProperty("sdwan_fw_enabled")
    private boolean sdwanEnabled;
}
