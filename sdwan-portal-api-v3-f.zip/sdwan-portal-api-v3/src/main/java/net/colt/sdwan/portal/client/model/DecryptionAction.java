package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum DecryptionAction {
    DECRYPT("decrypt"),
    NO_DECRYPT("no-decrypt");

    private String value;

    DecryptionAction(String value) {
        this.value = value;
    }

    @JsonCreator
    public static DecryptionAction fromValue(String text) {
        for (DecryptionAction b : DecryptionAction.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        throw new IllegalArgumentException("Unexpected value '" + text + "'");
    }

    @JsonValue
    @Override
    public String toString() {
        return String.valueOf(value);
    }

}