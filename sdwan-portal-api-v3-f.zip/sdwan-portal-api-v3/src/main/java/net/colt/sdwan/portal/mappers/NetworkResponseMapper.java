package net.colt.sdwan.portal.mappers;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import net.colt.sdwan.portal.model.NetworkResponseV1;

import java.util.List;
import java.util.Set;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class NetworkResponseMapper {

    public static List<NetworkResponseV1> mapNetworkResponsesFromNetworks(Set<String> networks) {
        return networks.stream().map(NetworkResponseMapper::mapToNetwork).toList();
    }

    public static NetworkResponseV1 mapToNetwork(String network) {
        return new NetworkResponseV1(network, network);
    }

}
