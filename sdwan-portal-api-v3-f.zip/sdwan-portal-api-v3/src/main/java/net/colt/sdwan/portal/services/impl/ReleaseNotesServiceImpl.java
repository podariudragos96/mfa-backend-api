package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.database.entities.ReleaseNotes;
import net.colt.sdwan.portal.database.repositories.ReleaseNotesRepository;
import net.colt.sdwan.portal.model.ContentTypeV1;
import net.colt.sdwan.portal.model.ReleaseNotesResponseV1;
import net.colt.sdwan.portal.services.ReleaseNotesService;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import static net.colt.sdwan.portal.util.BytesArrayToStringUtil.bytesArrayToString;

@RequiredArgsConstructor
@Service
public class ReleaseNotesServiceImpl implements ReleaseNotesService {

    private final ReleaseNotesRepository releaseNotesRepository;

    public List<ReleaseNotesResponseV1> getReleaseNotes() {
        List<ReleaseNotes> releaseNotesList = releaseNotesRepository.findAll();
        if (CollectionUtils.isNotEmpty(releaseNotesList)) {
            return releaseNotesList.stream()
                    .map(releaseNote ->
                            new ReleaseNotesResponseV1()
                                    .contentType(ContentTypeV1.fromValue(releaseNote.getContentType().name()))
                                    .releaseDt(releaseNote.getReleaseDate())
                                    .version(releaseNote.getVersion())
                                    .note(bytesArrayToString(releaseNote.getNote())))
                    .toList();
        }
        return Collections.emptyList();
    }

    public LocalDateTime getLastReleaseDateTime() {
        ReleaseNotes releaseNotes = releaseNotesRepository.findTopByOrderByReleaseDate();
        if (Objects.nonNull(releaseNotes)) {
            return releaseNotes.getReleaseDate();
        }
        return null;
    }
}
