package net.colt.sdwan.portal.client.helper;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.client.feign.mfa.IdentityAuthFeign;
import net.colt.sdwan.portal.client.feign.mfa.IdentityMfaFeign;
import net.colt.sdwan.portal.client.model.identityaccess.*;
import net.colt.sdwan.portal.model.SendEmailRequestV1;
import net.colt.sdwan.portal.model.VerifyEmailRequestV1;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@RequiredArgsConstructor
@Component
public class IdentityAccessMfaClientHelper {
    private final IdentityMfaFeign identityMfaFeign;
    private final IdentityAuthFeign identityAuthFeign;

    public ResponseEntity<LoginResponseApiV1> authLogin(LoginRequestApiV1 req, Boolean mfaEnabled) {
        return identityAuthFeign.authLogin(req, mfaEnabled);
    }

    public void sendEmailOtp(String sessionId) {
        SendEmailRequestV1 req = SendEmailRequestV1.builder().sessionId(sessionId).build();
        identityMfaFeign.sendMfaEmailV1(req);
    }

    public ResponseEntity<VerifyOtpProfileResponseApiV1> verifyEmailOtp(String sessionId, String code) {
        VerifyEmailRequestV1 req = VerifyEmailRequestV1.builder().sessionId(sessionId).code(code).build();
        return identityMfaFeign.verifyMfaEmailV1(req);
    }

    public ResponseEntity<AuthMfaEmailSend200Response> sendSmsOtp(String sessionId) {
        SendSmsReqApiV1 req = SendSmsReqApiV1.builder().sessionId(sessionId).build();
        return identityMfaFeign.sendMfaSmsV1(req);
    }

    public ResponseEntity<VerifyOtpProfileResponseApiV1> verifySmsOtp(String sessionId, String code) {
        VerifySmsReqApiV1 req = VerifySmsReqApiV1.builder()
                        .sessionId(sessionId)
                        .code(code)
                        .build();
        return identityMfaFeign.verifyMfaSmsV1(req);
    }

    public ResponseEntity<StartTotpSessionResponseApiV1> startTotpSession(String sessionId) {
        StartTotpSessionRequestApiV1 req = StartTotpSessionRequestApiV1.builder().sessionId(sessionId).build();
        return identityMfaFeign.startTotpSessionV1(req);
    }

    public ResponseEntity<VerifyOtpProfileResponseApiV1> verifyTotp(String sessionId, String code) {
        VerifyTotpRequestApiV1 req = VerifyTotpRequestApiV1.builder().sessionId(sessionId).code(code).build();
        return identityMfaFeign.verifyTotpV1(req);
    }

    public ResponseEntity<Void> deleteTotp(String sessionId) {
        DeleteTotpRequestApiV1 req = DeleteTotpRequestApiV1.builder().sessionId(sessionId).build();
        return identityMfaFeign.deleteTotpConfigsV1(req);
    }
}
