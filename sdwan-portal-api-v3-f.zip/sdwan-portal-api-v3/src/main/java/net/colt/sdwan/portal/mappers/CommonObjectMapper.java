package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.generated.model.service.SiteTypeV1;
import net.colt.sdwan.sitesettings.api.generated.model.SiteTypeApiV1;
import org.mapstruct.Mapper;

@Mapper
public interface CommonObjectMapper {
    SiteTypeApiV1 from(SiteTypeV1 siteTypeV1);
}
