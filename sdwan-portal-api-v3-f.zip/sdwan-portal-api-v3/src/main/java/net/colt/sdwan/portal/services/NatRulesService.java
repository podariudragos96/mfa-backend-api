package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.*;

import java.util.List;

public interface NatRulesService {

    /**
     * @deprecated
     * This wll be removed after the migration to the version 2 is completed
     */
    @SuppressWarnings("java:S1133")
    @Deprecated(forRemoval = true)
    NatRulesResponseV1 getNatRulesBySiteId(final String siteId);

    /**
     * @deprecated
     * This wll be removed after the migration to the version 2 is completed
     */
    @SuppressWarnings("java:S1133")
    @Deprecated(forRemoval = true)
    CorrelationIdResponseV1 updateNatRulesBySiteId(final String siteId, NatRulesRequestV1 body);

    NatRuleSetResponseV1 getNatRulesBySiteIdV2(final String siteId);

    CorrelationIdResponseV1 updateNatRulesBySiteIdV2(final String siteId, NatRulesRequestV1 body);

    NatRuleSetResponseV1 getNatRulesHistoryBySiteIdAndRuleSetIdV2(String siteId, String ruleSetId);

    List<NatRuleHistoryResponseV1> getNatRulesHistoryBySiteIdV2(String siteId);

}
