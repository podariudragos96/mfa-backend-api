package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Setter
@Getter
@AllArgsConstructor
@ToString
@NoArgsConstructor
public class StaticRoute {

    private String destination;

    @JsonProperty("next_hop")
    private String nextNop;

    @JsonProperty("interface")
    private String interfac;


}
