package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Setter
@Getter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PolicyApiRule {

    @JsonProperty("name")
    private String name;

    @JsonProperty("description")
    private String description;

    @JsonProperty("behaviour")
    private String behaviour;

    @JsonProperty("metrics")
    private List<PolicyApiMetric> metrics;

    @JsonProperty("source")
    private List<String> source;

    @JsonProperty("destination")
    private List<String> destination;

    @JsonProperty("interfaces")
    private List<PolicyApiInterface> interfaces;

    @JsonProperty("avoid")
    private VersaDirectoryAvoidInterface avoid;

    @JsonProperty("qos-profile")
    private List<String> qos;

    @JsonProperty("vpn")
    private String vpn;

    @JsonProperty("protocol")
    private String protocol;

    @JsonProperty("source-port")
    private String sourcePort;

    @JsonProperty("destination-port")
    private String destinationPort;

    @JsonProperty("source-negate")
    private Boolean sourceNegate;

    @JsonProperty("destination-negate")
    private Boolean destinationNegate;

    @JsonProperty("difference")
    private String difference;

    @JsonProperty("application")
    private List<String> applications;

    @JsonProperty("source_zone")
    private List<String> sourceZone;

    @JsonProperty("destination_zone")
    private List<String> destinationZone;

    @JsonProperty("evaluate_continuously")
    private Boolean evaluateCont;
}
