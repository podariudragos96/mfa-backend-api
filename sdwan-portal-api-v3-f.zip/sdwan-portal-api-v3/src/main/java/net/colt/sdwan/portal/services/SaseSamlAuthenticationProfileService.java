package net.colt.sdwan.portal.services;


import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SaseSamlAuthenticationProfileRequestV1;
import net.colt.sdwan.portal.model.SaseSamlAuthenticationProfilesResponseV1;

public interface SaseSamlAuthenticationProfileService {

    SaseSamlAuthenticationProfilesResponseV1 getSamlAuthenticationProfilesV1(String networkId);

    CorrelationIdResponseV1 updateSamlAuthenticationProfileV1(String tenantUuid, String samlUuid, SaseSamlAuthenticationProfileRequestV1 saseSamlAuthenticationProfileRequestV1);

}
