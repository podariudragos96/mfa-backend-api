package net.colt.sdwan.portal.database.entities;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "DOCUMENTS")
public class Documents extends BaseEntity {

    @Column(name = "CONTENT", nullable = false)
    @Lob
    private byte[] content;
   
    @Enumerated(EnumType.STRING)
    @Column(name = "CONTENT_TYPE", nullable = false)
    private ContentTypeEnum contentType = null;

    @Column(name = "LANGUAGE_CODE", nullable = false)
    private String language;

    @Column(name = "CREATED_ON", nullable = false)
    private LocalDateTime createdOn;

    @Column(name = "LAST_UPDATED")
    private LocalDateTime lastUpdatedOn;

    @Column(name = "STATUS", nullable = false)
    private String status;

    @Column(name = "DOCUMENT_TYPE", nullable = false)
    private String documentType;
}
