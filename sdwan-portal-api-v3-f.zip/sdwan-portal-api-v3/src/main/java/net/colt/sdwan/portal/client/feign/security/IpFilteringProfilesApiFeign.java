package net.colt.sdwan.portal.client.feign.security;

import net.colt.sdwan.security.api.generated.api.IpFilteringApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "ipFilteringProfilesApiFeign", url = "${sdwan.security.api.baseurl}",
        configuration = SecurityApiFeignConfiguration.class)
public interface IpFilteringProfilesApiFeign extends IpFilteringApiApi {
}
