package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.generated.model.service.SecurityResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.feign.security.AntivirusProfilesApiFeign;
import net.colt.sdwan.portal.mappers.AntivirusProfileLogsMapper;
import net.colt.sdwan.portal.mappers.AntivirusProfileMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.AntivirusService;
import net.colt.sdwan.portal.services.MetaService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.security.api.generated.model.*;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static java.util.Objects.nonNull;
import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.constant.SecurityConstants.SECURITY_ANTIVIRUS_PROFILES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.MODIFYING_ANTIVIRUS_PROFILES_RULES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;
import static org.apache.commons.collections4.CollectionUtils.isNotEmpty;

@Service
@Slf4j
@RequiredArgsConstructor
public class AntivirusServiceImpl implements AntivirusService {

    private final SitesService sitesService;
    private final AntivirusProfilesApiFeign antivirusProfilesApiFeign;
    private final SiteResponseValidator siteResponseValidator;
    private final AntivirusProfileMapper antivirusProfileMapper;
    private final AntivirusProfileLogsMapper antivirusProfileLogsMapper;
    private final MetaService metaService;
    private final ResponseEntityValidator responseEntityValidator;

    @Override
    public AntivirusProfileResponseV1 getAntivirusProfilesBySiteIdV1(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final SecurityResponseV1 securityResponseV1 = siteResponse.getSiteFeatures().getSecurity();
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(securityResponseV1.getFirewall().getValue());

        siteResponseValidator.validateSecurityProfileFeatureSupport(hasAdvancedFirewall, securityResponseV1.getAntivirusEnabled());
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        final ResponseEntity<AntivirusProfilesApiResponseV1> antivirusProfilesApiResponseEntity =
                antivirusProfilesApiFeign.getAntivirusProfilesV1(Integer.parseInt(siteId), siteResponse.getNetworkId());
        responseEntityValidator.checkResponseEntity(antivirusProfilesApiResponseEntity, SECURITY_ANTIVIRUS_PROFILES);

        return antivirusProfileMapper.from(antivirusProfilesApiResponseEntity.getBody());
    }

    public CorrelationIdResponseV1 updateAntivirusProfilesBySiteIdV1(String siteId, AntivirusProfilesRequestV1 antivirusProfilesRequestV1) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final SecurityResponseV1 securityResponseV1 = siteResponse.getSiteFeatures().getSecurity();
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(securityResponseV1.getFirewall().getValue());

        siteResponseValidator.validateSecurityProfileFeatureSupport(hasAdvancedFirewall, securityResponseV1.getAntivirusEnabled());
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);

        if (Boolean.FALSE.equals(securityResponseV1.getAntivirusEnabled())) {
            throw new SdwanNotFoundException("Antivirus is not enabled on the site with the site id '" + siteId + "'.");
        }

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final AntivirusProfilesApiRequestV1 antivirusProfileApiV1s =
                antivirusProfileMapper.from(antivirusProfilesRequestV1.getAntivirusProfiles());

        checkFileType(antivirusProfileApiV1s);
        antivirusProfileApiV1s.setLoggerType(LoggerType.fromValue(siteResponse.getSiteFeatures().getSecurity().getLogging().getLoggingType()));

        final List<String> deviceNames = sitesService.getDeviceNamesFromSiteResponse(siteResponse);
        UserAuth userAuth = AuthUserHelper.getAuthUser();

        try {
            sitesService.updateOngoingAction(siteId, MODIFYING_ANTIVIRUS_PROFILES_RULES);
            final ResponseEntity<Void> responseEntity = antivirusProfilesApiFeign.updateAntivirusProfilesV1(
                    Integer.parseInt(siteId), siteResponse.getNetworkId(),
                    userAuth.getUsername(), deviceNames, true, antivirusProfileApiV1s);

            responseEntityValidator.checkResponseEntity(responseEntity, SECURITY_ANTIVIRUS_PROFILES);
            return new CorrelationIdResponseV1(MDC.get(CORRELATION_ID));
        } catch (Exception ex) {
            log.error("Failed to update Security Profiles", ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw new SdwanInternalServerErrorException("Failed to update Security Profiles with '" + ex.getMessage() + "'.", ex);
        }
    }

    @Override
    public List<AntivirusProfileLogsResponseV1> getAntivirusProfileLogsV1(String siteId, String profileName) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final SecurityResponseV1 securityResponseV1 = siteResponse.getSiteFeatures().getSecurity();
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(securityResponseV1.getFirewall().getValue());

        siteResponseValidator.validateSecurityProfileFeatureSupport(hasAdvancedFirewall, securityResponseV1.getAntivirusEnabled());
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final List<String> deviceNames = sitesService.getDeviceNamesFromSiteResponse(siteResponse);
        final List<String> deviceUuids = sitesService.getDeviceUuidsFromSiteResponse(siteResponse);

        final ResponseEntity<List<AntivirusProfileApiLogsResponseV1>> responseEntity = antivirusProfilesApiFeign.getAntivirusProfileLogsV1(
                Integer.parseInt(siteId), siteResponse.getNetworkId(), profileName, deviceNames, deviceUuids);
        responseEntityValidator.checkResponseEntity(responseEntity, SECURITY_ANTIVIRUS_PROFILES);

        return antivirusProfileLogsMapper.from(requireNonNull(responseEntity.getBody()));
    }

    private void checkFileType(AntivirusProfilesApiRequestV1 antivirusProfilesApiRequest) {
        final List<String> fileTypeResponseNames = metaService.getAllFileTypes().stream()
                .map(FileTypeDetailsV1::getName)
                .toList();

        if (nonNull(antivirusProfilesApiRequest)
                && isNotEmpty(antivirusProfilesApiRequest.getAntivirusProfiles())
                && isNotEmpty(fileTypeResponseNames)) {

            final List<AntivirusProfileApiV1> antivirusProfilesApi = antivirusProfilesApiRequest.getAntivirusProfiles();
            final Optional<String> nonExistingFileTypes = antivirusProfilesApi.stream()
                    .flatMap(antivirusProfile -> antivirusProfile.getFileTypes().stream())
                    .filter(fileType -> !fileTypeResponseNames.contains(fileType.toLowerCase())).findAny();

            if (nonExistingFileTypes.isPresent()) {
                throw new IllegalArgumentException("Unexpected file type '" + nonExistingFileTypes.get() + "'");
            }
        }
    }
}
