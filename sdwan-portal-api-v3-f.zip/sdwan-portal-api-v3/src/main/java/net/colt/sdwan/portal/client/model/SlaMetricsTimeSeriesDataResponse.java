package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SlaMetricsTimeSeriesDataResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("delay")
    @Valid
    private List<SlaMetricsTimeSeriesAnalyticsResponse> delay = new ArrayList<>();

    @JsonProperty("fwd_delay")
    @Valid
    private List<SlaMetricsTimeSeriesAnalyticsResponse> fwdDelay = new ArrayList<>();

    @JsonProperty("rev_delay")
    @Valid
    private List<SlaMetricsTimeSeriesAnalyticsResponse> revDelay = new ArrayList<>();

    @JsonProperty("fwd_loss_ratio")
    @Valid
    private List<SlaMetricsTimeSeriesAnalyticsResponse> fwdLossRatio = new ArrayList<>();

    @JsonProperty("pdu_loss_ratio")
    @Valid
    private List<SlaMetricsTimeSeriesAnalyticsResponse> pduLossRatio = new ArrayList<>();

    @JsonProperty("rev_loss_ratio")
    @Valid
    private List<SlaMetricsTimeSeriesAnalyticsResponse> revLossRatio = new ArrayList<>();

    public SlaMetricsTimeSeriesDataResponse delay(List<SlaMetricsTimeSeriesAnalyticsResponse> delay) {
        this.delay = delay;
        return this;
    }

    public SlaMetricsTimeSeriesDataResponse addDelayItem(SlaMetricsTimeSeriesAnalyticsResponse delayItem) {
        this.delay.add(delayItem);
        return this;
    }

    /**
     * Get delay
     *
     * @return delay
     */
    @ApiModelProperty(required = true, value = "")
    @NotNull

    @Valid

    public List<SlaMetricsTimeSeriesAnalyticsResponse> getDelay() {
        return delay;
    }

    public void setDelay(List<SlaMetricsTimeSeriesAnalyticsResponse> delay) {
        this.delay = delay;
    }

    public SlaMetricsTimeSeriesDataResponse fwdDelay(List<SlaMetricsTimeSeriesAnalyticsResponse> fwdDelay) {
        this.fwdDelay = fwdDelay;
        return this;
    }

    public SlaMetricsTimeSeriesDataResponse addFwdDelayItem(SlaMetricsTimeSeriesAnalyticsResponse fwdDelayItem) {
        this.fwdDelay.add(fwdDelayItem);
        return this;
    }

    /**
     * Get fwdDelay
     *
     * @return fwdDelay
     */
    @ApiModelProperty(required = true, value = "")
    @NotNull

    @Valid

    public List<SlaMetricsTimeSeriesAnalyticsResponse> getFwdDelay() {
        return fwdDelay;
    }

    public void setFwdDelay(List<SlaMetricsTimeSeriesAnalyticsResponse> fwdDelay) {
        this.fwdDelay = fwdDelay;
    }

    public SlaMetricsTimeSeriesDataResponse revDelay(List<SlaMetricsTimeSeriesAnalyticsResponse> revDelay) {
        this.revDelay = revDelay;
        return this;
    }

    public SlaMetricsTimeSeriesDataResponse addRevDelayItem(SlaMetricsTimeSeriesAnalyticsResponse revDelayItem) {
        this.revDelay.add(revDelayItem);
        return this;
    }

    /**
     * Get revDelay
     *
     * @return revDelay
     */
    @ApiModelProperty(required = true, value = "")
    @NotNull

    @Valid

    public List<SlaMetricsTimeSeriesAnalyticsResponse> getRevDelay() {
        return revDelay;
    }

    public void setRevDelay(List<SlaMetricsTimeSeriesAnalyticsResponse> revDelay) {
        this.revDelay = revDelay;
    }

    public SlaMetricsTimeSeriesDataResponse fwdLossRatio(List<SlaMetricsTimeSeriesAnalyticsResponse> fwdLossRatio) {
        this.fwdLossRatio = fwdLossRatio;
        return this;
    }

    public SlaMetricsTimeSeriesDataResponse addFwdLossRatioItem(SlaMetricsTimeSeriesAnalyticsResponse fwdLossRatioItem) {
        this.fwdLossRatio.add(fwdLossRatioItem);
        return this;
    }

    /**
     * Get fwdLossRatio
     *
     * @return fwdLossRatio
     */
    @ApiModelProperty(required = true, value = "")
    @NotNull

    @Valid

    public List<SlaMetricsTimeSeriesAnalyticsResponse> getFwdLossRatio() {
        return fwdLossRatio;
    }

    public void setFwdLossRatio(List<SlaMetricsTimeSeriesAnalyticsResponse> fwdLossRatio) {
        this.fwdLossRatio = fwdLossRatio;
    }

    public SlaMetricsTimeSeriesDataResponse pduLossRatio(List<SlaMetricsTimeSeriesAnalyticsResponse> pduLossRatio) {
        this.pduLossRatio = pduLossRatio;
        return this;
    }

    public SlaMetricsTimeSeriesDataResponse addPduLossRatioItem(SlaMetricsTimeSeriesAnalyticsResponse pduLossRatioItem) {
        this.pduLossRatio.add(pduLossRatioItem);
        return this;
    }

    /**
     * Get pduLossRatio
     *
     * @return pduLossRatio
     */
    @ApiModelProperty(required = true, value = "")
    @NotNull

    @Valid

    public List<SlaMetricsTimeSeriesAnalyticsResponse> getPduLossRatio() {
        return pduLossRatio;
    }

    public void setPduLossRatio(List<SlaMetricsTimeSeriesAnalyticsResponse> pduLossRatio) {
        this.pduLossRatio = pduLossRatio;
    }

    public SlaMetricsTimeSeriesDataResponse revLossRatio(List<SlaMetricsTimeSeriesAnalyticsResponse> revLossRatio) {
        this.revLossRatio = revLossRatio;
        return this;
    }

    public SlaMetricsTimeSeriesDataResponse addRevLossRatioItem(SlaMetricsTimeSeriesAnalyticsResponse revLossRatioItem) {
        this.revLossRatio.add(revLossRatioItem);
        return this;
    }

    /**
     * Get revLossRatio
     *
     * @return revLossRatio
     */
    @ApiModelProperty(required = true, value = "")
    @NotNull

    @Valid

    public List<SlaMetricsTimeSeriesAnalyticsResponse> getRevLossRatio() {
        return revLossRatio;
    }

    public void setRevLossRatio(List<SlaMetricsTimeSeriesAnalyticsResponse> revLossRatio) {
        this.revLossRatio = revLossRatio;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SlaMetricsTimeSeriesDataResponse slaMetricsTimeSeriesDataResponse = (SlaMetricsTimeSeriesDataResponse) o;
        return Objects.equals(this.delay, slaMetricsTimeSeriesDataResponse.delay) &&
                Objects.equals(this.fwdDelay, slaMetricsTimeSeriesDataResponse.fwdDelay) &&
                Objects.equals(this.revDelay, slaMetricsTimeSeriesDataResponse.revDelay) &&
                Objects.equals(this.fwdLossRatio, slaMetricsTimeSeriesDataResponse.fwdLossRatio) &&
                Objects.equals(this.pduLossRatio, slaMetricsTimeSeriesDataResponse.pduLossRatio) &&
                Objects.equals(this.revLossRatio, slaMetricsTimeSeriesDataResponse.revLossRatio);
    }

    @Override
    public int hashCode() {
        return Objects.hash(delay, fwdDelay, revDelay, fwdLossRatio, pduLossRatio, revLossRatio);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class SlaMetricsTimeSeriesDataResponseV1 {\n");

        sb.append("    delay: ").append(toIndentedString(delay)).append("\n");
        sb.append("    fwdDelay: ").append(toIndentedString(fwdDelay)).append("\n");
        sb.append("    revDelay: ").append(toIndentedString(revDelay)).append("\n");
        sb.append("    fwdLossRatio: ").append(toIndentedString(fwdLossRatio)).append("\n");
        sb.append("    pduLossRatio: ").append(toIndentedString(pduLossRatio)).append("\n");
        sb.append("    revLossRatio: ").append(toIndentedString(revLossRatio)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

