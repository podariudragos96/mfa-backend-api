package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.client.model.customerapi.ApiUserResponseV1;
import net.colt.sdwan.portal.model.ApiUserKeyResponseModel;
import net.colt.sdwan.portal.model.ApiUserSessionResponseV1;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface ApiUserMapper {

    @Mapping(target = "networkId", source = "apiUserResponseV1.networkId")
    @Mapping(target = "userAgent", source = "apiUserResponseV1.userAgent")
    @Mapping(target = "apiKeys", source = "apiUserResponseV1.apiKeys")
    ApiUserSessionResponseV1 toApiUserSessionResponseV1(ApiUserResponseV1 apiUserResponseV1);

    @Mapping(target = "tenantId", source = "apiUserResponseV1.tenantId")
    @Mapping(target = "networkId", source = "apiUserResponseV1.networkId")
    @Mapping(target = "userAgent", source = "apiUserResponseV1.userAgent")
    @Mapping(target = "apiKeys", source = "apiUserResponseV1.apiKeys")
    ApiUserKeyResponseModel toApiUserKeyResponseModel(ApiUserResponseV1 apiUserResponseV1);
}
