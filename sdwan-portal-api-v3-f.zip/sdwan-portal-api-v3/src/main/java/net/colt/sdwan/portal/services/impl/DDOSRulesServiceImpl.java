package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.async.utils.ThreadUtils;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.AnalyticsApiClient;
import net.colt.sdwan.portal.client.PolicyApiClient;
import net.colt.sdwan.portal.client.feign.security.SecurityDdosApiFeign;
import net.colt.sdwan.portal.client.model.DDoSRuleSetHistory;
import net.colt.sdwan.portal.client.model.DDoSRulesAnalytics;
import net.colt.sdwan.portal.mappers.DdosRulesEventLogsResponseMapper;
import net.colt.sdwan.portal.mappers.DdosRulesMapper;
import net.colt.sdwan.portal.mappers.UpdateDDoSRuleSetHistoryMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.DDOSRulesService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.util.CompletableFutureUtil;
import net.colt.sdwan.portal.validator.DdosRulesValidator;
import net.colt.sdwan.portal.validator.DeviceResponseValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.security.api.generated.model.DdosRuleHistoryApiResponseV1;
import net.colt.sdwan.security.api.generated.model.DdosRulesApiResponseV1;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.model.OnGoingActionV2.MODIFYING_DDOS_RULES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;

@Service
@Slf4j
@RequiredArgsConstructor
public class DDOSRulesServiceImpl implements DDOSRulesService {

    private final SitesService sitesService;
    private final PolicyApiClient policyApiClient;
    private final AnalyticsApiClient analyticsApiClient;
    private final DeviceResponseValidator deviceResponseValidator;
    private final SiteResponseValidator siteResponseValidator;
    private final DdosRulesEventLogsResponseMapper ddosRulesEventLogsResponseMapper;
    private final UpdateDDoSRuleSetHistoryMapper updateDDoSRuleSetHistoryMapper;
    private final DdosRulesValidator ddosRulesValidator;
    private final SecurityDdosApiFeign securityDdosApiFeign;
    private final DdosRulesMapper ddosRulesMapper;

    private static final String INVALID_USER_ERROR_MSG = "User does not have valid customer site values";
    private static final String USER_CUSTOMER_NOT_FOUND_ERROR_TEMPLATE = "User customer not found or no valid site/device found for this siteid %s";

    private static final String UPDATE_DDOS_ERROR_MSG = "Failed to update DDOS Rules";

    @Override
    public DdosRuleSetResponseV1 getDDOSRulesBySiteIdV2(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());
        siteResponseValidator.validateAdvancedFirewallEnabled(hasAdvancedFirewall);
        if (siteResponseValidator.hasValidTenantSiteValues(siteResponse)) {
            requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
            final ResponseEntity<DdosRulesApiResponseV1>
                    responseEntity = securityDdosApiFeign.getDDOSRulesV1(siteResponse.getNetworkId(), siteId);
            return ddosRulesMapper.from(responseEntity.getBody());
        }
        throw new SdwanNotFoundException(USER_CUSTOMER_NOT_FOUND_ERROR_TEMPLATE.formatted(siteId));
    }

    @Override
    public DdosRuleSetResponseV1 getDDOSRulesHistoryBySiteIdAndRuleSetIdV1(String siteId, String ruleSetId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());
        siteResponseValidator.validateAdvancedFirewallEnabled(hasAdvancedFirewall);
        if (siteResponseValidator.hasValidTenantSiteValues(siteResponse)) {
            requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
            final ResponseEntity<DdosRulesApiResponseV1>
                    responseEntity = securityDdosApiFeign.getDDOSRulesHistoryByIdV1(siteResponse.getNetworkId(), siteId, ruleSetId);
            return ddosRulesMapper.from(responseEntity.getBody());
        }
        throw new SdwanNotFoundException(USER_CUSTOMER_NOT_FOUND_ERROR_TEMPLATE.formatted(siteId));
    }

    @Override
    public List<DdosRuleHistoryResponseV1> getDDOSRulesHistoryBySiteIdV1(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());
        siteResponseValidator.validateAdvancedFirewallEnabled(hasAdvancedFirewall);
        if (siteResponseValidator.hasValidTenantSiteValues(siteResponse)) {
            requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
            final ResponseEntity<List<DdosRuleHistoryApiResponseV1>>
                    responseEntity = securityDdosApiFeign.getDDOSRulesHistoryV1(siteResponse.getNetworkId(), siteId);
            return ddosRulesMapper.from(responseEntity.getBody());
        }
        throw new SdwanNotFoundException(USER_CUSTOMER_NOT_FOUND_ERROR_TEMPLATE.formatted(siteId));
    }

    @Override
    public CorrelationIdResponseV1 updateDDOSRulesBySiteIdV2(final String siteId, final DdosRulesRequestV1 ddosRulesRequest) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        siteResponseValidator.validateAdvancedFirewallEnabled(hasAdvancedFirewall);
        sitesService.updateOngoingAction(siteId, MODIFYING_DDOS_RULES);

        if (!siteResponseValidator.hasValidTenantSiteValues(siteResponse)) {
            throw new SdwanBadRequestException(INVALID_USER_ERROR_MSG);
        }
        ddosRulesValidator.isDdosIpv6Enabled(siteResponse, ddosRulesRequest);
        ddosRulesValidator.validateRateFields(ddosRulesRequest);

        List<net.colt.sdwan.generated.model.service.DeviceResponseV1> deviceResponses = deviceResponseValidator.hasValidAndReturnDevices(siteId);
        DDoSRuleSetHistory dDoSRuleSetHistory =
                updateDDoSRuleSetHistoryMapper.mapFromDDoSRulesRequest(ddosRulesRequest, siteResponse);
        try {
            siteResponse.setDevices(deviceResponses);
            policyApiClient.updateDDoSRulesV2(dDoSRuleSetHistory, siteResponse);
            return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
        } catch (Exception ex) {
            log.error(UPDATE_DDOS_ERROR_MSG, ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }
    }

    @Override
    public CorrelationIdResponseV1 updateDDOSRulesBySiteIdV3(final String siteId, final DdosRulesRequestV1 ddosRulesRequest) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        siteResponseValidator.validateAdvancedFirewallEnabled(hasAdvancedFirewall);
        try {
            sitesService.updateOngoingAction(siteId, MODIFYING_DDOS_RULES);

            if (!siteResponseValidator.hasValidTenantSiteValues(siteResponse)) {
                throw new SdwanBadRequestException(INVALID_USER_ERROR_MSG);
            }
            ddosRulesValidator.isDdosIpv6Enabled(siteResponse, ddosRulesRequest);
            ddosRulesValidator.validateRateFields(ddosRulesRequest);

            List<net.colt.sdwan.generated.model.service.DeviceResponseV1> deviceResponses = deviceResponseValidator.hasValidAndReturnDevices(siteId);

            requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

            final List<String> deviceNames = deviceResponses.stream().map(DeviceResponseV1::getResourceName).toList();

            securityDdosApiFeign.updateDdosRulesV1(siteResponse.getNetworkId(), siteId, deviceNames, ddosRulesMapper.from(ddosRulesRequest, siteResponse));
            return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
        } catch (Exception ex) {
            log.error(UPDATE_DDOS_ERROR_MSG, ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }
    }

    /**
     * @param siteId
     * @param startDate
     * @param endDate
     * @return
     */
    @Override
    public DdosEventLogsResponseV1 getDdosEventLogsBySiteIdV1(String siteId, LocalDateTime startDate, LocalDateTime endDate) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());
        siteResponseValidator.validateAdvancedFirewallEnabled(hasAdvancedFirewall);
        List<DDoSRulesAnalytics> dDoSRulesAnalytics = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(siteResponse.getDevices())) {
            List<CompletableFuture<DDoSRulesAnalytics>> ddosAnalytics = siteResponse.getDevices().stream()
                    .map(device ->
                            CompletableFuture.supplyAsync(ThreadUtils.withMdc(() ->
                                    analyticsApiClient.getDdosEventLogs(siteResponse, device, startDate, endDate))))
                    .toList();
            dDoSRulesAnalytics.addAll(CompletableFutureUtil.getCompletableFutureValues(ddosAnalytics));
        }
        return ddosRulesEventLogsResponseMapper.mapToResponse(dDoSRulesAnalytics);
    }
}
