package net.colt.sdwan.portal.client;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.common.logging.service.LoggingService;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.InterfaceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.model.*;
import net.colt.sdwan.portal.model.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.*;

import static java.util.Collections.emptyList;
import static net.colt.sdwan.portal.client.ParamsLabels.*;
import static net.colt.sdwan.portal.client.ServicesUrlProperties.*;
import static net.colt.sdwan.portal.constant.Constants.SLASH;
import static net.colt.sdwan.portal.util.LocalDateTimeOperations.formatDateTime;


@Component
public class AnalyticsApiClient extends AbstractRestApiClient {

    public static final String FORMAT_TABLE = "table";
    public static final String FORMAT_ARRAY_OBJECT = "arrayObject";
    public static final int TOP_COUNT_VALUE = 500;
    private static final Integer DEFAULT_COUNT = 10;
    private static final String DEFAULT_DDOS_ANALYTICS_END_DATE = "today";

    @Value("${analytics.time.series.metrics}")
    private String analyticsMetrics;

    @Value("${analytics.base.url}")
    private String analyticsApiBaseUrl;

    public AnalyticsApiClient(AuthHeaderGenerator authHeaderGenerator, RestTemplate restTemplate, LoggingService loggingService) {
        super(authHeaderGenerator, restTemplate, loggingService);
    }

    public List<AnalyticsTimeSeriesData> getTimeSeries(SiteResponseV1 site, DeviceResponseV1 device, LocalDateTime startDate, LocalDateTime endDate, boolean queryDIA) {
        String baseUrl = getAnalyticsUrl(site);
        Map<String, Object> params = new HashMap<>();
        params.put(CUSTOMER, site.getNetworkId());
        params.put(SITE, device.getResourceName());
        params.put(START_DATE, formatDateTime(startDate));
        params.put(END_DATE, formatDateTime(endDate));
        params.put(METRICS, analyticsMetrics);
        params.put(FORMAT, FORMAT_ARRAY_OBJECT);
        params.put(DIA, queryDIA);
        ResponseEntity<AnalyticsTimeSeriesData[]> responseEntity =
                get(baseUrl, ANALYTICS_API_TIME_SERIES_URI, params, AnalyticsTimeSeriesData[].class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return Arrays.asList(responseEntity.getBody());
        }
        return emptyList();
    }

    public InterfaceAnalyticsTableResponse getInterfaceAnalyticsTableResponse(
            SiteResponseV1 site, DeviceResponseV1 device, LocalDateTime startDate, LocalDateTime endDate, boolean queryDIA) {
        String baseUrl = getAnalyticsUrl(site);
        Map<String, Object> params = new HashMap<>();
        params.put(CUSTOMER, site.getNetworkId());
        params.put(DEVICE, device.getResourceName());
        params.put(START_DATE, formatDateTime(startDate));
        params.put(DIA, queryDIA);
        params.put(END_DATE, formatDateTime(endDate));
        ResponseEntity<InterfaceAnalyticsTableResponse> responseEntity =
                get(baseUrl, ANALYTICS_API_INTERFACE_ANALYTICS_TABULAR_URI, params, InterfaceAnalyticsTableResponse.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not find Tabular Interface Analytics");
    }

    public ApplicationAnalytics getApplicationsAnalytics(SiteResponseV1 site, DeviceResponseV1 device, InterfaceResponseV1 interfaceResponse, LocalDateTime startDate, LocalDateTime endDate, Integer count, List<String> applications) {

        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_APPLICATION_URI +
                SLASH + site.getNetworkId() +
                SLASH + device.getResourceName() +
                SLASH + (Objects.nonNull(interfaceResponse.getNetwork()) ? interfaceResponse.getNetwork() : interfaceResponse.getCircuitName());
        Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        if (!CollectionUtils.isEmpty(applications)) {
            params.put(APPLICATIONS, String.join(",", applications));
        }
        ResponseEntity<ApplicationAnalytics> responseEntity = get(baseUrl, path, params, ApplicationAnalytics.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }

        throw new SdwanNotFoundException("Could not findByOcn Application Analytics");
    }

    public List<QOSAnalyticsTimeSeriesData> getQOSTimeSeries(SiteResponseV1 site, DeviceResponseV1 device, LocalDateTime startDate, LocalDateTime endDate) {
        String baseUrl = getAnalyticsUrl(site);
        Map<String, Object> params = new HashMap<>();
        params.put(CUSTOMER, site.getNetworkId());
        params.put(SITE, device.getResourceName());
        params.put(START_DATE, formatDateTime(startDate));
        params.put(END_DATE, formatDateTime(endDate));
        ResponseEntity<QOSAnalyticsTimeSeriesData[]> responseEntity =
                get(baseUrl, ANALYTICS_API_QOS_TIME_SERIES_URI, params, QOSAnalyticsTimeSeriesData[].class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return Arrays.asList(responseEntity.getBody());
        }
        return emptyList();
    }


    public InterfaceApplicationAnalyticsTableResponse getApplicationsAnalyticsTable(SiteResponseV1 site, DeviceResponseV1 device, InterfaceResponseV1 interfaceResponse,
                                                                                    LocalDateTime startDate, LocalDateTime endDate, Integer count, List<String> applications) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_APPLICATION_URI
                .concat(SLASH).concat(site.getNetworkId())
                .concat(SLASH).concat(device.getResourceName())
                .concat(SLASH).concat(Objects.nonNull(interfaceResponse.getNetwork()) ? interfaceResponse.getNetwork() : interfaceResponse.getCircuitName());
        Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        if (!CollectionUtils.isEmpty(applications)) {
            params.put(APPLICATIONS, String.join(",", applications));
        }
        params.put(FORMAT, FORMAT_TABLE);
        ResponseEntity<InterfaceApplicationAnalyticsTableResponse> responseEntity =
                get(baseUrl, path, params, InterfaceApplicationAnalyticsTableResponse.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not findByOcn Application Analytics table");
    }

    public List<FWRuleLogEvents> getFirewallRulesLogs(final SiteResponseV1 site, List<DeviceResponseV1> deviceResponses,
                                                      final String ruleName, final LocalDateTime startDate, final LocalDateTime endDate) {
        String baseUrl = getAnalyticsUrl(site);

        final String formattedRuleName = ruleName.replace(" ", "_-");
        Map<String, Object> params = new HashMap<>();
        params.put(START, formatDateTime(startDate));
        params.put(END, formatDateTime(endDate));
        params.put(TOP_COUNT, TOP_COUNT_VALUE);
        List<FirewallRuleLogResponse> firewallRuleLogResponses = deviceResponses.stream()
                .map(deviceResponse -> {
                    final String path = ANALYTICS_FW_RULE_LOG_API
                            .concat(SLASH)
                            .concat(site.getNetworkId())
                            .concat(SLASH).concat(deviceResponse.getResourceName())
                            .concat(SLASH).concat(formattedRuleName);

                    final ResponseEntity<FirewallRuleLogResponse> responseEntity =
                            get(baseUrl, path, params, FirewallRuleLogResponse.class, getHttpEntity());
                    return responseEntity.getBody();
                }).toList();

        List<FWRuleLogEvents> fwRuleLogEvents = new ArrayList<>();
        firewallRuleLogResponses.stream().filter(Objects::nonNull)
                .forEach(fwLogs -> fwRuleLogEvents.addAll(fwLogs.getEvents()));
        return fwRuleLogEvents;
    }

    public DDoSRulesAnalytics getDdosEventLogs(SiteResponseV1 site, DeviceResponseV1 device, LocalDateTime startDate, LocalDateTime endDate) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_DDOS_URI
                .concat(SLASH).concat(site.getNetworkId())
                .concat(SLASH).concat(device.getResourceName());
        Map<String, Object> params = new HashMap<>();
        params.put(START_DATE, formatDateTime(startDate));
        String endDateStr = DEFAULT_DDOS_ANALYTICS_END_DATE;
        if (Objects.nonNull(endDate)) {
            endDateStr = formatDateTime(endDate);
        }
        params.put(END_DATE, endDateStr);
        ResponseEntity<DDoSRulesAnalytics> responseEntity =
                get(baseUrl, path, params, DDoSRulesAnalytics.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not findByOcn any DdosRules");
    }

    public DDoSRulesTimeSeries getDdosAnalyticsTimeSeries(SiteResponseV1 site, List<String> deviceNames, LocalDateTime startDate, LocalDateTime endDate) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_DDOS_TIME_SERIES_URI.concat(SLASH).concat(site.getNetworkId());
        Map<String, Object> params = new HashMap<>();
        params.put(START_DATE, formatDateTime(startDate));
        String endDateStr = DEFAULT_DDOS_ANALYTICS_END_DATE;
        if (Objects.nonNull(endDate)) {
            endDateStr = formatDateTime(endDate);
        }
        params.put(END_DATE, endDateStr);
        deviceNames.forEach(deviceName -> params.put(DEVICE, deviceName));

        ResponseEntity<DDoSRulesTimeSeries> responseEntity =
                get(baseUrl, path, params, DDoSRulesTimeSeries.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not get DdosAnalyticsTimeSeries");
    }

    public List<FirewallRulesNetworkApiResponse> getFirewallNetworkTopAnalytics(String versaAnalytics, String networkId, FirewallRulesActionV1 action,
                                                                                LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        String baseUrl = analyticsApiBaseUrl + SLASH + versaAnalytics;
        String path = FW_ACTION_API.concat(SLASH).concat(networkId);
        Map<String, Object> params = new HashMap<>();
        params.put(START, formatDateTime(startDate));
        params.put(END, formatDateTime(endDate));
        params.put(TOP_COUNT, count);
        params.put(ACTION, action.name().toLowerCase());
        ResponseEntity<FirewallRulesNetworkApiResponse[]> responseEntity =
                get(baseUrl, path, params, FirewallRulesNetworkApiResponse[].class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return Arrays.stream(responseEntity.getBody()).toList();
        }
        throw new SdwanNotFoundException("Could not findByNetwork any Network");
    }

    public FirewallRulesNamesNetworkApiResponse getFirewallAnalyticsByRuleName(String versaAnalytics, String networkId, String ruleName,
                                                                               FirewallRulesActionV1 action, LocalDateTime startDate,
                                                                               LocalDateTime endDate) throws JsonProcessingException {
        String baseUrl = analyticsApiBaseUrl + SLASH + versaAnalytics;
        String path = FW_LOG_API.concat(SLASH).concat(networkId).concat(SLASH).concat(ruleName);
        Map<String, Object> params = new HashMap<>();
        params.put(START_DATE, formatDateTime(startDate));
        params.put(END_DATE, formatDateTime(endDate));
        params.put(ACTION, action.name().toLowerCase());
        ResponseEntity<Object> responseEntity = get(baseUrl, path, params, Object.class, getHttpEntity());
        if (Objects.nonNull(responseEntity)) {
            Object body = responseEntity.getBody();
            if (Objects.nonNull(body)) {
                return new ObjectMapper().readValue(body.toString(), FirewallRulesNamesNetworkApiResponse.class);
            }
        }
        throw new SdwanNotFoundException("Could not findByNetwork any Network");
    }

    private String getAnalyticsUrl(final SiteResponseV1 site) {
        return analyticsApiBaseUrl.concat(SLASH + site.getVersaAnalyticsInstance());
    }

    public List<URLFilterLogsResponse> getURLLogsResponses(final SiteResponseV1 siteResponse, final String deviceName, final LocalDateTime startDt, final LocalDateTime endDt) {
        String baseUrl = getAnalyticsUrl(siteResponse);
        String path = ANALYTICS_API_URL_FILTER_LOGS.concat(siteResponse.getNetworkId()).concat(SLASH).concat(deviceName);
        Map<String, Object> params = new HashMap<>();
        params.put(START_DATE, formatDateTime(startDt));
        params.put(END_DATE, formatDateTime(endDt));
        ResponseEntity<URLFilterLogsResponse[]> responseEntity = get(baseUrl, path, params, URLFilterLogsResponse[].class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return Arrays.stream(responseEntity.getBody()).toList();
        }
        return emptyList();
    }

    public List<SSLDecryptionLogsResponse> getSslDecryptionLogsResponses(final SiteResponseV1 siteResponse, final String deviceName, final LocalDateTime startDt, final LocalDateTime endDt) {
        String baseUrl = getAnalyticsUrl(siteResponse);
        String path = ANALYTICS_API_SSL_DECRYPTION_LOGS.concat(siteResponse.getNetworkId()).concat(SLASH).concat(deviceName);
        Map<String, Object> params = new HashMap<>();
        params.put(START_DATE, formatDateTime(startDt));
        params.put(END_DATE, formatDateTime(endDt));
        ResponseEntity<SSLDecryptionLogsResponse[]> responseEntity = get(baseUrl, path, params, SSLDecryptionLogsResponse[].class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return Arrays.stream(responseEntity.getBody()).toList();
        }
        return emptyList();
    }

    public SlaMetricsTimeSeriesDataResponse getSlaMetricsTimeSeries(SiteResponseV1 site, DeviceResponseV1 device, String remoteDeviceName, String interfaceCircuitName, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_SLA_METRICS_URI +
                SLASH + site.getNetworkId() +
                SLASH + device.getResourceName();
        Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        if (remoteDeviceName != null) {
            params.put(REMOTE_DEVICE_NAME, remoteDeviceName);
        }
        if (interfaceCircuitName != null) {
            params.put(INTERFACE, interfaceCircuitName);
        }
        ResponseEntity<SlaMetricsTimeSeriesDataResponse> responseEntity = get(baseUrl, path, params, SlaMetricsTimeSeriesDataResponse.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not get SlaMetricsTimeSeries");
    }

    public SlaMetricsTableDataResponse getSlaMetricsTableData(SiteResponseV1 site, DeviceResponseV1 device, String remoteDeviceName, String interfaceCircuitName, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_SLA_METRICS_URI
                .concat(SLASH).concat(site.getNetworkId())
                .concat(SLASH).concat(device.getResourceName());
        Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        if (remoteDeviceName != null) {
            params.put(REMOTE_DEVICE_NAME, remoteDeviceName);
        }
        if (interfaceCircuitName != null) {
            params.put(INTERFACE, interfaceCircuitName);
        }
        params.put(FORMAT, FORMAT_TABLE);
        ResponseEntity<SlaMetricsTableDataResponse> responseEntity =
                get(baseUrl, path, params, SlaMetricsTableDataResponse.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not get SlaMetricsTableData");
    }

    public FirewallRulesAnalyticsTableDataResponseV1 getFirewallRulesAnalyticsTableDataByNetworkId(SiteResponseV1 site, String deviceName, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_FIREWALL_RULES_BY_NETWORK
                .concat(SLASH).concat(site.getNetworkId());
        Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        if (deviceName != null) {
            params.put(DEVICE, deviceName);
        }
        params.put(FORMAT, FORMAT_TABLE);
        ResponseEntity<FirewallRulesAnalyticsTableDataResponseV1> responseEntity =
                get(baseUrl, path, params, FirewallRulesAnalyticsTableDataResponseV1.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not get FirewallRulesAnalyticsTableDataByNetworkId");
    }

    public FirewallZonesAnalyticsTableDataResponseV1 getFirewallZonesAnalyticsTableDataByNetworkId(SiteResponseV1 site, String deviceName, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_FIREWALL_ZONES_BY_NETWORK
                .concat(SLASH).concat(site.getNetworkId());
        Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        if (deviceName != null) {
            params.put(DEVICE, deviceName);
        }
        params.put(FORMAT, FORMAT_TABLE);
        ResponseEntity<FirewallZonesAnalyticsTableDataResponseV1> responseEntity =
                get(baseUrl, path, params, FirewallZonesAnalyticsTableDataResponseV1.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not get FirewallZonesAnalyticsTableDataByNetworkId");
    }

    public FirewallRulesAnalyticsTimeSeriesDataResponseV1 getFirewallRulesAnalyticsTimeSeriesByNetworkId(SiteResponseV1 site, String deviceName, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_FIREWALL_RULES_BY_NETWORK
                .concat(SLASH).concat(site.getNetworkId());
        Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        if (deviceName != null) {
            params.put(DEVICE, deviceName);
        }
        ResponseEntity<FirewallRulesAnalyticsTimeSeriesDataResponseV1> responseEntity =
                get(baseUrl, path, params, FirewallRulesAnalyticsTimeSeriesDataResponseV1.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not get FirewallRulesAnalyticsTimeSeriesByNetworkId");
    }

    public FirewallZonesAnalyticsTimeSeriesDataResponseV1 getFirewallZonesAnalyticsTimeSeriesByNetworkId(SiteResponseV1 site, String deviceName, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_FIREWALL_ZONES_BY_NETWORK
                .concat(SLASH).concat(site.getNetworkId());
        Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        if (deviceName != null) {
            params.put(DEVICE, deviceName);
        }
        ResponseEntity<FirewallZonesAnalyticsTimeSeriesDataResponseV1> responseEntity =
                get(baseUrl, path, params, FirewallZonesAnalyticsTimeSeriesDataResponseV1.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not get FirewallZonesAnalyticsTimeSeriesByNetworkId");
    }

    public TopUsageResponseV1 getTopAccessCircuitsByNetworkId(SiteResponseV1 site, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_TOP_USAGE_BY_NETWORK
                .concat(SLASH).concat(site.getNetworkId());
        Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        params.put(TYPE, "access_circuit");
        ResponseEntity<TopUsageResponseV1> responseEntity =
                get(baseUrl, path, params, TopUsageResponseV1.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not get TopAccessCircuitsByNetworkId");
    }

    public TopUsageResponseV1 getTopDevicesByNetworkId(SiteResponseV1 site, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_TOP_USAGE_BY_NETWORK
                .concat(SLASH).concat(site.getNetworkId());
        Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        params.put(TYPE, "site");
        ResponseEntity<TopUsageResponseV1> responseEntity =
                get(baseUrl, path, params, TopUsageResponseV1.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not get TopSitesByNetworkId");
    }

    public UsageByPathAnalyticsTableDataResponseV1 getUsageByPathAnalyticsTableDataBySiteIdAndDeviceId(SiteResponseV1 site, DeviceResponseV1 device, String remoteDeviceName, String interfaceCircuitName, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_USAGE_BY_PATH
                .concat(SLASH).concat(site.getNetworkId())
                .concat(SLASH).concat(device.getResourceName());
        Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        if (remoteDeviceName != null) {
            params.put(REMOTE_DEVICE_NAME, remoteDeviceName);
        }
        if (interfaceCircuitName != null) {
            params.put(INTERFACE, interfaceCircuitName);
        }
        params.put(FORMAT, FORMAT_TABLE);
        ResponseEntity<UsageByPathAnalyticsTableDataResponseV1> responseEntity =
                get(baseUrl, path, params, UsageByPathAnalyticsTableDataResponseV1.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not get UsageByPathAnalyticsTableDataBySiteIdAndDeviceId");
    }

    public UsageByPathAnalyticsTimeSeriesDataResponseV1 getUsageByPathAnalyticsTimeSeriesBySiteIdAndDeviceId(SiteResponseV1 site, DeviceResponseV1 device, String remoteDeviceName, String interfaceCircuitName, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_USAGE_BY_PATH +
                SLASH + site.getNetworkId() +
                SLASH + device.getResourceName();
        Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        if (remoteDeviceName != null) {
            params.put(REMOTE_DEVICE_NAME, remoteDeviceName);
        }
        if (interfaceCircuitName != null) {
            params.put(INTERFACE, interfaceCircuitName);
        }
        ResponseEntity<UsageByPathAnalyticsTimeSeriesDataResponseV1> responseEntity = get(baseUrl, path, params, UsageByPathAnalyticsTimeSeriesDataResponseV1.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not get UsageByPathAnalyticsTimeSeriesBySiteIdAndDeviceId");
    }

    public UsersAnalyticsTableDataResponseV1 getUsersAnalyticsTableDataBySiteIdAndDeviceId(SiteResponseV1 site, DeviceResponseV1 device, String interfaceCircuitName, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_USERS_BY_DEVICE
                .concat(SLASH).concat(site.getNetworkId())
                .concat(SLASH).concat(device.getResourceName());
        Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        if (interfaceCircuitName != null) {
            params.put(INTERFACE, interfaceCircuitName);
        }
        params.put(FORMAT, FORMAT_TABLE);
        ResponseEntity<UsersAnalyticsTableDataResponseV1> responseEntity =
                get(baseUrl, path, params, UsersAnalyticsTableDataResponseV1.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not get UsersAnalyticsTableDataBySiteIdAndDeviceId");
    }

    public UsersAnalyticsTimeSeriesDataResponseV1 getUsersAnalyticsTimeSeriesBySiteIdAndDeviceId(SiteResponseV1 site, DeviceResponseV1 device, String interfaceCircuitName, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_USERS_BY_DEVICE +
                SLASH + site.getNetworkId() +
                SLASH + device.getResourceName();
        Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        if (interfaceCircuitName != null) {
            params.put(INTERFACE, interfaceCircuitName);
        }
        ResponseEntity<UsersAnalyticsTimeSeriesDataResponseV1> responseEntity = get(baseUrl, path, params, UsersAnalyticsTimeSeriesDataResponseV1.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not get UsersAnalyticsTimeSeriesBySiteIdAndDeviceId");
    }

    private HttpEntity<Object> getHttpEntity() {
        return new HttpEntity<>(authHeaderGenerator.createSDWANAnalyticsHeaders());
    }

    public List<AntivirusDetectionEventResponseV1> getAntivirusDetectionEvents(SiteResponseV1 site, DeviceResponseV1 device, LocalDateTime startDate, LocalDateTime endDate,
                                                                               Integer count) {
        String baseUrl = getAnalyticsUrl(site);
        String path = ANALYTICS_API_ANTIVIRUS_DETECTION_EVENTS_URI +
                SLASH + site.getNetworkId() +
                SLASH + device.getResourceName();
        Map<String, Object> params = new HashMap<>();
        params.put(START_DATE, formatDateTime(startDate));
        params.put(END_DATE, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        ResponseEntity<AntivirusDetectionEventResponseV1[]> responseEntity =
                get(baseUrl, path, params, AntivirusDetectionEventResponseV1[].class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return Arrays.asList(responseEntity.getBody());
        }
        throw new SdwanNotFoundException("Could not get antivirus detection events");
    }

    public List<SystemAnalyticsTimeSeriesResponseV1> getSystemSeriesAnalytics(SiteResponseV1 site, DeviceResponseV1 device, LocalDateTime startDate, LocalDateTime endDate) {
        String baseUrl = getAnalyticsUrl(site);

        String path = SYSTEM_TIME_SERIES_ANALYTICS + SLASH + site.getNetworkId() + SLASH + device.getResourceName();
        Map<String, Object> params = new HashMap<>();
        params.put(START_DATE, formatDateTime(startDate));
        params.put(END_DATE, formatDateTime(endDate));
        ResponseEntity<SystemAnalyticsTimeSeriesResponseV1[]> responseEntity =
                get(baseUrl, path, params, SystemAnalyticsTimeSeriesResponseV1[].class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return Arrays.asList(responseEntity.getBody());
        }
        throw new SdwanNotFoundException("Could not get antivirus detection events");
    }

    public List<VulnerabilityDetectionEventResponseV1> getVulnerabilityDetectionEvents(
            SiteResponseV1 site, DeviceResponseV1 device, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        final String baseUrl = getAnalyticsUrl(site);
        final String path = ANALYTICS_API_IDP_VULNERABILITY_DETECTION_EVENTS_URI +
                SLASH + site.getNetworkId() +
                SLASH + device.getResourceName();
        final Map<String, Object> params = new HashMap<>();
        params.put(START_DATE, formatDateTime(startDate));
        params.put(END_DATE, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        final ResponseEntity<VulnerabilityDetectionEventResponseV1[]> responseEntity =
                get(baseUrl, path, params, VulnerabilityDetectionEventResponseV1[].class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return Arrays.asList(responseEntity.getBody());
        }
        throw new SdwanNotFoundException("Could not get idp vulnerability detection events");
    }

    public List<IPFilteringDetectionEventResponseV1> getIpFilteringDetectionEvents(
            SiteResponseV1 site, DeviceResponseV1 device, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        final String baseUrl = getAnalyticsUrl(site);
        final String path = ANALYTICS_API_IP_FILTERING_DETECTION_EVENTS_URI +
                SLASH + site.getNetworkId() +
                SLASH + device.getResourceName();
        final Map<String, Object> params = new HashMap<>();
        params.put(START_DATE, formatDateTime(startDate));
        params.put(END_DATE, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        final ResponseEntity<IPFilteringDetectionEventResponseV1[]> responseEntity =
                get(baseUrl, path, params, IPFilteringDetectionEventResponseV1[].class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return Arrays.asList(responseEntity.getBody());
        }
        throw new SdwanNotFoundException("Could not get ip filtering detection events");
    }

    public VrfTimeSeriesAnalyticsResponseV1 getVrfTimeSeriesAnalytics(
            SiteResponseV1 site,
            DeviceResponseV1 device,
            String interfaceCircuitName,
            LocalDateTime startDate,
            LocalDateTime endDate,
            Integer count) {
        final String baseUrl = getAnalyticsUrl(site);
        final String path = ANALYTICS_API_VRF
                .concat(SLASH).concat(site.getNetworkId())
                .concat(SLASH).concat(device.getResourceName());
        final Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        if (interfaceCircuitName != null) {
            params.put(INTERFACE, interfaceCircuitName);
        }
        final ResponseEntity<VrfTimeSeriesAnalyticsResponseV1> responseEntity =
                get(baseUrl, path, params, VrfTimeSeriesAnalyticsResponseV1.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not get VRF time series Analytics");
    }

    public VrfTableDataAnalyticsResponseV1 getVrfTableDataAnalytics(
            SiteResponseV1 site,
            DeviceResponseV1 device,
            String interfaceCircuitName,
            LocalDateTime startDate,
            LocalDateTime endDate,
            Integer count) {
        final String baseUrl = getAnalyticsUrl(site);
        final String path = ANALYTICS_API_VRF
                .concat(SLASH).concat(site.getNetworkId())
                .concat(SLASH).concat(device.getResourceName());
        final Map<String, Object> params = new HashMap<>();
        params.put(FROM, formatDateTime(startDate));
        params.put(TO, formatDateTime(endDate));
        if (Objects.isNull(count)) {
            count = DEFAULT_COUNT;
        }
        params.put(COUNT, count);
        if (interfaceCircuitName != null) {
            params.put(INTERFACE, interfaceCircuitName);
        }
        params.put(FORMAT, FORMAT_TABLE);
        final ResponseEntity<VrfTableDataAnalyticsResponseV1> responseEntity =
                get(baseUrl, path, params, VrfTableDataAnalyticsResponseV1.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException("Could not get VRF table data analytics");
    }
}
