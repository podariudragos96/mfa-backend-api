package net.colt.sdwan.portal.database.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "SSO_DOMAIN")
public class SsoDomain {

    @Id
    @Column(name = "DOMAIN")
    private String domain;

    @Column(name = "URL")
    private String url;

}
