package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.generated.model.service.InterfaceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.netflow.ipfix.api.generated.model.NetflowCollectorApiV1;
import net.colt.sdwan.portal.model.NetFlowCollectorV1;
import net.colt.sdwan.portal.services.InterfaceService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Component
public class NetflowCollectorRequestMapper {

    private static final ModelMapper modelMapper = SingletonModelMapper.getInstance();
    private final InterfaceService interfaceService;

    public List<NetflowCollectorApiV1> mapNetflowCollectors(List<NetFlowCollectorV1> netFlowCollectors, SiteResponseV1 siteResponse) {
        return netFlowCollectors.stream()
                .map(collector -> mapNetflowCollector(collector, siteResponse))
                .toList();
    }

    private NetflowCollectorApiV1 mapNetflowCollector(NetFlowCollectorV1 netFlowCollectorV1, SiteResponseV1 siteResponse) {
        NetflowCollectorApiV1 mappedNetflowCollector = modelMapper.map(netFlowCollectorV1, NetflowCollectorApiV1.class);
        mappedNetflowCollector.setIp(netFlowCollectorV1.getIp());
        Optional<InterfaceResponseV1> interfaceResponse = interfaceService.filterInterfaceResponseFromSite(siteResponse,
                netFlowCollectorV1.getVpn());
        if (interfaceResponse.isEmpty()) {
            throw new SdwanBadRequestException(String.format("No Interface found for provided VPN '%s'.", netFlowCollectorV1.getVpn()));
        }

        return mappedNetflowCollector;
    }
}
