package net.colt.sdwan.portal.services.impl;

import jakarta.json.Json;
import jakarta.json.JsonPatch;
import jakarta.json.JsonPatchBuilder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.generated.model.service.SiteStatusV1;
import net.colt.sdwan.portal.client.ServiceApiClient;
import net.colt.sdwan.portal.mappers.SiteResponseMapper;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.OnGoingActionV2;
import net.colt.sdwan.portal.model.SiteRequestV1;
import net.colt.sdwan.portal.model.SiteResponseV3;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.portal.validator.UserTenantValidator;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import static java.util.Objects.nonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static org.apache.commons.collections4.CollectionUtils.isNotEmpty;

@RequiredArgsConstructor
@Slf4j
@Service
public class SitesServiceImpl implements SitesService {

    private final SiteResponseMapper siteResponseMapper;
    private final ServiceApiClient serviceApiClient;
    private final SiteResponseValidator siteResponseValidator;
    private final UserTenantValidator userTenantValidator;

    @Override
    public List<SiteResponseV3> getAllSitesV3() {
        Set<SiteResponseV1> activeSites = getAllUserSites().stream()
                .filter(this::isSiteValid)
                .collect(Collectors.toSet());
        return activeSites.stream()
                .map(siteResponseMapper::fromV3)
                .toList();
    }

    private boolean isSiteValid(SiteResponseV1 siteResponseV1) {
        return SiteStatusV1.ACTIVE.equals(siteResponseV1.getSiteStatus())
                && isNotEmpty(siteResponseV1.getDevices())
                && siteResponseV1.getDevices().stream()
                .allMatch(deviceResponseV1 ->
                        DeviceResponseV1.StatusEnum.ACTIVE.equals(deviceResponseV1.getStatus()));
    }

    @Override
    public SiteResponseV3 getSiteBySiteIdV3(String siteId) {
        final SiteResponseV1 siteResponse = getApiSiteAndVerify(siteId);
        return siteResponseMapper.fromV3(siteResponse);
    }

    @Override
    public SiteResponseV1 getApiSiteAndVerify(String siteId) {
        if (StringUtils.isEmpty(siteId)) {
            throw new SdwanBadRequestException("Empty site id");
        }

        SiteResponseV1 siteResponse = serviceApiClient.getSiteDetailsById(siteId);
        if (!userTenantValidator.hasValidUserTenant(siteResponse)) {
            throw new SdwanNotFoundException("No site found for this user's tenant.");
        }
        return siteResponse;
    }

    @Override
    public List<String> getLockedSites(String username) {
        final List<SiteResponseV1> lockedSites = serviceApiClient.getLockedSites(username);
        if (CollectionUtils.isNotEmpty(lockedSites)) {
            return lockedSites.stream().filter(SiteResponseV1::getLocked).map(s -> s.getId().toString()).toList();
        }
        return Collections.emptyList();
    }

    @Override
    public void unlockSites(List<String> siteIds, String userName) {
        log.debug("Unlocking sites {}", siteIds);
        siteIds.forEach(id -> {
            final Runnable runnable = () -> unlockSite(userName, id);
            runnable.run();
        });
    }

    /**
     * Both lockedDt and OngoingAction are not being set on the SiteRequest because they are set on service-api.
     */
    private void unlockSite(String userName, String id) {
        final JsonPatch jsonPatch = Json.createPatchBuilder()
                .replace("/locked", false)
                .replace("/lockedUser", userName)
                .build();

        serviceApiClient.updateSiteDetails(jsonPatch, Long.valueOf(id));
        log.debug("Finished unlocking site {}. ", id);
    }

    @Override
    public void updateSiteWithStatusOrFriendlyName(final String siteId, final SiteRequestV1 siteRequest) {
        log.debug("Updating site: {} | locking {} and friendly name {}", siteId, siteRequest.getLocked(),
                siteRequest.getFriendlyName());
        if (Objects.isNull(siteRequest.getFriendlyName()) && Objects.isNull(siteRequest.getLocked())) {
            throw new SdwanBadRequestException("PATCH Sites: both values are null.");
        }

        final SiteResponseV1 siteResponse = getApiSiteAndVerify(siteId);

        if (isSiteLockedByAnotherUser(siteResponse)) {
            throw new SdwanBadRequestException(String.format("Site with id %s is already locked by another user.", siteId));
        }

        final JsonPatchBuilder jsonPatchBuilder = Json.createPatchBuilder();

        if (nonNull(siteRequest.getFriendlyName())) {
            jsonPatchBuilder.replace("/friendlyName", siteRequest.getFriendlyName());
            log.debug("Finished updating friendly name for site {}.", siteId);
        }

        if (nonNull(siteRequest.getLocked())) {
            jsonPatchBuilder.replace("/locked", siteRequest.getLocked());
            jsonPatchBuilder.replace("/lockedUser", Objects.requireNonNull(AuthUserHelper.getAuthUser()).getUsername());
        }

        serviceApiClient.updateSiteDetails(jsonPatchBuilder.build(), Long.valueOf(siteId));
        log.debug("Finished locking/unlocking site {}. ", siteId);
    }

    private boolean isSiteLockedByAnotherUser(SiteResponseV1 siteResponse) {
        return siteResponse.getLocked() && !siteResponse.getLockedUser().equals(AuthUserHelper.getAuthUser().getUsername());
    }

    @Override
    public void updateOngoingAction(String siteId, OnGoingActionV2 ongoingAction) {
        updateOnGoingActionImpl(siteId, ongoingAction.toString());
    }

    private void updateOnGoingActionImpl(String siteId, String ongoingAction) {
        log.debug("Updating ongoing action for site {} to {}", siteId, ongoingAction);
        final JsonPatch jsonPatch = Json.createPatchBuilder()
                .replace("/onGoingAction", ongoingAction)
                .build();

        serviceApiClient.updateSiteDetails(jsonPatch, Long.valueOf(siteId));
    }

    @Override
    public CorrelationIdResponseV1 rediscoverBySiteId(final String siteId) {
        final SiteResponseV1 siteResponse = getApiSiteAndVerify(siteId);
        if (CollectionUtils.isNotEmpty(siteResponse.getDevices())
                && siteResponse.getDevices().stream().findFirst().isPresent()) {
            siteResponseValidator.isDeviceSetReachableBySiteId(siteResponse);
            siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
            updateOngoingAction(siteId, OnGoingActionV2.REDISCOVERING);
            serviceApiClient.rediscoverBySiteId(siteResponse.getId());
            return new CorrelationIdResponseV1(MDC.get(CORRELATION_ID));
        }
        throw new SdwanBadRequestException("Empty device set for site id: " + siteId);
    }

    public List<SiteResponseV1> getAllByUserTenants() {
        final List<Integer> userTenantIds = Objects.requireNonNull(AuthUserHelper.getAuthUser()).getAccessibleTenantIds();

        final List<SiteResponseV1> response = serviceApiClient.getSitesByTenantIds(userTenantIds);

        if (CollectionUtils.isEmpty(response)) {
            log.error("No site found for user's customers: " + AuthUserHelper.getAuthUser().getUsername());
        }
        return response;
    }

    public Set<SiteResponseV1> getAllUserSites() {

        List<Integer> userTenantIds = AuthUserHelper.getAuthUser().getAccessibleTenantIds();
        List<SiteResponseV1> response = serviceApiClient.getSitesByTenantIds(userTenantIds);
        return new HashSet<>(response);
    }

    public List<String> getDeviceNamesFromSiteResponse(SiteResponseV1 siteResponse) {
        final List<String> deviceNames = new ArrayList<>();
        if (isNotEmpty(siteResponse.getDevices())) {
            siteResponse.getDevices().forEach(device -> deviceNames.add(device.getResourceName()));
        }
        return deviceNames;
    }

    public List<String> getDeviceUuidsFromSiteResponse(SiteResponseV1 siteResponse) {
        final List<String> deviceUuids = new ArrayList<>();
        if (isNotEmpty(siteResponse.getDevices())) {
            siteResponse.getDevices().forEach(device -> deviceUuids.add(device.getUuid()));
        }
        return deviceUuids;
    }

    @Override
    public void updateLoggingProfile(String siteId, String loggingProfile, String loggingEvent) {
        log.debug("Updating logging profile for site {} to {}", siteId, loggingProfile);
        final JsonPatch jsonPatch = Json.createPatchBuilder()
                .replace("/loggingProfile", loggingProfile)
                .replace("/loggingEvent", loggingEvent)
                .build();

        serviceApiClient.updateSiteDetails(jsonPatch, Long.valueOf(siteId));
    }
}
