package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.client.model.*;
import net.colt.sdwan.portal.model.*;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.*;

@Component
public class InterfaceAnalyticsMapper extends CommonMapper {
    private static final List<AnalyticsMetricEnum> type2Metrics = Arrays.stream(AnalyticsMetricEnum.values()).toList();

    public Optional<InterfaceAnalyticsTimeSeriesDataResponseV2> mapFromApiResponse(List<AnalyticsTimeSeriesData> analyticsTimeSeriesDataList,
                                                                                   final String deviceName, final String interfaceCircuitName) {
        analyticsTimeSeriesDataList = analyticsTimeSeriesDataList.stream()
                .filter(timeSeriesData -> Objects.nonNull(filterTimeSeriesData(timeSeriesData, deviceName, interfaceCircuitName)))
                .toList();
        analyticsTimeSeriesDataList = mergeLabels(analyticsTimeSeriesDataList);
        Map<String, List<AnalyticsTimeSeriesData>> map = new HashMap<>();
        analyticsTimeSeriesDataList.forEach(seriesData -> {
            if (map.containsKey(seriesData.getCircuitName())) {
                map.get(seriesData.getCircuitName()).add(seriesData);
            } else {
                map.put(seriesData.getCircuitName(), new ArrayList<>(Collections.singletonList(seriesData)));
            }
        });
        return map.keySet().stream()
                .map(key -> mapInterfaceAnalyticsTimeSeriesDataResponse(key, map.get(key))).findAny();
    }

    private AnalyticsTimeSeriesData filterTimeSeriesData(AnalyticsTimeSeriesData timeSeriesData, final String deviceName, String interfaceCircuitName) {
        AnalyticsTimeSeries analyticsTimeSeries = timeSeriesData.getAnalyticsTimeSeries();
        final String circuitName = timeSeriesData.getCircuitName();
        if (interfaceCircuitName.equalsIgnoreCase(circuitName) && !circuitName.contains(deviceName)
                && type2Metrics.contains(analyticsTimeSeries.getMetric())) {
            timeSeriesData.setCircuitName(circuitName.substring(circuitName.indexOf(",") + 1));
            return timeSeriesData;
        }
        return null;
    }

    private InterfaceAnalyticsTimeSeriesDataResponseV2 mapInterfaceAnalyticsTimeSeriesDataResponse(String key, List<AnalyticsTimeSeriesData> analyticsTimeSeriesData) {
        List<InterfaceAnalyticsTimeSeriesZoneResponseV1> zones = new ArrayList<>();
        zones.add(getInterfaceAnalyticsZoneResponse("SDWAN", analyticsTimeSeriesData));

        return new InterfaceAnalyticsTimeSeriesDataResponseV2()
                .circuitName(key)
                .zones(zones);
    }

    public InterfaceAnalyticsTimeSeriesZoneResponseV1 getInterfaceAnalyticsZoneResponse(String zoneName, List<AnalyticsTimeSeriesData> analyticsTimeSeriesData) {
        return new InterfaceAnalyticsTimeSeriesZoneResponseV1()
                .zoneName(zoneName)
                .metrics(mapMetricList(analyticsTimeSeriesData.stream()
                        .map(AnalyticsTimeSeriesData::getAnalyticsTimeSeries)
                        .toList()));
    }

    private List<InterfaceAnalyticsTimeSeriesAnalyticsResponseV1> mapMetricList(List<AnalyticsTimeSeries> analyticsTimeSeriesList) {
        return analyticsTimeSeriesList.stream().map(this::mapMetric).toList();
    }

    private InterfaceAnalyticsTimeSeriesAnalyticsResponseV1 mapMetric(AnalyticsTimeSeries seriesData) {
        return new InterfaceAnalyticsTimeSeriesAnalyticsResponseV1()
                .label(mapLabelFromClientEnum(seriesData.getLabel()))
                .metric(mapMetricFromClientEnum(seriesData.getMetric()))
                .data(mapDataFromList(seriesData.getData()));
    }

    private AnalyticsLabelV1 mapLabelFromClientEnum(AnalyticsLabelEnum label) {
        if (Objects.nonNull(label)) {
            return AnalyticsLabelV1.fromValue(label.name());
        }
        return null;
    }

    private AnalyticsMetricV1 mapMetricFromClientEnum(AnalyticsMetricEnum label) {
        if (Objects.nonNull(label)) {
            return AnalyticsMetricV1.fromValue(label.name());
        }
        return null;
    }

    private List<InterfaceAnalyticsDataResponseV1> mapDataFromList(List<List<BigDecimal>> data) {
        return data.stream()
                .map(list -> new InterfaceAnalyticsDataResponseV1()
                        .value(list.get(0) == null ? 0 : list.get(0).doubleValue())
                        .time(list.get(1).longValue()))
                .toList();
    }

    private List<AnalyticsTimeSeriesData> mergeLabels(final List<AnalyticsTimeSeriesData> analyticsTimeSeriesDataList) {
        Set<AnalyticsTimeSeriesData> analyticsTimeSeriesDataSet = new HashSet<>(analyticsTimeSeriesDataList);
        analyticsTimeSeriesDataList.forEach(seriesData ->
                analyticsTimeSeriesDataSet.stream()
                        .filter(seriesDataFromSet -> seriesDataFromSet.equals(seriesData))
                        .filter(seriesDataFromSet -> seriesDataFromSet.getAnalyticsTimeSeries().getData().addAll(seriesData.getAnalyticsTimeSeries().getData()))
        );
        return new ArrayList<>(analyticsTimeSeriesDataSet);
    }

    public InterfaceAnalyticsTableDataResponseV1 mapFromApiTableResponse(InterfaceAnalyticsTableResponse interfaceAnalyticsTableResponse, String circuitName) {
        InterfaceAnalyticsTableDataResponseV1 response = new InterfaceAnalyticsTableDataResponseV1();
        if (!CollectionUtils.isEmpty(interfaceAnalyticsTableResponse.getInterfaces())) {
            ArrayList<InterfaceAnalyticsTableDataZoneResponseV1> zones = new ArrayList<>();

            final InterfaceAnalyticsRowResponse interfaceAnalyticsRowResponse = interfaceAnalyticsTableResponse.getInterfaces().stream()
                    .filter(rowResponse -> Objects.equals(rowResponse.getAccessCircuit(), circuitName))
                    .findFirst()
                    .orElse(new InterfaceAnalyticsRowResponse());

            zones.add(getTableRowResponse(interfaceAnalyticsRowResponse, "SD-WAN"));
            response = new InterfaceAnalyticsTableDataResponseV1()
                    .circuitName(circuitName)
                    .zones(zones);
        }
        return response;
    }

    public InterfaceAnalyticsTableDataZoneResponseV1 getTableRowResponse(InterfaceAnalyticsRowResponse interfaceAnalyticsRowResponse, String zoneName) {
        return new InterfaceAnalyticsTableDataZoneResponseV1()
                .zoneName(zoneName)
                .site(interfaceAnalyticsRowResponse.getSite())
                .accessCircuit(interfaceAnalyticsRowResponse.getAccessCircuit())
                .uplinkBandwidth(interfaceAnalyticsRowResponse.getUplinkBandwidth())
                .downlinkBandwidth(interfaceAnalyticsRowResponse.getDownlinkBandwidth())
                .ip(interfaceAnalyticsRowResponse.getIp())
                .isp(interfaceAnalyticsRowResponse.getIsp())
                .appliance(interfaceAnalyticsRowResponse.getApplicance())
                .volumeIn(interfaceAnalyticsRowResponse.getVolumeRx())
                .volumeOut(interfaceAnalyticsRowResponse.getVolumeTx())
                .bandwidthIn(interfaceAnalyticsRowResponse.getBandwidthRx())
                .bandwidthOut(interfaceAnalyticsRowResponse.getBandwidthTx());
    }
}
