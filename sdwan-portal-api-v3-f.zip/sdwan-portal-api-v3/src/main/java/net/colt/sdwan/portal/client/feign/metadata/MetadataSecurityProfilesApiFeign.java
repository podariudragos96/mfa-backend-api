package net.colt.sdwan.portal.client.feign.metadata;

import net.colt.sdwan.metadata.api.generated.api.SecurityProfilesApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "metadataApiClient", url = "${sdwan.metadata.api.baseurl}",
        configuration = MetadataFeignConfiguration.class)
public interface MetadataSecurityProfilesApiFeign extends SecurityProfilesApiApi {
}
