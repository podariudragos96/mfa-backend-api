package net.colt.sdwan.portal.mappers;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.modelmapper.ModelMapper;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SingletonModelMapper {

    public static ModelMapper getInstance() {
        return SingletonHelper.INSTANCE;
    }

    private static class SingletonHelper {
        private static final ModelMapper INSTANCE = new ModelMapper();
    }
}
