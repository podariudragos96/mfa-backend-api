package net.colt.sdwan.portal.client.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

@Getter
@AllArgsConstructor
public enum FloodProtocol {

    TCP("TCP"),
    UDP("UDP"),
    ICMP("ICMP"),
    ANY("Any"),
    TCP_OR_UDP("TCP_OR_UDP");

    private final String name;

    public static boolean contains(String value) {
        for (FloodProtocol p : FloodProtocol.values()) {
            if (p.name().equalsIgnoreCase(value)) {
                return true;
            }
        }
        return false;
    }

    public static FloodProtocol fromValue(final String value) {
        if (ANY.name().equalsIgnoreCase(value) || StringUtils.isEmpty(value)) {
            return ANY;
        }
        return FloodProtocol.valueOf(value.toUpperCase());
    }
}
