package net.colt.sdwan.portal.client;

import org.springframework.stereotype.Component;

/**
 * Refactor your code to get this URI from a customizable parameter.
 * URIs should not be hardcoded java:S1075
 * We decided to ignore this rule since these paths are static and are not going to change
 */
@SuppressWarnings("java:S1075")
@Component
public class ServicesUrlProperties {
    public static final String POLICY_RULES_LIMIT = "steering.rules.limit";
    public static final String POLICY_RULES_LIMIT_CGW = "steering.rules.limit.cgw";
    public static final String FIREWALL_RULES_LIMIT = "firewall.rules.limit";
    public static final String FIREWALL_RULES_LIMIT_CGW = "firewall.rules.limit.cgw";
    public static final String POLICY_RULES_LIMIT_GW = "steering.rules.limit.gw";
    public static final String POLICY_RULES_LIMIT_DGW = "steering.rules.limit.dgw";
    public static final String FIREWALL_RULES_LIMIT_GW = "firewall.rules.limit.gw";
    public static final String FIREWALL_RULES_LIMIT_DGW = "firewall.rules.limit.dgw";
    public static final String POLICY_API_PING_URI = "/ping";
    public static final String POLICY_API_V2 = "/v2";
    public static final String POLICY_API_POLICIES_CLOUD_GATEWAY_URI = "/cgw/policies";
    public static final String POLICY_API_CGW_FIREWALL_RULES_URI = "/cgw/firewall-rules";
    public static final String POLICY_API_GW_FIREWALL_RULES_URI = "/gw/firewall-rules";
    public static final String POLICY_API_POLICIES_HISTORY = "/history";
    public static final String POLICY_API_FIREWALL_RULES_URI = "/firewall-rules";
    public static final String POLICY_API_FIREWALL_RULES_HISTORY_URI = "/history";
    public static final String POLICY_API_POLICIES_DECRYPTION_RULES_URI = "/decryption_rules";
    public static final String POLICY_API_POLICIES_DECRYPTION_RULES_HISTORY = "/history";
    public static final String POLICY_API_POLICIES_CLOUD_URI = "/gw/policies";
    public static final String POLICY_API_POLICIES_URI = "/policies";
    public static final String POLICY_API_TRACEROUTE_URI = "/traceroute";
    public static final String POLICY_API_MOS_EXTENSION_URI = "/mos/sessions/extensive";
    public static final String POLICY_API_DYNAMIC_STATS_URI = "/dynamicstats";
    public static final String POLICY_API_DDOS_URI = "/ddos";
    public static final String POLICY_API_NAT_URI = "/nat_rules";
    public static final String POLICY_API_NAT_HISTORY = "/history";
    public static final String POLICY_DYNAMIC_NAT_URI = "/dynamic/routes";
    public static final String POLICY_API_CLEAR_STATS_URI = "/clearstats";
    public static final String POLICY_API_LOCAL_INTERNET_BREAKOUT = "/local_internet_breakout";
    public static final String POLICY_API_NETWORKS = "/networks";
    public static final String POLICY_API_SITES = "/sites";
    public static final String POLICY_API_SHOW_INTERFACE = "/show-interface";
    public static final String POLICY_API_PPPOE_STAT = "/pppoe-stat";
    public static final String ANALYTICS_API_APPLICATION_URI = "/sdwan/applications";
    public static final String ANALYTICS_API_DDOS_URI = "/ddos";
    public static final String ANALYTICS_API_SSL_DECRYPTION_LOGS = "/ssl_decryption/logs/";
    public static final String ANALYTICS_API_URL_FILTER_LOGS = "/url_filter/logs/";
    public static final String ANALYTICS_API_DDOS_TIME_SERIES_URI = "/ddos/time_series";
    public static final String ANALYTICS_API_TIME_SERIES_URI = "/time-series/";
    public static final String ANALYTICS_API_QOS_TIME_SERIES_URI = "/qos-time-series/";
    public static final String ANALYTICS_API_INTERFACE_ANALYTICS_TABULAR_URI = "/interface-analytics-tabular/";
    public static final String ANALYTICS_API_SLA_METRICS_URI = "/sla-metrics";
    public static final String ANALYTICS_API_FIREWALL_RULES_BY_NETWORK = "/firewall-rules-by-network";
    public static final String ANALYTICS_API_FIREWALL_ZONES_BY_NETWORK = "/firewall-zones-by-network";
    public static final String ANALYTICS_API_TOP_USAGE_BY_NETWORK = "/top-usage-by-network";
    public static final String ANALYTICS_API_USERS_BY_DEVICE = "/users-by-device";
    public static final String ANALYTICS_API_USAGE_BY_PATH = "/usage-by-path";
    public static final String ANALYTICS_API_ANTIVIRUS_DETECTION_EVENTS_URI = "/antivirus-detection-events";
    public static final String ANALYTICS_API_IDP_VULNERABILITY_DETECTION_EVENTS_URI = "/idp-vulnerability-detection-events";
    public static final String ANALYTICS_API_IP_FILTERING_DETECTION_EVENTS_URI = "/ip-filtering-detection-events";
    public static final String ANALYTICS_API_VRF = "/vrf-usage";
    public static final String ANALYTICS_FW_RULE_LOG_API = "/firewall-rule-logs";
    public static final String FW_ACTION_API = "/fw/actions";
    public static final String FW_LOG_API = "/fw/rule";
    public static final String SYSTEM_TIME_SERIES_ANALYTICS = "/system/time_series";

    private ServicesUrlProperties() {
    }
}
