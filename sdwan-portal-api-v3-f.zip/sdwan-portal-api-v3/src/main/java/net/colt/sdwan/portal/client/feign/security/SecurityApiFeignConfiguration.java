package net.colt.sdwan.portal.client.feign.security;

import feign.RequestInterceptor;
import feign.auth.BasicAuthRequestInterceptor;
import net.colt.sdwan.portal.client.feign.util.FeignConfigurationUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

public class SecurityApiFeignConfiguration {

    protected String username;
    protected String password;

    public SecurityApiFeignConfiguration(
            @Value("${sdwan.security.api.user}") String username,
            @Value("${sdwan.security.api.pwd}") String password) {
        this.username = username;
        this.password = password;
    }

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        return new BasicAuthRequestInterceptor(username, password);
    }

    @Bean
    public RequestInterceptor requestUriInterceptor() {
        return FeignConfigurationUtil::getRequestUri;
    }
}
