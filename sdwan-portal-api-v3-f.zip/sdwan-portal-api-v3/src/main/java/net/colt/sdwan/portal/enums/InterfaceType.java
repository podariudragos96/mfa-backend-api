package net.colt.sdwan.portal.enums;

public enum InterfaceType {
    MPLS,
    INT,
    LTE
}
