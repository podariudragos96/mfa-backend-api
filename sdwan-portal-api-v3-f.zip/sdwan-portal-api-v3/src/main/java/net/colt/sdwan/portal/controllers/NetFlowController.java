package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.NetflowIpfixApiApi;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.NetFlowHistoryResponseV1;
import net.colt.sdwan.portal.model.NetFlowRequestV1;
import net.colt.sdwan.portal.model.NetFlowResponseV1;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.NetFlowService;
import net.colt.sdwan.portal.validator.model.NetFlowValidator;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@RequiredArgsConstructor
@Controller
public class NetFlowController implements NetflowIpfixApiApi {

    private final NetFlowService netFlowService;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setValidator(new NetFlowValidator());
    }

    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<NetFlowResponseV1> getNetflowRuleSetV1(String siteId) {
        return ResponseEntity.ok(netFlowService.getNetflowRuleSetV1(siteId));
    }

    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<NetFlowHistoryResponseV1>> getNetflowRulesHistoryV2(String siteId) {
        return ResponseEntity.ok(netFlowService.getNetflowRulesHistoryV2(siteId));
    }

    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<NetFlowResponseV1> getNetflowRulesHistoryByIdV1(String siteId, String id) {
        return ResponseEntity.ok(netFlowService.getNetflowRulesHistoryByIdV1(siteId, id));
    }

    @SDWanAsyncMethod("/v1/sites/{site_id}/netflow_ipfix")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateNetFlowRuleSetV1(String siteId,
                                                                          @RequestBody NetFlowRequestV1 netFlowRequestV1) {
        return ResponseEntity.ok(netFlowService.updateNetflowRulesV1(siteId, netFlowRequestV1));
    }
}
