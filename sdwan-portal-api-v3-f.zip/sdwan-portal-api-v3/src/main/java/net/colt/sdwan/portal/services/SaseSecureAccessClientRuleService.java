package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SaseSecureAccessClientRulesRequestV1;
import net.colt.sdwan.portal.model.SaseSecureAccessClientRulesResponseV1;

public interface SaseSecureAccessClientRuleService {

    SaseSecureAccessClientRulesResponseV1 getSecureAccessClientRulesV1(String tenantUuid);

    CorrelationIdResponseV1 updateSecureAccessClientRulesV1(String tenantUuid,
                                                            SaseSecureAccessClientRulesRequestV1 saseSecureAccessClientRulesRequestV1);

}
