package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.generated.model.service.SiteTypeV1;
import net.colt.sdwan.portal.client.feign.sitesettings.LanConfigApiFeign;
import net.colt.sdwan.portal.mappers.LanConfigMapper;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.LanConfigV1;
import net.colt.sdwan.portal.model.LanConfigurationRequestV1;
import net.colt.sdwan.portal.model.OnGoingActionV2;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.LanConfigService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.sitesettings.api.generated.model.LanConfigurationRequestV1ApiV1;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;

@Slf4j
@RequiredArgsConstructor
@Service
public class LanConfigServiceImpl implements LanConfigService {

    private final SitesService sitesService;
    private final SiteResponseValidator siteResponseValidator;
    private final ResponseEntityValidator responseEntityValidator;
    private final LanConfigApiFeign lanConfigApiFeign;
    private final LanConfigMapper lanConfigMapper;

    public static final String UPDATE_LAN_CONFIG = "UPDATE LAN CONFIG";

    @Override
    public CorrelationIdResponseV1 updateLansConfigs(String siteId, LanConfigurationRequestV1 lanConfigurationRequestV1) {

        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final String initiatedUserId = requireNonNull(AuthUserHelper.getAuthUser()).getUsername();

        if (!List.of(SiteTypeV1.BRANCH, SiteTypeV1.DEDICATED_GATEWAY).contains(siteResponse.getSiteType())) {
            throw new SdwanBadRequestException("Invalid siteType='%s' : updateLansConfigs operation is only allowed for Branch and Dedicated-Gateway sites.".formatted(siteResponse.getSiteType()));
        }
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        LanConfigurationRequestV1ApiV1 lanConfigurationRequestV1ApiV1 = lanConfigMapper
                .from(lanConfigurationRequestV1);

        List<DeviceResponseV1> deviceResponseV1 = siteResponse.getDevices();
        List<LanConfigV1> networks = lanConfigurationRequestV1.getConfig();
        List<String> deviceNames = new ArrayList<>();

        for (DeviceResponseV1 devices : deviceResponseV1) {
            for (LanConfigV1 lanConfig : networks) {
                net.colt.sdwan.generated.model.service.InterfaceResponseV1 interfaceResponseV1 =
                        devices.getInterfaces()
                                .stream()
                                .filter(i -> Objects.equals(i.getNetwork(), lanConfig.getNetwork()))
                                .findFirst()
                                .orElseThrow(() -> new SdwanBadRequestException("Network='%s' does not match any linked to devices for site id='%s'."
                                        .formatted(lanConfig.getNetwork(), siteResponse.getId())));

                if (!"LAN".equals(interfaceResponseV1.getType())) {
                    throw new SdwanBadRequestException("Interface id='%s' does not correspond to a LAN network.".formatted(lanConfig.getNetwork()));
                }
            }
            deviceNames.add(devices.getResourceName());
        }
        try {
            sitesService.updateOngoingAction(siteId, OnGoingActionV2.MODIFYING_LAN_INTERFACE_FRIENDLY_NAME);

            final ResponseEntity<Void> interfaceResponseEntity = lanConfigApiFeign.updateLansConfigurationsV1(
                    siteResponse.getNetworkId(),
                    String.valueOf(siteResponse.getId()),
                    initiatedUserId,
                    deviceNames,
                    lanConfigurationRequestV1ApiV1
            );

            responseEntityValidator.checkResponseEntity(interfaceResponseEntity, UPDATE_LAN_CONFIG);

        } catch (Exception ex) {
            log.error("Failed to update LAN interface friendly name for site with id " + siteId, ex.getMessage(), ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }

        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }
}
