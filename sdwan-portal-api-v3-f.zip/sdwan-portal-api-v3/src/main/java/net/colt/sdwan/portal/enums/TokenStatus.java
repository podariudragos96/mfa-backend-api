package net.colt.sdwan.portal.enums;

public enum TokenStatus {
    VALID,
    EXPIRED,
    NOT_FOUND
}
