package net.colt.sdwan.portal.config;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.common.logging.interceptor.ForwardCorrelationIdRequestInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@RequiredArgsConstructor
public class InterceptorsConfig {

    @Bean
    public ForwardCorrelationIdRequestInterceptor forwardCorrelationIdRequestInterceptor() {
        return new ForwardCorrelationIdRequestInterceptor();
    }
}
