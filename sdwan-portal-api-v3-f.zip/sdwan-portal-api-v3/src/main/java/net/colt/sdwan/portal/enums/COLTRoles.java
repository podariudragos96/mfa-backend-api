package net.colt.sdwan.portal.enums;


import java.util.Arrays;

public enum COLTRoles {
    SD_WAN_READ_ONLY_ROLE("SD-WANReadOnlyRole"),
    SD_WAN_READ_WRITE_ROLE("SD-WANReadWriteRole"),
    SD_WAN_READ_WRITE_FIREWALL("SD-WANRWFirewallRole"),
    SD_WAN_INSTALL_MANAGER_ROLE("SD-WANInstallManagerRole"),
    SD_WAN_READ_WRITE_TENANT("SD-WANRWWLTenantRole");

    private final String value;

    COLTRoles(String v) {
        value = v;
    }

    public static COLTRoles fromValue(final String v) {
        return Arrays.stream(COLTRoles.values())
                .filter(colRoles -> colRoles.value.equals(v)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException(v));
    }

    public static boolean contains(final String name) {
        return Arrays.asList(COLTRoles.values())
                .stream()
                .anyMatch(thisRole -> thisRole.value().equalsIgnoreCase(name));
    }

    public String value() {
        return value;
    }

}
