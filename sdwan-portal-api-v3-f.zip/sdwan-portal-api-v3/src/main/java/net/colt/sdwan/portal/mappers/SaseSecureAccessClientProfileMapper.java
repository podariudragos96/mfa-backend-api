package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.model.versa.sase.api.SecureAccessClientProfilesRequestApiV1;
import net.colt.sdwan.generated.model.versa.sase.api.SecureAccessClientProfilesResponseApiV1;
import net.colt.sdwan.portal.model.SecureAccessClientProfilesRequestV1;
import net.colt.sdwan.portal.model.SecureAccessClientProfilesResponseV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SaseSecureAccessClientProfileMapper {

    private final ModelMapper modelMapper;

    public SecureAccessClientProfilesResponseV1 from(SecureAccessClientProfilesResponseApiV1 response) {
        return modelMapper.map(response, SecureAccessClientProfilesResponseV1.class);
    }

    public SecureAccessClientProfilesRequestApiV1 from(SecureAccessClientProfilesRequestV1 request) {
        return modelMapper.map(request, SecureAccessClientProfilesRequestApiV1.class);
    }

}
