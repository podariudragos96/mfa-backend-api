package net.colt.sdwan.portal.services.impl;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.common.exceptions.exception.SdwanUnauthorizedException;
import net.colt.sdwan.portal.client.helper.IdentityAccessMfaClientHelper;
import net.colt.sdwan.portal.client.model.identityaccess.AuthMfaEmailSend200Response;
import net.colt.sdwan.portal.client.model.identityaccess.LoginRequestApiV1;
import net.colt.sdwan.portal.client.model.identityaccess.LoginResponseApiV1;
import net.colt.sdwan.portal.client.model.identityaccess.StartTotpSessionResponseApiV1;
import net.colt.sdwan.portal.client.model.identityaccess.VerifyOtpProfileResponseApiV1;
import net.colt.sdwan.portal.model.FinalTokenResponseV1;
import net.colt.sdwan.portal.model.SendEmailRequestV1;
import net.colt.sdwan.portal.model.SendSmsRequestV1;
import net.colt.sdwan.portal.model.StartTotpSessionRequestV1;
import net.colt.sdwan.portal.model.StartTotpSessionResponseV1;
import net.colt.sdwan.portal.model.VerifyEmailRequestV1;
import net.colt.sdwan.portal.model.VerifySmsReqApiV1;
import net.colt.sdwan.portal.model.VerifyTotpRequestV1;
import net.colt.sdwan.portal.services.MfaService;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.util.UUID;

@RequiredArgsConstructor
@Service
@Slf4j
public class MfaServiceImpl implements MfaService {

    private static final Boolean MFA_ENABLED = Boolean.TRUE;

    private final IdentityAccessMfaClientHelper identityAccessMfaClientHelper;
    private final ModelMapper modelMapper;

    @Override
    public void sendMfaEmail(SendEmailRequestV1 req) {
        final String sessionId = requireSessionId(req != null ? req.getSessionId() : null, "sendMfaEmail");

        try {
            identityAccessMfaClientHelper.sendEmailOtp(sessionId);
        } catch (FeignException fe) {
            throw mapFeign(fe, "sendMfaEmail");
        }
    }

    @Override
    public FinalTokenResponseV1 verifyMfaEmail(VerifyEmailRequestV1 req) {
        final String sessionId = requireSessionId(req != null ? req.getSessionId() : null, "verifyMfaEmail");
        final String code = requireCode(req != null ? req.getCode() : null, "verifyMfaEmail");

        try {
            ResponseEntity<VerifyOtpProfileResponseApiV1> response = identityAccessMfaClientHelper.verifyEmailOtp(sessionId, code);
            ensureOk(response, "verifyMfaEmail");
            return new FinalTokenResponseV1().token(sessionId);
        } catch (FeignException fe) {
            throw mapFeign(fe, "verifyMfaEmail");
        }
    }

    @Override
    public void sendMfaSms(SendSmsRequestV1 req) {

        final String sessionId = requireSessionId(req != null ? req.getSessionId() : null, "sendMfaSms");
        try {
            ResponseEntity<AuthMfaEmailSend200Response> response = identityAccessMfaClientHelper.sendSmsOtp(sessionId);
            ensureSent(response, "sendMfaSms");
        } catch (FeignException fe) {
            throw mapFeign(fe, "sendMfaSms");
        }
    }

    @Override
    public FinalTokenResponseV1 verifyMfaSms(VerifySmsReqApiV1 req) {
        final String sessionId = requireSessionId(req != null ?
                req.getSessionId() : null, "verifyMfaSms");
        final String code = requireCode(req != null ? req.getCode() : null, "verifyMfaSms");
        try {
            ResponseEntity<VerifyOtpProfileResponseApiV1> response = identityAccessMfaClientHelper.verifySmsOtp(sessionId, code);
            ensureOk(response, "verifyMfaSms");
            return new FinalTokenResponseV1().token(sessionId);
        } catch (FeignException fe) {
            throw mapFeign(fe, "verifyMfaSms");
        }
    }

    @Override
    public StartTotpSessionResponseV1 startTotpSession(StartTotpSessionRequestV1 req) {

        final String username = requireUsername(req != null ? req.getUsername() : null, "startTotpSession");
        final String password = requirePassword(req != null ? req.getPassword() : null, "startTotpSession");
        final String sessionId = UUID.randomUUID().toString();
        try {
            final LoginRequestApiV1 loginRequest =
                    LoginRequestApiV1.builder()
                            .sessionId(sessionId)
                            .username(username)
                            .password(password)
                            .build();

            final ResponseEntity<LoginResponseApiV1> loginResponse = identityAccessMfaClientHelper.authLogin(loginRequest, MFA_ENABLED);

            ensureOk(loginResponse, "startTotpSession.authLogin");

            final ResponseEntity<StartTotpSessionResponseApiV1> startResp = identityAccessMfaClientHelper.startTotpSession(sessionId);

            if (startResp != null && HttpStatus.NOT_IMPLEMENTED.equals(startResp.getStatusCode())) {
                throw new SdwanInternalServerErrorException("Identity-access-api TOTP start-session is not implemented (returns 501).");
            }
            ensureOk(startResp, "startTotpSession.authMfaTotpStartSession");
            final StartTotpSessionResponseApiV1 body = startResp.getBody();
            if (body == null) {
                throw new SdwanInternalServerErrorException("startTotpSession: identity returned 200 with empty body");
            }
            return modelMapper.map(body, StartTotpSessionResponseV1.class);
        } catch (FeignException fe) {
            throw mapFeign(fe, "startTotpSession");
        }
    }

    @Override
    public FinalTokenResponseV1 verifyTotp(VerifyTotpRequestV1 req) {
        final String sessionId = requireSessionId(req != null ? req.getSessionId() : null, "verifyTotp");
        final String code = requireCode(req != null ? req.getCode() : null, "verifyTotp");

        try {
            ResponseEntity<VerifyOtpProfileResponseApiV1> response = identityAccessMfaClientHelper.verifyTotp(sessionId, code);
            ensureOk(response, "verifyTotp");
            return new FinalTokenResponseV1().token(sessionId);
        } catch (FeignException fe) {
            throw mapFeign(fe, "verifyTotp");
        }
    }

    @Override
    public void deleteTotpConfigs() {
        final String sessionId = requireSessionId(req != null ? req.getSessionId() : null, "deleteTotpConfigs");
        try {
            ResponseEntity<Void> response = identityAccessMfaClientHelper.deleteTotp(sessionId);
            ensureOk(response, "deleteTotpConfigs");
        } catch (FeignException fe) {
            throw mapFeign(fe, "deleteTotpConfigs");
        }
    }

    private void ensureSent(ResponseEntity<AuthMfaEmailSend200Response> response, String ctx) {
        if (response == null) {
            throw new SdwanInternalServerErrorException(ctx + ": identity response is null");
        }
        if (!HttpStatus.OK.equals(response.getStatusCode())) {
            throw fromStatus(response.getStatusCode(), ctx + ": identity returned " + response.getStatusCode());
        }
        AuthMfaEmailSend200Response body = response.getBody();
        if (body == null || !Boolean.TRUE.equals(body.getSent())) {
            throw new SdwanBadRequestException(ctx + ": identity did not send OTP");
        }
    }

    private void ensureOk(ResponseEntity<?> response, String ctx) {

        if (response == null) {
            throw new SdwanInternalServerErrorException(ctx + ": identity response is null");
        }

        if (!response.getStatusCode().is2xxSuccessful()) {
            throw fromStatus(response.getStatusCode(), ctx + ": identity returned " + response.getStatusCode());
        }
    }

    private RuntimeException fromStatus(HttpStatusCode status, String msg) {
        if (status == null) {
            return new SdwanInternalServerErrorException(msg);
        }

        if (HttpStatus.BAD_REQUEST.equals(status)) {
            return new SdwanBadRequestException(msg);
        }

        if (HttpStatus.UNAUTHORIZED.equals(status)) {
            return new SdwanUnauthorizedException(msg);
        }

        if (HttpStatus.NOT_FOUND.equals(status)) {
            return new SdwanNotFoundException(msg);
        }

        if (HttpStatus.NOT_IMPLEMENTED.equals(status)) {
            return new SdwanInternalServerErrorException(msg);
        }

        return new SdwanInternalServerErrorException(msg);
    }

    private RuntimeException mapFeign(FeignException fe, String ctx) {
        if (fe == null) {
            return new SdwanInternalServerErrorException(ctx + ": FeignException is null");
        }

        int status = fe.status();
        if (status == 400) return new SdwanBadRequestException(ctx + ": identity returned 400");
        if (status == 401) return new SdwanUnauthorizedException(ctx + ": identity returned 401");
        if (status == 404) return new SdwanNotFoundException(ctx + ": identity returned 404");
        if (status == 501) return new SdwanInternalServerErrorException(ctx + ": identity returned 501 NOT_IMPLEMENTED");

        return new SdwanInternalServerErrorException(ctx + ": identity call failed (" + status + "): " + fe.getMessage());
    }

    private String requireSessionId(String sessionId, String ctx) {
        if (StringUtils.isBlank(sessionId)) {
            throw new SdwanBadRequestException(ctx + ": session_id is required");
        }

        return sessionId;
    }

    private String requireCode(String code, String ctx) {
        if (StringUtils.isBlank(code)) {
            throw new SdwanBadRequestException(ctx + ": code is required");
        }

        return code;
    }

    private String requireUsername(String username, String ctx) {
        if (StringUtils.isBlank(username)) {
            throw new SdwanBadRequestException(ctx + ": username is required");
        }

        return username;
    }

    private String requirePassword(String password, String ctx) {
        if (StringUtils.isBlank(password)) {
            throw new SdwanBadRequestException(ctx + ": password is required");
        }

        return password;
    }
}
