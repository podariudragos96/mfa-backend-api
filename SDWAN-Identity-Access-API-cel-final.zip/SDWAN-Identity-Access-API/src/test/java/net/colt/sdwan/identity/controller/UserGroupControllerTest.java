package net.colt.sdwan.identity.controller;

import net.colt.sdwan.generated.model.identityaccess.UserGroupApiV1;
import net.colt.sdwan.generated.model.identityaccess.UserGroupCreateRequestApiV1;
import net.colt.sdwan.identity.service.UserGroupService;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserGroupControllerTest {

    @Test
    void addUserGroupV1_shouldReturn201() {
        UserGroupService svc = mock(UserGroupService.class);
        UserGroupController c = new UserGroupController(svc);

        UserGroupCreateRequestApiV1 req = new UserGroupCreateRequestApiV1();
        req.setName("realmA");
        req.setDisplayName("Realm A");

        ResponseEntity<UserGroupApiV1> r = c.addUserGroupV1(req);
        assertEquals(201, r.getStatusCodeValue());
        verify(svc).createRealm(any());
    }

    @Test
    void getUserGroupByIdV1_shouldDelegate() {
        UserGroupService svc = mock(UserGroupService.class);
        UserGroupController c = new UserGroupController(svc);

        UserGroupApiV1 dto = new UserGroupApiV1();
        dto.setId("id");
        dto.setName("realmA");

        when(svc.getUserGroupById("id")).thenReturn(dto);

        ResponseEntity<UserGroupApiV1> r = c.getUserGroupByIdV1("id");
        assertEquals(200, r.getStatusCodeValue());
        assertSame(dto, r.getBody());
    }

    @Test
    void userGroupsLookupV1_shouldReturnList() {
        UserGroupService svc = mock(UserGroupService.class);
        UserGroupController c = new UserGroupController(svc);

        UserGroupApiV1 dto = new UserGroupApiV1();
        dto.setId("id");
        dto.setName("realmA");

        when(svc.listUserGroups()).thenReturn(List.of(dto));

        ResponseEntity<List<UserGroupApiV1>> r = c.userGroupsLookupV1();
        assertEquals(200, r.getStatusCodeValue());
        assertEquals(1, r.getBody().size());
    }
}
