package net.colt.sdwan.identity.service.impl;

import net.colt.sdwan.identity.dto.SmsResponse;
import org.junit.jupiter.api.Test;
import org.springframework.context.MessageSource;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.util.Locale;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class SmsServiceImplTest {

    @Test
    void sendSms_shouldNotSend_whenMobileBlank() {
        MessageSource ms = mock(MessageSource.class);
        RestTemplate rt = mock(RestTemplate.class);

        SmsServiceImpl svc = new SmsServiceImpl();
        ReflectionTestUtils.setField(svc, "messageSource", ms);
        ReflectionTestUtils.setField(svc, "restTemplate", rt);

        svc.sendSms("   ", "site", "addr", "STATUS", Locale.ENGLISH);

        assertFalse(svc.wasSmsSent());
        verifyNoInteractions(rt);
    }

    @Test
    void sendSms_shouldSendAndSetWasSmsSentTrue_whenExchangeReturnsSuccess() {
        MessageSource ms = mock(MessageSource.class);
        RestTemplate rt = mock(RestTemplate.class);

        when(ms.getMessage(eq("STATUS_OK"), any(), eq(Locale.ENGLISH))).thenReturn("hello addr");

        ResponseEntity<SmsResponse> response =
                new ResponseEntity<>(new SmsResponse("SUCCESS", null), HttpStatus.OK);

        when(rt.exchange(
                eq("http://sms"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(SmsResponse.class),
                anyMap()
        )).thenReturn(response);

        SmsServiceImpl svc = new SmsServiceImpl();
        ReflectionTestUtils.setField(svc, "messageSource", ms);
        ReflectionTestUtils.setField(svc, "restTemplate", rt);
        ReflectionTestUtils.setField(svc, "smsApiUrl", "http://sms");
        ReflectionTestUtils.setField(svc, "smsApiSecurityToken", "token");

        svc.sendSms("+40123456789", "site", "addr", "STATUS_OK", Locale.ENGLISH);

        assertTrue(svc.wasSmsSent());
        verify(rt, times(1)).exchange(
                eq("http://sms"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(SmsResponse.class),
                anyMap()
        );
    }

    @Test
    void sendSms_shouldSetWasSmsSentFalse_whenExchangeThrows() {
        MessageSource ms = mock(MessageSource.class);
        RestTemplate rt = mock(RestTemplate.class);

        when(ms.getMessage(eq("STATUS_OK"), any(), eq(Locale.ENGLISH))).thenReturn("msg");
        when(rt.exchange(anyString(), any(), any(), eq(SmsResponse.class), anyMap()))
                .thenThrow(new RuntimeException("boom"));

        SmsServiceImpl svc = new SmsServiceImpl();
        ReflectionTestUtils.setField(svc, "messageSource", ms);
        ReflectionTestUtils.setField(svc, "restTemplate", rt);
        ReflectionTestUtils.setField(svc, "smsApiUrl", "http://sms");
        ReflectionTestUtils.setField(svc, "smsApiSecurityToken", "token");

        svc.sendSms("+40123456789", "site", "addr", "STATUS_OK", Locale.ENGLISH);

        assertFalse(svc.wasSmsSent());
    }
}