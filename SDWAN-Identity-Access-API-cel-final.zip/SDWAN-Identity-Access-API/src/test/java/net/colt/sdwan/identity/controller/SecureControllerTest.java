package net.colt.sdwan.identity.controller;

import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class SecureControllerTest {

    @Test
    void ping_shouldReturnMessage() {
        SecureController c = new SecureController();
        ResponseEntity<?> r = c.ping();
        assertEquals(200, r.getStatusCodeValue());
        assertTrue(r.getBody() instanceof Map);
        assertTrue(((Map<?, ?>) r.getBody()).get("message").toString().contains("authenticated"));
    }
}
