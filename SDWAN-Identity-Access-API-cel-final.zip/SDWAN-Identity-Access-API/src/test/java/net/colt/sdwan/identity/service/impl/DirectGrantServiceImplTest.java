package net.colt.sdwan.identity.service.impl;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class DirectGrantServiceImplTest {

    @Test
    void validateCredentials_shouldReturnTrue_on2xx() {
        DirectGrantServiceImpl svc = new DirectGrantServiceImpl("http://kc", "cid", "csec");

        RestTemplate rt = mock(RestTemplate.class);
        when(rt.postForEntity(anyString(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("{}", HttpStatus.OK));

        ReflectionTestUtils.setField(svc, "rest", rt);

        assertTrue(svc.validateCredentials("realm", "u", "p"));
    }

    @Test
    void validateCredentialsDetailed_shouldParseErrorAndDescription() {
        DirectGrantServiceImpl svc = new DirectGrantServiceImpl("http://kc", "cid", "csec");

        String body = "{\"error\":\"invalid_grant\",\"error_description\":\"Invalid user credentials\"}";
        HttpClientErrorException ex = HttpClientErrorException.create(
                HttpStatus.BAD_REQUEST,
                "Bad Request",
                HttpHeaders.EMPTY,
                body.getBytes(StandardCharsets.UTF_8),
                StandardCharsets.UTF_8
        );

        RestTemplate rt = mock(RestTemplate.class);
        when(rt.postForEntity(anyString(), any(), eq(String.class))).thenThrow(ex);
        ReflectionTestUtils.setField(svc, "rest", rt);

        DirectGrantServiceImpl.DagResult r = svc.validateCredentialsDetailed("realm", "u", "p", "ocid", "ocsec");
        assertFalse(r.ok());
        assertEquals("invalid_grant", r.error());
        assertEquals("Invalid user credentials", r.errorDescription());
    }

    @Test
    void validateCredentialsWithTotp_shouldReturnFalse_onHttpError() {
        DirectGrantServiceImpl svc = new DirectGrantServiceImpl("http://kc", "cid", "csec");

        RestTemplate rt = mock(RestTemplate.class);
        when(rt.postForEntity(anyString(), any(), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.UNAUTHORIZED, "x", HttpHeaders.EMPTY, null, null));
        ReflectionTestUtils.setField(svc, "rest", rt);

        assertFalse(svc.validateCredentialsWithTotp("realm", "u", "p", "123456"));
    }
}
