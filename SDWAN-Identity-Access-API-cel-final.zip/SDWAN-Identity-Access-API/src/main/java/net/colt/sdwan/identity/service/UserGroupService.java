package net.colt.sdwan.identity.service;

import net.colt.sdwan.generated.model.identityaccess.UserGroupApiV1;
import net.colt.sdwan.generated.model.identityaccess.UserGroupCreateRequestApiV1;

import java.util.List;

public interface UserGroupService {

    UserGroupApiV1 createRealm(UserGroupCreateRequestApiV1 req);

    List<UserGroupApiV1> listUserGroups();

    UserGroupApiV1 getUserGroupById(String userGroupId);

    UserGroupApiV1 patchUserGroupById(String userGroupId, UserGroupApiV1 userGroupApiV1);

    void deleteUserGroupById(String userGroupId);
}
