package net.colt.sdwan.identity.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class SmsRequest {

    @JsonProperty("securityToken")
    private String securityToken;

    @JsonProperty("countryCode")
    private String countryCode;

    @JsonProperty("mobileNumber")
    private String mobileNumber;

    @JsonProperty("content")
    private String content;
}