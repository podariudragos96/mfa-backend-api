package net.colt.sdwan.identity.service;

import java.util.Locale;

public interface SmsService {

    void sendSms(String mobileNumber, String siteName, String siteAddress, String status, Locale locale);

    boolean wasSmsSent();

}
