package net.colt.sdwan.identity.service;

import net.colt.sdwan.generated.model.identityaccess.*;
import org.springframework.http.ResponseEntity;

public interface AuthFlowService {

    ResponseEntity<LoginResponseApiV1> authLogin(LoginRequestApiV1 loginRequestApiV1, Boolean mfaEnabled);

    ResponseEntity<AuthMfaEmailSend200Response> sendEmailOtp(SendEmailReqApiV1 req);

    ResponseEntity<VerifyOtpProfileResponseApiV1> verifyEmailOtp(VerifyEmailReqApiV1 req);

    ResponseEntity<AuthMfaEmailSend200Response> sendSmsOtp(SendSmsReqApiV1 req);

    ResponseEntity<VerifyOtpProfileResponseApiV1> verifySmsOtp(VerifySmsReqApiV1 req);

    ResponseEntity<StartTotpSessionResponseApiV1> startTotpSession(StartTotpSessionRequestApiV1 req);

    ResponseEntity<VerifyOtpProfileResponseApiV1> verifyTotp(VerifyTotpRequestApiV1 req);

    ResponseEntity<Void> deleteTotp(DeleteTotpRequestApiV1 req);

    ResponseEntity<AuthProfileSetEmail200Response> profileSetEmail(SetEmailRequestApiV1 req);

    ResponseEntity<AuthProfileVerifyEmail200Response> profileVerifyEmail(SendEmailReqApiV1 req);
}
