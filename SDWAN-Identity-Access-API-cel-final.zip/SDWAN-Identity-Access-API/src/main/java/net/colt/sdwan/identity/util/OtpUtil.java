package net.colt.sdwan.identity.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;

public final class OtpUtil {

    private static final SecureRandom RND = new SecureRandom();

    private OtpUtil() {}

    public static String generate6Digits() {
        int n = RND.nextInt(1_000_000);
        return String.format("%06d", n);
    }

    public static String hashForSession(String sessionId, String code) {
        // sessionId is used as a salt so identical OTPs don't hash the same across sessions
        return sha256Hex(sessionId + ":" + code);
    }

    public static String sha256Hex(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    public static boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null) return false;
        if (a.length() != b.length()) return false;

        int result = 0;
        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }
        return result == 0;
    }
}
