package net.colt.sdwan.identity.service;

import net.colt.sdwan.generated.model.identityaccess.UserApiV1;

import java.util.List;

public interface UserService {

    UserApiV1 createUser(String userGroupId, UserApiV1 userApiV1);

    List<UserApiV1> listUsers(String userGroupId);

    UserApiV1 getUser(String userGroupId, String userId);

    UserApiV1 updateUser(String userGroupId, String userId, UserApiV1 userApiV1);

    void deleteUser(String userGroupId, String userId);
}
