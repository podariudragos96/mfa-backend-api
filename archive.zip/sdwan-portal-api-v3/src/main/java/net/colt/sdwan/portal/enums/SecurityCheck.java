package net.colt.sdwan.portal.enums;

public enum SecurityCheck {
    SUCCESS,
    NO_NOVITAS_ACCESS_ROLE,
    INVALID_CREDENTIALS,
    OCN_NOT_MATCHED
}
