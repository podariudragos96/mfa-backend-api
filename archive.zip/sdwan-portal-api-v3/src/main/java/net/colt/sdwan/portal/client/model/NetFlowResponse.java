package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * NetFlowResponseV1
 */
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NetFlowResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private String id;

    @JsonProperty("description")
    private String description;

    @JsonProperty("updated_dt")
    private LocalDateTime updatedDt;

    @JsonProperty("updated_by")
    private String updatedBy;

    @JsonProperty("collectors")
    @Valid
    private List<NetFlowCollectorResponse> collectors = new ArrayList<>();

    @JsonProperty("rules")
    @Valid
    private List<NetFlowRuleResponse> rules = new ArrayList<>();
}

