package net.colt.sdwan.portal.enums;

public enum PolicyResponseCheck {
    NO_DEFAULT_TRAFFIC_RULE,
    CSP_PEERING_INTERFACE_MISSING
}
