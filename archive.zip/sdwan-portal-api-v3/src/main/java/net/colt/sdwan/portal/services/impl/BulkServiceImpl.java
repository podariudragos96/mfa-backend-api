package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.client.feign.bulk.BulkApiFeign;
import net.colt.sdwan.portal.mappers.BulkRequestMapper;
import net.colt.sdwan.portal.model.BulkCopyRequestRequestV2;
import net.colt.sdwan.portal.model.BulkCopyRequestResponseV2;
import net.colt.sdwan.portal.model.BulkCopyRequestsResponseV1;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.BulkService;
import net.colt.sdwan.portal.validator.NetworkValidator;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import java.util.List;

import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;

@RequiredArgsConstructor
@Service
public class BulkServiceImpl implements BulkService {

    private final BulkApiFeign bulkApiFeign;
    private final BulkRequestMapper bulkRequestMapper;
    private final NetworkValidator networkValidator;

    @Override
    public CorrelationIdResponseV1 createBulkCopyRequest(BulkCopyRequestRequestV2 bulkCopyRequestRequest, String networkId) {
        networkValidator.validateNetworkId(networkId);
        UserAuth authUser = AuthUserHelper.getAuthUser();
        bulkApiFeign.createBulkCopyRequestV2(bulkRequestMapper.mapBulkApiRequest(authUser, networkId, bulkCopyRequestRequest));
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    @Override
    public List<BulkCopyRequestResponseV2> getBulkCopyRequestsById(String requestId, String networkId) {
        networkValidator.validateNetworkId(networkId);
        List<net.colt.sdwan.portal.client.model.bulkapi.BulkCopyRequestResponseV2> response = bulkApiFeign.getBulkCopyRequestsByIdV2(requestId, networkId).getBody();
        return bulkRequestMapper.mapBulkCopyRequestResponse(response);
    }

    @Override
    public List<BulkCopyRequestsResponseV1> getBulkCopyRequests(String networkId) {
        networkValidator.validateNetworkId(networkId);
        return bulkRequestMapper.mapBulkCopyRequestsResponse(bulkApiFeign.getBulkCopyRequestsV1(networkId).getBody());
    }
}
