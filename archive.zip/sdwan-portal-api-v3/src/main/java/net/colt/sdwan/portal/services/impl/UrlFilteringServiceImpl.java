package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.feign.security.UrlFilteringProfilesApiFeign;
import net.colt.sdwan.portal.mappers.UrlFilteringMapper;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.FirewallV1;
import net.colt.sdwan.portal.model.URLFilteringProfileResponseV1;
import net.colt.sdwan.portal.model.URLFilteringProfilesRequestV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.services.UrlFilteringService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.security.api.generated.model.LoggerType;
import net.colt.sdwan.security.api.generated.model.UrlFilteringProfilesApiRequestV1;
import net.colt.sdwan.security.api.generated.model.UrlFilteringProfilesApiResponseV1;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.constant.SecurityConstants.SECURITY_ANTIVIRUS_PROFILES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.MODIFYING_URL_FILTERING_PROFILES_RULES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;
import static org.apache.commons.collections4.CollectionUtils.isNotEmpty;

@Service
@Slf4j
@RequiredArgsConstructor
public class UrlFilteringServiceImpl implements UrlFilteringService {

    private final SitesService sitesService;
    private final UrlFilteringProfilesApiFeign urlFilteringProfilesApiFeign;
    private final SiteResponseValidator siteResponseValidator;
    private final UrlFilteringMapper urlFilteringMapper;
    private final ResponseEntityValidator responseEntityValidator;

    @Override
    public URLFilteringProfileResponseV1 getProfilesBySiteId(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());
        siteResponseValidator.validateSecurityProfileFeatureSupport(hasAdvancedFirewall, siteResponse.getSiteFeatures().getSecurity().getUrlFilteringEnabled());
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        final ResponseEntity<UrlFilteringProfilesApiResponseV1> urlFilteringProfiles =
                urlFilteringProfilesApiFeign.getURLFilteringProfilesV1(Integer.parseInt(siteId), siteResponse.getNetworkId());
        responseEntityValidator.checkResponseEntity(urlFilteringProfiles, SECURITY_ANTIVIRUS_PROFILES);
        return urlFilteringMapper.from(urlFilteringProfiles.getBody());
    }

    @Override
    public CorrelationIdResponseV1 updateProfilesBySiteId(String siteId, URLFilteringProfilesRequestV1 urLFilteringProfileV1) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());
        siteResponseValidator.validateSecurityProfileFeatureSupport(hasAdvancedFirewall, siteResponse.getSiteFeatures().getSecurity().getUrlFilteringEnabled());
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final UrlFilteringProfilesApiRequestV1 urlFilteringProfilesApiRequestV1 =
                urlFilteringMapper.from(urLFilteringProfileV1.getUrlFilteringProfiles());
        urlFilteringProfilesApiRequestV1.setLoggerType(LoggerType.fromValue(siteResponse.getSiteFeatures().getSecurity().getLogging().getLoggingType()));

        final List<String> deviceNames = new ArrayList<>(getDeviceNamesFromSiteResponse(siteResponse));
        UserAuth userAuth = AuthUserHelper.getAuthUser();

        try {
            sitesService.updateOngoingAction(siteId, MODIFYING_URL_FILTERING_PROFILES_RULES);
            final ResponseEntity<Void> responseEntity = urlFilteringProfilesApiFeign.updateURLFilteringProfilesV1(
                    Integer.parseInt(siteId), siteResponse.getNetworkId(), userAuth.getUsername(), deviceNames, urlFilteringProfilesApiRequestV1);

            responseEntityValidator.checkResponseEntity(responseEntity, SECURITY_ANTIVIRUS_PROFILES);
            return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
        } catch (Exception ex) {
            log.error("Failed to update Security Profiles", ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }
    }

    private Set<String> getDeviceNamesFromSiteResponse(SiteResponseV1 siteResponse) {
        final Set<String> deviceNames = new HashSet<>();
        if (isNotEmpty(siteResponse.getDevices())) {
            siteResponse.getDevices().forEach(device -> deviceNames.add(device.getResourceName()));
        }
        return deviceNames;
    }
}
