package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;

import java.io.Serializable;
import java.util.List;

public class NetFlowRuleRequest implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("priority")
    private Integer priority;

    @JsonProperty("name")
    private String name;

    @JsonProperty("destination_ips")
    @Valid
    private List<NetworkAddressResponse> destinationIps = null;

    @JsonProperty("source_ips")
    @Valid
    private List<NetworkAddressResponse> sourceIps = null;

    @JsonProperty("applications")
    @Valid
    private List<String> applications = null;
}
