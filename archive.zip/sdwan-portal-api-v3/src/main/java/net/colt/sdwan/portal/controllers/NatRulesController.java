package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.NatApiApi;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.NatRulesService;
import net.colt.sdwan.portal.validator.model.NatRulesResponseValidator;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

import static org.springframework.http.HttpStatus.OK;

@RequiredArgsConstructor
@Controller
public class NatRulesController implements NatApiApi {

    private final NatRulesService natRulesService;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setValidator(new NatRulesResponseValidator());
    }

    @Override
    @SuppressWarnings({"java:S1123", "java:S1133"})
    @Deprecated(forRemoval = true)
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<NatRulesResponseV1> getNatRulesBySiteIdV1(
            String siteId) {
        return new ResponseEntity<>(natRulesService.getNatRulesBySiteId(siteId), OK);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<NatRuleSetResponseV1> getNatRulesBySiteIdV2(String siteId) {
        return new ResponseEntity<>(natRulesService.getNatRulesBySiteIdV2(siteId), OK);
    }


    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<NatRuleHistoryResponseV1>> getNatRulesHistoryBySiteIdV2(String siteId) {
        return new ResponseEntity<>(natRulesService.getNatRulesHistoryBySiteIdV2(siteId), OK);
    }


    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<NatRuleSetResponseV1> getNatRulesBySiteIdAndRuleSetIdV1(String siteId,
                                                                                  String id) {
        return new ResponseEntity<>(natRulesService.getNatRulesHistoryBySiteIdAndRuleSetIdV2(siteId, id), OK);
    }

    @Override
    @SuppressWarnings({"java:S1123", "java:S1133"})
    @Deprecated(forRemoval = true)
    @SDWanAsyncMethod("/v1/sites/{site_id}/nat_rules")
    @PreAuthorize("hasAnyAuthority('SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateNatRulesBySiteIdV1(
            String siteId,
            @RequestBody NatRulesRequestV1 body
    ) {
        return ResponseEntity.ok(natRulesService.updateNatRulesBySiteId(siteId, body));
    }

    @Override
    @SDWanAsyncMethod("/v2/sites/{site_id}/nat_rules")
    @PreAuthorize("hasAnyAuthority('SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateNatRulesBySiteIdV2(String siteId,
                                                                            @RequestBody NatRulesRequestV1 natRulesRequestV1) {
        return new ResponseEntity<>(natRulesService.updateNatRulesBySiteIdV2(siteId, natRulesRequestV1), OK);
    }
}
