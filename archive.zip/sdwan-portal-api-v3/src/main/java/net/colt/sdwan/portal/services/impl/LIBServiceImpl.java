package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.ServiceApiClient;
import net.colt.sdwan.portal.client.feign.sitesettings.LocalInternetBreakoutApiFeign;
import net.colt.sdwan.portal.mappers.LIBMapper;
import net.colt.sdwan.portal.mappers.LocalInternetBreakoutMapper;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.LocalInternetBreakoutPreferencesV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.LIBService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.util.CGWUtil;
import net.colt.sdwan.portal.validator.LIBPreferencesValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.portal.constant.Constants.DEVICE_PREFIX;
import static net.colt.sdwan.portal.model.OnGoingActionV2.MODIFYING_LIB_RULES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;

/**
 * This class aims to have Local Internet Breakout service features.
 */
@RequiredArgsConstructor
@Service
@Slf4j
public class LIBServiceImpl implements LIBService {

    private final ServiceApiClient serviceApiClient;
    private final SitesService sitesService;
    private final LocalInternetBreakoutApiFeign localInternetBreakoutApiFeign;
    private final LocalInternetBreakoutMapper mapper;
    private final SiteResponseValidator siteResponseValidator;

    /**
     * Retrieve local internet breakout preferences with provided inputs
     *
     * @param siteId site unique identifier
     * @return List of Local internet breakout preferences
     */
    @Override
    public List<LocalInternetBreakoutPreferencesV1> getLIBPreferences(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (CGWUtil.isDedicatedGatewayOrGateway(siteResponse.getSiteType().getValue())) {
            List<net.colt.sdwan.generated.model.service.LocalInternetBreakoutPreferencesV1> libPref =
                    serviceApiClient.getLIBPreferencesBySiteId(siteId);
            return LIBMapper.mapToListOfLibPreferences(libPref);
        }

        return LIBMapper.mapToListOfLibPreferences(
                serviceApiClient.getLIBPreferencesBySiteId(siteId));
    }

    /**
     * Update local internet breakout preferences with provided inputs
     *
     * @param siteId                   site unique identifier
     * @param interfacesLIBPreferences List of Local internet breakout preferences
     * @return Correlation unique identifier
     */
    @Override
    public CorrelationIdResponseV1 updateLIBPreferences(String siteId,
                                                        List<LocalInternetBreakoutPreferencesV1> interfacesLIBPreferences) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);

        final List<LocalInternetBreakoutPreferencesV1> validLIBPreferences =
                LIBPreferencesValidator.validateLIBPreferences(interfacesLIBPreferences, siteResponse.getDevices());

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        try {
            final Map<String, Boolean> devicePrimaryMap = siteResponse.getDevices()
                    .stream()
                    .collect(Collectors.toMap(
                            device -> DEVICE_PREFIX.concat(device.getResourceName()),
                            device -> siteResponse.getDevices().size() == 1 || device.getIsPrimary()));

            sitesService.updateOngoingAction(siteId, MODIFYING_LIB_RULES);

            localInternetBreakoutApiFeign.updateLIBV1(siteResponse.getId().intValue(), siteResponse.getNetworkId(), devicePrimaryMap,
                    AuthUserHelper.getAuthUser().getUsername(), mapper.from(validLIBPreferences));
            return new CorrelationIdResponseV1(MDC.get("correlationId"));
        } catch (Exception ex) {
            log.error("Failed to update LIB preferences", ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }
    }

}
