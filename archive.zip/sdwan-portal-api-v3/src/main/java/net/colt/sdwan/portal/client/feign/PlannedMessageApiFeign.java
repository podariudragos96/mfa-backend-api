package net.colt.sdwan.portal.client.feign;

import net.colt.sdwan.system.api.generated.api.PlannedMessageApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "systemApiClient", url = "${sdwan.system.api.baseurl}", configuration = PlannedMessageApiFeignConfiguration.class)
public interface PlannedMessageApiFeign extends PlannedMessageApi {
}
