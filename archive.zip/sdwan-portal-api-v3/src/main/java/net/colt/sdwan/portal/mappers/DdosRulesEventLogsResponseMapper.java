package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.client.model.DDoSRulesAnalytics;
import net.colt.sdwan.portal.client.model.DDosLogEvents;
import net.colt.sdwan.portal.model.DdosEventLogsResponseV1;
import net.colt.sdwan.portal.model.DdosEventsResponseV1;
import org.apache.commons.collections4.CollectionUtils;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
public class DdosRulesEventLogsResponseMapper extends CommonMapper {

    public DdosEventLogsResponseV1 mapToResponse(final List<DDoSRulesAnalytics> dDoSRulesAnalyticsList) {
        DdosEventLogsResponseV1 analyticsResponse = new DdosEventLogsResponseV1();
        if (CollectionUtils.isNotEmpty(dDoSRulesAnalyticsList)) {
            List<DdosEventsResponseV1> events = dDoSRulesAnalyticsList.stream()
                    .map(this::mapToEvents)
                    .toList().stream()
                    .flatMap(List::stream)
                    .toList();
            analyticsResponse.setEvents(events);
        }

        return analyticsResponse;
    }

    private List<DdosEventsResponseV1> mapToEvents(DDoSRulesAnalytics dDoSRulesAnalytics) {
        List<DdosEventsResponseV1> events = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(dDoSRulesAnalytics.getEvents())) {
            events = dDoSRulesAnalytics.getEvents().stream().filter(Objects::nonNull)
                    .map(event -> mapToDdosEvent(event, dDoSRulesAnalytics.getDevice()))
                    .toList();
        }
        return events;
    }

    private DdosEventsResponseV1 mapToDdosEvent(final DDosLogEvents dosLogEvents, final String device) {
        ModelMapper mapper = new ModelMapper();
        DdosEventsResponseV1 responseV1 = mapper.map(dosLogEvents, DdosEventsResponseV1.class);
        responseV1.setDeviceName(device);
        return responseV1.receiveTime(mapStrToTimestamp(dosLogEvents.getReceiveTime()));
    }
}
