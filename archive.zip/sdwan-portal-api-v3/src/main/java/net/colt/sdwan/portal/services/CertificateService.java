package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.CertificateTypeV1;
import net.colt.sdwan.portal.model.DeviceCustomerManagedCertificateRequestV1;
import net.colt.sdwan.portal.model.DeviceSelfSignedCertificateRequestV1;
import net.colt.sdwan.portal.model.DeviceSelfSignedCertificateResponseV1;

public interface CertificateService {

    DeviceSelfSignedCertificateResponseV1 getCertificateBySiteIdAndDeviceIdV1(String siteId, String deviceId, CertificateTypeV1 certificateType);

    void createSelfSignedCertificateBySiteIdAndDeviceIdV1(String siteId, String deviceId, DeviceSelfSignedCertificateRequestV1 deviceSelfSignedCertificateRequestV1);

    void uploadCustomerCertificateBySiteIdAndDeviceIdV1(String siteId, String deviceId, DeviceCustomerManagedCertificateRequestV1 deviceCustomerManagedCertificateRequestV1);
}
