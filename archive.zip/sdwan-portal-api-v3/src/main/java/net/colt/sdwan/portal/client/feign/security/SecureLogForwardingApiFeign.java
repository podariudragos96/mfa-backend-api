package net.colt.sdwan.portal.client.feign.security;

import net.colt.sdwan.security.api.generated.api.SecureLogForwardingApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "secureLogForwardingApiFeign", url = "${sdwan.security.api.baseurl}",
        configuration = SecurityApiFeignConfiguration.class)
public interface SecureLogForwardingApiFeign extends SecureLogForwardingApiApi {
}
