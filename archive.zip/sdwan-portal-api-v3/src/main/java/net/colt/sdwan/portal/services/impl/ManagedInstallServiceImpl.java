package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.service.ManagedInstallSecurityDetailsRequestV1;
import net.colt.sdwan.portal.client.ServiceApiClient;
import net.colt.sdwan.portal.mappers.ManagedInstallResponsesMapper;
import net.colt.sdwan.portal.model.ManagedInstallPatchRequestV1;
import net.colt.sdwan.portal.model.ManagedInstallResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.ManagedInstallService;
import net.colt.sdwan.portal.validator.ManagedInstallValidator;
import org.springframework.stereotype.Service;

import java.util.List;

import static java.util.Objects.nonNull;
import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.generated.model.service.ManagedInstallStatusV1.CANCELED;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

@RequiredArgsConstructor
@Service
@Slf4j
public class ManagedInstallServiceImpl implements ManagedInstallService {

    private final ManagedInstallResponsesMapper managedInstallResponsesMapper;
    private final ManagedInstallValidator managedInstallValidator;
    private final ServiceApiClient serviceApiClient;

    @Override
    public List<ManagedInstallResponseV1> getAllManagedInstallOrders() {
        List<Integer> userTenantIds = AuthUserHelper.getAuthUser().getAccessibleTenantIds();
        List<net.colt.sdwan.generated.model.service.ManagedInstallResponseV1> managedInstalls =
                serviceApiClient.getManagedInstallDeviceForTenantIds(userTenantIds)
                        .stream()
                        .filter(this::isInstallValidStatus)
                        .toList();

        return managedInstallResponsesMapper.mapFromZTPDeviceResponses(managedInstalls);
    }

    private boolean isInstallValidStatus(net.colt.sdwan.generated.model.service.ManagedInstallResponseV1 managedInstall) {
        return !CANCELED.equals(managedInstall.getStatus());
    }

    @Override
    public ManagedInstallResponseV1 getManagedInstallOrderById(String deviceId) {
        net.colt.sdwan.generated.model.service.ManagedInstallResponseV1 installResponseV1 = serviceApiClient.getManagedInstallDeviceById(deviceId);
        managedInstallValidator.validateUserIsAllowedToFetchManagedInstall(installResponseV1);
        return managedInstallResponsesMapper.mapFromZTPDeviceResponse(installResponseV1);
    }

    @Override
    public ManagedInstallResponseV1 patchManagedInstallOrders(String deviceId, ManagedInstallPatchRequestV1 patchRequest) {
        final String initiatedUserId = requireNonNull(AuthUserHelper.getAuthUser()).getUsername();

        net.colt.sdwan.generated.model.service.ManagedInstallResponseV1 installResponseV1 =
                serviceApiClient.getManagedInstallDeviceById(deviceId);

        managedInstallValidator.validateUserIsAllowedToFetchManagedInstall(installResponseV1);

        final ManagedInstallSecurityDetailsRequestV1 securityDetailsRequestV1 = new ManagedInstallSecurityDetailsRequestV1();

        if (nonNull(patchRequest.getPassphrase()) && patchRequest.getPassphrase().isEmpty()) {
            securityDetailsRequestV1.setRegeneratePassphrase(true);
        }

        if (nonNull(patchRequest.getPin()) && patchRequest.getPin().isEmpty()) {
            securityDetailsRequestV1.setResetPin(true);
        }

        if (isNotBlank(patchRequest.getInstallerMobileNo())) {
            securityDetailsRequestV1.setInstallerMobileNo(patchRequest.getInstallerMobileNo());
        }

        return managedInstallResponsesMapper.mapFromZTPDeviceResponse(
                serviceApiClient.updateManagedInstall(deviceId, securityDetailsRequestV1, initiatedUserId));
    }

}
