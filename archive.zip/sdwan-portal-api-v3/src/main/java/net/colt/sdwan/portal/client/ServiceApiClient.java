package net.colt.sdwan.portal.client;

import jakarta.json.Json;
import jakarta.json.JsonPatch;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.data.criteria.filter.LongFilter;
import net.colt.sdwan.common.data.criteria.filter.StringFilter;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.common.exceptions.exception.SdwanUnprocessableEntityException;
import net.colt.sdwan.common.logging.service.LoggingService;
import net.colt.sdwan.generated.model.service.*;
import net.colt.sdwan.portal.client.feign.service.ServiceApiDeviceFeign;
import net.colt.sdwan.portal.client.feign.service.ServiceApiInterfaceFeign;
import net.colt.sdwan.portal.client.feign.service.ServiceApiManagedInstallFeign;
import net.colt.sdwan.portal.client.feign.service.ServiceApiSiteFeign;
import net.colt.sdwan.portal.client.helper.TenantClientHelper;
import net.colt.sdwan.portal.client.model.DeviceRequest;
import net.colt.sdwan.portal.security.AuthUserHelper;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;

import static java.util.Objects.nonNull;
import static java.util.Objects.requireNonNull;

@Component
@Slf4j
public class ServiceApiClient extends AbstractRestApiClient {
    private static final String SITE_ID_NOT_NUMERIC = "The Site with the identifier '%s' is not valid.";
    private static final String DEVICE_ID_NOT_NUMERIC = "The Device with the identifier '%s' is not valid.";

    private final TenantClientHelper tenantClientHelper;
    private final ServiceApiSiteFeign serviceApiSiteFeign;
    private final ServiceApiDeviceFeign serviceApiDeviceFeign;
    private final ServiceApiInterfaceFeign serviceApiInterfaceFeign;
    private final ServiceApiManagedInstallFeign serviceApiManagedInstallFeign;

    public ServiceApiClient(AuthHeaderGenerator authHeaderGenerator,
                            RestTemplate restTemplate,
                            LoggingService loggingService,
                            TenantClientHelper tenantClientHelper,
                            ServiceApiSiteFeign serviceApiSiteFeign,
                            ServiceApiDeviceFeign serviceApiDeviceFeign,
                            ServiceApiInterfaceFeign serviceApiInterfaceFeign,
                            ServiceApiManagedInstallFeign serviceApiManagedInstallFeign) {
        super(authHeaderGenerator, restTemplate, loggingService);
        this.tenantClientHelper = tenantClientHelper;
        this.serviceApiSiteFeign = serviceApiSiteFeign;
        this.serviceApiDeviceFeign = serviceApiDeviceFeign;
        this.serviceApiInterfaceFeign = serviceApiInterfaceFeign;
        this.serviceApiManagedInstallFeign = serviceApiManagedInstallFeign;
    }

    public List<SiteResponseV1> getSiteDetailsByCriteria(final SiteCriteria siteCriteria) {
        ResponseEntity<List<SiteResponseV1>> response = serviceApiSiteFeign.getSitesByParametersV1(siteCriteria);

        if (nonNull(response) && nonNull(response.getBody())) {
            return response.getBody();
        }

        throw new SdwanNotFoundException(String.format("The Site with the criteria '%s' could not be found.", siteCriteria));
    }

    public SiteResponseV1 getSiteDetailsById(final String siteId) {
        if (!StringUtils.isNumeric(siteId)) {
            throw new SdwanUnprocessableEntityException(String.format(SITE_ID_NOT_NUMERIC, siteId));
        }
        LongFilter longFilter = new LongFilter();
        longFilter.setEquals(Long.valueOf(siteId));
        SiteCriteria siteCriteria = new SiteCriteria();
        siteCriteria.setSiteId(longFilter);
        siteCriteria.setFetchDevices(true);
        siteCriteria.setFetchInterfaces(true);


        ResponseEntity<List<SiteResponseV1>> response = serviceApiSiteFeign.getSitesByParametersV1(siteCriteria);
        List<SiteResponseV1> body = response.getBody();

        if (CollectionUtils.isNotEmpty(body)) {
            return body.get(0);
        }

        throw new SdwanNotFoundException(String.format("The Site with the identifier '%s' could not be found.", siteId));
    }


    public List<SiteResponseV1> getLockedSites(String username) {
        StringFilter stringFilter = new StringFilter();
        stringFilter.setEquals(username);

        SiteCriteria siteCriteria = new SiteCriteria();
        siteCriteria.setLockedUser(stringFilter);
        siteCriteria.setFetchDevices(true);

        ResponseEntity<List<SiteResponseV1>> response = serviceApiSiteFeign.getSitesByParametersV1(siteCriteria);

        if (nonNull(response) && nonNull(response.getBody())) {
            return response.getBody();
        }

        return Collections.emptyList();
    }

    public void updateDeviceCustomerManagedCertificate(final DeviceRequest deviceRequest) {
        final JsonPatch jsonPatch = Json.createPatchBuilder()
                .replace("/isCustomerManagedCertificateGenerated", deviceRequest.getIsCustomerManagedCertificateGenerated())
                .build();

        serviceApiDeviceFeign.partiallyUpdateDeviceV1(Long.valueOf(deviceRequest.getId()), jsonPatch);
    }

    public void updateDeviceSelfSignedCertificate(final DeviceRequest deviceRequest) {
        final JsonPatch jsonPatch = Json.createPatchBuilder()
                .replace("/isSelfSignedCertificateGenerated", deviceRequest.getIsSelfSignedCertificateGenerated())
                .build();

        serviceApiDeviceFeign.partiallyUpdateDeviceV1(Long.valueOf(deviceRequest.getId()), jsonPatch);
    }

    public void rediscoverBySiteId(final Long id) {
        serviceApiSiteFeign.discoverSiteV1(id, requireNonNull(AuthUserHelper.getAuthUser()).getUsername());
    }

    public void updateSiteDetails(final JsonPatch jsonPatch, Long id) {
        serviceApiSiteFeign.partialUpdateSiteV1(id, jsonPatch);
    }

    public DeviceResponseV1 getDeviceDetailsById(final String deviceId) {
        if (!StringUtils.isNumeric(deviceId)) {
            throw new SdwanUnprocessableEntityException(String.format(DEVICE_ID_NOT_NUMERIC, deviceId));
        }

        LongFilter idFilter = new LongFilter();
        idFilter.setEquals(Long.valueOf(deviceId));

        DeviceCriteria deviceCriteria = new DeviceCriteria();
        deviceCriteria.setId(idFilter);

        ResponseEntity<List<DeviceResponseV1>> response = serviceApiDeviceFeign.getDevicesByParametersV1(deviceCriteria);
        List<DeviceResponseV1> body = response.getBody();

        if (CollectionUtils.isNotEmpty(body)) {
            return body.get(0);
        }

        throw new SdwanNotFoundException(String.format("The Device with the identifier '%s' could not be found.", deviceId));
    }

    public DeviceResponseV1 getDeviceDetailsByName(final String deviceName) {
        StringFilter resourceNameFilter = new StringFilter();
        resourceNameFilter.setEquals(deviceName);

        DeviceCriteria deviceCriteria = new DeviceCriteria();
        deviceCriteria.setResourceName(resourceNameFilter);

        ResponseEntity<List<DeviceResponseV1>> response = serviceApiDeviceFeign.getDevicesByParametersV1(deviceCriteria);
        List<DeviceResponseV1> body = response.getBody();

        if (CollectionUtils.isNotEmpty(body)) {
            return body.get(0);
        }

        throw new SdwanNotFoundException(String.format("The Device with the name '%s' could not be found.", deviceName));
    }


    public List<InterfaceResponseV1> getInterfacesByDeviceId(final String deviceId) {
        if (!StringUtils.isNumeric(deviceId)) {
            throw new SdwanUnprocessableEntityException(String.format(DEVICE_ID_NOT_NUMERIC, deviceId));
        }

        LongFilter deviceIdFilter = new LongFilter();
        deviceIdFilter.setEquals(Long.valueOf(deviceId));

        InterfaceCriteria interfaceCriteria = new InterfaceCriteria();
        interfaceCriteria.setDeviceId(deviceIdFilter);

        ResponseEntity<List<InterfaceResponseV1>> response = serviceApiInterfaceFeign.getInterfacesByParametersV1(interfaceCriteria);

        if (nonNull(response) && nonNull(response.getBody())) {
            return response.getBody();
        }
        return Collections.emptyList();
    }

    public InterfaceResponseV1 getInterfaceById(final Long interfaceId) {
        LongFilter idFilter = new LongFilter();
        idFilter.setEquals(interfaceId);

        InterfaceCriteria interfaceCriteria = new InterfaceCriteria();
        interfaceCriteria.setId(idFilter);

        ResponseEntity<List<InterfaceResponseV1>> response = serviceApiInterfaceFeign.getInterfacesByParametersV1(interfaceCriteria);
        List<InterfaceResponseV1> body = response.getBody();

        if (CollectionUtils.isNotEmpty(body)) {
            return body.get(0);
        }

        throw new SdwanNotFoundException(String.format("The Interface with the identifier '%s' could not be found.", interfaceId));
    }

    public List<ManagedInstallResponseV1> getManagedInstallDeviceByCriteria(final ManagedInstallCriteria criteria) {
        final ResponseEntity<List<ManagedInstallResponseV1>> response =
                serviceApiManagedInstallFeign.getZtpDevicesByParametersV1(criteria);

        return nonNull(response.getBody()) ? response.getBody() : Collections.emptyList();
    }


    public List<ManagedInstallResponseV1> getManagedInstallDeviceForTenantIds(List<Integer> tenantIds) {
        List<Integer> customerIds = tenantClientHelper.getCustomerIdsByTenantIds(tenantIds);

        final LongFilter longFilter = new LongFilter();
        longFilter.setIn(customerIds.stream().map(Long::valueOf).toList());

        final ManagedInstallCriteria criteria = new ManagedInstallCriteria();
        criteria.setCustomerId(longFilter);

        return getManagedInstallDeviceByCriteria(criteria);
    }

    public ManagedInstallResponseV1 getManagedInstallDeviceById(final String deviceId) {
        if (!StringUtils.isNumeric(deviceId)) {
            throw new SdwanUnprocessableEntityException(String.format(DEVICE_ID_NOT_NUMERIC, deviceId));
        }

        final LongFilter longFilter = new LongFilter();
        longFilter.setEquals(Long.valueOf(deviceId));

        final ManagedInstallCriteria criteria = new ManagedInstallCriteria();
        criteria.setId(longFilter);

        final ResponseEntity<List<ManagedInstallResponseV1>> response =
                serviceApiManagedInstallFeign.getZtpDevicesByParametersV1(criteria);

        if (nonNull(response)) {
            final List<ManagedInstallResponseV1> body = response.getBody();

            if (CollectionUtils.isNotEmpty(body)) {
                return body.get(0);
            }
        }

        throw new SdwanNotFoundException(String.format("The Managed Install Device with the criteria '%s' could not be found.", criteria));
    }

    public ManagedInstallResponseV1 updateManagedInstall(final String deviceId, final ManagedInstallSecurityDetailsRequestV1 requestV1, final String initiatedUserId) {
        if (!StringUtils.isNumeric(deviceId)) {
            throw new SdwanUnprocessableEntityException(String.format(DEVICE_ID_NOT_NUMERIC, deviceId));
        }

        final ResponseEntity<ManagedInstallResponseV1> response = serviceApiManagedInstallFeign.updateManagedInstallDeviceSecurityDetailsV1(
                Long.valueOf(deviceId),
                initiatedUserId,
                requestV1);

        if (nonNull(response.getBody())) {
            return response.getBody();
        }

        throw new SdwanInternalServerErrorException(String.format("The Managed Install Device with the identifier '%s' could not be updated.", requestV1));
    }

    public List<LocalInternetBreakoutPreferencesV1> getLIBPreferencesBySiteId(final String siteId) {
        if (!StringUtils.isNumeric(siteId)) {
            throw new SdwanUnprocessableEntityException(String.format(SITE_ID_NOT_NUMERIC, siteId));
        }

        ResponseEntity<List<LocalInternetBreakoutPreferencesV1>> response = serviceApiSiteFeign.getLocalInternetBreakoutBySiteId(Long.valueOf(siteId));

        if (nonNull(response) && nonNull(response.getBody())) {
            return response.getBody();
        }
        return Collections.emptyList();
    }


    public List<SiteResponseV1> getSitesByTenantIds(List<Integer> tenantIds) {
        LongFilter tenantIdFilter = new LongFilter();
        tenantIdFilter.setIn(tenantIds.stream().map(Long::valueOf).toList());
        StringFilter statusFilter = new StringFilter();
        statusFilter.setEquals(SiteStatusV1.ACTIVE.getValue());
        SiteCriteria siteCriteria = new SiteCriteria();
        siteCriteria.setTenantId(tenantIdFilter);
        siteCriteria.setSiteStatus(statusFilter);
        siteCriteria.setFetchDevices(true);

        ResponseEntity<List<SiteResponseV1>> response = serviceApiSiteFeign.getSitesByParametersV1(siteCriteria);

        if (nonNull(response) && nonNull(response.getBody())) {
            return response.getBody();
        }
        return Collections.emptyList();
    }
}
