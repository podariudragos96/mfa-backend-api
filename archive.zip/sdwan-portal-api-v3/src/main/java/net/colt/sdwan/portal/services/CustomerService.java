package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.client.model.customerapi.CustomerResponseV1;
import net.colt.sdwan.portal.client.model.customerapi.CustomerSummaryResponseV1;
import net.colt.sdwan.portal.client.model.customerapi.UpdateCustomerRequestV1;

import java.util.List;

public interface CustomerService {

    void save(final Integer customerId, final UpdateCustomerRequestV1 customer);

    CustomerSummaryResponseV1 findByOcn(final String ocn);

    CustomerResponseV1 findById(final Integer customerId);

    CustomerSummaryResponseV1 findByVersaOrgName(final String versaOrgName);

    List<CustomerResponseV1> findAllByIdList(final List<Integer> ids);

    List<CustomerSummaryResponseV1> findAllByOcnList(final List<String> ocnList);

}
