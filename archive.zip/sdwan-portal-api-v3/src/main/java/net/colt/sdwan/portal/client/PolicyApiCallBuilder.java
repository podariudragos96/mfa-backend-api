package net.colt.sdwan.portal.client;

import net.colt.sdwan.common.exceptions.exception.SdwanUnprocessableEntityException;
import net.colt.sdwan.generated.model.service.CgwResponseV1;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.InterfaceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.model.Status;
import net.colt.sdwan.portal.enums.RoutingStatsType;
import net.colt.sdwan.portal.model.RoutingProtocolV1;
import net.colt.sdwan.portal.model.RoutingTypeV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import java.util.*;

import static java.lang.Boolean.FALSE;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.client.ParamsLabels.*;
import static net.colt.sdwan.portal.client.ServicesUrlProperties.*;
import static net.colt.sdwan.portal.constant.Constants.SLASH;
import static net.colt.sdwan.portal.mappers.UserModelMapper.mapRolesToCSV;
import static net.colt.sdwan.portal.util.CGWUtil.*;

@Component
public class PolicyApiCallBuilder {

    @Value("${policy.api.base.url}")
    private String policyURL;

    String buildPolicyApiPath(final String siteType, final String siteId) {
        StringBuilder builder = new StringBuilder();
        if (isCloudGateway(siteType)) {
            builder.append(POLICY_API_POLICIES_CLOUD_GATEWAY_URI);
        } else if (isGateway(siteType)) {
            builder.append(POLICY_API_POLICIES_CLOUD_URI);
        } else {
            builder.append(POLICY_API_POLICIES_URI);
        }
        return builder.append(SLASH).append(siteId).toString();
    }

    String buildPolicyApiPathV2(final String siteType, final String siteId) {
        StringBuilder builder = new StringBuilder();
        builder.append(POLICY_API_V2);
        if (isCloudGateway(siteType)) {
            builder.append(POLICY_API_POLICIES_CLOUD_GATEWAY_URI);
        } else if (isGateway(siteType)) {
            builder.append(POLICY_API_POLICIES_CLOUD_URI);
        } else {
            builder.append(POLICY_API_POLICIES_URI);
        }
        return builder.append(SLASH).append(siteId).toString();
    }

    String buildFirewallRulesApiPath(final String siteType, final String siteId) {
        StringBuilder builder = new StringBuilder();
        if (isCloudGateway(siteType)) {
            builder.append(POLICY_API_CGW_FIREWALL_RULES_URI);
        } else if (isGateway(siteType)) {
            builder.append(POLICY_API_GW_FIREWALL_RULES_URI);
        } else {
            builder.append(POLICY_API_FIREWALL_RULES_URI);
        }
        return builder.append(SLASH).append(siteId).toString();
    }

    String buildFirewallRulesApiPathV2(final String siteType, final String siteId) {
        StringBuilder builder = new StringBuilder();
        builder.append(POLICY_API_V2);
        if (isCloudGateway(siteType)) {
            builder.append(POLICY_API_CGW_FIREWALL_RULES_URI);
        } else if (isGateway(siteType)) {
            builder.append(POLICY_API_GW_FIREWALL_RULES_URI);
        } else {
            builder.append(POLICY_API_FIREWALL_RULES_URI);
        }
        return builder.append(SLASH).append(siteId).toString();
    }

    String buildFirewallRulesHistoryApiPath(final String siteType, final String siteId) {
        StringBuilder builder = new StringBuilder();
        builder.append(POLICY_API_V2);
        if (isCloudGateway(siteType)) {
            builder.append(POLICY_API_CGW_FIREWALL_RULES_URI);
        } else if (isGateway(siteType)) {
            builder.append(POLICY_API_GW_FIREWALL_RULES_URI);
        } else {
            builder.append(POLICY_API_FIREWALL_RULES_URI);
        }
        return builder.append(SLASH).append(siteId).append(POLICY_API_FIREWALL_RULES_HISTORY_URI).toString();
    }

    String buildFirewallRulesHistoryByIdApiPath(final String siteType, final String siteId, final String ruleSetId) {
        StringBuilder builder = new StringBuilder();
        builder.append(POLICY_API_V2);
        if (isCloudGateway(siteType)) {
            builder.append(POLICY_API_CGW_FIREWALL_RULES_URI);
        } else if (isGateway(siteType)) {
            builder.append(POLICY_API_GW_FIREWALL_RULES_URI);
        } else {
            builder.append(POLICY_API_FIREWALL_RULES_URI);
        }
        return builder.append(SLASH).append(siteId).append(POLICY_API_FIREWALL_RULES_HISTORY_URI).append(SLASH).append(ruleSetId).toString();
    }

    String buildDecryptionRulesApiPath(String siteType, String siteId) {
        StringBuilder builder = new StringBuilder();
        if (isBranch(siteType)) {
            builder.append(POLICY_API_POLICIES_DECRYPTION_RULES_URI);
        } else {
            throw new SdwanUnprocessableEntityException("Decryption rules are only applicable for Branch site (type: " + siteType + ", id: " + siteId + ").");
        }
        return builder.append(SLASH).append(siteId).toString();
    }

    String buildDecryptionRulesApiPathV2(String siteType, String siteId) {
        StringBuilder builder = new StringBuilder();
        builder.append(POLICY_API_V2);
        if (isBranch(siteType)) {
            builder.append(POLICY_API_POLICIES_DECRYPTION_RULES_URI);
        } else {
            throw new SdwanUnprocessableEntityException("Decryption rules are only applicable for Branch site (type: " + siteType + ", id: " + siteId + ").");
        }
        return builder.append(SLASH).append(siteId).toString();
    }


    public boolean isLTE(final List<DeviceResponseV1> deviceSet) {
        boolean isLTE = false;
        if (CollectionUtils.isNotEmpty(deviceSet)) {
            isLTE = deviceSet.stream()
                    .filter(device -> device.getStatus().getValue().equals(Status.ACTIVE.value())
                            && Objects.nonNull(device.getIsLte()))
                    .anyMatch(DeviceResponseV1::getIsLte);
        }
        return isLTE;
    }

    String findPrimaryDeviceName(final List<DeviceResponseV1> deviceResponseSet) {
        Optional<DeviceResponseV1> deviceResponse = deviceResponseSet.stream()
                .filter(device -> Objects.nonNull(device.getIsPrimary()) && device.getIsPrimary()).findFirst();
        String name = null;
        if (deviceResponse.isPresent()) {
            name = deviceResponse.get().getResourceName();
        }
        return name;
    }

    String getCpsPeeringInterface(List<DeviceResponseV1> deviceSet, List<CgwResponseV1> cgwResponseV1s, final InterfaceResponseV1 interfaceResponse) {
        if (Objects.nonNull(interfaceResponse)) {
            return interfaceResponse.getZone();
        }
        Optional<DeviceResponseV1> deviceResponseOpt = Optional.empty();
        if (CollectionUtils.isNotEmpty(deviceSet)) {
            deviceResponseOpt = deviceSet.stream().findFirst();
        }

        if (deviceResponseOpt.isPresent() && Objects.nonNull(cgwResponseV1s)) {
            DeviceResponseV1 deviceResponseV1 = deviceResponseOpt.get();
            final Optional<CgwResponseV1> cgwDetails = cgwResponseV1s.stream()
                    .filter(c -> c.getCgwName().equals(deviceResponseV1.getResourceName()))
                    .findAny();

            return cgwDetails
                    .map(CgwResponseV1::getCspPeeringInterface)
                    .orElse(null);
        }

        return null;
    }

    String buildDeviceNamesParam(final List<DeviceResponseV1> deviceSet) {
        final StringBuilder devices = new StringBuilder();
        if (CollectionUtils.isNotEmpty(deviceSet)) {
            deviceSet.stream()
                    .filter(device -> device.getStatus().name().equalsIgnoreCase(Status.ACTIVE.name()))
                    .forEach(deviceResponse -> devices.append(DEVICE_PATH).append(deviceResponse.getResourceName()));
        }
        return devices.toString();
    }

    Map<String, Object> buildDecryptionDefaultParamsMap(SiteResponseV1 siteResponse) {
        Map<String, Object> params = buildUserRolesParamsMap();
        params.put(CUSTOMER, siteResponse.getNetworkId());
        params.put(DEVICES_PARAMS, buildDeviceNamesParam(new ArrayList<>(siteResponse.getDevices())));
        return params;
    }

    Map<String, Object> buildPoliciesParamsMap(SiteResponseV1 siteResponse, InterfaceResponseV1 interfaceResponse, boolean isUpdate) {
        Map<String, Object> params = buildUserRolesParamsMap();
        params.put(CUSTOMER, siteResponse.getNetworkId());
        String cspPeeringInterface = getCpsPeeringInterface(siteResponse.getDevices(), siteResponse.getCgw(), interfaceResponse);
        if (isCloudGateway(siteResponse.getSiteType().getValue()) && Objects.nonNull(cspPeeringInterface)) {
            params.put(CSP_PEERING_INTERFACE, cspPeeringInterface);
        }
        if (isUpdate) {
            params.put(ASYNC, true);
        }
        params.put(IS_LTE, isLTE(siteResponse.getDevices()));
        return params;
    }


    Map<String, Object> buildCommonsParamsMap(final String managementIpv4) {
        Map<String, Object> params = buildUserRolesParamsMap();
        params.put(MANAGEMENT_IPV4, managementIpv4);
        params.put(ACTION, HttpMethod.GET.toString());
        params.put(ASYNC, true);
        params.put(EVENT_ID, MDC.get(CORRELATION_ID));

        return params;
    }

    Map<String, Object> buildUserRolesParamsMap() {
        Map<String, Object> params = new HashMap<>();
        UserAuth userAuth = AuthUserHelper.getAuthUser();
        params.put(INITIATED_USER_ID, userAuth.getUsername());
        params.put(INITIATED_USER_ROLE, mapRolesToCSV(userAuth.getRoles()));
        return params;
    }

    String buildPingOrTraceroutePath(boolean isPing, String versaInstance) {
        String url = policyURL.concat(SLASH + versaInstance);
        if (isPing) {
            url = url.concat(POLICY_API_PING_URI);
        } else {
            url = url.concat(POLICY_API_TRACEROUTE_URI);
        }
        return url;
    }

    Map<String, Object> putRoutingProtocolValues(final Map<String, Object> params, RoutingProtocolV1 routingProtocol,
                                                 RoutingTypeV1 routingType, Boolean formatted) {
        if (Objects.nonNull(routingProtocol)) {
            params.put(ROUTING_PROTOCOL, routingProtocol.toString().toLowerCase());
            if (RoutingProtocolV1.BGP.equals(routingProtocol) && Objects.nonNull(routingType)) {
                params.put(BGP_TYPE, routingType.toString().toLowerCase());
            }
            if (RoutingProtocolV1.STATIC.equals(routingProtocol)) {
                params.put(FORMATTED, formatted);
            }
        }
        return params;
    }

    Map<String, Object> putNeighborCommandValues(final Map<String, Object> params,
                                                 RoutingProtocolV1 routingProtocol,
                                                 RoutingStatsType statsType,
                                                 Boolean brief,
                                                 final String versaOrg) {
        if (RoutingStatsType.neighbor.equals(statsType) && Objects.nonNull(brief)) {
            params.put(BRIEF, brief);
            if (FALSE.equals(brief) && RoutingProtocolV1.OSPF.equals(routingProtocol)) {
                params.put(ORG, versaOrg);
            }
        }
        return params;
    }

}
