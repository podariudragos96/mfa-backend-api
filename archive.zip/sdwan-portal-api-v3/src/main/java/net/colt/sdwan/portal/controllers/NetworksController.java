package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.NetworkApiApi;
import net.colt.sdwan.portal.model.FirewallRulesActionV1;
import net.colt.sdwan.portal.model.FirewallRulesNetworkResponseV1;
import net.colt.sdwan.portal.model.NetworkResponseV1;
import net.colt.sdwan.portal.services.NetworksService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;
import java.util.List;

@RequiredArgsConstructor
@Controller
public class NetworksController implements NetworkApiApi {

    private final NetworksService networksService;

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<FirewallRulesNetworkResponseV1>> getFirewallRulesByNetworkIdV1(String networkId,
            @RequestParam(value = "action", defaultValue = "null") FirewallRulesActionV1 action,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt,
            @RequestParam(value = "count") Integer count) {
        return ResponseEntity.ok(networksService.getFirewallRulesByNetworkId(networkId, action, startDt, endDt, count));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<NetworkResponseV1>> getNetworksV1() {
        return ResponseEntity.ok(networksService.getNetworks());
    }
}
