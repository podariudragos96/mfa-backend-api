package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.feign.sitesettings.SnmpApiFeign;
import net.colt.sdwan.portal.constant.SnmpConstants;
import net.colt.sdwan.portal.mappers.SnmpMapper;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SnmpRequestV1;
import net.colt.sdwan.portal.model.SnmpResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.services.SnmpService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.portal.validator.SnmpRequestV1Validator;
import net.colt.sdwan.sitesettings.api.generated.model.SnmpRequestApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.SnmpResponseApiV1;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.model.OnGoingActionV2.MODIFYING_SNMP_RULES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;
import static net.colt.sdwan.portal.model.SiteTypeV1.BRANCH;

@Service
@Slf4j
@RequiredArgsConstructor
public class SnmpServiceImpl implements SnmpService {

    private final SitesService sitesService;
    private final SnmpApiFeign snmpApiFeign;
    private final SnmpMapper snmpMapper;
    private final ResponseEntityValidator responseEntityValidator;

    private final SiteResponseValidator siteResponseValidator;

    @Override
    public SnmpResponseV1 getSnmpV1(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (!BRANCH.toString().equalsIgnoreCase(siteResponse.getSiteType().getValue())) {
            throw new SdwanBadRequestException(SnmpConstants.SNMP_ONLY_AVAILABLE_ON_BRANCH_SITES);
        }

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final ResponseEntity<SnmpResponseApiV1> snmpResponseEntity =
                snmpApiFeign.getSnmpV1(siteResponse.getId().intValue(), siteResponse.getNetworkId());
        responseEntityValidator.checkResponseEntity(snmpResponseEntity, SnmpConstants.SNMP_FEATURE_NAME);

        return snmpMapper.from(snmpResponseEntity.getBody());
    }

    @Override
    public CorrelationIdResponseV1 updateSnmpV1(String siteId, SnmpRequestV1 snmpRequestV1) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);

        if (!BRANCH.toString().equalsIgnoreCase(siteResponse.getSiteType().getValue())) {
            throw new SdwanBadRequestException(SnmpConstants.SNMP_ONLY_AVAILABLE_ON_BRANCH_SITES);
        }

        SnmpRequestV1Validator.validateSnmpRequestV1(snmpRequestV1, siteResponse);

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        SnmpRequestApiV1 snmpRequestApiV1 = snmpMapper.from(snmpRequestV1, siteResponse);

        try {
            sitesService.updateOngoingAction(siteId, MODIFYING_SNMP_RULES);

            final ResponseEntity<Void> snmpResponseEntity = snmpApiFeign.updateSnmpV1(Integer.valueOf(siteId),
                    siteResponse.getNetworkId(), AuthUserHelper.getAuthUser().getUsername(),
                    sitesService.getDeviceNamesFromSiteResponse(siteResponse), snmpRequestApiV1);
            responseEntityValidator.checkResponseEntity(snmpResponseEntity, SnmpConstants.SNMP_FEATURE_NAME);
        } catch (Exception ex) {
            log.error("Failed to update " + SnmpConstants.SNMP_FEATURE_NAME + " for site with id " + siteId, ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }

        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

}
