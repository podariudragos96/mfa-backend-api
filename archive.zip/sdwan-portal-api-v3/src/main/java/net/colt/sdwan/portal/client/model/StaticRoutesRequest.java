package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class StaticRoutesRequest {
    @NotNull
    @JsonProperty("vrf")
    private String vrf;

    @JsonProperty("destination")
    @NotNull
    private String destination;

    @NotNull
    @JsonProperty("next_hop")
    private String nextHop;

    @NotNull
    @JsonProperty("interface")
    private String vniInterface;

}
