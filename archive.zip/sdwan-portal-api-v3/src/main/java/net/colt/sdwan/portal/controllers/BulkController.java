package net.colt.sdwan.portal.controllers;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.portal.generated.controllers.BulkApiApi;
import net.colt.sdwan.portal.model.BulkCopyRequestRequestV2;
import net.colt.sdwan.portal.model.BulkCopyRequestResponseV2;
import net.colt.sdwan.portal.model.BulkCopyRequestsResponseV1;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.BulkService;
import net.colt.sdwan.portal.validator.model.BulkCopyRequestValidator;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
@RestController
public class BulkController implements BulkApiApi {

    private final BulkService bulkService;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setValidator(new BulkCopyRequestValidator());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<BulkCopyRequestsResponseV1>> getBulkCopyRequestsV1(String networkId) {
        return ResponseEntity.ok(bulkService.getBulkCopyRequests(networkId));
    }

    @Override
    @SDWanAsyncMethod("/v1/networks/{network_id}/requests/bulk-copy")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> createBulkCopyRequestV2(String networkId,
                                                                           @Valid @RequestBody BulkCopyRequestRequestV2 bulkCopyRequestRequestV2) {
        return ResponseEntity.ok(bulkService.createBulkCopyRequest(bulkCopyRequestRequestV2, networkId));
    }

    @Override
    public ResponseEntity<List<BulkCopyRequestResponseV2>> getBulkCopyRequestsByIdV2(String networkId, String requestId) {
        return ResponseEntity.ok(bulkService.getBulkCopyRequestsById(requestId, networkId));
    }
}
