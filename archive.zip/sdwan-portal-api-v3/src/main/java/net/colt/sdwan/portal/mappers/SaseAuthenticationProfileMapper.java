package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.model.versa.sase.api.SamlAuthenticationProfileRequestApiV1;
import net.colt.sdwan.generated.model.versa.sase.api.SamlAuthenticationProfilesResponseApiV1;
import net.colt.sdwan.portal.model.SaseSamlAuthenticationProfileRequestV1;
import net.colt.sdwan.portal.model.SaseSamlAuthenticationProfilesResponseV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SaseAuthenticationProfileMapper {

    private final ModelMapper modelMapper;

    public SaseSamlAuthenticationProfilesResponseV1 from(SamlAuthenticationProfilesResponseApiV1 profilesResponseApiV1) {
        return modelMapper.map(profilesResponseApiV1, SaseSamlAuthenticationProfilesResponseV1.class);
    }

    public SamlAuthenticationProfileRequestApiV1 from(SaseSamlAuthenticationProfileRequestV1 profileRequestV1) {
        return modelMapper.map(profileRequestV1, SamlAuthenticationProfileRequestApiV1.class);
    }
}
