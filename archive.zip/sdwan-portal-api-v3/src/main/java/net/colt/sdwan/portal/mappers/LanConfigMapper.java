package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.model.LanConfigurationRequestV1;
import net.colt.sdwan.sitesettings.api.generated.model.LanConfigurationRequestV1ApiV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@RequiredArgsConstructor
@Component
public class LanConfigMapper {

    private final ModelMapper modelMapper;

    public LanConfigurationRequestV1ApiV1 from(LanConfigurationRequestV1 lanConfigurationRequestV1) {
        return modelMapper.map(lanConfigurationRequestV1, LanConfigurationRequestV1ApiV1.class);
    }

}
