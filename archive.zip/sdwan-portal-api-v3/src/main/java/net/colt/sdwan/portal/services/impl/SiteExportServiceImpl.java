package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.data.criteria.filter.Filter;
import net.colt.sdwan.common.data.criteria.filter.LongFilter;
import net.colt.sdwan.portal.client.feign.service.ServiceApiSiteExportFeign;
import net.colt.sdwan.portal.mappers.SiteExportMapper;
import net.colt.sdwan.portal.mappers.SupportedLanguageMapper;
import net.colt.sdwan.portal.model.SiteExportCriteria;
import net.colt.sdwan.portal.model.SiteResponseV3;
import net.colt.sdwan.portal.model.SupportedLanguageV1;
import net.colt.sdwan.portal.services.SiteExportService;
import net.colt.sdwan.portal.services.SitesService;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

@Service
@Slf4j
@Transactional
@RequiredArgsConstructor
public class SiteExportServiceImpl implements SiteExportService {

    private final ServiceApiSiteExportFeign serviceApiSiteExportFeign;
    private final SitesService sitesService;
    private final SiteExportMapper siteExportMapper;
    private final SupportedLanguageMapper supportedLanguageMapper;

    @Override
    public ResponseEntity<Resource> exportSite(String accept,
                                               SupportedLanguageV1 acceptLanguage,
                                               SiteExportCriteria siteExportCriteria) {
        final List<Long> requestedSiteIds = this.extractSiteIds(siteExportCriteria.getSiteId());

        if (CollectionUtils.isEmpty(requestedSiteIds)) {
            final String networkId = Optional.ofNullable(siteExportCriteria.getNetworkId()).map(Filter::getEquals).orElse(null);

            final List<SiteResponseV3> accessibleSites = sitesService.getAllSitesV3();

            final List<Long> siteIds = accessibleSites.stream()
                    .filter(site -> Objects.equals(site.getNetworkId(), networkId))
                    .map(SiteResponseV3::getId)
                    .filter(Objects::nonNull)
                    .map(Long::parseLong)
                    .toList();

            // add filtered user accessible site IDs into the criteria
            final LongFilter customerSiteIdFilter = new LongFilter();
            customerSiteIdFilter.setIn(siteIds);
            siteExportCriteria.setSiteId(customerSiteIdFilter);
        }

        // validate requested siteIds
        requestedSiteIds.forEach(siteId -> sitesService.getApiSiteAndVerify(String.valueOf(siteId)));

        return serviceApiSiteExportFeign.exportSitesV1(
                accept,
                supportedLanguageMapper.toSupportedLanguageV1(acceptLanguage),
                siteExportMapper.toSiteExportCriteria(siteExportCriteria));
    }

    private List<Long> extractSiteIds(LongFilter siteIdFilter) {
        if (siteIdFilter == null) return new ArrayList<>();

        Stream<Long> siteIdsFromSingleValueFields = Stream.of(
                siteIdFilter.getEquals(),
                siteIdFilter.getNotEquals(),
                siteIdFilter.getGreaterThan(),
                siteIdFilter.getLessThan(),
                siteIdFilter.getGreaterThanOrEqual(),
                siteIdFilter.getLessThanOrEqual()
        );

        return Stream.concat(
                        Stream.concat(
                                Optional.ofNullable(siteIdFilter.getIn()).stream().flatMap(List::stream),
                                Optional.ofNullable(siteIdFilter.getNotIn()).stream().flatMap(List::stream)
                        ),
                        siteIdsFromSingleValueFields
                )
                .filter(Objects::nonNull)
                .distinct()
                .toList();
    }

}
