package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.model.DeviceCustomerManagedCertificateRequestV1;
import net.colt.sdwan.portal.model.DeviceSelfSignedCertificateRequestV1;
import net.colt.sdwan.security.api.generated.model.CustomerManagedCertificateApiRequestV1;
import net.colt.sdwan.security.api.generated.model.SelfSignedCertificateApiRequestV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@RequiredArgsConstructor
@Component
public class CertificateMapper {

    private final ModelMapper modelMapper;

    public SelfSignedCertificateApiRequestV1 from(DeviceSelfSignedCertificateRequestV1 deviceSelfSignedCertificateRequestV1) {
        return modelMapper.map(deviceSelfSignedCertificateRequestV1, SelfSignedCertificateApiRequestV1.class);
    }

    public CustomerManagedCertificateApiRequestV1 from(DeviceCustomerManagedCertificateRequestV1 deviceCustomerManagedCertificateRequestV1) {
        return modelMapper.map(deviceCustomerManagedCertificateRequestV1, CustomerManagedCertificateApiRequestV1.class);
    }

}
