package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.SystemStatus;

import java.util.List;

public interface SystemStatusService {

    List<SystemStatus> findByActiveSystemStatuses();

    boolean isSystemModuleDisabled(String module);
}
