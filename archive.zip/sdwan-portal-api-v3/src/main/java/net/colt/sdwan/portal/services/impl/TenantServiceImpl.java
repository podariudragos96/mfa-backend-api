package net.colt.sdwan.portal.services.impl;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.portal.client.helper.TenantClientHelper;
import net.colt.sdwan.portal.client.model.customerapi.EditTenantRequestV1;
import net.colt.sdwan.portal.client.model.customerapi.TenantResponseV1;
import net.colt.sdwan.portal.client.model.customerapi.TenantStatus;
import net.colt.sdwan.portal.client.model.customerapi.TenantUserResponseV1;
import net.colt.sdwan.portal.model.EditTenantPortalRequestV1;
import net.colt.sdwan.portal.model.TenantPortalResponseV1;
import net.colt.sdwan.portal.model.TenantUserPortalResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.TenantService;
import net.colt.sdwan.portal.services.TenantUserService;
import org.apache.commons.collections4.CollectionUtils;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
@Service
@Slf4j
public class TenantServiceImpl implements TenantService {

    private final TenantUserService tenantUserService;
    private final ModelMapper modelMapper;
    private final TenantClientHelper tenantClientHelper;

    @Override
    public List<TenantPortalResponseV1> getTenantByParams(Integer customerId, String domain, String versaOrg) {
        List<TenantResponseV1> body = tenantClientHelper.getTenantByParams(customerId, domain, versaOrg);
        return modelMapper.map(body, new TypeToken<List<TenantPortalResponseV1>>() {
        }.getType());
    }

    @Override
    public List<TenantPortalResponseV1> getAccessibleResellerTenants() {
        UserAuth authUser = AuthUserHelper.getAuthUser();
        log.debug("Get All Tenant for userid {}, username {}", authUser.getUserId(), authUser.getUsername());
        List<TenantResponseV1> tenantResponse = tenantClientHelper.findAllByIdList(authUser.getAccessibleTenantIds());
        // filter only tenant that are whitelabel
        tenantResponse = tenantResponse.stream()
                .filter(TenantResponseV1::getWhitelabel)
                .toList();
        return modelMapper.map(tenantResponse, new TypeToken<List<TenantPortalResponseV1>>() {
        }.getType());
    }

    @Override
    public void editTenant(Integer tenantId, EditTenantPortalRequestV1 editTenantPortalRequestV1) {
        final EditTenantRequestV1 request = modelMapper.map(editTenantPortalRequestV1, EditTenantRequestV1.class);
        if (request.getStatus() == TenantStatus.DISABLED) {
            updateUserStatus(tenantId);
        }
        tenantClientHelper.editTenant(tenantId, request);
    }

    private void updateUserStatus(Integer tenantId) {
        TenantResponseV1 tenantResponse = tenantClientHelper.findById(tenantId);
        List<TenantUserResponseV1> response = tenantClientHelper.getTenantUserByTenantId(tenantId);
        response.forEach(tenantUser ->
                this.tenantUserService.clearByUsername(tenantUserService.generateUsername(tenantUser, tenantResponse)));
    }

    @Override
    public TenantPortalResponseV1 getTenantById(Integer tenantId) {
        TenantResponseV1 body = tenantClientHelper.findById(tenantId);
        return modelMapper.map(body, TenantPortalResponseV1.class);
    }

    @Override
    public List<Integer> getTenantIdsByCustomerId(Integer customerId) {
        List<Integer> result = new ArrayList<>();
        List<TenantResponseV1> response = tenantClientHelper.getTenantByParams(customerId, null, null);
        if (CollectionUtils.isNotEmpty(response)) {
            log.debug("Get Tenant Id by Customer Id: {}", customerId);
            result.addAll(response.stream()
                    .map(TenantResponseV1::getTenantId)
                    .toList());
        }
        return result;
    }


    @Override
    public List<TenantUserPortalResponseV1> getTenantUserByTenantId(Integer tenantId) {
        List<TenantUserResponseV1> response = tenantClientHelper.getTenantUserByTenantId(tenantId);
        return modelMapper.map(response, new TypeToken<List<TenantUserPortalResponseV1>>() {
        }.getType());
    }
}
