package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.util.LocalDateTimeOperations;
import net.colt.sdwan.portal.util.SiteResponseUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static net.colt.sdwan.portal.util.LocalDateTimeOperations.DATE_PATTERN_REGULAR;

@RequiredArgsConstructor
@Component
public class SiteResponseMapper extends CommonMapper {

    private final InterfaceSummaryResponseMapper interfaceSummaryResponseMapper;

    public SiteResponseV3 fromV3(SiteResponseV1 siteResponse) {
        final List<net.colt.sdwan.generated.model.service.InterfaceResponseV1> mergedList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(siteResponse.getDevices())) {
            siteResponse.getDevices().forEach(deviceResponse -> mergedList.addAll(deviceResponse.getInterfaces()));
        }

        final InterfaceSummaryResponseV1 interfaceSummaryResponse =
                interfaceSummaryResponseMapper.mapFromList(mergedList, siteResponse.getNetworkId(), siteResponse.getSiteType().getValue(), siteResponse.getCgw());
        final SteeringResponseV1 steeringResponseV1 = mapSteeringTypeV2(siteResponse.getSiteFeatures().getSteering().getInternetSteering());

        return new SiteResponseV3().id(siteResponse.getId().toString())
                .createdDt(siteResponse.getCreatedDt())
                .updatedDt(siteResponse.getUpdatedDt())
                .reachable(mapReachableFromString(siteResponse.getReachable().getValue()))
                .syncStatus(mapReachableFromString(siteResponse.getSyncStatus().getValue()))
                .friendlyName(siteResponse.getFriendlyName())
                .resourceName(siteResponse.getResourceName())
                .ongoingAction(mapOngoingActionV2(siteResponse.getOnGoingAction().getValue()))
                .location(mapLocationResponseV1(siteResponse))
                .siteType(mapSiteTypeEnum(siteResponse.getSiteType().getValue()))
                .siteSubtype(mapSiteSubtypeEnum(siteResponse.getSiteSubtype()))
                .contractNumber(siteResponse.getOrderNo())
                .ipAddressFamily(SiteResponseV3.IpAddressFamilyEnum.valueOf(siteResponse.getIpAddressFamily().getValue()))
                .maxFirewallRules(siteResponse.getMaxFirewallRules())
                .maxPolicyRules(siteResponse.getMaxPolicyRules())
                .maxQosRules(siteResponse.getMaxQosRules())
                .locked(siteResponse.getLocked())
                .networkId(siteResponse.getNetworkId())
                .linkedSites(mapLinkedSites(siteResponse.getLinkedSites()))
                .lockedUser(siteResponse.getLockedUser())
                .lockedDt(siteResponse.getLockedDt() != null ? LocalDateTimeOperations.formatDateTimePattern(siteResponse.getLockedDt(), DATE_PATTERN_REGULAR) : null)
                .interfaces(interfaceSummaryResponse)
                .configurationHash(siteResponse.getConfigurationHash())
                .vpns(SiteResponseUtils.mapVpns(siteResponse))
                .siteFeatures(mapSiteFeatures(siteResponse, steeringResponseV1))
                .devices(mapDevices(siteResponse.getDevices()))
                .isDualSite(siteResponse.getDevices().size() > 1);
    }

    private LocationResponseV1 mapLocationResponseV1(SiteResponseV1 siteResponse) {
        return new LocationResponseV1()
                .address(siteResponse.getLocation().getAddress())
                .longitude(siteResponse.getLocation().getLongitude())
                .latitude(siteResponse.getLocation().getLatitude());
    }

    private SiteResponseV3SiteFeatures mapSiteFeatures(SiteResponseV1 siteResponse, SteeringResponseV1 steeringResponseV1) {
        return new SiteResponseV3SiteFeatures()
                .centralInternetBreakoutEnabled(siteResponse.getSiteFeatures().getCentralInternetBreakoutEnabled())
                .diaEnabled(siteResponse.getSiteFeatures().getDiaEnabled())
                .voipEnabled(siteResponse.getSiteFeatures().getVoipEnabled())
                .security(mapSecurityResponseV2(siteResponse))
                .steering(steeringResponseV1)
                .sase(mapSaseResponseV1(siteResponse))
                .zscaler(mapZScalerResponseV1(siteResponse))
                .qos(mapQosResponseV1(siteResponse));
    }

    private SaseResponseV1 mapSaseResponseV1(SiteResponseV1 siteResponse) {
        return SaseResponseV1.builder()
                .isEnabled(siteResponse.getSiteFeatures().getSase().getIsEnabled())
                .isActive(siteResponse.getSiteFeatures().getSase().getIsActive())
                .build();
    }

    private ZScalerResponseV1 mapZScalerResponseV1(SiteResponseV1 siteResponse) {
        return ZScalerResponseV1.builder()
                .zscalerEnabled(siteResponse.getSiteFeatures().getZscaler().getZscalerEnabled())
                .zscalerActive(siteResponse.getSiteFeatures().getZscaler().getZscalerActive())
                .build();
    }

    private QosResponseV1 mapQosResponseV1(SiteResponseV1 siteResponse) {
        return QosResponseV1.builder()
                .qosEnabled(siteResponse.getSiteFeatures().getQos().getQosEnabled())
                .mplsQosEnabled(siteResponse.getSiteFeatures().getQos().getMplsQosEnabled())
                .build();
    }

    private OnGoingActionV2 mapOngoingActionV2(final String ongoingAction) {
        OnGoingActionV2 ongoingActionEnum = OnGoingActionV2.NONE;
        if (StringUtils.isNotEmpty(ongoingAction)) {
            ongoingActionEnum = OnGoingActionV2.fromValue(ongoingAction);
        }
        return ongoingActionEnum;
    }

    private SteeringResponseV1 mapSteeringTypeV2(final Boolean isInternetSteering) {

        SteeringResponseV1 steeringResponseV1 = new SteeringResponseV1();
        steeringResponseV1.setSdwanSteering(SdwanSteeringV1.ADVANCED);
        steeringResponseV1.setInternetSteering(isInternetSteering);

        return steeringResponseV1;
    }

    public ServiceStatusV1 mapReachableFromString(final String reachable) {
        ServiceStatusV1 serviceStatusV1 = ServiceStatusV1.NONE;
        if (Objects.nonNull(reachable)) {
            serviceStatusV1 = ServiceStatusV1.fromValue(reachable);
        }
        return serviceStatusV1;
    }

    private SecurityResponseV2 mapSecurityResponseV2(SiteResponseV1 siteResponse) {
        return new SecurityResponseV2()
                .ipsVulnerabilityEnabled(siteResponse.getSiteFeatures().getSecurity().getIpsVulnerabilityEnabled())
                .ipFilteringEnabled(siteResponse.getSiteFeatures().getSecurity().getIpFilteringEnabled())
                .antivirusEnabled(siteResponse.getSiteFeatures().getSecurity().getAntivirusEnabled())
                .firewall(FirewallV1.valueOf(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue()))
                .urlFilteringEnabled(siteResponse.getSiteFeatures().getSecurity().getUrlFilteringEnabled())
                .logging(mapLoggingEvent(siteResponse.getSiteFeatures().getSecurity().getLogging().getLoggingType(), siteResponse.getSiteFeatures().getSecurity().getLogging().getLoggingEvent()))
                .securityPlusEnabled(siteResponse.getSiteFeatures().getSecurity().getSecurityPlusEnabled());


    }

    private LoggingV1 mapLoggingEvent(String loggingProfile, String loggingEvent) {
        return new LoggingV1().loggingType(loggingProfile).loggingEvent(loggingEvent);
    }

    private List<DeviceV1> mapDevices(final List<net.colt.sdwan.generated.model.service.DeviceResponseV1> deviceSet) {
        List<DeviceV1> deviceV1List=new ArrayList<>();
        deviceSet.forEach(deviceResponseV1 ->
                deviceV1List.add(DeviceV1.builder().resourceName(deviceResponseV1.getResourceName())
                        .specification(DeviceSpecificationV1.builder().model(deviceResponseV1.getModel())
                                .serialNumber(deviceResponseV1.getSerialNumber()).softwareVersion(deviceResponseV1.getSwVersion()).build()).build())
        );
        return deviceV1List;
    }

    private List<LinkedSitesV1> mapLinkedSites(final List<net.colt.sdwan.generated.model.service.LinkedSitesV1> linkedSitesV1s) {
        return linkedSitesV1s.stream()
                .map(linkedSitesV1 ->
                        LinkedSitesV1.builder()
                                .siteId(linkedSitesV1.getSiteId())
                                .priority(linkedSitesV1.getPriority())
                                .build())
                .toList();
    }
}
