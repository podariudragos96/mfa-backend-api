package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
public class InterfaceQOSAnalyticsTableResponse {

    @JsonProperty("interfaces")
    List<InterfaceQOSAnalyticsRowResponse> interfaces = new ArrayList<>();
}
