package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.EditTenantPortalRequestV1;
import net.colt.sdwan.portal.model.TenantPortalResponseV1;
import net.colt.sdwan.portal.model.TenantUserPortalResponseV1;

import java.util.List;

public interface TenantService {


    public List<TenantPortalResponseV1> getTenantByParams(Integer customerId, String domain, String versaOrg);

    public void editTenant(Integer tenantId, EditTenantPortalRequestV1 editTenantPortalRequestV1);

    public TenantPortalResponseV1 getTenantById(Integer tenantId);

    public List<Integer> getTenantIdsByCustomerId(Integer customerId);

    List<TenantPortalResponseV1> getAccessibleResellerTenants();

    public List<TenantUserPortalResponseV1> getTenantUserByTenantId(Integer tenantId);

}
