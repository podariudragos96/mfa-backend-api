package net.colt.sdwan.portal.client.helper;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.client.feign.customer.CustomerFeign;
import net.colt.sdwan.portal.client.model.customerapi.CustomerResponseV1;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Objects;

@RequiredArgsConstructor
@Component
public class CustomerClientHelper {

    private final CustomerFeign customerFeign;

    /**
     * Get customer response from id by calling the customer-api.
     *
     * @param customerId requested identifier
     * @return the customer response or null if the customer-id doesn't exist.
     */
    public CustomerResponseV1 findById(Integer customerId) {
        CustomerResponseV1 result = null;
        ResponseEntity<CustomerResponseV1> response = customerFeign.getCustomerV1(customerId);
        if (Objects.nonNull(response) && HttpStatus.OK.equals(response.getStatusCode())) {
            result = response.getBody();
        }
        return result;
    }

}
