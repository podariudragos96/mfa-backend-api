package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.portal.client.model.customerapi.TenantResponseV1;
import net.colt.sdwan.portal.services.WhitelabelDomainCertificateService;
import net.colt.sdwan.portal.util.EmailSender;
import net.colt.sdwan.portal.util.FilePathBuilder;
import net.colt.sdwan.portal.validator.FileValidator;
import net.colt.sdwan.portal.validator.TenantValidator;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class WhitelabelDomainCertificateServiceImpl implements WhitelabelDomainCertificateService {

    private final TenantValidator tenantValidator;
    private final FileValidator fileValidator;
    private final FilePathBuilder filePathBuilder;
    private final EmailSender emailSender;
    private final SimpleDateFormat folderDateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");

    /**
     * Validates the domain and files.
     *
     * <p>
     * Copy the MultipartFile to local files and send a notification email to DevOps
     * for certificate set up.
     * </p>
     *
     * @param domain reseller domain name
     * @param files  certificate files
     */
    @Override
    public void uploadCertificates(String domain, List<MultipartFile> files) {
        TenantResponseV1 tenant = tenantValidator.validateTenantDomain(domain);
        fileValidator.validateCertificates(files);
        List<File> localFiles = storeAllFiles(domain, files);
        emailSender.sendNewSslCertificatesEmail(tenant, localFiles);
    }

    private List<File> storeAllFiles(String domain, List<MultipartFile> files) {
        String temporaryPath = folderDateFormat.format(new Date());

        return files.stream()
                .map(multipartFile -> storeFile(multipartFile,
                        filePathBuilder.buildFullPathFile(domain, temporaryPath, multipartFile.getOriginalFilename())))
                .toList();
    }

    private File storeFile(MultipartFile file, File localFile) {
        try {
            FileUtils.writeByteArrayToFile(localFile, file.getBytes());
        } catch (IOException e) {
            log.error("The file failed to upload", e);
            throw new SdwanInternalServerErrorException("The file failed to upload", e);
        }
        return localFile;
    }
}