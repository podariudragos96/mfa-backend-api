package net.colt.sdwan.portal.client.feign.sase;

import net.colt.sdwan.generated.controller.versa.sase.api.SecureAccessClientProfileApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "saseSecureAccessClientProfileFeign", url = "${sdwan.sase.api.baseurl}",
        configuration = SaseApiFeignConfiguration.class)
public interface SaseSecureAccessClientProfileFeign extends SecureAccessClientProfileApiApi {
}
