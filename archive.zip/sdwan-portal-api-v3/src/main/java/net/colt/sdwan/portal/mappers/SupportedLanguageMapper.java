package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.generated.model.service.SupportedLanguageV1;
import org.mapstruct.Mapper;

@Mapper
public interface SupportedLanguageMapper {

    SupportedLanguageV1 toSupportedLanguageV1(net.colt.sdwan.portal.model.SupportedLanguageV1 entity);
}
