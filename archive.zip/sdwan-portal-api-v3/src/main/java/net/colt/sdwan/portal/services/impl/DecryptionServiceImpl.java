package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.async.utils.ThreadUtils;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.AnalyticsApiClient;
import net.colt.sdwan.portal.client.ServiceApiClient;
import net.colt.sdwan.portal.client.feign.security.DecryptionApiFeign;
import net.colt.sdwan.portal.client.model.SSLDecryptionLogsResponse;
import net.colt.sdwan.portal.client.model.Status;
import net.colt.sdwan.portal.mappers.DecryptionMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.DecryptionService;
import net.colt.sdwan.portal.services.MetaService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.util.CompletableFutureUtil;
import net.colt.sdwan.portal.validator.DecryptionRulesValidator;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.security.api.generated.model.DecryptionRuleSetApiResponseV1;
import net.colt.sdwan.security.api.generated.model.DecryptionRulesHistoryApiResponseV1;
import net.colt.sdwan.security.api.generated.model.DecryptionRulesRequestApiV1;
import net.colt.sdwan.security.api.generated.model.LoggerType;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.constant.Constants.DEVICE_PREFIX;
import static net.colt.sdwan.portal.model.OnGoingActionV2.MODIFYING_DECRYPTION_RULES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;
import static net.colt.sdwan.portal.util.LocalDateTimeOperations.mapTimestamp;
import static org.apache.commons.lang3.ObjectUtils.isEmpty;

@Service
@Slf4j
@RequiredArgsConstructor
public class DecryptionServiceImpl implements DecryptionService {

    private final SitesService sitesService;
    private final ServiceApiClient serviceApiClient;
    private final SiteResponseValidator siteResponseValidator;
    private final AnalyticsApiClient analyticsApiClient;
    private final DecryptionRulesValidator decryptionRulesValidator;
    private final UrlFilteringServiceImpl urlFilteringService;
    private final DecryptionApiFeign decryptionApiFeign;
    private final ResponseEntityValidator responseEntityValidator;
    private final MetaService metaService;
    private final DecryptionMapper mapper;

    public List<SSLDecryptionLogsResponseV1> getSSLDecryptionLogsBySiteIdV1(final String siteId, LocalDateTime startDt,
                                                                            LocalDateTime endDt) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());
        siteResponseValidator.validateAdvancedFirewallEnabled(hasAdvancedFirewall);

        if (StringUtils.isBlank(siteResponse.getNetworkId()) || startDt.isAfter(endDt)) {
            throw new SdwanBadRequestException(String.format("Start date is after end date or versa org name is empty for siteId '%s'.", siteId));
        }

        final List<CompletableFuture<List<SSLDecryptionLogsResponse>>> responses = siteResponse.getDevices().stream()
                .map(device -> CompletableFuture.supplyAsync(ThreadUtils.withMdc(() ->
                        analyticsApiClient.getSslDecryptionLogsResponses(siteResponse, device.getResourceName(), startDt, endDt))))
                .toList();

        final List<SSLDecryptionLogsResponse> sslDecryptionLogsResponseCompletableFutures = CompletableFutureUtil.getCompletableFutureValues(responses)
                .stream().flatMap(List::stream)
                .toList();

        final List<SSLDecryptionLogsResponse> sslDecryptionLogsResponses = new ArrayList<>(sslDecryptionLogsResponseCompletableFutures);
        return sslDecryptionLogsResponses.stream()
                .map(logs -> {
                    SSLDecryptionLogsResponseV1 responseV1 = new ModelMapper().map(logs, SSLDecryptionLogsResponseV1.class);
                    responseV1.receiveTime(mapTimestamp(logs.getReceiveTime()));
                    return responseV1;
                })
                .toList();
    }

    @Override
    public DecryptionRuleSetResponseV1 getDecryptionRulesBySiteIdV2(String siteId) {
        final SiteResponseV1 siteResponse = isDecryptionActionAvailable(siteId);
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());

        siteResponseValidator.validateAdvancedFirewallEnabled(hasAdvancedFirewall);
        final ResponseEntity<DecryptionRuleSetApiResponseV1> decryptionRules = decryptionApiFeign.getDecryptionRulesV1(siteResponse.getNetworkId(), siteId);
        responseEntityValidator.checkResponseEntity(decryptionRules, "decryption rules");

        if (isEmpty(decryptionRules.getBody())) {
            throw new SdwanNotFoundException("No decryption rules were found for site %s.".formatted(siteId));
        }

        return mapper.from(decryptionRules.getBody());
    }

    @Override
    public DecryptionRuleSetResponseV1 getDecryptionRulesHistoryBySiteIdAndRulesSetIdV2(String siteId, String ruleSetId) {
        final SiteResponseV1 siteResponse = isDecryptionActionAvailable(siteId);
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());

        siteResponseValidator.validateAdvancedFirewallEnabled(hasAdvancedFirewall);
        final ResponseEntity<DecryptionRuleSetApiResponseV1> decryptionRules = decryptionApiFeign.getDecryptionRulesByIdV1(siteResponse.getNetworkId(), siteId, ruleSetId);
        responseEntityValidator.checkResponseEntity(decryptionRules, "decryption rules");

        if (isEmpty(decryptionRules.getBody())) {
            throw new SdwanNotFoundException("No decryption rules were found for site %s and rule set id %s ".formatted(siteId, ruleSetId));
        }

        return mapper.from(decryptionRules.getBody());
    }

    @Override
    public List<DecryptionRulesHistoryResponseV1> getDecryptionRulesHistoryBySiteIdV2(String siteId) {
        final SiteResponseV1 siteResponse = isDecryptionActionAvailable(siteId);
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());
        siteResponseValidator.validateAdvancedFirewallEnabled(hasAdvancedFirewall);
        final ResponseEntity<List<DecryptionRulesHistoryApiResponseV1>> decryptionRulesHistory = decryptionApiFeign.getDecryptionRulesHistoryV1(siteResponse.getNetworkId(), siteId);
        responseEntityValidator.checkResponseEntity(decryptionRulesHistory, "decryption rules history");
        return mapper.from(decryptionRulesHistory.getBody());
    }

    @Override
    public CorrelationIdResponseV1 updateDecryptionRulesBySiteIdV2(String siteId, DecryptionRulesRequestV1 request) {
        SiteResponseV1 siteResponse = isDecryptionActionAvailable(siteId);
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        siteResponseValidator.validateAdvancedFirewallEnabled(hasAdvancedFirewall);
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        validateSecurityProfiles(siteId, request.getRuleSet(), siteResponse);
        validatePredefinedUrlCategories(request.getRuleSet());

        try {
            sitesService.updateOngoingAction(siteId, MODIFYING_DECRYPTION_RULES);

            final Map<String, Boolean> deviceMap = siteResponse.getDevices()
                    .stream()
                    .collect(Collectors.toMap(
                            device -> DEVICE_PREFIX.concat(device.getResourceName()),
                            device -> siteResponse.getDevices().size() == 1 || device.getIsPrimary()));

            final DecryptionRulesRequestApiV1 requestMapped = mapper.from(request.getRuleSet().get(0))
                    .initiatedUserId(Objects.requireNonNull(AuthUserHelper.getAuthUser()).getUsername())
                    .zonesTemplateKey(siteResponse.getZonesTplKey())
                    .loggerType(LoggerType.fromValue(siteResponse.getSiteFeatures().getSecurity().getLogging().getLoggingType()));

            requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

            decryptionApiFeign.updateDecryptionRulesV1(siteResponse.getNetworkId(), siteId, deviceMap, requestMapped);

            return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
        } catch (Exception ex) {
            log.error("Failed to update Decryption Rules", ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }
    }

    /**
     * This will validate if the 'Predefined URL Categories' sent on the request exist on the database through the Metadata API
     * The 'User Defined URL Categories' are validated on the Security API because they are stored on the MongoDB
     *
     * @param decryptionRuleSetRequest contains all the decryption rules sent on the request
     */
    private void validatePredefinedUrlCategories(List<DecryptionRuleSetRequestV1> decryptionRuleSetRequest) {

        final Set<String> requestPredefinedUrlCategories = decryptionRuleSetRequest.stream()
                .map(DecryptionRuleSetRequestV1::getRules)
                .flatMap(List::stream)
                .map(DecryptionRuleRequestV1::getUrlCategory)
                .map(DecryptionUrlCategoryV1::getPredefined)
                .flatMap(Set::stream)
                .collect(Collectors.toSet());

        if (CollectionUtils.isNotEmpty(requestPredefinedUrlCategories)) {
            final List<String> existingPredefinedUrlCategories = metaService.getAllURLCategories(new MetadataCriteria(), 0, Integer.MAX_VALUE).getUrlPredefinedCategories().stream()
                    .map(UrlCategoryDetailsV1::getName)
                    .toList();

            requestPredefinedUrlCategories.forEach(urlCategory -> {
                if (!existingPredefinedUrlCategories.contains(urlCategory)) {
                    throw new SdwanBadRequestException("The Predefined URL Category '%s' does not exist on the database."
                            .formatted(urlCategory));
                }
            });
        }
    }

    private void validateSecurityProfiles(String siteId,
                                          List<DecryptionRuleSetRequestV1> decryptionRuleSetRequest,
                                          SiteResponseV1 siteResponse) {
        if (hasUrlFilteringProfiles(decryptionRuleSetRequest)) {
            final URLFilteringProfileResponseV1 urlFilteringProfiles = urlFilteringService.getProfilesBySiteId(siteId);
            decryptionRulesValidator.validateSecurityProfilesInDecryptionRules(
                    decryptionRuleSetRequest,
                    siteResponse,
                    urlFilteringProfiles.getUrlFilteringProfiles());
        }
    }

    private boolean hasUrlFilteringProfiles(List<DecryptionRuleSetRequestV1> decryptionRuleSetRequest) {
        for (DecryptionRuleSetRequestV1 decryptionRuleSetRequestV1 : decryptionRuleSetRequest) {
            final boolean hasUrlFilteringProfiles = decryptionRuleSetRequestV1.getRules().stream()
                    .anyMatch(decryptionRuleRequestV1 ->
                            StringUtils.isNotEmpty(decryptionRuleRequestV1.getUrlFilteringProfileOverride()));
            if (hasUrlFilteringProfiles) {
                log.debug("There is some Url Filtering Profile connected to any Decryption rule");
                return true;
            }
        }
        log.debug("There is no Url Filtering Profile connected to any Decryption Rule");
        return false;
    }

    private SiteResponseV1 isDecryptionActionAvailable(String siteId) {
        // check user has access to site
        SiteResponseV1 siteResponse = serviceApiClient.getSiteDetailsById(siteId);
        siteResponseValidator.hasValidSiteAndTenantValues(siteResponse);

        // Check certificate date
        List<DeviceResponseV1> devices = siteResponse.getDevices();
        boolean isCertificateAvailable = devices.stream()
                .filter(device -> device.getStatus().name().equalsIgnoreCase(Status.ACTIVE.name()))
                .anyMatch(d -> (d.getIsSelfSignedCertificateGenerated() || d.getIsCustomerManagedCertificateGenerated()));
        if (!isCertificateAvailable) {
            throw new AccessDeniedException(String.format("Decryption action not available because " +
                    "some certificates end date are not set for the device(s) of this site id '%s'.", siteId));
        }

        return siteResponse;
    }
}
