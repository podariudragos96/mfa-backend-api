package net.colt.sdwan.portal.client.model;

public enum FwAction {
    deny, allow, reject, apply_security_profile
}
