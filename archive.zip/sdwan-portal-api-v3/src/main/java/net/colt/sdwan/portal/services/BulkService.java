package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.BulkCopyRequestRequestV2;
import net.colt.sdwan.portal.model.BulkCopyRequestResponseV2;
import net.colt.sdwan.portal.model.BulkCopyRequestsResponseV1;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;

import java.util.List;

public interface BulkService {
    CorrelationIdResponseV1 createBulkCopyRequest(BulkCopyRequestRequestV2 bulkCopyRequestRequest, String networkId);

    List<BulkCopyRequestResponseV2> getBulkCopyRequestsById(String requestId, String networkId);

    List<BulkCopyRequestsResponseV1> getBulkCopyRequests(String networkId);
}
