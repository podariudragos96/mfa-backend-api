package net.colt.sdwan.portal.client.feign.sitesettings;

import net.colt.sdwan.sitesettings.api.generated.api.BreakoutApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "breakoutApiClient",
        url = "${sdwan.site.settings.api.baseurl}",
        configuration = SiteSettingsApiFeignConfiguration.class)
public interface BreakoutApiFeign extends BreakoutApiApi {
}
