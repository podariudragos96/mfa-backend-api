package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.common.logging.constant.LoggingLabels;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.feign.sitesettings.DnsApiFeign;
import net.colt.sdwan.portal.constant.DnsProxyConstants;
import net.colt.sdwan.portal.mappers.DnsProxyMapper;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.DNSProxyRequestV1;
import net.colt.sdwan.portal.model.DNSProxyResponseV1;
import net.colt.sdwan.portal.model.DnsProxyHistoryResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.DnsProxyService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.sitesettings.api.generated.model.DNSProxyRequestApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.DNSProxyResponseApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.DnsProxyHistoryResponseApiV1;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.portal.model.OnGoingActionV2.MODIFYING_DNS_PROXY_RULES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;
import static net.colt.sdwan.portal.model.SiteTypeV1.BRANCH;

@Service
@Slf4j
@RequiredArgsConstructor
public class DnsProxyServiceImpl implements DnsProxyService {

    private final SitesService sitesService;
    private final DnsApiFeign dnsApiFeign;
    private final DnsProxyMapper dnsProxyMapper;
    private final ResponseEntityValidator responseEntityValidator;

    private final SiteResponseValidator siteResponseValidator;

    @Override
    public DNSProxyResponseV1 getDNSProxiesV1(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (!BRANCH.toString().equalsIgnoreCase(siteResponse.getSiteType().getValue())) {
            throw new SdwanBadRequestException(DnsProxyConstants.DNS_ONLY_AVAILABLE_ON_BRANCH_SITES);
        }

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final ResponseEntity<DNSProxyResponseApiV1> dnsProxyResponseEntity =
                dnsApiFeign.getDnsProxiesV1(siteResponse.getId().intValue(), siteResponse.getNetworkId());
        responseEntityValidator.checkResponseEntity(dnsProxyResponseEntity, DnsProxyConstants.DNS_FEATURE_NAME);

        return dnsProxyMapper.from(dnsProxyResponseEntity.getBody());
    }

    @Override
    public CorrelationIdResponseV1 updateDNSProxiesV1(String siteId, DNSProxyRequestV1 dnsProxyRequestV1) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);

        if (!BRANCH.toString().equalsIgnoreCase(siteResponse.getSiteType().getValue())) {
            throw new SdwanBadRequestException(DnsProxyConstants.DNS_ONLY_AVAILABLE_ON_BRANCH_SITES);
        }

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        DNSProxyRequestApiV1 dnsProxyRequestApiV1 = dnsProxyMapper.from(dnsProxyRequestV1);

        try {
            sitesService.updateOngoingAction(siteId, MODIFYING_DNS_PROXY_RULES);
            UserAuth userAuth = AuthUserHelper.getAuthUser();
            dnsProxyRequestApiV1.setUpdatedBy(userAuth.getUsername());
            dnsProxyRequestApiV1.setUpdatedDt(LocalDateTime.now());
            dnsProxyRequestApiV1.setDescription(dnsProxyRequestV1.getDescription());

            final ResponseEntity<Void> dnsProxyResponseEntity = dnsApiFeign.updateDnsProxiesV1(Integer.valueOf(siteId),
                    siteResponse.getNetworkId(), AuthUserHelper.getAuthUser().getUsername(),
                    sitesService.getDeviceNamesFromSiteResponse(siteResponse), dnsProxyRequestApiV1);
            responseEntityValidator.checkResponseEntity(dnsProxyResponseEntity, DnsProxyConstants.DNS_FEATURE_NAME);
        } catch (Exception ex) {
            log.error("Failed to update " + DnsProxyConstants.DNS_FEATURE_NAME + " for site with id " + siteId, ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }

        return new CorrelationIdResponseV1().correlationId(MDC.get(LoggingLabels.CORRELATION_ID));
    }


    @Override
    public List<DnsProxyHistoryResponseV1> getDnsProxiesHistoryV1(String siteId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        Objects.requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        ResponseEntity<List<DnsProxyHistoryResponseApiV1>> responseEntity = dnsApiFeign.getDnsProxiesHistoryV1(
                siteResponse.getId().toString(), siteResponse.getNetworkId());
        responseEntityValidator.checkResponseEntity(responseEntity, DnsProxyConstants.DNS_FEATURE_NAME);
        if (responseEntity.hasBody()) {
            return dnsProxyMapper.from(responseEntity.getBody());
        }
        return new ArrayList<>();
    }

    @Override
    public DNSProxyResponseV1 getDnsProxyResponseHistoryByIdV1(String siteId, String ruleSetId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        Objects.requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        ResponseEntity<DNSProxyResponseApiV1> responseEntity = dnsApiFeign.getDnsProxiesHistoryByIdV1(siteResponse.getId().toString(), siteResponse.getNetworkId(), ruleSetId);
        responseEntityValidator.checkResponseEntity(responseEntity, DnsProxyConstants.DNS_FEATURE_NAME);
        if (responseEntity.hasBody()) {
            return dnsProxyMapper.from(responseEntity.getBody());
        }
        return new DNSProxyResponseV1();
    }
}