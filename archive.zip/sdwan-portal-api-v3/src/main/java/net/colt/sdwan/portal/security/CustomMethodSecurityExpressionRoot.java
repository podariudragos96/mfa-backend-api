package net.colt.sdwan.portal.security;

import net.colt.sdwan.portal.security.models.UserAuth;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.expression.SecurityExpressionRoot;
import org.springframework.security.access.expression.method.MethodSecurityExpressionOperations;
import org.springframework.security.core.Authentication;

import java.util.Arrays;
import java.util.Collections;

public class CustomMethodSecurityExpressionRoot extends SecurityExpressionRoot implements MethodSecurityExpressionOperations {

    private Object filterObject;
    private Object returnObject;
    private Object target;

    CustomMethodSecurityExpressionRoot(Authentication authentication) {
        super(authentication);
    }

    @Override
    public Object getFilterObject() {
        return filterObject;
    }

    @Override
    public void setFilterObject(Object filterObject) {
        this.filterObject = filterObject;
    }

    @Override
    public Object getReturnObject() {
        return returnObject;
    }

    @Override
    public void setReturnObject(Object returnObject) {
        this.returnObject = returnObject;
    }

    @Override
    public Object getThis() {
        return target;
    }

    void setThis(Object target) {
        this.target = target;
    }

    /**
     * Custom 'hasFeatureFlag()' expression
     */
    public boolean hasFeatureFlag(String... featureFlagName) {
        UserAuth userAuth = AuthUserHelper.getAuthUser();

        if (userAuth != null && userAuth.getFeatures() != null && !userAuth.getFeatures().isEmpty() && !Collections.disjoint(userAuth.getFeatures(), Arrays.asList(featureFlagName))) {
            return true;
        } else {
            throw new AccessDeniedException("You do not have access to this feature. Please contact your Account Executive.");
        }
    }
}
