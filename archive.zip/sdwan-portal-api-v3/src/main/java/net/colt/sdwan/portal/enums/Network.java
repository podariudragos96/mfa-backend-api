package net.colt.sdwan.portal.enums;

public enum Network {
    INTERNET,
    SDWAN,
    CLOUD,
    EAST_WEST,
    NONE
}
