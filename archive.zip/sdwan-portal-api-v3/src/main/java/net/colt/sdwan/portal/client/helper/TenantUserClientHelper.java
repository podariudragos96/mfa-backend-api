package net.colt.sdwan.portal.client.helper;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.client.feign.customer.TenantUserFeign;
import net.colt.sdwan.portal.client.model.customerapi.CreateTenantUserRequestV1;
import net.colt.sdwan.portal.client.model.customerapi.CreateTenantUserResponseV1;
import net.colt.sdwan.portal.client.model.customerapi.EditTenantUserRequestV1;
import net.colt.sdwan.portal.client.model.customerapi.TenantUserResponseV1;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Objects;

@RequiredArgsConstructor
@Component
public class TenantUserClientHelper {

    private final TenantUserFeign tenantUserFeign;

    public TenantUserResponseV1 getTenantUserById(Integer tenantUserId) {
        final ResponseEntity<TenantUserResponseV1> response = tenantUserFeign.getTenantUserByIdV1(tenantUserId);
        TenantUserResponseV1 result = null;
        if (Objects.nonNull(response) && HttpStatus.OK.equals(response.getStatusCode())) {
            result = response.getBody();
        }
        return result;
    }

    public CreateTenantUserResponseV1 createTenantUser(Integer tenantId, CreateTenantUserRequestV1 createTenantUserRequestV1) {
        final ResponseEntity<CreateTenantUserResponseV1> response = tenantUserFeign.addTenantUserV1(tenantId, createTenantUserRequestV1);
        CreateTenantUserResponseV1 body = null;

        if (Objects.nonNull(response)) {
            body = response.getBody();
        }
        return body;
    }

    public void editTenantUser(Integer tenantUserId, EditTenantUserRequestV1 editTenantUserRequestV1) {
        tenantUserFeign.editTenantUserV1(tenantUserId, editTenantUserRequestV1);
    }

    public void deleteTenantUserByIdV1(Integer tenantUserId) {
        tenantUserFeign.deleteTenantUserByIdV1(tenantUserId);
    }

}
