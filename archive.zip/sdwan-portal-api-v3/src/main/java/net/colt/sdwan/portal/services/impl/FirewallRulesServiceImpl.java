package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.common.exceptions.exception.SdwanUnprocessableEntityException;
import net.colt.sdwan.generated.model.service.CgwResponseV1;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.InterfaceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.generated.model.service.SiteTypeV1;
import net.colt.sdwan.portal.client.AnalyticsApiClient;
import net.colt.sdwan.portal.client.model.FWRuleLogEvents;
import net.colt.sdwan.portal.client.model.FirewallRules;
import net.colt.sdwan.portal.constant.ErrorMessageConstants;
import net.colt.sdwan.portal.mappers.FirewallModelMapper;
import net.colt.sdwan.portal.mappers.FirewallRuleLogsResponseMappers;
import net.colt.sdwan.portal.mappers.UpdateFirewallRulesRequestMapper;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.FirewallRuleHistoryResponseV1;
import net.colt.sdwan.portal.model.FirewallRuleLogsResponseV1;
import net.colt.sdwan.portal.model.FirewallRuleSetResponseV2;
import net.colt.sdwan.portal.model.FirewallRulesRequestV2;
import net.colt.sdwan.portal.services.DeviceService;
import net.colt.sdwan.portal.services.FirewallRulesService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.InterfaceResponseValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.portal.validator.UpdateRulesValidator;
import net.colt.sdwan.security.api.generated.model.LoggerType;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.constant.SecurityConstants.FAILED_TO_UPDATED_FIREWALL_RULES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.MODIFYING_FIREWALL_RULES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;
import static org.apache.commons.collections4.CollectionUtils.isNotEmpty;

@Slf4j
@Service
@RequiredArgsConstructor
public class FirewallRulesServiceImpl implements FirewallRulesService {

    private final SitesService sitesService;
    private final DeviceService deviceService;
    private final SiteResponseValidator siteResponseValidator;
    private final InterfaceResponseValidator interfaceResponseValidator;
    private final UpdateRulesValidator updateRulesValidator;
    private final AnalyticsApiClient analyticsApiClient;
    private final FirewallRuleLogsResponseMappers firewallRuleLogsResponseMappers;
    private final UpdateFirewallRulesRequestMapper updateFirewallRulesRequestMapper;
    private final SecurityFirewallServiceImpl securityFirewallService;
    private final FirewallModelMapper firewallModelMapper;

    @Override
    public FirewallRuleSetResponseV2 getFirewallRulesBySiteIdV3(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        siteResponseValidator.hasValidSiteAndTenantValues(siteResponse);

        net.colt.sdwan.security.api.generated.model.FirewallRuleSetResponseV2
                firewallRules = securityFirewallService.getFirewallRulesBySiteIdV2(siteId);

        return firewallModelMapper.from(firewallRules);
    }

    @Override
    public List<FirewallRuleHistoryResponseV1> getFirewallRulesHistoryBySiteIdV1(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        siteResponseValidator.hasValidSiteAndTenantValues(siteResponse);

        List<net.colt.sdwan.security.api.generated.model.FirewallRuleSetResponseV1> firewallRulesHistory =
                securityFirewallService.getFirewallRulesHistoryV1(siteId);

        return firewallRulesHistory.stream()
                .map(firewallModelMapper::fromSecurityApi)
                .toList();
    }

    @Override
    public FirewallRuleSetResponseV2 getFirewallRulesHistoryBySiteIdAndRuleSetIdV2(String siteId, String ruleSetId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        siteResponseValidator.hasValidSiteAndTenantValues(siteResponse);

        net.colt.sdwan.security.api.generated.model.FirewallRuleSetResponseV2 firewallRules =
                securityFirewallService.getFirewallRulesHistoryByIdV2(siteId, ruleSetId);

        return firewallModelMapper.from(firewallRules);
    }

    /**
     * Retrieve the firewall rules logs based on the provided site id, rule name and
     * time interval. Check whether the siteid is mapped to the user's customers.
     * Try to retrieve the site by site id, check whether the siteid is mapped to
     * the user's customers. Map the returned values to the needed response.
     *
     * @param siteId
     * @return FirewallRulesResponse mapped from the received values returned by
     * policy api
     */
    @Override
    public List<FirewallRuleLogsResponseV1> getFirewallRulesLogsBySiteIdAndRuleName(String siteId,
                                                                                    final String ruleName,
                                                                                    final LocalDateTime startDate,
                                                                                    final LocalDateTime endDate) {
        if (startDate.isAfter(endDate)) {
            throw new SdwanUnprocessableEntityException("Bad value for date");
        }
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        if (siteResponseValidator.hasValidTenantSiteValues(siteResponse)) {
            List<DeviceResponseV1> deviceResponses = deviceService.getApiDevicesFromSiteToDeviceList(siteId);
            List<FWRuleLogEvents> fwRuleLogEvents = analyticsApiClient.getFirewallRulesLogs(siteResponse,
                    deviceResponses, ruleName, startDate, endDate);
            return firewallRuleLogsResponseMappers.mapFrom(fwRuleLogEvents);
        }
        throw new SdwanNotFoundException(ErrorMessageConstants.CUSTOMER_OR_SITE_OR_DEVICE_NOT_FOUND_MESSAGE_TEMPLATE.formatted(siteId));
    }

    @Override
    public CorrelationIdResponseV1 updateFirewallRulesBySiteIdV3(final String siteId,
                                                                 final FirewallRulesRequestV2 firewallRulesRequest) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        siteResponseValidator.hasValidSiteAndTenantValues(siteResponse);
        InterfaceResponseV1 interfaceResponse = interfaceResponseValidator.getCpsPeeringInterface(siteResponse);
        FirewallRules firewallRules = updateFirewallRulesRequestMapper.mapFromFirewallRulesRequestV1(firewallRulesRequest,
                siteResponse, interfaceResponse);
        updateRulesValidator.validateUpdateFirewallRules(Collections.singletonList(firewallRules), siteResponse);

        try {

            sitesService.updateOngoingAction(siteId, MODIFYING_FIREWALL_RULES);

            List<String> deviceNames = getDeviceNamesFromSiteResponse(siteResponse);

            final net.colt.sdwan.security.api.generated.model.FirewallRulesRequestV2 request =
                    firewallModelMapper.from(firewallRulesRequest);
            // set zones template key
            request.setZonesTemplateKey(siteResponse.getZonesTplKey());

            //set primary device Name
            request.setPrimaryDeviceName(getPrimaryDeviceName(siteResponse.getDevices()));

            // set logger type
            request.setLoggerType(LoggerType.fromValue(siteResponse.getSiteFeatures().getSecurity().getLogging().getLoggingType()));

            // set Csp Peering Interface Name for CGW
            if (siteResponse.getSiteType().equals(SiteTypeV1.CLOUD_GATEWAY)) {
                final String cpsPeeringInterfaceName = this.getCpsPeeringInterfaceName(siteResponse.getDevices(), siteResponse.getCgw(), interfaceResponse);
                request.getRuleSet().get(0).setCspPeeringInterface(cpsPeeringInterfaceName);
            }

            securityFirewallService.updateFirewallRulesByNetworkAndSiteIdV2(
                    siteId,
                    deviceNames,
                    siteResponse.getSiteType().getValue(),
                    request);

            return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));

        } catch (Exception ex) {
            log.error(FAILED_TO_UPDATED_FIREWALL_RULES, ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }

    }

    private List<String> getDeviceNamesFromSiteResponse(SiteResponseV1 siteResponse) {
        return isNotEmpty(siteResponse.getDevices()) ?
                siteResponse.getDevices().stream()
                        .map(DeviceResponseV1::getResourceName)
                        .toList() : Collections.emptyList();
    }

    private String getPrimaryDeviceName(final List<DeviceResponseV1> deviceResponseSet) {
        String name = null;
        if (deviceResponseSet != null && !deviceResponseSet.isEmpty()) {
            if (deviceResponseSet.size() == 1) {
                name = deviceResponseSet.iterator().next().getResourceName();
            } else {
                Optional<DeviceResponseV1> deviceResponse = deviceResponseSet.stream()
                        .filter(device -> Objects.nonNull(device.getIsPrimary()) && device.getIsPrimary()).findFirst();
                if (deviceResponse.isPresent()) {
                    name = deviceResponse.get().getResourceName();
                }
            }
        }
        return name;
    }

    private String getCpsPeeringInterfaceName(List<DeviceResponseV1> deviceSet, List<CgwResponseV1> cgwResponseV1s, InterfaceResponseV1 interfaceResponse) {
        if (interfaceResponse != null) {
            return interfaceResponse.getZone();
        }

        return Optional.ofNullable(deviceSet)
                .filter(CollectionUtils::isNotEmpty)
                .map(devices -> devices.get(0))
                .flatMap(device ->
                        Optional.ofNullable(cgwResponseV1s)
                                .flatMap(cgws -> cgws.stream()
                                        .filter(cgw -> cgw.getCgwName().equals(device.getResourceName()))
                                        .map(CgwResponseV1::getCspPeeringInterface)
                                        .findFirst())
                )
                .orElse(null);
    }

}
