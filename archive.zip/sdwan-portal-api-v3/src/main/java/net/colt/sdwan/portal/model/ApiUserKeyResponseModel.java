package net.colt.sdwan.portal.model;

import jakarta.validation.Valid;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApiUserKeyResponseModel {

    @Valid
    private List<@Valid ApiKey> apiKeys;

    private String networkId;

    private String userAgent;

    private Integer tenantId;
}
