package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.BrandingPortalResponseV1;

public interface BrandingService {

    BrandingPortalResponseV1 getBranding(String xColtHost);

}
