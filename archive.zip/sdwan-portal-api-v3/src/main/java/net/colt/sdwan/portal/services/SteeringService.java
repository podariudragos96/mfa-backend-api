package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SteeringHistoryResponseV1;
import net.colt.sdwan.portal.model.SteeringPolicyRequestV1;
import net.colt.sdwan.portal.model.SteeringPolicyResponseV1;

import java.util.List;

public interface SteeringService {

    SteeringPolicyResponseV1 getSteeringPoliciesV1(String siteId);

    List<SteeringHistoryResponseV1> getSteeringPoliciesHistoryV1(String siteId);

    SteeringPolicyResponseV1 getSteeringPoliciesHistoryByIdV1(String siteId, String ruleSetId);

    CorrelationIdResponseV1 updateSteeringPoliciesV1(String siteId, SteeringPolicyRequestV1 internetPolicyRequestV1);
}
