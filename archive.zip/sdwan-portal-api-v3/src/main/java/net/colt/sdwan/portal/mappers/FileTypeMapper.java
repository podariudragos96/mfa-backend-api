package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.metadata.api.generated.model.FileTypeV1;
import net.colt.sdwan.metadata.api.generated.model.FileTypesResponseV1;
import net.colt.sdwan.portal.model.FileTypeDetailsV1;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

import static org.apache.commons.collections4.CollectionUtils.isNotEmpty;

@Component
public class FileTypeMapper {

    public List<FileTypeDetailsV1> mapToResponse(final FileTypesResponseV1 fileTypesResponseV1) {
        List<FileTypeDetailsV1> fileTypeDetailsV1s = new ArrayList<>();
        if (isNotEmpty(fileTypesResponseV1.getFileTypes())) {
            fileTypeDetailsV1s = fileTypesResponseV1.getFileTypes().stream()
                    .map(this::toFileType)
                    .toList();
        }
        return fileTypeDetailsV1s;
    }

    private FileTypeDetailsV1 toFileType(FileTypeV1 fileTypeV1) {
        return new FileTypeDetailsV1()
                .id(fileTypeV1.getId().toString())
                .name(fileTypeV1.getName())
                .description(fileTypeV1.getDescription());
    }

}
