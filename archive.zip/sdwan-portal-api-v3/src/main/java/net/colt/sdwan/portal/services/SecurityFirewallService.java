package net.colt.sdwan.portal.services;

import net.colt.sdwan.security.api.generated.model.FirewallRuleSetResponseV1;
import net.colt.sdwan.security.api.generated.model.FirewallRuleSetResponseV2;
import net.colt.sdwan.security.api.generated.model.FirewallRulesRequestV2;

import java.util.List;

public interface SecurityFirewallService {

    List<FirewallRuleSetResponseV1> getFirewallRulesHistoryV1(final String siteId);

    FirewallRuleSetResponseV2 getFirewallRulesBySiteIdV2(final String siteId);

    FirewallRuleSetResponseV2 getFirewallRulesHistoryByIdV2(final String siteId, final String ruleSetId);

    void updateFirewallRulesByNetworkAndSiteIdV2(String siteId, List<String> deviceNames, String siteType, FirewallRulesRequestV2 firewallRulesRequestV2);
}
