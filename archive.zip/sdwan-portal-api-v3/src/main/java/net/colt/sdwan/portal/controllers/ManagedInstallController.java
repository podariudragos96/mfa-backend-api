package net.colt.sdwan.portal.controllers;

import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.ManagedInstallApiApi;
import net.colt.sdwan.portal.model.ManagedInstallPatchRequestV1;
import net.colt.sdwan.portal.model.ManagedInstallResponseV1;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.ManagedInstallService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequiredArgsConstructor
@RestController
public class ManagedInstallController implements ManagedInstallApiApi {

    private final ManagedInstallService managedInstallService;

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANInstallManagerRole')")
    public ResponseEntity<List<ManagedInstallResponseV1>> getAllManagedInstallOrdersV1() {

        return ResponseEntity.ok(managedInstallService.getAllManagedInstallOrders());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANInstallManagerRole')")
    public ResponseEntity<ManagedInstallResponseV1> getManagedInstallOrderByIdV1(String id) {
        return ResponseEntity.ok(managedInstallService.getManagedInstallOrderById(id));
    }


    @Override
    @SDWanAsyncMethod("/v1/managed_install/{id}")
    @PreAuthorize("hasAnyAuthority('SD-WANInstallManagerRole')")
    public ResponseEntity<ManagedInstallResponseV1> patchManagedInstallOrdersV1(@ApiParam(value = "", required = true) String id, ManagedInstallPatchRequestV1 managedInstallPatchRequestV1) {
        return ResponseEntity.ok(managedInstallService.patchManagedInstallOrders(id, managedInstallPatchRequestV1));
    }
}
