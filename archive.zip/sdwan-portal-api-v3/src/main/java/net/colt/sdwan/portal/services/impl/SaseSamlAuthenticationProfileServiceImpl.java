package net.colt.sdwan.portal.services.impl;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.utils.SdwanExceptionUtils;
import net.colt.sdwan.generated.model.versa.sase.api.SamlAuthenticationProfileRequestApiV1;
import net.colt.sdwan.generated.model.versa.sase.api.SamlAuthenticationProfilesResponseApiV1;
import net.colt.sdwan.portal.client.feign.sase.SaseAuthenticationProfileFeign;
import net.colt.sdwan.portal.enums.SaseOperation;
import net.colt.sdwan.portal.mappers.SaseAuthenticationProfileMapper;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SaseSamlAuthenticationProfileRequestV1;
import net.colt.sdwan.portal.model.SaseSamlAuthenticationProfilesResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.SaseSamlAuthenticationProfileService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;

@Service
@RequiredArgsConstructor
@Slf4j
public class SaseSamlAuthenticationProfileServiceImpl implements SaseSamlAuthenticationProfileService {

    private final SaseAuthenticationProfileFeign feign;
    private final SaseAuthenticationProfileMapper mapper;
    private final ResponseEntityValidator responseEntityValidator;

    @Override
    public SaseSamlAuthenticationProfilesResponseV1 getSamlAuthenticationProfilesV1(String tenantUuid) {
        log.info("Getting sase authentication profiles details via sase api for tenantUuid={}", tenantUuid);

        final ResponseEntity<SamlAuthenticationProfilesResponseApiV1> response = feign.getSamlAuthenticationProfilesV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.AUTHENTICATION_PROFILE_GET.getName());

        log.info("Get sase authentication profile request completed successfully for tenantUuid={}.", tenantUuid);
        return mapper.from(response.getBody());
    }

    @Override
    public CorrelationIdResponseV1 updateSamlAuthenticationProfileV1(
            String tenantUuid,
            String samlUuid,
            SaseSamlAuthenticationProfileRequestV1 saseSamlAuthenticationProfileRequestV1) {
        log.info("Updating sase authentication profile details for tenantUuid={} and samlUuid={}", tenantUuid, samlUuid);

        try {
            UserAuth userAuth = requireNonNull(AuthUserHelper.getAuthUser());
            SamlAuthenticationProfileRequestApiV1 apiRequestV1 = mapper.from(saseSamlAuthenticationProfileRequestV1);
            feign.updateSamlAuthenticationProfileV1(userAuth.getUsername(), tenantUuid, samlUuid, apiRequestV1);
            log.info("Update sase authentication profile request completed successfully for initiatedUserId={}, tenantUuid={} and samlUuid={}."
                    , userAuth.getUsername(), tenantUuid, samlUuid);

        } catch (FeignException fe) {
            final String errorMsg = String.format("Failed to update Authentication profile for tenantUuid=%s and samlUuid=%s", tenantUuid, samlUuid);
            throw SdwanExceptionUtils.buildSdwanException(fe.status(), errorMsg);
        }

        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

}
