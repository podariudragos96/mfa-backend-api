package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.model.AddressGroupObjectCriteria;
import net.colt.sdwan.portal.model.AddressGroupsRequestV1;
import net.colt.sdwan.portal.model.AddressGroupsResponseV1;
import net.colt.sdwan.sitesettings.api.generated.model.AddressGroupObjectCriteriaApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.AddressGroupsRequestApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.AddressGroupsResponseApiV1;
import org.mapstruct.Mapper;

@Mapper
public interface AddressGroupMapper extends CommonObjectMapper{

    AddressGroupObjectCriteriaApiV1 from(AddressGroupObjectCriteria criteria);

    AddressGroupsResponseV1 from(AddressGroupsResponseApiV1 response);

    AddressGroupsRequestApiV1 from(AddressGroupsRequestV1 request);
}
