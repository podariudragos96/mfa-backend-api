package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.SaseSiteToSiteTunnelsResponseV1;

public interface SaseSiteToSiteTunnelService {

    SaseSiteToSiteTunnelsResponseV1 getSiteToSiteTunnelsV1(String tenantUuid);

}
