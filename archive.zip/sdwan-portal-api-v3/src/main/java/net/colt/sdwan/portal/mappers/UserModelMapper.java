package net.colt.sdwan.portal.mappers;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import net.colt.sdwan.portal.client.model.customerapi.UserResponseV3;
import net.colt.sdwan.portal.security.models.Role;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.session.api.generated.model.UserInfo;
import org.apache.commons.collections4.CollectionUtils;
import org.modelmapper.ModelMapper;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class UserModelMapper {
    private static final ModelMapper modelMapper = new ModelMapper();

    public static UserAuth mapAuthUserFromUserResponseV3(UserResponseV3 userResponse) {
        UserAuth userAuth = null;
        if (Objects.nonNull(userResponse)) {
            userAuth = modelMapper.map(userResponse, UserAuth.class);
            userAuth.setRoles(mapRoles(userResponse.getRoles()));
        }
        return userAuth;
    }

    public static UserAuth mapAuthUserFromSessionResponseV1(UserInfo userInfo) {
        UserAuth userAuth = null;
        if (Objects.nonNull(userInfo)) {
            userAuth = modelMapper.map(userInfo, UserAuth.class);
            userAuth.setRoles(mapRoles(userInfo.getRoles()));
        }
        return userAuth;
    }

    public static UserAuth mapAuthUserFromApiUserResponseV1(String userName,List<String> roles,List<Integer> tenantIds) {
        if (Objects.nonNull(userName) && CollectionUtils.isNotEmpty(roles)) {
            return UserAuth.builder().roles(mapRoles(roles)).username(userName).accessibleTenantIds(tenantIds).build();
       }
        return null;
    }

    public static UserInfo mapSessionResponseV1ToUserAuth(final UserAuth user) {
        UserInfo userInfo = modelMapper.map(user, UserInfo.class);
        userInfo.setRoles(mapRolesToList(user.getRoles()));
        return userInfo;
    }

    public static List<Role> mapRoles(final List<String> roles) {
        return roles.stream()
                .map(Role::new)
                .toList();
    }

    public static String mapRolesToCSV(final List<Role> roles) {
        return roles.stream()
                .map(Role::getName)
                .collect(Collectors.joining(","));
    }

    public static List<String> mapRolesToList(List<Role> roles) {
        return roles.stream()
                .map(Role::getName)
                .toList();
    }
}
