package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class URLFilterLogsResponse {
    @JsonProperty("receive_time")
    private String receiveTime;

    @JsonProperty("device_name")
    private String deviceName;

    @JsonProperty("vpn")
    private String vpn;

    @JsonProperty("url")
    private URLFilterLogsURLResponse url;

    @JsonProperty("action")
    private UrlFilterLogsAction action;

    @JsonProperty("action_message")
    private String actionType;

    @JsonProperty("source")
    private URLFilterLogsOriginResponse source;

    @JsonProperty("destination")
    private URLFilterLogsOriginResponse destination;

}
