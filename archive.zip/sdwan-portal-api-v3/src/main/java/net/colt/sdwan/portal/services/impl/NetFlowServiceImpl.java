package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.netflow.ipfix.api.generated.model.NetFlowHistoryResponseApiV1;
import net.colt.sdwan.netflow.ipfix.api.generated.model.NetflowRequestApiV1;
import net.colt.sdwan.netflow.ipfix.api.generated.model.NetflowResponseApiV1;
import net.colt.sdwan.portal.client.feign.netflow.NetflowApiFeign;
import net.colt.sdwan.portal.mappers.NetFlowResponseMapper;
import net.colt.sdwan.portal.mappers.NetflowCollectorRequestMapper;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.NetFlowHistoryResponseV1;
import net.colt.sdwan.portal.model.NetFlowRequestV1;
import net.colt.sdwan.portal.model.NetFlowResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.DeviceService;
import net.colt.sdwan.portal.services.NetFlowService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import org.apache.commons.collections4.CollectionUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.constant.SecurityConstants.NETFLOW_IP_FIX_PROFILES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.MODIFYING_NETFLOW_RULES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;

@Service
@Slf4j
@RequiredArgsConstructor
public class NetFlowServiceImpl implements NetFlowService {
    private final SitesService sitesService;
    private final DeviceService deviceService;
    private final SiteResponseValidator siteResponseValidator;
    private final NetflowApiFeign netflowApiFeign;
    private final NetFlowResponseMapper netFlowResponseMapper;
    private final NetflowCollectorRequestMapper collectorRequestMapper;
    private final ModelMapper modelMapper;
    private final ResponseEntityValidator responseEntityValidator;

    @Override
    public NetFlowResponseV1 getNetflowRuleSetV1(String siteId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        ResponseEntity<NetflowResponseApiV1> responseEntity = netflowApiFeign.getNetflowRuleSetV1(
                siteResponse.getId().intValue(), siteResponse.getNetworkId());
        responseEntityValidator.checkResponseEntity(responseEntity, NETFLOW_IP_FIX_PROFILES);
        return netFlowResponseMapper.mapNetFlowResponseV1(responseEntity.getBody());
    }

    @Override
    public List<NetFlowHistoryResponseV1> getNetflowRulesHistoryV2(String siteId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        ResponseEntity<List<NetFlowHistoryResponseApiV1>> responseEntity = netflowApiFeign.getNetflowRulesHistoryV2(
                siteResponse.getId().toString(), siteResponse.getNetworkId());
        responseEntityValidator.checkResponseEntity(responseEntity, NETFLOW_IP_FIX_PROFILES);
        List<NetFlowHistoryResponseV1> netFlowResponses = new ArrayList<>();
        if (responseEntity.hasBody()) {
            return Arrays.asList(modelMapper.map((responseEntity.getBody()), NetFlowHistoryResponseV1[].class));
        }
        return netFlowResponses;
    }

    @Override
    public NetFlowResponseV1 getNetflowRulesHistoryByIdV1(String siteId, String ruleSetId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        ResponseEntity<NetflowResponseApiV1> responseEntity = netflowApiFeign.getNetflowRulesHistoryByIdV1(
                siteResponse.getId().toString(), siteResponse.getNetworkId(), ruleSetId);
        responseEntityValidator.checkResponseEntity(responseEntity, NETFLOW_IP_FIX_PROFILES);
        NetFlowResponseV1 netFlowResponses = new NetFlowResponseV1();
        if (responseEntity.hasBody()) {
            return modelMapper.map((responseEntity.getBody()), NetFlowResponseV1.class);
        }
        return netFlowResponses;
    }

    @Override
    public CorrelationIdResponseV1 getNetflowRulesStatisticsV1(String siteId, String deviceId, Integer collectorNumber) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        UserAuth authUser = AuthUserHelper.getAuthUser();
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteIfPresent(siteResponse, deviceId);
        ResponseEntity<Void> responseEntity = netflowApiFeign.getCollectorStatisticsByNumberV1(
                siteResponse.getNetworkId(), siteResponse.getId().toString(), collectorNumber, authUser.getUsername(),
                deviceResponse.getManagementIpv4());
        responseEntityValidator.checkResponseEntity(responseEntity, NETFLOW_IP_FIX_PROFILES);
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    @Override
    public NetFlowResponseV1 rediscoverByNetworkIdAndSiteIdAndDeviceIdV1(String siteId, String networkId, String deviceId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        ResponseEntity<NetflowResponseApiV1> responseEntity = netflowApiFeign.netFlowIPFixDiscoveryV1(
                siteResponse.getId().toString(), deviceResponse.getResourceName(), networkId);
        responseEntityValidator.checkResponseEntity(responseEntity, NETFLOW_IP_FIX_PROFILES);
        return netFlowResponseMapper.mapNetFlowResponseV1(responseEntity.getBody());
    }

    @Override
    public CorrelationIdResponseV1 updateNetflowRulesV1(String siteId, NetFlowRequestV1 netFlowRequestV1) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        List<String> deviceNames = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(siteResponse.getDevices())) {
            siteResponse.getDevices().forEach(device -> deviceNames.add(device.getResourceName()));
        }
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        siteResponseValidator.hasValidSiteAndTenantValues(siteResponse);
        UserAuth userAuth = AuthUserHelper.getAuthUser();
        NetflowRequestApiV1 netflowRequestV1 = modelMapper.map(netFlowRequestV1, NetflowRequestApiV1.class);
        netflowRequestV1.updatedBy(userAuth.getUsername());
        netflowRequestV1.updatedDt(LocalDateTime.now());
        netflowRequestV1.setCollectors(collectorRequestMapper.mapNetflowCollectors(netFlowRequestV1.getCollectors(), siteResponse));

        try {
            sitesService.updateOngoingAction(siteId, MODIFYING_NETFLOW_RULES);
            ResponseEntity<Void> responseEntity = netflowApiFeign.updateNetflowRuleSetV1(
                    siteResponse.getId().intValue(), siteResponse.getNetworkId(),
                    userAuth.getUsername(), deviceNames, netflowRequestV1);
            responseEntityValidator.checkResponseEntity(responseEntity, NETFLOW_IP_FIX_PROFILES);
            return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
        } catch (Exception e) {
            sitesService.updateOngoingAction(siteId, NONE);
            throw e;
        }
    }
}
