package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.client.model.customerapi.UserResponseV3;
import net.colt.sdwan.portal.model.TenantUserPortalResponseV1;

public interface TenantUserAuthService {

    UserResponseV3 doAuthentication(String domain, String userName, String password);

    TenantUserPortalResponseV1 authenticate(String domain, String username, String password);

}
