package net.colt.sdwan.portal.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    private static final String API_TITLE = "SD-WAN Portal API";
    private static final String API_VERSION = "v6";
    private static final String API_LICENSE_NAME = "Apache 2.0";
    private static final String API_LICENSE_URL = "https://www.apache.org/licenses/LICENSE-2.0.html";
    private static final String API_CONTACT_NAME = "SD-WAN Portal Support";
    private static final String API_CONTACT_EMAIL = "SDWANPortalSupport@colt.net";
    private static final String API_SECURITY_SCHEME = "basic";
    private static final String API_SECURITY_SCHEME_NAME = "BasicAuth";

    @Bean
    public OpenAPI customOpenAPI() {
        final Info info = new Info()
                .title(API_TITLE)
                .version(API_VERSION)
                .license(new License()
                        .name(API_LICENSE_NAME)
                        .url(API_LICENSE_URL))
                .contact(new Contact()
                        .name(API_CONTACT_NAME)
                        .email(API_CONTACT_EMAIL));

        final SecurityScheme securityScheme = new SecurityScheme()
                .name(API_SECURITY_SCHEME_NAME)
                .scheme(API_SECURITY_SCHEME)
                .type(SecurityScheme.Type.HTTP);

        return new OpenAPI()
                .info(info)
                .addSecurityItem(new SecurityRequirement()
                        .addList(API_SECURITY_SCHEME_NAME))
                .components(new Components()
                        .addSecuritySchemes(API_SECURITY_SCHEME_NAME, securityScheme));
    }
}