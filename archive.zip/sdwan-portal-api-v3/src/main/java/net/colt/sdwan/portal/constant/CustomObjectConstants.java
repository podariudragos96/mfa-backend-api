package net.colt.sdwan.portal.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CustomObjectConstants {

    public static final String ADDRESS_GROUP_NAME = "ADDRESS GROUP";
}
