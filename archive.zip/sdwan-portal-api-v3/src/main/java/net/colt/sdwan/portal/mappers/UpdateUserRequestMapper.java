package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.client.model.customerapi.UpdateUserRequestV3;
import net.colt.sdwan.portal.client.model.customerapi.UserResponseV3;
import net.colt.sdwan.portal.security.models.UserAuth;
import org.springframework.stereotype.Component;

import static net.colt.sdwan.portal.mappers.UserModelMapper.mapRolesToList;


@Component
public class UpdateUserRequestMapper {


    public UpdateUserRequestV3 mapFromResponse(final UserAuth user) {
        return new UpdateUserRequestV3()
                .roles(mapRolesToList(user.getRoles()))
                .customisation(user.getCustomisation())
                .tenantIds(user.getAccessibleTenantIds())
                .lastLoggedInDt(user.getLastLoggedInDt())
                .preferredLanguage(user.getPreferredLanguage());
    }

    public UpdateUserRequestV3 mapFromResponse(final UserResponseV3 user) {
        return new UpdateUserRequestV3()
                .roles(user.getRoles())
                .customisation(user.getCustomisation())
                .tenantIds(user.getAccessibleTenantIds())
                .customisationOld(user.getCustomisationOld())
                .lastLoggedInDt(user.getLastLoggedInDt())
                .preferredLanguage(user.getPreferredLanguage());
    }
}
