package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Setter
@Getter
@ToString
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class VersaDirectoryAvoidInterface {

    @JsonInclude(Include.NON_EMPTY)
    @JsonProperty("local")
    private List<String> local;

    @JsonInclude(Include.NON_EMPTY)
    @JsonProperty("remote")
    private List<String> remote;

}
