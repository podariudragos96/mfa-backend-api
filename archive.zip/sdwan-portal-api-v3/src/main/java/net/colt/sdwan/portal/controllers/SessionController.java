package net.colt.sdwan.portal.controllers;

import jakarta.servlet.http.HttpServletRequest;
import net.colt.sdwan.common.exceptions.exception.SdwanException;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.common.exceptions.exception.SdwanUnauthorizedException;
import net.colt.sdwan.portal.client.model.customerapi.UserResponseV3;
import net.colt.sdwan.portal.generated.controllers.ApiUserApi;
import net.colt.sdwan.portal.generated.controllers.AuthenticationApiApi;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.XColtHostFilter;
import net.colt.sdwan.portal.security.factory.SecuritySessionFactory;
import net.colt.sdwan.portal.services.ApiUserService;
import net.colt.sdwan.portal.services.PortalAuthService;
import net.colt.sdwan.portal.util.ClientIPAddressHelper;
import net.colt.sdwan.portal.util.EmailUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class SessionController extends AbstractHttpServletController implements AuthenticationApiApi, ApiUserApi {

    private static final Logger cefLogger = LoggerFactory.getLogger("cef-logger");

    private final PortalAuthService portalAuthService;
    private final SecuritySessionFactory securitySessionFactory;
    private final ClientIPAddressHelper clientIPAddressHelper;
    private final ApiUserService apiUserService;

    public SessionController(HttpServletRequest request, PortalAuthService portalAuthService, SecuritySessionFactory securitySessionFactory, ClientIPAddressHelper clientIPAddressHelper, ApiUserService apiUserService) {
        super(request);
        this.portalAuthService = portalAuthService;
        this.securitySessionFactory = securitySessionFactory;
        this.clientIPAddressHelper = clientIPAddressHelper;
        this.apiUserService = apiUserService;
    }

    @Override
    public ResponseEntity<SessionResponseV1> loginV1(SessionRequestV1 body) {
        final String username = body.getUsername().toLowerCase();
        final UserResponseV3 user = getUser(username, body.getPassword());
        final SessionResponseV1 sessionResponseV1 = securitySessionFactory.getSession(user);
        logSuccessMsgToSecuritySystem(request, user.getUsername(), user.getName());
        return new ResponseEntity<>(sessionResponseV1, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> logoutV1() {
        securitySessionFactory.destroySession();
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override

    public ResponseEntity<Void> updateSessionV1(UpdateSessionRequestV1 body) {
        return new ResponseEntity<>(HttpStatus.OK);
    }


    @Override
    public ResponseEntity<AccountLookupResponseV1> accountLookupV1(AccountLookupRequestV1 accountLookupRequestV1) {
        return ResponseEntity.ok(portalAuthService.accountLookup(getHeaderValue(XColtHostFilter.X_COLT_HOST), accountLookupRequestV1));
    }

    private void logSuccessMsgToSecuritySystem(HttpServletRequest request, String username, String name) {
        final String userNameOrEmailPrefix = EmailUtils.verifyAndRetrieveEmailPrefix(username);
        final String clientIp = clientIPAddressHelper.getClientIpFromRequest(request);
        cefLogger.warn("CEF:0|novitas|sdwan|1.0|100|Successful Login|1|src={} request={} requestMethod={} duser={} cs1Label=customer cs1={} cs2Label=authProcess cs2=sdwanPortal",
                clientIp,
                request.getRequestURL(),
                request.getMethod(),
                userNameOrEmailPrefix,
                name);
    }

    private void logFailureMsgToSecuritySystem(HttpServletRequest request, String username) {
        final String userNameOrEmailPrefix = EmailUtils.verifyAndRetrieveEmailPrefix(username);
        final String clientIp = clientIPAddressHelper.getClientIpFromRequest(request);
        cefLogger.warn("CEF:0|novitas|sdwan|1.0|101|Failed Login|1|src={} request={} requestMethod={} duser={} cs2Label=authProcess cs2=sdwanPortal",
                clientIp,
                request.getRequestURL(),
                request.getMethod(),
                userNameOrEmailPrefix);
    }

    /**
     * POST /v1/api_user/session : Create session for api user
     * This API gets the user details and provides a user api key to api users.
     *
     * @param requestV1 Api user SessionRequest object that needs to be sent to the backend (optional)
     * @return Success response (status code 200)
     * or Bad request (status code 400)
     * or Authentication failure (status code 401)
     * or Not Acceptable (status code 406)
     * or Unsupported Media Type (status code 415)
     * or Internal server error (status code 500)
     * or Service unavailable (status code 503)
     */
    @Override
    public ResponseEntity<List<ApiUserSessionResponseV1>> apiUserLoginV1(ApiUserSessionRequestV1 requestV1) {
        final UserResponseV3 user = getUser(requestV1.getUsername(), requestV1.getPassword());
        logSuccessMsgToSecuritySystem(request, user.getUsername(), user.getName());
        return new ResponseEntity<>(apiUserService.getApiUserDetails(user), HttpStatus.OK);
    }

    /**
     * POST /v1/api_user/session/api_key/renew : Renew api key for the user
     * This API gets the user details and provides a user api key to api users.
     *
     * @param requestV1 Api user Renew key Request object that needs to be sent to the backend (optional)
     * @return Success response (status code 200)
     * or Bad request (status code 400)
     * or Authentication failure (status code 401)
     * or Not Acceptable (status code 406)
     * or Unsupported Media Type (status code 415)
     * or Internal server error (status code 500)
     * or Service unavailable (status code 503)
     */
    @Override
    public ResponseEntity<List<ApiUserSessionResponseV1>> renewApiKeyV1(ApiUserRenewKeyRequestV1 requestV1) {
        final UserResponseV3 user = getUser(requestV1.getUsername(), requestV1.getPassword());
        logSuccessMsgToSecuritySystem(request, user.getUsername(), user.getName());
        return new ResponseEntity<>(apiUserService.renewApiKeyV1(user, requestV1.getUserAgent()), HttpStatus.OK);
    }

    private UserResponseV3 getUser(String username, String password) {
        try {
            return portalAuthService.doAuthentication(
                    getHeaderValue(XColtHostFilter.X_COLT_HOST), username.toLowerCase(), password);
        } catch (SdwanException e) {
            HttpStatusCode statusCode = e.getStatusCode();
            if (statusCode.equals(HttpStatus.UNAUTHORIZED)) {
                logFailureMsgToSecuritySystem(request, username);
                throw new SdwanUnauthorizedException("Unauthorized", e);
            } else if (statusCode.equals(HttpStatus.FORBIDDEN)) {
                logFailureMsgToSecuritySystem(request, username);
                throw new AccessDeniedException("Forbidden");
            } else {
                logFailureMsgToSecuritySystem(request, username);
                throw new SdwanInternalServerErrorException("Error while authenticating user: " + e.getProblemDetailWithCause().getDetail(), e);
            }
        } catch (Exception e) {
            logFailureMsgToSecuritySystem(request, username);
            throw new SdwanInternalServerErrorException("Error while authenticating user: " + e.getMessage(), e);
        }
    }
}
