package net.colt.sdwan.portal.client.feign.sase;

import net.colt.sdwan.generated.controller.versa.sase.api.TaskApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "saseTaskFeign",
        url = "${sdwan.sase.api.baseurl}",
        configuration = SaseApiFeignConfiguration.class)
public interface SaseTaskFeign extends TaskApiApi {
}
