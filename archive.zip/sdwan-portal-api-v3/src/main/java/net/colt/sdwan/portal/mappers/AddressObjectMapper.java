package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.model.AddressObjectCriteria;
import net.colt.sdwan.portal.model.AddressesRequestV1;
import net.colt.sdwan.portal.model.AddressesResponseV1;
import net.colt.sdwan.sitesettings.api.generated.model.AddressObjectCriteriaApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.AddressesRequestApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.AddressesResponseApiV1;
import org.mapstruct.Mapper;

@Mapper
public interface AddressObjectMapper extends CommonObjectMapper {

    AddressObjectCriteriaApiV1 from(AddressObjectCriteria criteria);

    AddressesResponseV1 from(AddressesResponseApiV1 addressesResponseApiV1);

    AddressesRequestApiV1 from(AddressesRequestV1 addressesRequestV1);

}

