package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.model.versa.sase.api.TaskResponseApiV1;
import net.colt.sdwan.generated.model.versa.sase.api.TasksResponseApiV1;
import net.colt.sdwan.portal.model.SaseTaskResponseV1;
import net.colt.sdwan.portal.model.SaseTasksResponseV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SaseTaskMapper {

    private final ModelMapper modelMapper;

    public SaseTasksResponseV1 from(TasksResponseApiV1 tasksResponseApiV1) {
        return modelMapper.map(tasksResponseApiV1, SaseTasksResponseV1.class);
    }

    public SaseTaskResponseV1 from(TaskResponseApiV1 taskResponseApiV1) {
        return modelMapper.map(taskResponseApiV1, SaseTaskResponseV1.class);
    }
}
