package net.colt.sdwan.portal.client.feign.service;

import net.colt.sdwan.generated.controller.service.ManagedInstallApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "serviceApiManagedInstallClient", url = "${sdwan.service.api.base.url}", configuration = ServiceFeignConfiguration.class)
public interface ServiceApiManagedInstallFeign extends ManagedInstallApi {

}