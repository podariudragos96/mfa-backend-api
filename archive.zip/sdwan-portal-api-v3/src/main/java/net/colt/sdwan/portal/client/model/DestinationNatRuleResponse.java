package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DestinationNatRuleResponse {

    @JsonProperty("name")
    private String name;

    @JsonProperty("description")
    private String description;

    @JsonProperty("source-network")
    private List<String> sourceNetwork;

    @JsonProperty("destination-network")
    private List<String> destinationNetwork;

    @JsonProperty("private_ip")
    private List<String> privateIps;

    @JsonProperty("private_port")
    private String privatePort;

    @JsonProperty("nat_ip")
    private List<String> natIps;

    @JsonProperty("public_port")
    private String publicPort;

    @JsonProperty("protocol")
    private String protocol;

    @JsonProperty("precedence")
    private String precedence;

    @JsonProperty("editable")
    private Boolean editable;
}
