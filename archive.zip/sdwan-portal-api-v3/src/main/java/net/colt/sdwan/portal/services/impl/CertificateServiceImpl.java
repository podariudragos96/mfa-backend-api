package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.FirewallV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.ServiceApiClient;
import net.colt.sdwan.portal.client.feign.security.SslDecryptionCertificateApiFeign;
import net.colt.sdwan.portal.client.model.DeviceRequest;
import net.colt.sdwan.portal.mappers.CertificateMapper;
import net.colt.sdwan.portal.model.CertificateTypeV1;
import net.colt.sdwan.portal.model.DeviceCustomerManagedCertificateRequestV1;
import net.colt.sdwan.portal.model.DeviceSelfSignedCertificateRequestV1;
import net.colt.sdwan.portal.model.DeviceSelfSignedCertificateResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.CertificateService;
import net.colt.sdwan.portal.services.DeviceService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.security.api.generated.model.SslCertificateApiResponseV1;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.ObjectUtils;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemReader;
import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.portal.constant.CertificateConstants.DEVICE_SOFTWARE_VERSION_PREFIX_WITH_NO_CA_CHAIN_DATA;
import static net.colt.sdwan.security.api.generated.model.CertificateTypeApiV1.fromValue;

@Slf4j
@Service
@RequiredArgsConstructor
public class CertificateServiceImpl implements CertificateService {

    public static final String BEGIN_CERTIFICATE = "-----BEGIN CERTIFICATE-----";
    public static final String END_CERTIFICATE = "-----END CERTIFICATE-----";
    public static final String X_509 = "X509";
    public static final String PRIVATE_KEY = "PRIVATE KEY";
    private static final String CA_CHAIN_DATA_NOT_POPULATED_ERROR = "Invalid request:  Ca chain data must be populated for devices which software version does not starts with 21.2";
    private static final String CA_CHAIN_DATA_POPULATED_ERROR = "Invalid request:  Ca chain data should not be populated for devices which software version starts with 21.2";

    private final SitesService sitesService;
    private final DeviceService deviceService;
    private final SiteResponseValidator siteResponseValidator;
    private final ServiceApiClient serviceApiClient;
    private final SslDecryptionCertificateApiFeign sslDecryptionCertificateApiFeign;
    private final CertificateMapper certificateMapper;
    private final ResponseEntityValidator responseEntityValidator;

    @Override
    public DeviceSelfSignedCertificateResponseV1 getCertificateBySiteIdAndDeviceIdV1(
            String siteId, String deviceId, CertificateTypeV1 certificateType) {

        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue()
                .equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());
        siteResponseValidator.validateAdvancedFirewallEnabled(hasAdvancedFirewall);
        siteResponseValidator.hasValidSiteForDeviceCertificateAccess(siteResponse);

        final DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final ResponseEntity<SslCertificateApiResponseV1> sslCertificateResponse = sslDecryptionCertificateApiFeign.getSslDecryptionCertificateV1(
                siteResponse.getNetworkId(), siteId, deviceResponse.getResourceName(), fromValue(certificateType.getValue()));
        responseEntityValidator.checkResponseEntity(sslCertificateResponse, "CertificateServiceImpl.getCertificateBySiteIdAndDeviceIdV1");

        return new DeviceSelfSignedCertificateResponseV1().certificateData(requireNonNull(sslCertificateResponse.getBody()).getCertificate());
    }

    @Override
    public void createSelfSignedCertificateBySiteIdAndDeviceIdV1(
            String siteId, String deviceId, DeviceSelfSignedCertificateRequestV1 deviceSelfSignedCertificateRequestV1) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue()
                .equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());

        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        siteResponseValidator.validateAdvancedFirewallEnabled(hasAdvancedFirewall);
        final DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        siteResponseValidator.hasValidSiteForDeviceCertificateAccess(siteResponse);

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final ResponseEntity<Void> response = sslDecryptionCertificateApiFeign.generateSelfSignedCertificateV1(
                siteResponse.getNetworkId(), siteId, deviceResponse.getResourceName(), certificateMapper.from(deviceSelfSignedCertificateRequestV1));
        responseEntityValidator.checkResponseEntity(response, "CertificateServiceImpl.createSelfSignedCertificateBySiteIdAndDeviceIdV1");

        DeviceRequest deviceRequest = new ModelMapper().map(deviceResponse, DeviceRequest.class);
        deviceRequest.setIsSelfSignedCertificateGenerated(true);
        serviceApiClient.updateDeviceSelfSignedCertificate(deviceRequest);
    }

    private X509Certificate convertStringToX509Cert(final String certificate) {
        final byte[] converted = Base64.decodeBase64(certificate
                .replace(BEGIN_CERTIFICATE, "")
                .replace(END_CERTIFICATE, ""));
        final InputStream targetStream = new ByteArrayInputStream(converted);

        try {
            return (X509Certificate) CertificateFactory
                    .getInstance(X_509)
                    .generateCertificate(targetStream);
        } catch (CertificateException e) {
            throw new SdwanInternalServerErrorException(e.getMessage());
        }
    }

    private PemObject validatePrivateKey(final String privateKey) {
        final PemReader keyReader = new PemReader(new StringReader(privateKey));
        final PemObject keyPemObject;

        try {
            keyPemObject = keyReader.readPemObject();
        } catch (IOException e) {
            throw new SdwanInternalServerErrorException(e.getMessage());
        }

        if (keyPemObject == null || !keyPemObject.getType().contains(PRIVATE_KEY)) {
            throw new IllegalArgumentException();
        }

        return keyPemObject;
    }

    @Override
    public void uploadCustomerCertificateBySiteIdAndDeviceIdV1(String siteId, String deviceId, DeviceCustomerManagedCertificateRequestV1 deviceCustomerManagedCertificateRequestV1) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue()
                .equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());

        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        siteResponseValidator.validateAdvancedFirewallEnabled(hasAdvancedFirewall);
        final DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        siteResponseValidator.hasValidSiteForDeviceCertificateAccess(siteResponse);
        try {
            this.convertStringToX509Cert(deviceCustomerManagedCertificateRequestV1.getCertificateData());
        } catch (Exception e) {
            log.error("Invalid certificate", e);
            throw new SdwanBadRequestException("Invalid certificate.", e);
        }
        try {
            this.validatePrivateKey(deviceCustomerManagedCertificateRequestV1.getPrivateKeyData());
        } catch (Exception e) {
            log.error("Invalid private key", e);
            throw new SdwanBadRequestException("Invalid private key.", e);
        }

        final String caChainData = deviceCustomerManagedCertificateRequestV1.getCaChainData();
        final String swVersion = deviceResponse.getSwVersion();
        if (!swVersion.startsWith(DEVICE_SOFTWARE_VERSION_PREFIX_WITH_NO_CA_CHAIN_DATA) && ObjectUtils.isEmpty(caChainData)) {
            throw new SdwanBadRequestException(CA_CHAIN_DATA_NOT_POPULATED_ERROR);
        } else if (swVersion.startsWith(DEVICE_SOFTWARE_VERSION_PREFIX_WITH_NO_CA_CHAIN_DATA) && ObjectUtils.isNotEmpty(caChainData)) {
            throw new SdwanBadRequestException(CA_CHAIN_DATA_POPULATED_ERROR);
        }

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final ResponseEntity<Void> response = sslDecryptionCertificateApiFeign.uploadCustomerManagedCertificateV1(
                swVersion, siteResponse.getNetworkId(), siteId, deviceResponse.getResourceName(), certificateMapper.from(deviceCustomerManagedCertificateRequestV1));
        responseEntityValidator.checkResponseEntity(response, "CertificateServiceImpl.uploadCustomerCertificateBySiteIdAndDeviceIdV1");

        DeviceRequest deviceRequest = new ModelMapper().map(deviceResponse, DeviceRequest.class);
        deviceRequest.setIsCustomerManagedCertificateGenerated(true);
        serviceApiClient.updateDeviceCustomerManagedCertificate(deviceRequest);
    }
}
