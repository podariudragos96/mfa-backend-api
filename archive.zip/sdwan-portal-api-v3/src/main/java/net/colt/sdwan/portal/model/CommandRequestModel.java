package net.colt.sdwan.portal.model;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class CommandRequestModel {
    private String siteId;
    private String deviceId;
    private String interfaceId;
    private String vrf;
    private String targetIP;
    private String srcIp;
    private boolean isPing;
    private String managementIpv4;
}
