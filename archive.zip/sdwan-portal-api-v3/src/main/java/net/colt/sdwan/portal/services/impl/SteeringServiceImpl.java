package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.InterfaceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.feign.steering.SteeringApiFeign;
import net.colt.sdwan.portal.mappers.CommonMapper;
import net.colt.sdwan.portal.mappers.SteeringResponseMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.services.SteeringService;
import net.colt.sdwan.portal.util.ClientIPAddressHelper;
import net.colt.sdwan.portal.validator.IPAddressValidator;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.portal.validator.SteeringPoliciesRequestValidator;
import net.colt.sdwan.steering.api.generated.model.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.constant.SecurityConstants.STEERING_PROFILES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.MODIFYING_STEERING_RULES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;
import static net.colt.sdwan.portal.util.CGWUtil.isBranch;

@Service
@RequiredArgsConstructor
@Slf4j
public class SteeringServiceImpl implements SteeringService {

    private final SitesService sitesService;
    private final SiteResponseValidator siteResponseValidator;
    private final SteeringApiFeign steeringApiFeign;
    private final SteeringResponseMapper steeringResponseMapper;
    private final ModelMapper modelMapper;
    private final SteeringPoliciesRequestValidator steeringPoliciesRequestValidator;
    private final CommonMapper commonMapper;
    private final ResponseEntityValidator responseEntityValidator;


    @Override
    public SteeringPolicyResponseV1 getSteeringPoliciesV1(String siteId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        Objects.requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        ResponseEntity<SteeringPolicyApiResponseV1> responseEntity = steeringApiFeign.getSteeringPoliciesV1(
                siteResponse.getId().intValue(), siteResponse.getNetworkId());
        responseEntityValidator.checkResponseEntity(responseEntity, STEERING_PROFILES);
        return steeringResponseMapper.mapPolicyResponseV1(responseEntity.getBody());
    }

    @Override
    public List<SteeringHistoryResponseV1> getSteeringPoliciesHistoryV1(String siteId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        Objects.requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        ResponseEntity<List<SteeringPolicyApiHistoryResponseV1>> responseEntity = steeringApiFeign.getSteeringPoliciesHistoryV1(
                siteResponse.getId().toString(), siteResponse.getNetworkId());
        responseEntityValidator.checkResponseEntity(responseEntity, STEERING_PROFILES);

        List<SteeringHistoryResponseV1> steeringPolicyResponseV1s = new ArrayList<>();
        if (responseEntity.hasBody()) {
            return Arrays.asList(modelMapper.map((responseEntity.getBody()), SteeringHistoryResponseV1[].class));
        }
        return steeringPolicyResponseV1s;
    }

    @Override
    public SteeringPolicyResponseV1 getSteeringPoliciesHistoryByIdV1(String siteId, String ruleSetId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        Objects.requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        ResponseEntity<SteeringPolicyApiResponseV1> responseEntity = steeringApiFeign.getSteeringPoliciesHistoryByIdV1(
                siteResponse.getId().toString(), siteResponse.getNetworkId(), ruleSetId);
        responseEntityValidator.checkResponseEntity(responseEntity, STEERING_PROFILES);
        SteeringPolicyResponseV1 steeringPolicyResponseV1s = new SteeringPolicyResponseV1();
        if (responseEntity.hasBody()) {
            return modelMapper.map((responseEntity.getBody()), SteeringPolicyResponseV1.class);
        }
        return steeringPolicyResponseV1s;
    }

    @Override
    public CorrelationIdResponseV1 updateSteeringPoliciesV1(String siteId, SteeringPolicyRequestV1 steeringPolicyRequestV1) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        // Validation
        steeringPoliciesRequestValidator.validate(steeringPolicyRequestV1, siteResponse);

        Objects.requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        List<String> deviceNames = new ArrayList<>();
        Map<String, String> interfaceZone = new HashMap<>();

        if (CollectionUtils.isNotEmpty(siteResponse.getDevices())) {
            siteResponse.getDevices().forEach(device -> {
                deviceNames.add(device.getResourceName());
                device.getInterfaces().forEach(interfaceResponse -> interfaceZone.put(interfaceResponse.getNetwork(), interfaceResponse.getZone()));
            });
        }

        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        siteResponseValidator.hasValidSiteAndTenantValues(siteResponse);
        try {
            sitesService.updateOngoingAction(siteId, MODIFYING_STEERING_RULES);
            UserAuth userAuth = AuthUserHelper.getAuthUser();
            SteeringPolicyApiRequestV1 steeringPolicyApiRequestV1 = modelMapper.map(steeringPolicyRequestV1, SteeringPolicyApiRequestV1.class);
            steeringPolicyApiRequestV1.updatedBy(userAuth.getUsername());
            steeringPolicyApiRequestV1.updatedDt(LocalDateTime.now());

            //Validation
            SiteResponseV3 siteResponseV3 = sitesService.getSiteBySiteIdV3(siteId);
            steeringPolicyApiRequestV1.setInternetProcessing(isBranch(siteResponse.getSiteType().getValue()) && siteResponse.getSiteFeatures().getSteering().getInternetSteering());
            steeringPolicyApiRequestV1.setSaasProcessing(isBranch(siteResponse.getSiteType().getValue())
                    && siteResponse.getSiteFeatures().getCentralInternetBreakoutEnabled()
                    && (siteResponseV3.getInterfaces().getWan().getInternet() || siteResponseV3.getInterfaces().getWan().getCellular()));

            //Internet Rules
            steeringPolicyApiRequestV1.getInternetRules().forEach(internetSteeringPolicyRuleRequestV1 ->
                    internetSteeringPolicyRuleRequestV1.setZone(interfaceZone.get(internetSteeringPolicyRuleRequestV1.getVpn()))
            );

            // Update NextHop for Sdwan steering rules
            steeringPolicyApiRequestV1.getSdwanRules().forEach(this::updateNextHopIpV1);

            ResponseEntity<Void> responseEntity = steeringApiFeign.updateSteeringPoliciesV1(
                    siteResponse.getId().intValue(), siteResponse.getNetworkId(),
                    userAuth.getUsername(), deviceNames, steeringPolicyApiRequestV1);
            responseEntityValidator.checkResponseEntity(responseEntity, STEERING_PROFILES);
            return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
        } catch (Exception ex) {
            log.error("Failed to update policies", ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }
    }

    private void updateNextHopIpV1(SdwanPolicyApiRuleV1 sdwanPolicyApiRuleV1) {
        if (SdwanPolicyBehaviourV1.NEXT_HOP.equals(sdwanPolicyApiRuleV1.getBehaviour()) && Objects.nonNull(sdwanPolicyApiRuleV1.getNextHopDetails())
                && CollectionUtils.isEmpty(sdwanPolicyApiRuleV1.getNextHopDetails().getNextHopIps()) && Objects.nonNull(sdwanPolicyApiRuleV1.getNextHopDetails().getDestinationSiteId())) {
            // get Site response based on site id
            final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(sdwanPolicyApiRuleV1.getNextHopDetails().getDestinationSiteId().toString());
            // find Interface based on VPN
            Map<DeviceResponseV1, net.colt.sdwan.generated.model.service.InterfaceResponseV1> interfacesResp = commonMapper.findInterfacesBasedOnVpn(sdwanPolicyApiRuleV1.getVpn(), siteResponse);
            if (MapUtils.isNotEmpty(interfacesResp)) {
                SdwanPolicyApiNextHopRuleResponseV1 nextHopRuleResponseV1 = sdwanPolicyApiRuleV1.getNextHopDetails();
                // init ips list
                nextHopRuleResponseV1.setNextHopIps(new ArrayList<>());
                String vrrpIpV4 = getVrrpIpV4ForDualSite(siteResponse, interfacesResp.values().stream().findFirst());
                if (Objects.nonNull(vrrpIpV4)) {
                    nextHopRuleResponseV1.addNextHopIpsItem(
                            new SdwanPolicyApiNextHopIpV1().ipAddress(
                                    ClientIPAddressHelper.removeNetworkSubnetFromIp(vrrpIpV4)));
                } else {
                    // if there is no vrrp address we use the ipv4 address
                    interfacesResp.keySet().forEach(k -> {
                        if (StringUtils.isNotBlank(interfacesResp.get(k).getIpv4Address())) {
                            nextHopRuleResponseV1.addNextHopIpsItem(
                                    new SdwanPolicyApiNextHopIpV1().deviceName(k.getResourceName()).ipAddress(
                                            ClientIPAddressHelper.removeNetworkSubnetFromIp(interfacesResp.get(k).getIpv4Address())));
                        }
                    });
                }
            }
        }
    }

    private String getVrrpIpV4ForDualSite(SiteResponseV1 siteResponse, Optional<InterfaceResponseV1> interfaceResponse) {
        String result = null;
        boolean isDualCpeSite = siteResponse.getIsDualSite();
        // If there is a vrrp address we use it.
        if (isDualCpeSite && interfaceResponse.isPresent() && StringUtils.isNotBlank(interfaceResponse.get().getVrrpIpv4()) && IPAddressValidator.isIpv4(interfaceResponse.get().getVrrpIpv4())) {
            result = interfaceResponse.get().getVrrpIpv4();
        }
        return result;
    }
}
