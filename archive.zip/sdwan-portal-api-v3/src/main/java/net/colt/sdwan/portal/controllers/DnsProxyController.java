package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.DnsProxyApiApi;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.DNSProxyRequestV1;
import net.colt.sdwan.portal.model.DNSProxyResponseV1;
import net.colt.sdwan.portal.model.DnsProxyHistoryResponseV1;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.DnsProxyService;
import net.colt.sdwan.portal.validator.model.DnsProxiesPortalRequestV1Validator;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import java.util.List;

@RequiredArgsConstructor
@Controller
public class DnsProxyController implements DnsProxyApiApi {

    private final DnsProxyService dnsProxyService;
    private final DnsProxiesPortalRequestV1Validator validator;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setValidator(validator);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<DNSProxyResponseV1> getDNSProxiesV1(String siteId) {
        return ResponseEntity.ok(dnsProxyService.getDNSProxiesV1(siteId));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/dns_proxy")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateDNSProxiesV1(String siteId, DNSProxyRequestV1 dnsProxyRequestV1) {
        return ResponseEntity.ok(dnsProxyService.updateDNSProxiesV1(siteId, dnsProxyRequestV1));

    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<DNSProxyResponseV1> getDnsProxiesHistoryBySiteIdAndRuleSetIdV1(String siteId, String id) {
        return ResponseEntity.ok(dnsProxyService.getDnsProxyResponseHistoryByIdV1(siteId, id));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<List<DnsProxyHistoryResponseV1>> getDnsProxiesHistoryBySiteIdV1(String siteId) {
        return ResponseEntity.ok(dnsProxyService.getDnsProxiesHistoryV1(siteId));
    }
}
