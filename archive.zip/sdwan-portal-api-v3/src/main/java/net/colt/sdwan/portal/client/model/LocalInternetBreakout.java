package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Setter
@Getter
@Builder
@EqualsAndHashCode
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class LocalInternetBreakout {

    @JsonProperty("lan_interface")
    private String lanInterface;

    @JsonProperty("vrf")
    private String vrf;

    @JsonProperty("cloud_lookup_enabled")
    private Boolean cloudLookupEnabled;

    @JsonProperty("preferences")
    private List<LocalInternetBreakoutPreferences> preferences;
}
