package net.colt.sdwan.portal.client;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.common.logging.service.LoggingService;
import net.colt.sdwan.portal.util.LocalDateTimeOperations;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Objects;

import static net.colt.sdwan.portal.client.ParamsLabels.DEVICES_PARAMS;
import static org.apache.commons.lang3.ObjectUtils.isNotEmpty;

@Slf4j
public class AbstractRestApiClient {

    @Autowired
    public AbstractRestApiClient(AuthHeaderGenerator authHeaderGenerator, RestTemplate restTemplate, LoggingService loggingService) {
        this.authHeaderGenerator = authHeaderGenerator;
        this.restTemplate = restTemplate;
        this.loggingService = loggingService;
    }

    protected final AuthHeaderGenerator authHeaderGenerator;
    protected final RestTemplate restTemplate;
    protected final LoggingService loggingService;

    @Value("${sdwan.service.api.base.url}")
    private String serverUrl;

    <T> ResponseEntity<T> get(String url, String path, Map<String, Object> params,
                              Class<T> modelClass, HttpEntity<Object> entity) {
        return callApi(url, path, params, modelClass, HttpMethod.GET, entity);
    }

    <T> ResponseEntity<T> delete(String url, String path, Map<String, Object> params,
                                 Class<T> modelClass, HttpEntity<Object> entity) {
        return callApi(url, path, params, modelClass, HttpMethod.DELETE, entity);
    }

    <T> ResponseEntity<T> put(String url, String path, Map<String, Object> params,
                              Class<T> modelClass, HttpEntity<Object> entity) {
        return callApi(url, path, params, modelClass, HttpMethod.PUT, entity);
    }


    <T> ResponseEntity<T> post(String url, String path, Map<String, Object> params,
                               Class<T> modelClass, HttpEntity<Object> entity) {
        return callApi(url, path, params, modelClass, HttpMethod.POST, entity);
    }

    <T> ResponseEntity<T> patch(String url, String path, Map<String, Object> params,
                                Class<T> modelClass, HttpEntity<Object> entity) {
        return callApi(url, path, params, modelClass, HttpMethod.PATCH, entity);
    }

    protected <T> ResponseEntity<T> callApi(String url, String path, Map<String, Object> params,
                                            Class<T> modelClass, HttpMethod method, HttpEntity<Object> entity) {
        String urlCall = buildCallingUrl(url.concat(path), params);
        logInnerApiRequest(method, urlCall, modelClass.getName(), entity.getBody());
        ResponseEntity<T> response = null;
        try {
            LocalDateTime start = LocalDateTime.now();
            response = restTemplate.exchange(urlCall, method, entity, modelClass, params);
            long millis = LocalDateTimeOperations.substract(LocalDateTime.now(), start);
            log.debug("Call time {} {} {}", millis, method.name(), urlCall);
            if (Objects.nonNull(response) && response.getStatusCode().isError()) {
                log.error("Response error received from API: {} {}",
                        response.getStatusCode().toString(), response.getBody());
            } else {
                logInnerApiResponse(method, urlCall,
                        response.getStatusCode(), response.getBody());
            }
        } catch (Exception ex) {
            handleRestExceptions(url, path, params, ex);
        }
        return response;
    }

    private void handleRestExceptions(final String url, final String path, Map<String, Object> params, Exception ex) {
        log.error("Response error received from service api", ex);
        StringBuilder call = new StringBuilder().append(url).append(path).append(" params: ").append(params);
        if (StringUtils.isNotEmpty(ex.getMessage()) && (ex.getMessage().contains("404"))) {
            throw new SdwanNotFoundException(String.format("Resource '%s' could not be found.", call), ex);
        }

        if (ex instanceof HttpClientErrorException error
                && error.getStatusCode().value() == HttpStatus.BAD_REQUEST.value()
                && serverUrl.equals(url)) {
            throw new SdwanNotFoundException(String.format("Resource '%s' could not be found.", call), ex);
        }
        throw new SdwanInternalServerErrorException(String.format("Bad response on '%s'.", call), ex);
    }

    protected String buildCallingUrl(final String urlCall, final Map<String, Object> params) {
        if (isNotEmpty(params)) {
            final StringBuilder sb = new StringBuilder(urlCall).append("?");
            String devices = null;
            if (params.containsKey(DEVICES_PARAMS)) {
                devices = params.get(DEVICES_PARAMS).toString();
                params.remove(DEVICES_PARAMS);
            }
            params.forEach((k, v) -> sb.append(k).append("=").append(v).append("&"));
            sb.deleteCharAt(sb.lastIndexOf("&"));
            if (StringUtils.isNotEmpty(devices)) {
                sb.append(devices);
            }
            return sb.toString();
        }
        return urlCall;
    }

    private void logInnerApiRequest(final HttpMethod method, final String urlCall, final String className, final Object request) {
        log.info("Calling {} {} params: {} for type: {}", method.name(), urlCall, className);
        if (Objects.nonNull(request)) {
            try {
                String json = new ObjectMapper().writeValueAsString(request);
                log.info("Sending body: {}", json);
            } catch (JsonProcessingException e) {
                log.error("Could not parse/convert logging body to json: {}", e.getMessage());
            }
        }
    }

    private void logInnerApiResponse(final HttpMethod method, final String urlCall, final HttpStatusCode status, final Object response) {
        if (Objects.nonNull(response)) {
            try {
                String json = new ObjectMapper().writeValueAsString(response);
                log.info("Got response {} for {} {} body: {}", status.value(), method.name(), urlCall, json);
            } catch (JsonProcessingException e) {
                log.error("Could not parse/convert logging body to json: {}", e.getMessage());
            }
        }
    }
}
