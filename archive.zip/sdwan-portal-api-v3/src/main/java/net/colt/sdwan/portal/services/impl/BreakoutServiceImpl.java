package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.feign.sitesettings.BreakoutApiFeign;
import net.colt.sdwan.portal.constant.BreakoutConstants;
import net.colt.sdwan.portal.mappers.BreakoutMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.BreakoutService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.BreakoutValidator;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.sitesettings.api.generated.model.SaseBreakoutRequestApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.ZScalerBreakoutRequestApiV1;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;
import static org.apache.commons.collections4.CollectionUtils.isNotEmpty;

@Service
@Slf4j
@RequiredArgsConstructor
public class BreakoutServiceImpl implements BreakoutService {

    private final SitesService sitesService;
    private final SiteResponseValidator siteResponseValidator;
    private final BreakoutValidator breakoutValidator;
    private final BreakoutMapper breakoutMapper;
    private final BreakoutApiFeign breakoutApiFeign;
    private final ResponseEntityValidator responseEntityValidator;

    /*
     *
     * SASE Breakout
     *
     */
    @Override
    public SaseBreakoutResponseV1 getSaseBreakoutV1(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        breakoutValidator.validateSaseBreakoutSupport(siteResponse);
        return breakoutMapper.fromSaseBreakoutStatusToSaseBreakoutResponseV1(siteResponse.getSiteFeatures().getSase().getIsActive());
    }

    @Override
    public CorrelationIdResponseV1 updateSaseBreakoutV1(String siteId, SaseBreakoutRequestV1 saseBreakoutRequestV1) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        breakoutValidator.validateSaseBreakoutSupport(siteResponse);
        breakoutValidator.validateSaseBreakoutRequestV1(siteResponse, saseBreakoutRequestV1);

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        SaseBreakoutRequestApiV1 saseBreakoutRequestApiV1 = breakoutMapper.fromSaseBreakoutRequestV1ToSaseBreakoutRequestApiV1(saseBreakoutRequestV1);

        try {
            sitesService.updateOngoingAction(siteId, OnGoingActionV2.MODIFYING_SASE_BREAKOUT);

            final ResponseEntity<Void> snmpResponseEntity = breakoutApiFeign.updateSaseBreakoutV1(Integer.valueOf(siteId),
                    siteResponse.getNetworkId(), AuthUserHelper.getAuthUser().getUsername(),
                    sitesService.getDeviceNamesFromSiteResponse(siteResponse), saseBreakoutRequestApiV1);
            responseEntityValidator.checkResponseEntity(snmpResponseEntity, BreakoutConstants.SASE_BREAKOUT);
        } catch (Exception ex) {
            log.error("Failed to update " + BreakoutConstants.SASE_BREAKOUT + " for site with id " + siteId, ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }

        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    @Override
    public CorrelationIdResponseV1 updateZScalerBreakoutV1(String siteId, ZScalerBreakoutRequestV1 zScalerBreakoutRequestV1) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        breakoutValidator.validateZScalerBreakoutSupport(siteResponse, zScalerBreakoutRequestV1);

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final ZScalerBreakoutRequestApiV1 saseBreakoutRequestApiV1 =
                breakoutMapper.fromZScalerBreakoutRequestV1ToZScalerBreakoutRequestApiV1(zScalerBreakoutRequestV1);

        try {
            sitesService.updateOngoingAction(siteId, OnGoingActionV2.MODIFYING_ZSCALER_BREAKOUT);

            final List<String> devicesWithZscalerEnabled = new ArrayList<>();

            if (isNotEmpty(siteResponse.getDevices())) {
                siteResponse.getDevices().stream()
                        .filter(deviceResponseV1 -> Boolean.TRUE.equals(deviceResponseV1.getZscalerEnabled()))
                        .forEach(device -> devicesWithZscalerEnabled.add(device.getResourceName()));
            }

            final ResponseEntity<Void> snmpResponseEntity = breakoutApiFeign.updateZScalerBreakoutV1(
                    Integer.valueOf(siteId),
                    siteResponse.getNetworkId(),
                    AuthUserHelper.getAuthUser().getUsername(),
                    devicesWithZscalerEnabled,
                    saseBreakoutRequestApiV1);

            responseEntityValidator.checkResponseEntity(snmpResponseEntity, BreakoutConstants.ZSCALER_BREAKOUT);

        } catch (Exception ex) {
            log.error("Failed to update " + BreakoutConstants.ZSCALER_BREAKOUT + " for site with id " + siteId, ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }

        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

}
