package net.colt.sdwan.portal.client.feign.sitesettings;

import feign.RequestInterceptor;
import feign.auth.BasicAuthRequestInterceptor;
import net.colt.sdwan.common.data.criteria.config.AbstractCriteriaApiFeignConfiguration;
import net.colt.sdwan.portal.client.feign.util.FeignConfigurationUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

public class SiteSettingsApiFeignConfiguration extends AbstractCriteriaApiFeignConfiguration {

    protected String username;
    protected String password;

    public SiteSettingsApiFeignConfiguration(
            @Value("${sdwan.site.settings.api.user}") String username,
            @Value("${sdwan.site.settings.api.pwd}") String password) {
        this.username = username;
        this.password = password;
    }

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        return new BasicAuthRequestInterceptor(username, password);
    }

    @Bean
    public RequestInterceptor requestUriInterceptor() {
        return FeignConfigurationUtil::getRequestUri;
    }
}
