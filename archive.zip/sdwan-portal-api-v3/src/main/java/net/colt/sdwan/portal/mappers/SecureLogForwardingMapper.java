package net.colt.sdwan.portal.mappers;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.model.SecureLogForwardingHistoryResponseV1;
import net.colt.sdwan.portal.model.SecureLogForwardingRequestV1;
import net.colt.sdwan.portal.model.SecureLogForwardingResponseV1;
import net.colt.sdwan.security.api.generated.model.SecureLogForwardingApiRequestV1;
import net.colt.sdwan.security.api.generated.model.SecureLogForwardingApiResponseV1;
import net.colt.sdwan.security.api.generated.model.SecureLogForwardingHistoryApiResponseV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class SecureLogForwardingMapper {

    private final ModelMapper modelMapper;

    public SecureLogForwardingApiRequestV1 from(SecureLogForwardingRequestV1 secureLogForwardingRequestV1) {
        return modelMapper.map(secureLogForwardingRequestV1, SecureLogForwardingApiRequestV1.class);
    }

    public List<SecureLogForwardingHistoryResponseV1> from(List<SecureLogForwardingHistoryApiResponseV1> history) {
        final List<SecureLogForwardingHistoryResponseV1> result = new ArrayList<>();
        history.forEach(historyItem -> result.add(modelMapper.map(historyItem, SecureLogForwardingHistoryResponseV1.class)));
        return result;
    }

    public SecureLogForwardingResponseV1 from(SecureLogForwardingApiResponseV1 historyItem) {
        return modelMapper.map(historyItem, SecureLogForwardingResponseV1.class);
    }
}
