package net.colt.sdwan.portal.security;

import feign.FeignException;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanServiceUnavailableException;
import net.colt.sdwan.common.exceptions.exception.SdwanUnauthorizedException;
import net.colt.sdwan.portal.client.feign.session.SessionApiFeign;
import net.colt.sdwan.portal.model.ApiUserKeyResponseModel;
import net.colt.sdwan.portal.security.models.RequestDetails;
import net.colt.sdwan.portal.services.ApiUserService;
import net.colt.sdwan.portal.services.SystemStatusService;
import net.colt.sdwan.session.api.generated.model.SdwanSessionResponseV1;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

import static java.util.Objects.nonNull;

@RequiredArgsConstructor
@Component
@Slf4j
public class TokenFilter implements HandlerInterceptor {

    public static final String X_AUTH_TOKEN = "x-auth-token";

    private static final Pattern managementPattern = Pattern.compile("\\/management\\/*");
    public static final String X_COLT_USER_AGENT="X-Colt-User-Agent";
    public static final String API_CLIENT="api-client";

    private final SessionApiFeign sessionApiFeign;
    private final SystemStatusService systemStatusService;
    private final CustomAuthenticationProvider customAuthenticationProvider;
    private final ApiUserService apiUserService;

    @Value("${session.path}")
    private String sessionPath;

    @Value("${branding.path}")
    private String brandingPath;

    @Value("${planned.messages.path}")
    private String plannedMessages;

    @Value("${renew.api.key.path}")
    private String renewApiKeyPath;

    private List<RequestDetails> pathsNoSessionCheck;

    @PostConstruct
    private void init() {
        pathsNoSessionCheck = List.of(
                new RequestDetails(sessionPath, HttpMethod.POST),
                new RequestDetails(sessionPath, HttpMethod.OPTIONS),
                new RequestDetails(sessionPath, HttpMethod.DELETE),
                new RequestDetails(brandingPath, HttpMethod.GET),
                new RequestDetails(plannedMessages, HttpMethod.GET),
                new RequestDetails(renewApiKeyPath, HttpMethod.POST));
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws IOException, SdwanUnauthorizedException, SdwanServiceUnavailableException {

        log.debug("Checking session for {} {}", request.getServletPath(), request.getMethod());
        if (StringUtils.isNotEmpty(request.getServletPath())
                && (pathsNoSessionCheck.stream().anyMatch(
                path -> request.getServletPath().contains(path.getPath())
                        && path.getMethod().name().equals(request.getMethod())) ||
                managementPattern.matcher(request.getServletPath()).find())) {
            log.debug("Skipped token checking for {} {}", request.getServletPath(), request.getMethod());
            return true;
        }
        final String token=request.getHeader(X_AUTH_TOKEN);

        final String coltUserAgent=request.getHeader(X_COLT_USER_AGENT);
        boolean isApiUserAgent =StringUtils.isNotBlank(coltUserAgent) && coltUserAgent.endsWith(API_CLIENT);


        if (StringUtils.isNotEmpty(token)) {
            if (isApiUserAgent) {
                log.info("Request from Api-client {}",coltUserAgent);
                return validateApiUserKey(token,coltUserAgent);
            } else if (StringUtils.isBlank(coltUserAgent) || coltUserAgent.equals("portal-ui")){
                return  validateToken(token);
            }
            else {
                throw new SdwanUnauthorizedException("Not a valid X-Colt-User-Agent "+coltUserAgent);
            }
        }
        throw new SdwanUnauthorizedException("Missing token");
    }

    private boolean validateApiUserKey(String userApiKey,String userAgent) {
        try {
            ApiUserKeyResponseModel responseV1=apiUserService.getApiUserBasedOnKey(userApiKey,userAgent);
            if (Objects.nonNull(responseV1) && Objects.nonNull(responseV1.getTenantId())) {
                customAuthenticationProvider.createApiUSerSecurityContext(userAgent,List.of(responseV1.getTenantId()));
                return true;
            } else {
                throw new SdwanUnauthorizedException("Api User key is invalid");
            }
        } catch (FeignException fe) {
            log.error("Failed to validate Api User API: {}", fe.getMessage());
            return false;
        }
    }

    private boolean validateToken(String token) {
        try {
            final ResponseEntity<SdwanSessionResponseV1> responseEntity = sessionApiFeign.getSdwanSessionV1(token);
            if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && responseEntity.hasBody()) {
                return handleValidToken(token);
            } else {
                handleNotValidToken(token, null);
            }
        } catch (FeignException fe) {
            log.error("Error while calling Session API: {}", fe.getMessage());
            handleNotValidToken(token, fe);
        }
        return false;
    }
    private boolean handleValidToken(final String token) throws SdwanServiceUnavailableException {
        if (systemStatusService.isSystemModuleDisabled("SYSTEM")) {
            throw new SdwanServiceUnavailableException("System module disabled");
        }
        try {
            final SdwanSessionResponseV1 refreshedToken = sessionApiFeign.refreshSdwanSessionV1(token).getBody();
            if (nonNull(refreshedToken)) {
                customAuthenticationProvider.createSecurityContext(refreshedToken);
                return true;
            }
            return false;
        } catch (FeignException fe) {
            log.error("Failed to process refresh SD-WAN token operation: {}", fe.getMessage());
            return false;
        }
    }

    private void handleNotValidToken(final String token, @Nullable Throwable cause) throws SdwanUnauthorizedException {
        try {
            sessionApiFeign.deleteSdwanSessionV1(token);
        } catch (FeignException fe) {
            log.error("Failed to process delete SD-WAN token operation: {}", fe.getMessage());
        }
        throw new SdwanUnauthorizedException("Token invalid", cause);
    }
}
