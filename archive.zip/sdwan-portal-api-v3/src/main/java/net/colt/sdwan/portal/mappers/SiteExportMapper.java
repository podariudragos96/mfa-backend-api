package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.generated.model.service.SiteExportCriteria;
import org.mapstruct.Mapper;

@Mapper
public interface SiteExportMapper {

    SiteExportCriteria toSiteExportCriteria(net.colt.sdwan.portal.model.SiteExportCriteria siteExportCriteria);
}
