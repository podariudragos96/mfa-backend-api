package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.portal.client.model.customerapi.UserResponseV3;
import net.colt.sdwan.portal.database.entities.SsoDomain;
import net.colt.sdwan.portal.database.repositories.SsoDomainRepository;
import net.colt.sdwan.portal.model.AccountLookupRequestV1;
import net.colt.sdwan.portal.model.AccountLookupResponseV1;
import net.colt.sdwan.portal.services.ColtOnlineAuthService;
import net.colt.sdwan.portal.services.PortalAuthService;
import net.colt.sdwan.portal.services.TenantUserAuthService;
import net.colt.sdwan.portal.util.XColtHostUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

import static org.apache.commons.lang3.StringUtils.isEmpty;

@RequiredArgsConstructor
@Service
@Slf4j
public class PortalAuthServiceImpl implements PortalAuthService {

    private final XColtHostUtil xColtHostUtil;
    private final ColtOnlineAuthService coltOnlineAuthService;
    private final TenantUserAuthService tenantUserAuthService;
    private final SsoDomainRepository ssoDomainRepository;

    private boolean coltOnlineSSOActive;

    @Override
    public UserResponseV3 doAuthentication(String domain, String username, String password) {
        if (xColtHostUtil.isColtDomain(domain)) {
            log.debug("Authenticate with colt domain: {}", domain);
            return coltOnlineAuthService.doAuthentication(username, password);
        } else {
            log.debug("Authenticate without colt domain: {}", domain);
            return tenantUserAuthService.doAuthentication(domain, username, password);
        }
    }

    @Override
    public AccountLookupResponseV1 accountLookup(String domain, AccountLookupRequestV1 accountLookupRequestV1) {

        String username = accountLookupRequestV1.getUsername();
        AccountLookupResponseV1 response = new AccountLookupResponseV1();

        if (isEmpty(username)) {
            throw new SdwanBadRequestException("Username can't be empty");
        }

        final List<SsoDomain> ssoDomainList = ssoDomainRepository.findAll();

        ssoDomainList.stream()
                .filter(sso -> !isEmpty(sso.getDomain().trim()) && username.endsWith(sso.getDomain()))
                .findFirst()
                .ifPresent(s -> response.setTargetLocation(s.getUrl()));

        if (isEmpty(response.getTargetLocation()) && coltOnlineSSOActive && xColtHostUtil.isColtDomain(domain)) {
            ssoDomainList.stream()
                    .filter(sso -> sso.getDomain() != null && isEmpty(sso.getDomain().trim()))
                    .findFirst()
                    .ifPresent(s -> response.setTargetLocation(s.getUrl()));
        }

        return response;
    }

    @Value("${portal.saml.colt.online.enabled:false}")
    public void setColtOnlineSSOActive(boolean coltOnlineSSOActive) {
        this.coltOnlineSSOActive = coltOnlineSSOActive;
    }

}
