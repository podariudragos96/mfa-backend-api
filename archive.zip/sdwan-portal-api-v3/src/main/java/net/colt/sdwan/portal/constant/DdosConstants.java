package net.colt.sdwan.portal.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DdosConstants {

    public static final String UPDATE_DDOS_ERROR_MSG = "Failed to update DDOS Rules";
}
