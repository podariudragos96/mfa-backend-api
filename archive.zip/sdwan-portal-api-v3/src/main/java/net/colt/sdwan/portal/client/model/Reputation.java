package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class Reputation {

    @JsonProperty("action")
    private String action;

    @JsonProperty("reputation")
    private List<String> reputations;
}
