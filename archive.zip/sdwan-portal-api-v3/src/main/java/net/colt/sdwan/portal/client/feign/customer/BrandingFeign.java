package net.colt.sdwan.portal.client.feign.customer;

import net.colt.sdwan.portal.generated.customerapi.controllers.BrandingApiApi;
import org.springframework.cloud.openfeign.FeignClient;


@FeignClient(name = "brandingClient", url = "${sdwan.customer.api.baseurl}", configuration = CustomerFeignConfiguration.class)
public interface BrandingFeign extends BrandingApiApi {

}
