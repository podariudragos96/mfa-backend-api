package net.colt.sdwan.portal.client.feign.customer;

import feign.auth.BasicAuthRequestInterceptor;
import net.colt.sdwan.common.data.criteria.config.AbstractCriteriaApiFeignConfiguration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

public class CustomerFeignConfiguration extends AbstractCriteriaApiFeignConfiguration {

    protected String username;
    protected String password;

    public CustomerFeignConfiguration(
            @Value("${sdwan.customer.api.user}") String username,
            @Value("${sdwan.customer.api.pwd}") String password) {
        this.username = username;
        this.password = password;
    }

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        return new BasicAuthRequestInterceptor(username, password);
    }
}
