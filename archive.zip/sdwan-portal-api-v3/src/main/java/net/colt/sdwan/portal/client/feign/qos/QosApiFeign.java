package net.colt.sdwan.portal.client.feign.qos;

import net.colt.sdwan.qos.api.generated.api.QosApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "qosApiClient", url = "${sdwan.qos.api.baseurl}",
        configuration = QosApiFeignConfiguration.class)
public interface QosApiFeign extends QosApiApi {
}
