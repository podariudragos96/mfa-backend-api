package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@EqualsAndHashCode
public class UploadCustomerManagedCertificateRequest {

    @JsonProperty("certificate_data")
    private String certificateData;

    @JsonProperty("private_key_data")
    private String privateKeyData;

    @JsonProperty("ca_chain_data")
    private String caChainData;
}
