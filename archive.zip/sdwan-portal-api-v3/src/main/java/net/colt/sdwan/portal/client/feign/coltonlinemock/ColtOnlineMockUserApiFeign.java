package net.colt.sdwan.portal.client.feign.coltonlinemock;

import net.colt.sdwan.coltonlinemock.api.generated.api.UserApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "coltOnlineMockApiClient", url = "${sdwan.colt-online-mock.api.baseurl}",
        configuration = ColtOnlineMockApiFeignConfiguration.class)
public interface ColtOnlineMockUserApiFeign extends UserApi {
}
