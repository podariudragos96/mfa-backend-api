package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * NetFlowCollectorResponseV1
 */
@Setter
@Getter
@NoArgsConstructor
public class NetFlowCollectorResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("number")
    private Integer number;

    @JsonProperty("vpn")
    private String vpn;

    @JsonProperty("descrption")
    private String descrption;

    @JsonProperty("ip")
    private String ip;

    @JsonProperty("port")
    private Integer port;
    @JsonProperty("protocol")
    private ProtocolEnum protocol;
    @JsonProperty("hosted_on_internet")
    private Boolean hostedOnInternet;

    /**
     * Gets or Sets protocol
     */
    public enum ProtocolEnum {
        TCP("TCP"),

        UDP("UDP");

        private String value;

        ProtocolEnum(String value) {
            this.value = value;
        }

        @JsonCreator
        public static ProtocolEnum fromValue(String text) {
            for (ProtocolEnum b : ProtocolEnum.values()) {
                if (String.valueOf(b.value).equals(text)) {
                    return b;
                }
            }
            throw new IllegalArgumentException("Unexpected value '" + text + "'");
        }

        @Override
        @JsonValue
        public String toString() {
            return String.valueOf(value);
        }
    }
}

