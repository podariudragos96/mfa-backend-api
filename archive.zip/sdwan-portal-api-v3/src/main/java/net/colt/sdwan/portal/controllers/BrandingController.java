package net.colt.sdwan.portal.controllers;

import jakarta.servlet.http.HttpServletRequest;
import net.colt.sdwan.portal.generated.controllers.BrandingApiApi;
import net.colt.sdwan.portal.model.BrandingPortalResponseV1;
import net.colt.sdwan.portal.security.XColtHostFilter;
import net.colt.sdwan.portal.services.BrandingService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

@Controller
public class BrandingController extends AbstractHttpServletController implements BrandingApiApi {

    private final BrandingService brandingService;

    public BrandingController(HttpServletRequest request, BrandingService brandingService) {
        super(request);
        this.brandingService = brandingService;
    }

    @Override
    public ResponseEntity<BrandingPortalResponseV1> getBrandingV1() {
        return ResponseEntity.ok(brandingService.getBranding(getHeaderValue(XColtHostFilter.X_COLT_HOST)));
    }
}
