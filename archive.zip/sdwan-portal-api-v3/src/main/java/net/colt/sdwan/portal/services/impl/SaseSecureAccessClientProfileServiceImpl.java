package net.colt.sdwan.portal.services.impl;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.utils.SdwanExceptionUtils;
import net.colt.sdwan.generated.model.versa.sase.api.SecureAccessClientProfilesResponseApiV1;
import net.colt.sdwan.portal.client.feign.sase.SaseSecureAccessClientProfileFeign;
import net.colt.sdwan.portal.enums.SaseOperation;
import net.colt.sdwan.portal.mappers.SaseSecureAccessClientProfileMapper;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SecureAccessClientProfilesRequestV1;
import net.colt.sdwan.portal.model.SecureAccessClientProfilesResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.SaseSecureAccessClientProfileService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;

@Service
@RequiredArgsConstructor
@Slf4j
public class SaseSecureAccessClientProfileServiceImpl implements SaseSecureAccessClientProfileService {

    private final ResponseEntityValidator responseEntityValidator;
    private final SaseSecureAccessClientProfileMapper mapper;
    private final SaseSecureAccessClientProfileFeign feign;

    @Override
    public SecureAccessClientProfilesResponseV1 getSecureAccessClientProfilesV1(String tenantUuid) {
        log.info("Getting sase secure access client profiles via sase-api for tenantUuid={}", tenantUuid);

        final ResponseEntity<SecureAccessClientProfilesResponseApiV1> saseApiResp = feign.getSecureAccessClientProfilesV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(saseApiResp, SaseOperation.SECURE_ACCESS_CLIENT_PROFILES.getName());

        log.info("Get sase secure access client profiles request completed successfully for tenantUuid={}.", tenantUuid);
        return mapper.from(requireNonNull(saseApiResp.getBody()));
    }

    @Override
    public CorrelationIdResponseV1 updateSecureAccessClientProfilesV1(
            String tenantUuid, SecureAccessClientProfilesRequestV1 request) {
        log.info("Updating sase secure access client profiles for tenantUuid={} ...", tenantUuid);

        try {
            final UserAuth userAuth = requireNonNull(AuthUserHelper.getAuthUser());

            feign.updateSecureAccessClientProfilesV1(userAuth.getUsername(), tenantUuid, mapper.from(request));
            log.info("Update sase secure access client profiles request was completed successfully for initiatedUserId={} and tenantUuid={}.",
                    userAuth.getUsername(), tenantUuid);

        } catch (FeignException e) {
            final String errorMsg = String.format("Failed to update Secure Access Client Profiles for tenantUuid=%s.", tenantUuid);
            throw SdwanExceptionUtils.buildSdwanException(e.status(), errorMsg);
        }

        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));

    }

}
