package net.colt.sdwan.portal.client.model;

public enum SSLDecryptionLogsAction {
    ALLOW, ALERT, REJECT, NONE;
}
