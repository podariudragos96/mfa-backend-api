package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@ToString
@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FWRuleLogEvents {

    @JsonProperty("device")
    private String device;

    @JsonProperty("timestamp")
    private String timestamp;

    @JsonProperty("src_ip")
    private String srcIP;

    @JsonProperty("dst_ip")
    private String dstIP;

    @JsonProperty("src_port")
    private Integer srcPort;

    @JsonProperty("dst_port")
    private Integer dstPort;

    @JsonProperty("protocol")
    private String protocol;

    @JsonProperty("action")
    private String action;

    @JsonProperty("type")
    private String type;

    @JsonProperty("session_id")
    private String sessionId;

    @JsonProperty("application")
    private String application;
}
