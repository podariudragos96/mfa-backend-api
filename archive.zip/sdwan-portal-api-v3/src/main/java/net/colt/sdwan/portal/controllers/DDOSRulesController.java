package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.DdosApiApi;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.DDOSRulesService;
import net.colt.sdwan.portal.validator.model.DdosRulesRequestValidator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;
import java.util.List;

import static org.springframework.http.HttpStatus.OK;

@RequiredArgsConstructor
@Controller
public class DDOSRulesController implements DdosApiApi {

    private final DDOSRulesService ddosRulesService;
    private boolean ddosNewEndpointEnabled;


    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setValidator(new DdosRulesRequestValidator());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<DdosRuleSetResponseV1> getDDOSRulesBySiteIdV2(String siteId) {
        return new ResponseEntity<>(ddosRulesService.getDDOSRulesBySiteIdV2(siteId), OK);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<DdosRuleSetResponseV1> getDDOSRulesHistoryBySiteIdAndRuleSetIdV1(String siteId,String id) {
        return new ResponseEntity<>(ddosRulesService.getDDOSRulesHistoryBySiteIdAndRuleSetIdV1(siteId, id), OK);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<DdosRuleHistoryResponseV1>> getDDOSRulesHistoryBySiteIdV1(String siteId) {
        return new ResponseEntity<>(ddosRulesService.getDDOSRulesHistoryBySiteIdV1(siteId), OK);
    }

    @Override
    @SDWanAsyncMethod("/v2/sites/{site_id}/ddos_rules")
    @PreAuthorize("hasAnyAuthority('SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateDDOSRulesBySiteIdV2(String siteId,
                                                                             @RequestBody DdosRulesRequestV1 ddosRulesRequestV1) {
        return ResponseEntity.ok(ddosNewEndpointEnabled ?
                ddosRulesService.updateDDOSRulesBySiteIdV3(siteId, ddosRulesRequestV1) :
                ddosRulesService.updateDDOSRulesBySiteIdV2(siteId, ddosRulesRequestV1));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<DdosEventLogsResponseV1> getDdosEventLogsBySiteIdV1(
            String siteId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt) {
        return ResponseEntity.ok(ddosRulesService.getDdosEventLogsBySiteIdV1(siteId, startDt, endDt));
    }

    @Value("${ddos.newendpoint.enabled}")
    public void setNewDdosEndpointEnabled(boolean ddosNewEndpointEnabled) {
        this.ddosNewEndpointEnabled = ddosNewEndpointEnabled;
    }

}
