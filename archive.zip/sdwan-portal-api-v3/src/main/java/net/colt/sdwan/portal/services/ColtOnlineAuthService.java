package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.client.model.customerapi.UserResponseV3;
import net.colt.sdwan.portal.security.models.UserAuth;

/**
 * This Service supports the authentication process present in Test Environments (DEV/QAs/SIT/DEMO).
 */
public interface ColtOnlineAuthService {

    /**
     * IMPORTANT! This authentication no longer connects to Colt Online Webservice.
     * This flow its only used for test environments (DEV/QAs/SIT/DEMO) and emulates Colt Online Basic Authentication to access portal during login.
     * It is totally controlled by our team through sdwan-colt-online-mock-api-v2.
     * RFS and PROD uses Colt Online SSO which is a different Auth process.
     * Here follows the mock process:
     * Step 1. Authenticate user into the colt online mock platform
     * Step 2. Check if the user has the needed roles to access resources
     * Step 3. Handle the user customer OCN authorization use cases
     *
     * @param username colt online mock username
     * @param password colt online mock password
     * @return the UserResponseV3 result
     */
    UserResponseV3 doAuthentication(String username, String password);



    /**
     * Retrieve the user roles from colt online mock and map them to spring security roles
     *
     * @param username colt online mock username
     * @return @authUser having the roles
     */
    UserAuth accessUserAuthorities(final String username);

}
