package net.colt.sdwan.portal.services.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.data.criteria.filter.LongFilter;
import net.colt.sdwan.common.data.criteria.filter.StringFilter;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.generated.model.service.SiteCriteria;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.AnalyticsApiClient;
import net.colt.sdwan.portal.client.ServiceApiClient;
import net.colt.sdwan.portal.client.model.FirewallRulesNamesNetworkApiResponse;
import net.colt.sdwan.portal.client.model.FirewallRulesNetworkApiResponse;
import net.colt.sdwan.portal.mappers.FirewallAnalyticsRuleNameResponseMapper;
import net.colt.sdwan.portal.mappers.FirewallRulesNetworkResponseMapper;
import net.colt.sdwan.portal.mappers.NetworkResponseMapper;
import net.colt.sdwan.portal.model.FirewallAnalyticsRuleNameResponseV1;
import net.colt.sdwan.portal.model.FirewallRulesActionV1;
import net.colt.sdwan.portal.model.FirewallRulesNetworkResponseV1;
import net.colt.sdwan.portal.model.NetworkResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.NetworksService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@RequiredArgsConstructor
@Service
public class NetworksServiceImpl implements NetworksService {

    private final AnalyticsApiClient analyticsApiClient;
    private final ServiceApiClient serviceApiClient;
    private final FirewallRulesNetworkResponseMapper firewallRulesNetworkResponseMapper;
    private final FirewallAnalyticsRuleNameResponseMapper firewallAnalyticsRuleNameResponseMapper;

    @Override
    public List<FirewallRulesNetworkResponseV1> getFirewallRulesByNetworkId(String networkId,
                                                                            FirewallRulesActionV1 action, LocalDateTime startDt, LocalDateTime endDt, Integer count) {
        if (StringUtils.isBlank(networkId)) {
            throw new SdwanNotFoundException("Network id cannot be null, empty or blank.");
        }

        StringFilter versaOrg = new StringFilter();
        versaOrg.setEquals(networkId);
        SiteCriteria siteCriteria = new SiteCriteria();
        siteCriteria.setVersaOrg(versaOrg);

        List<SiteResponseV1> sites = serviceApiClient.getSiteDetailsByCriteria(siteCriteria);
        if (Objects.isNull(sites) || sites.isEmpty()) {
            throw new SdwanBadRequestException("Site was not found.");
        }
        List<FirewallRulesNetworkApiResponse> networkResponses;
        networkResponses = analyticsApiClient.getFirewallNetworkTopAnalytics(sites.get(0).getVersaAnalyticsInstance(), networkId, action, startDt, endDt, count);
        return firewallRulesNetworkResponseMapper.mapFromNetworkApiResponse(networkResponses);
    }

    @Override
    public List<FirewallAnalyticsRuleNameResponseV1> getFirewallAnalyticsByRuleName(String ruleName, String networkId,
                                                                                    FirewallRulesActionV1 action, LocalDateTime startDt, LocalDateTime endDt) {
        if (StringUtils.isBlank(networkId) || StringUtils.isBlank(ruleName)) {
            throw new SdwanNotFoundException("Network id and rule name cannot be null, empty or blank.");
        }

        StringFilter versaOrg = new StringFilter();
        versaOrg.setEquals(networkId);
        SiteCriteria siteCriteria = new SiteCriteria();
        siteCriteria.setVersaOrg(versaOrg);

        List<SiteResponseV1> sites = serviceApiClient.getSiteDetailsByCriteria(siteCriteria);
        if (Objects.isNull(sites) || sites.isEmpty()) {
            throw new SdwanBadRequestException("Sites was not found.");
        }

        try {
            FirewallRulesNamesNetworkApiResponse networkApiResponse = analyticsApiClient
                    .getFirewallAnalyticsByRuleName(sites.get(0).getVersaAnalyticsInstance(), networkId, ruleName, action, startDt, endDt);
            return firewallAnalyticsRuleNameResponseMapper.mapFromResponseList(networkApiResponse);
        } catch (JsonProcessingException e) {
            log.error("error parsing analytics json", e);
            throw new SdwanInternalServerErrorException("Error parsing analytics JSON.", e);
        }
    }

    @Override
    public List<NetworkResponseV1> getNetworks() {
        final List<Integer> userTenantIds = Objects.requireNonNull(AuthUserHelper.getAuthUser()).getAccessibleTenantIds();

        StringFilter statusFilter = new StringFilter();
        statusFilter.setEquals("ACTIVE");

        LongFilter tenantIdFilter = new LongFilter();
        tenantIdFilter.setIn(userTenantIds.stream().map(Long::valueOf).toList());

        SiteCriteria siteCriteria = new SiteCriteria();
        siteCriteria.setSiteStatus(statusFilter);
        siteCriteria.setTenantId(tenantIdFilter);

        final Set<String> networks = serviceApiClient.getSiteDetailsByCriteria(siteCriteria).stream().map(SiteResponseV1::getNetworkId).collect(Collectors.toSet());
        return NetworkResponseMapper.mapNetworkResponsesFromNetworks(networks).stream().sorted(Comparator.comparing(NetworkResponseV1::getId))
                .toList();
    }
}
