package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.List;

@EqualsAndHashCode(exclude = "data")
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class AnalyticsTimeSeries {

    @JsonProperty("metric")
    private AnalyticsMetricEnum metric;

    @JsonProperty("label")
    private AnalyticsLabelEnum label;

    @JsonProperty("data")
    private List<List<BigDecimal>> data;

}
