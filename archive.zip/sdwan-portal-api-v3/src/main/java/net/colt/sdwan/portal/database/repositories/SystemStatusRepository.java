package net.colt.sdwan.portal.database.repositories;

import net.colt.sdwan.portal.enums.NovitasSystemStatus;
import net.colt.sdwan.portal.model.SystemStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SystemStatusRepository extends JpaRepository<SystemStatus, Integer> {

    List<SystemStatus> findByStatus(NovitasSystemStatus status);

    SystemStatus findByModuleAndStatus(String module, NovitasSystemStatus status);

}