package net.colt.sdwan.portal.services.impl;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.async.utils.ThreadUtils;
import net.colt.sdwan.portal.client.feign.customer.CustomerFeign;
import net.colt.sdwan.portal.client.model.customerapi.CustomerResponseV1;
import net.colt.sdwan.portal.client.model.customerapi.CustomerStatus;
import net.colt.sdwan.portal.client.model.customerapi.CustomerSummaryResponseV1;
import net.colt.sdwan.portal.client.model.customerapi.UpdateCustomerRequestV1;
import net.colt.sdwan.portal.services.CustomerService;
import net.colt.sdwan.portal.util.CompletableFutureUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class CustomerServiceImpl implements CustomerService {

    private final CustomerFeign customerFeign;

    /**
     * Create a user by having the customer entity data set
     *
     * @param customer
     * @return
     */
    @Override
    public void save(Integer customerId, UpdateCustomerRequestV1 customer) {
        customerFeign.updateCustomerV1(customerId, customer);
    }

    /**
     * Find customer by the given ocn value
     *
     * @param ocn
     * @return
     */
    @Override
    public CustomerSummaryResponseV1 findByOcn(String ocn) {
        CustomerSummaryResponseV1 customerSummaryResponse = null;
        try {
            if (StringUtils.isNotBlank(ocn)) {
                ResponseEntity<List<CustomerSummaryResponseV1>> customerResponses =
                        customerFeign.getCustomerbyParamsV1(ocn, "", CustomerStatus.ACTIVE);
                final List<CustomerSummaryResponseV1> body = customerResponses.getBody();
                if (customerResponses.getStatusCode().equals(HttpStatus.OK) && CollectionUtils.isNotEmpty(body)) {
                    customerSummaryResponse = body.get(0);
                }
            }
        } catch (Exception e) {
            log.error("Exception thrown while getting the customer summary response by ocn: {} | {}",
                    ocn, e);
        }
        return customerSummaryResponse;
    }

    /**
     * @param customerId
     * @return
     */
    @Override
    public CustomerResponseV1 findById(Integer customerId) {
        ResponseEntity<CustomerResponseV1> customerResponse = customerFeign.getCustomerV1(customerId);
        if (customerResponse.getStatusCode().equals(HttpStatus.OK)
                && Objects.nonNull(customerResponse.getBody())) {
            return customerResponse.getBody();
        }
        return null;
    }

    /**
     * Find customer by the given ocn versaOrgName
     *
     * @param versaOrgName
     * @return
     */
    @Override
    public CustomerSummaryResponseV1 findByVersaOrgName(final String versaOrgName) {
        ResponseEntity<List<CustomerSummaryResponseV1>> customerResponses = customerFeign.getCustomerbyParamsV1("", versaOrgName, CustomerStatus.ACTIVE);
        final List<CustomerSummaryResponseV1> body = customerResponses.getBody();
        if (customerResponses.getStatusCode().equals(HttpStatus.OK) && CollectionUtils.isNotEmpty(body)) {
            return body.get(0);
        }
        return null;
    }

    /**
     * Find all customers by a given id list
     *
     * @param ids
     * @return the list of the customers found
     */
    @Override
    public List<CustomerResponseV1> findAllByIdList(final List<Integer> ids) {
        final List<CompletableFuture<CustomerResponseV1>> customerResponsesEvents = ids.stream()
                .map(id -> CompletableFuture.supplyAsync(ThreadUtils.withMdc(() -> findById(id))))
                .toList();
        final Set<CustomerResponseV1> completableFutureValues = CompletableFutureUtil.getCompletableFutureValues(customerResponsesEvents);

        return new ArrayList<>(completableFutureValues);
    }

    @Override
    public List<CustomerSummaryResponseV1> findAllByOcnList(List<String> ocnList) {
        final List<CompletableFuture<List<CustomerSummaryResponseV1>>> customerResponsesEvents = ocnList.stream()
                .filter(StringUtils::isNotBlank)
                .map(ocn -> CompletableFuture.supplyAsync(ThreadUtils.withMdc(() ->
                        customerFeign.getCustomerbyParamsV1(ocn, "", CustomerStatus.ACTIVE).getBody())))
                .toList();

        final Set<List<CustomerSummaryResponseV1>> completableFutureValues = CompletableFutureUtil.getCompletableFutureValues(customerResponsesEvents);
        return completableFutureValues
                .stream()
                .flatMap(List::stream)
                .toList();
    }

}