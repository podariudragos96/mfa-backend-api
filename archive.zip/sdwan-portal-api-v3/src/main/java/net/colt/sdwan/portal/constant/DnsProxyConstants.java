package net.colt.sdwan.portal.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DnsProxyConstants {

    // Feature definition
    public static final String DNS_FEATURE_NAME = "DNS Proxy";

    // Error messages
    public static final String DNS_ONLY_AVAILABLE_ON_BRANCH_SITES = "DNS Proxy is only available for sites of type branch";


}
