package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.DecryptionApiApi;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.DecryptionService;
import net.colt.sdwan.portal.validator.model.DecryptionRulesRequestV1Validator;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;
import java.util.List;

@RequiredArgsConstructor
@Controller
public class DecryptionController implements DecryptionApiApi {

    private final DecryptionService decryptionService;
    private final DecryptionRulesRequestV1Validator validator;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setValidator(validator);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<DecryptionRuleSetResponseV1> getDecryptionRulesBySiteIdV2(String siteId) {
        return ResponseEntity.ok(decryptionService.getDecryptionRulesBySiteIdV2(siteId));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<DecryptionRuleSetResponseV1> getDecryptionRulesHistoryBySiteIdAndRuleSetIdV1(String siteId, String id) {
        return ResponseEntity.ok(decryptionService.getDecryptionRulesHistoryBySiteIdAndRulesSetIdV2(siteId, id));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<DecryptionRulesHistoryResponseV1>> getDecryptionRulesHistoryBySiteIdV1(String siteId) {
        return ResponseEntity.ok(decryptionService.getDecryptionRulesHistoryBySiteIdV2(siteId));
    }

    @Override
    @SDWanAsyncMethod("/v2/sites/{site_id}/decryption_rules")
    @PreAuthorize("hasAnyAuthority('SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateDecryptionRulesBySiteIdV2(String siteId,
                                                                                   @RequestBody DecryptionRulesRequestV1 decryptionRulesRequestV1) {
        return ResponseEntity.ok(decryptionService.updateDecryptionRulesBySiteIdV2(siteId, decryptionRulesRequestV1));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<SSLDecryptionLogsResponseV1>> getSSLDecryptionLogsBySiteIdV1(String siteId,
                                                                                            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) @RequestParam(value = "start_dt", required = true) LocalDateTime startDt,
                                                                                            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) @RequestParam(value = "end_dt", required = true) LocalDateTime endDt) {
        return ResponseEntity.ok(decryptionService.getSSLDecryptionLogsBySiteIdV1(siteId, startDt, endDt));
    }

}
