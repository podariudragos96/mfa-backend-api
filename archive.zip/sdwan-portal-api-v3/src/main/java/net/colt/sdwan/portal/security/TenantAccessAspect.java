package net.colt.sdwan.portal.security;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.common.exceptions.exception.SdwanException;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.portal.client.helper.CustomerClientHelper;
import net.colt.sdwan.portal.client.helper.TenantClientHelper;
import net.colt.sdwan.portal.client.helper.TenantUserClientHelper;
import net.colt.sdwan.portal.client.model.customerapi.CustomerResponseV1;
import net.colt.sdwan.portal.client.model.customerapi.TenantResponseV1;
import net.colt.sdwan.portal.client.model.customerapi.TenantUserResponseV1;
import net.colt.sdwan.portal.util.CacheUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Component;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.*;
import java.util.stream.IntStream;

import static java.lang.Boolean.FALSE;
import static java.util.Objects.nonNull;

@RequiredArgsConstructor
@Slf4j
@Component
@Aspect
public class TenantAccessAspect {

    private static final String TENANT_USER_ID_FIELD = "tenantUserId";
    private static final String TENANT_ID_FIELD = "tenantId";
    private static final String GETTER_PREFIX = "get";

    private final CustomerClientHelper customerClientHelper;
    private final TenantClientHelper tenantClientHelper;
    private final TenantUserClientHelper tenantUserClientHelper;

    private final CacheUtils cacheUtils = new CacheUtils(300);

    /**
     * Extract Tenant Id or Customer Id and check that the current user can
     * view/edit it.
     *
     * @param joinPoint Method details
     */
    @Before("execution (* net.colt.sdwan.portal.services.TenantService.getTenantByParams(..)) || "
            + "execution (* net.colt.sdwan.portal.services.TenantService.addTenant(..)) || "
            + "execution (* net.colt.sdwan.portal.services.TenantService.getTenantById(..)) || "
            + "execution (* net.colt.sdwan.portal.services.TenantService.editTenant(..)) || "
            + "execution (* net.colt.sdwan.portal.services.TenantService.getTenantIdsByCustomerId(..)) || "
            + "execution (* net.colt.sdwan.portal.services.TenantService.getTenantUserByTenantId(..)) || "
            + "execution (* net.colt.sdwan.portal.services.TenantUserService.addTenantUser(..)) || "
            + "execution (* net.colt.sdwan.portal.services.TenantUserService.getTenantUserById(..)) || "
            + "execution (* net.colt.sdwan.portal.services.TenantUserService.editTenantUser(..))")
    public void checkBeforeUserPermission(JoinPoint joinPoint) {
        log.debug("Before: check user permission for {}", joinPoint.getSignature().toShortString());
        try {
            checkAllowedTenantId(extractField(joinPoint, TENANT_ID_FIELD));
            checkAllowedTenantUserId(extractField(joinPoint, TENANT_USER_ID_FIELD));

        } catch (SdwanException | AccessDeniedException apie) {
            throw apie;
        } catch (InvocationTargetException | IllegalAccessException e) {
            log.error("Error trying to get access to the tenant/customer id ", e);
            throw new SdwanInternalServerErrorException("Check user permission for tenant access failed", e);
        }
    }

    /**
     * Check that the result doens't contains any tenant details that should not be
     * accessible by the current user.
     *
     * @param joinPoint Method details
     * @param result    returned result
     */

    @AfterReturning(pointcut = "execution (* net.colt.sdwan.portal.services.TenantService.getTenantByParams(..))", returning = "result")
    public void checkResultUserPermission(JoinPoint joinPoint, Object result) {
        log.debug("AfterReturning: check user permission for {} with result {}.",
                joinPoint.getSignature().toShortString(), result);
        try {
            if (nonNull(result)) {
                if (result instanceof Collection<?>) {
                    // If collection (mainly List)
                    checkCollectionObjects(joinPoint, result);
                } else {
                    checkAllowedTenantId(getFieldValue(result.getClass(), result, TENANT_ID_FIELD));
                    checkAllowedTenantUserId(extractField(joinPoint, TENANT_USER_ID_FIELD));
                }
            }
        } catch (SdwanException | AccessDeniedException apie) {
            throw apie;
        } catch (Exception e) {
            log.error("Error trying to get access to the tenant/customer id", e);
            throw new SdwanInternalServerErrorException("Check user permission for tenant access failed", e);
        }
    }

    private void checkCollectionObjects(JoinPoint joinPoint, Object result)
            throws SdwanException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        ParameterizedType type = castToParameterizedType(methodSignature.getMethod().getGenericReturnType());
        if (type.getActualTypeArguments().length == 1) {
            Class<?> actualClazz = (Class<?>) type.getActualTypeArguments()[0];
            if (nonNull(actualClazz)) {
                for (Object object : (Collection<?>) result) {
                    checkAllowedTenantId(getFieldValue(actualClazz, object, TENANT_ID_FIELD));
                    checkAllowedTenantUserId(extractField(joinPoint, TENANT_USER_ID_FIELD));
                }
            }
        }
    }

    /**
     * Extract the searched field value (customerId or tenantId) from the arguments
     * or body.
     *
     * @param joinPoint     current method details
     * @param searchedFiled customerId or tenantId
     * @return value of the field if found
     * @throws InvocationTargetException Reflexion Error
     * @throws IllegalAccessException    Reflexion Error
     * @throws IllegalArgumentException  Reflexion Error
     */
    private Integer extractField(JoinPoint joinPoint, String searchedFiled)
            throws InvocationTargetException, IllegalAccessException, IllegalArgumentException {
        Integer result = null;

        MethodSignature codeSignature = (MethodSignature) joinPoint.getSignature();
        result = extractFieldFromParameters(joinPoint, codeSignature, searchedFiled);

        if (Objects.isNull(result)) {
            result = extractFieldFromBody(joinPoint, codeSignature, searchedFiled);
        }

        return result;
    }

    private Integer extractFieldFromParameters(JoinPoint joinPoint, MethodSignature codeSignature,
                                               String searchedFiled) {
        Integer result = null;
        String[] parameterNames = codeSignature.getParameterNames();
        OptionalInt indexOpt = IntStream.range(0, parameterNames.length)
                .filter(i -> searchedFiled.equals(parameterNames[i])).findFirst();
        if (indexOpt.isPresent()) {
            result = (Integer) joinPoint.getArgs()[indexOpt.getAsInt()];
        }
        return result;
    }

    private Integer extractFieldFromBody(JoinPoint joinPoint, MethodSignature codeSignature, String searchedField)
            throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Integer result = null;
        Type[] types = codeSignature.getMethod().getGenericParameterTypes();
        Object[] args = joinPoint.getArgs();

        for (int i = 0; i < types.length && Objects.isNull(result); i++) {
            if (types[i] instanceof Class<?>) {
                result = getFieldValue((Class<?>) types[i], args[i], searchedField);
            } else {
                log.debug("This method won't be checked: {}", codeSignature);
            }
        }
        return result;
    }

    /**
     * Extract from the object of type clazz the value of searchField.
     *
     * @param clazz         the class of the object
     * @param object        the object that might contain the value
     * @param searchedField the field searched (customerId of tenantId)
     * @return the value of searched field if found
     * @throws IllegalAccessException    Reflexion Error
     * @throws IllegalArgumentException  Reflexion Error
     * @throws InvocationTargetException Reflexion Error
     */
    private Integer getFieldValue(Class<?> clazz, Object object, String searchedField)
            throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Integer result = null;
        final String getterMethodName = generateGetter(searchedField);
        Optional<Method> method = Arrays.asList(clazz.getMethods()).stream()
                .filter(m -> getterMethodName.equalsIgnoreCase(m.getName())).findAny();
        if (method.isPresent()) {
            result = (Integer) method.get().invoke(object);
        }
        return result;
    }

    /**
     * Check If the Tenant Id is allowed to the current user.
     *
     * @param tenantId tenant to check
     * @throws AccessDeniedException if tenant is not allowed for the current user with
     *                               FORBIDDEN http error code
     */
    private void checkAllowedTenantId(Integer tenantId) throws AccessDeniedException {
        log.debug("Check permission for the tenantId {}", tenantId);
        if (nonNull(tenantId) && !AuthUserHelper.getAuthUser().getAccessibleTenantIds().contains(tenantId)) {
            throw new AccessDeniedException("The current user doesn't have access to this tenantId:" + tenantId);
        }
        checkTenantCustomerIsWhiteLabel(tenantId);
    }

    /**
     * Check If the Tenant User Id is allowed to the current user.
     *
     * @param tenantUserId tenant to check
     * @throws AccessDeniedException if tenant user is not allowed for the current user with
     *                               FORBIDDEN http error code
     */
    private void checkAllowedTenantUserId(Integer tenantUserId) throws AccessDeniedException {
        if (nonNull(tenantUserId)) {
            log.debug("Check permission for the tenantUserId {}", tenantUserId);
            String prefix = "tuid-2-tid";
            Integer tenantId = null;
            tenantId = cacheUtils.findCachings(prefix, tenantUserId);
            if (Objects.isNull(tenantId)) {
                TenantUserResponseV1 tenantUser = tenantUserClientHelper.getTenantUserById(tenantUserId);
                if (nonNull(tenantUser)) {
                    tenantId = tenantUser.getTenantId();
                }
                cacheUtils.addCachings(prefix, tenantUserId, tenantId);
            }
            if (Objects.isNull(tenantId) || !AuthUserHelper.getAuthUser().getAccessibleTenantIds().contains(tenantId)) {
                throw new AccessDeniedException("The current user doesn't have access to this tenantId:" + tenantUserId);
            }
            checkTenantCustomerIsWhiteLabel(tenantId);
        }
    }


    /**
     * Check if the tenant's customer is whitelabel or not.
     *
     * @param tenantId id to check
     * @throws SdwanException if the customer is found and is NOT whitelabel
     */
    private void checkTenantCustomerIsWhiteLabel(Integer tenantId) throws SdwanException {
        String prefix = "ci-2-wl";
        Boolean isWhitelabel = null;
        if (nonNull(tenantId)) {
            isWhitelabel = cacheUtils.findCachings(prefix, tenantId);
            if (Objects.isNull(isWhitelabel)) {
                TenantResponseV1 tenant = tenantClientHelper.findById(tenantId);
                if (nonNull(tenant)) {
                    CustomerResponseV1 customer = customerClientHelper.findById(tenant.getCustomerId());
                    if (nonNull(customer)) {
                        isWhitelabel = customer.getIsWhitelabel();
                    }
                }
                cacheUtils.addCachings(prefix, tenantId, isWhitelabel);
            }
        }

        if (nonNull(isWhitelabel) && FALSE.equals(isWhitelabel)) {
            log.error(
                    "The customer found is not is-whitelabe = true so you can't edit tenant or tenant-user, from tenant Id: {}.",
                    tenantId);
            throw new SdwanBadRequestException("The customer must be is-whitelabe = true, from tenant Id: " + tenantId + ".");
        }
    }

    private String generateGetter(String field) {
        return GETTER_PREFIX + field.substring(0, 1).toUpperCase() + field.substring(1);
    }

    private ParameterizedType castToParameterizedType(Type type) {
        if (type instanceof ParameterizedType parameterizedtype) {
            return parameterizedtype;
        } else {
            throw new SdwanInternalServerErrorException("Type " + type.getTypeName() + " is not ParameterizedType.");
        }
    }

}
