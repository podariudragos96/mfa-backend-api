package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Builder
@Setter
@Getter
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DeviceRequest {

    @JsonProperty("id")
    private Integer id;

    @JsonProperty("uuid")
    private String versaUUID;

    @JsonProperty("status")
    private Status status;

    @JsonProperty("serial_number")
    private String serialNumber;

    @JsonProperty("friendly_name")
    private String friendlyName;

    @JsonProperty("resource_name")
    private String resourceName;

    @JsonProperty("site")
    private SiteRequest site;

    @JsonProperty("reachable")
    private Boolean reachable;

    @JsonProperty("basic_firewall")
    private Boolean basicFirewall;

    @JsonProperty("model")
    private String model;

    @JsonProperty("enabled_services")
    private String enabledServices;

    @JsonProperty("cpu_count")
    private String cpuCount;

    @JsonProperty("disk")
    private String disk;

    @JsonProperty("memory")
    private String memory;

    @JsonProperty("sw_version")
    private String swVersion;

    @JsonProperty("management_ipv4")
    private String managmentIPv4;

    @JsonProperty("hostname")
    private String hostName;

    @JsonProperty("has_steering_policies")
    private Boolean hasSteeringPolicies;

    @JsonProperty("has_fw_rules")
    private Boolean hasFwRules;

    @JsonProperty("has_analytics")
    private Boolean hasAnalytics;

    @JsonProperty("advanced_firewall")
    private Boolean advancedFirewall;

    @JsonProperty("is_primary")
    private Boolean isPrimary;

    @JsonProperty("vrrp_priority")
    private Integer vrrpPriority;

    @JsonProperty("sync_status")
    private Boolean syncStatus;

    @JsonProperty("is_lte")
    private Boolean isLTE = false;

    @JsonProperty("manage_routing")
    private List<String> manageRouting;

    @JsonProperty("ucpe_id")
    private Integer ucpeId;

    @JsonProperty("is_virtual")
    private Boolean isVirtual = false;

    @JsonProperty("cgw_details")
    private CgwDetails cgwDetails;

    @JsonProperty("is_self_signed_certificate_generated")
    private Boolean isSelfSignedCertificateGenerated = false;

    @JsonProperty("is_customer_managed_certificate_expired")
    private Boolean isCustomerManagedCertificateGenerated = false;
}
