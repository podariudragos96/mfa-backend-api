package net.colt.sdwan.portal.client.feign.sase;

import net.colt.sdwan.generated.controller.versa.sase.api.SiteToSiteTunnelApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "SaseSiteToSiteTunnelFeign",
        url = "${sdwan.sase.api.baseurl}",
        configuration = SaseApiFeignConfiguration.class)
public interface SaseSiteToSiteTunnelFeign extends SiteToSiteTunnelApiApi {
}
