package net.colt.sdwan.portal.model;

import lombok.*;
import net.colt.sdwan.portal.enums.RoutingStatsType;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RoutingCommandRequestModel {
    private RoutingProtocolV1 routingProtocol;
    private Boolean formatted;
    private net.colt.sdwan.portal.model.RoutingTypeV1 routingType;
    private RoutingStatsType statsType;
    private Boolean brief;
}
