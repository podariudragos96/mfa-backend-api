package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.database.entities.FeatureDetails;
import net.colt.sdwan.portal.database.repositories.FeatureDetailsRepository;
import net.colt.sdwan.portal.enums.FeaturesFlag;
import net.colt.sdwan.portal.services.FeatureDetailsService;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.*;

@RequiredArgsConstructor
@Service
public class FeatureDetailsServiceImpl implements FeatureDetailsService {

    private static final Integer TENANT_GENERIC_ID = -999;

    private final FeatureDetailsRepository featureDetailsRepository;

    @Override
    public List<String> findFeatureFlags(List<Integer> tenantIds) {
        List<String> features = new ArrayList<>();

        List<Integer> ids = new ArrayList<>();
        ids.add(TENANT_GENERIC_ID);
        ids.addAll(tenantIds);

        List<FeatureDetails> featureDetails = featureDetailsRepository.findByTenantIdInAndFeatureFlag(ids,
                FeaturesFlag.YES.name());

        if (CollectionUtils.isNotEmpty(featureDetails)) {
            List<String> featuresNamesList = featureDetails
                    .stream()
                    .map(FeatureDetails::getFeatureName)
                    .distinct()
                    .toList();

            features.addAll(featuresNamesList);
        }

        return features;
    }

    public Map<Long, List<String>> getTenantsFeatureFlags(Set<Long> tenantIds) {
        Map<Long, List<String>> tenantFeatureFlagsMap = new HashMap<>();

        List<FeatureDetails> allFeatureFlagDetails = featureDetailsRepository.findAll();
        for (Long tenantId : tenantIds) {
            List<String> tenantFeatures = new ArrayList<>();
            for (FeatureDetails featureFlagDetail : allFeatureFlagDetails) {
                if (FeaturesFlag.YES.name().equals(featureFlagDetail.getFeatureFlag()) &&
                        (TENANT_GENERIC_ID.equals(featureFlagDetail.getTenantId())
                                || tenantId.equals(featureFlagDetail.getTenantId().longValue()))) {
                    tenantFeatures.add(featureFlagDetail.getFeatureName());
                }
            }
            tenantFeatureFlagsMap.put(tenantId, tenantFeatures);
        }
        return tenantFeatureFlagsMap;
    }

}
