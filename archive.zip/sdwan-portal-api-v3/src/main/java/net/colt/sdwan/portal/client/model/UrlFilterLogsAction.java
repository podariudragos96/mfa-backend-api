package net.colt.sdwan.portal.client.model;

public enum UrlFilterLogsAction {
    ALLOW, ALERT, ASK, JUSTIFY, BLOCK, RESET, WHITELIST_ALLOW;
}
