package net.colt.sdwan.portal.enums;

import net.colt.sdwan.portal.model.LocalInternetBreakoutPreferencesDetailsV1;

import java.util.Arrays;

/**
 * Local Internet Breakout preferences
 */
public enum LIBPreference {
    PRIORITY_1(LocalInternetBreakoutPreferencesDetailsV1.PreferenceEnum.PRIORITY_1, 120),
    PRIORITY_2(LocalInternetBreakoutPreferencesDetailsV1.PreferenceEnum.PRIORITY_2, 119),
    PRIORITY_3(LocalInternetBreakoutPreferencesDetailsV1.PreferenceEnum.PRIORITY_3, 118),
    PRIORITY_4(LocalInternetBreakoutPreferencesDetailsV1.PreferenceEnum.PRIORITY_4, 117),
    LTE_DEFAULT(LocalInternetBreakoutPreferencesDetailsV1.PreferenceEnum.LTE_DEFAULT, 50);

    private final LocalInternetBreakoutPreferencesDetailsV1.PreferenceEnum preference;
    private final Integer value;

    LIBPreference(LocalInternetBreakoutPreferencesDetailsV1.PreferenceEnum preference, Integer value) {
        this.preference = preference;
        this.value = value;
    }

    public static boolean contains(final int value) {
        return Arrays.stream(LIBPreference.values())
                .anyMatch(preference -> preference.value().equals(value));
    }

    public static Integer fromPreference(final LocalInternetBreakoutPreferencesDetailsV1.PreferenceEnum preference) {
        final LIBPreference preferenceMatch = Arrays.stream(LIBPreference.values())
                .filter(thisPreference -> thisPreference.preference.equals(preference))
                .findFirst()
                .orElseThrow(() ->
                        new IllegalArgumentException("Invalid LIB preference value: ".concat(String.valueOf(preference)))
                );
        return preferenceMatch.value();
    }

    public static LocalInternetBreakoutPreferencesDetailsV1.PreferenceEnum fromValue(final int value) {
        final LIBPreference preferenceMatch = Arrays.stream(LIBPreference.values())
                .filter(thisPreference -> thisPreference.value.equals(value))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Invalid LIB action value: ".concat(String.valueOf(value))));
        return preferenceMatch.preference();
    }

    public LocalInternetBreakoutPreferencesDetailsV1.PreferenceEnum preference() {
        return preference;
    }

    public Integer value() {
        return value;
    }
}
