package net.colt.sdwan.identity.util;

import com.google.i18n.phonenumbers.PhoneNumberUtil;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import net.colt.sdwan.identity.dto.PhoneNumber;

import java.util.Optional;
import java.util.Set;

import static java.lang.Long.parseLong;
import static org.apache.commons.lang3.StringUtils.isNumeric;

//TODO: Move this to common maybe???
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class PhoneNumbersUtil {

    public static Optional<PhoneNumber> getPhoneNumber(String phoneNumberWithCountryCode) {
        final Set<Integer> countryCodes = PhoneNumberUtil.getInstance().getSupportedCallingCodes();
        phoneNumberWithCountryCode = getPhoneNumberWithoutPlusSignFromInternationalAccessCode(phoneNumberWithCountryCode);

        if (isNumeric(phoneNumberWithCountryCode)) {
            for (Integer countryCode : countryCodes) {
                if (phoneNumberWithCountryCode.startsWith(countryCode.toString())) {
                    final int countryCodeDigitsCount = Integer.toString(Math.abs(countryCode)).length();
                    final long phoneNumberWithoutCountryCode = getPhoneNumberWithoutCountryCode(phoneNumberWithCountryCode, countryCodeDigitsCount);

                    final PhoneNumber phoneNumber = PhoneNumber.builder()
                            .countryCode(countryCode)
                            .number(phoneNumberWithoutCountryCode)
                            .build();

                    return Optional.of(phoneNumber);
                }
            }
        }

        return Optional.empty();
    }

    private static String getPhoneNumberWithoutPlusSignFromInternationalAccessCode(String phoneNumberWithCountryCode) {
        return phoneNumberWithCountryCode.trim()
                .replace("+", "")
                .replace("\s", "");
    }

    private static long getPhoneNumberWithoutCountryCode(String phoneNumberWithCountryCode, int countryCodeDigitsCount) {
        final String phoneNumberWithoutCountryCode = phoneNumberWithCountryCode.substring(countryCodeDigitsCount);
        return parseLong(phoneNumberWithoutCountryCode);
    }
}