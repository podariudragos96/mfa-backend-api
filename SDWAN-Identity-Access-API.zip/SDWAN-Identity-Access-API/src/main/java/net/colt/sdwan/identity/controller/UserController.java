package net.colt.sdwan.identity.controller;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.controller.identityaccess.UserApiApi;
import net.colt.sdwan.identity.dto.ExportUserDto;
import net.colt.sdwan.generated.model.identityaccess.UserApiV1;
import net.colt.sdwan.identity.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/users")
@RequiredArgsConstructor
public class UserController implements UserApiApi {

    private final UserService userService;

    @Override
    public ResponseEntity<UserApiV1> addUserV1(String userGroupId, net.colt.sdwan.generated.model.identityaccess.UserApiV1 userApiV1) {
        return ResponseEntity.status(201).body(userService.createUser(userGroupId, userApiV1));
    }

    @Override
    public ResponseEntity<List<UserApiV1>> usersLookupV1(String userGroupId) {
        return ResponseEntity.ok(userService.listUsers(userGroupId));
    }

    @Override
    public ResponseEntity<UserApiV1> getUserByIdV1(String userGroupId, String userId) {
        return ResponseEntity.ok(userService.getUser(userGroupId, userId));
    }

    @Override
    public ResponseEntity<UserApiV1> updateUserV1(String userGroupId, String userId, UserApiV1 userApiV1) {
        return ResponseEntity.ok(userService.updateUser(userGroupId, userId, userApiV1));
    }

    @Override
    public ResponseEntity<Void> deleteUserByIdV1(String userGroupId, String userId) {
        userService.deleteUser(userGroupId, userId);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{userId}/reset-password")
    public ResponseEntity<Void> triggerResetPassword(@PathVariable String realm, @PathVariable String userId) {
        userService.sendResetPasswordEmail(realm, userId);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/{userId}/verify-email")
    public ResponseEntity<Void> triggerEmailVerification(@PathVariable String realm, @PathVariable String userId) {
        userService.sendVerifyEmail(realm, userId);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/export")
    public ResponseEntity<List<ExportUserDto>> exportUsers(@PathVariable String realm) {
        return ResponseEntity.ok(userService.exportUsers(realm));
    }

}