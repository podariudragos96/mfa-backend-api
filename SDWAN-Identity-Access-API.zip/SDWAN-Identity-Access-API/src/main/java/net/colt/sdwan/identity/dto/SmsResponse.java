package net.colt.sdwan.identity.dto;

import lombok.*;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class SmsResponse {

    private String status;
    private String errorMessage;
}
