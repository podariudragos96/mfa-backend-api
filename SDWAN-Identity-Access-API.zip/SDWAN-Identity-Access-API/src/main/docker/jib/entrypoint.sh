#!/bin/sh
echo "The application is starting..."
exec java ${JAVA_OPTS} -noverify -Duser.timezone=UTC -XX:+AlwaysPreTouch -Djava.security.egd=file:/dev/./urandom -cp /app/resources/:/app/classes/:/app/libs/* "net.colt.sdwan.identity.SdwanIdentityAccessV1Application" "$@"
