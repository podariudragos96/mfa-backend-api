package net.colt.sdwan.identity.controller;

import net.colt.sdwan.generated.model.identityaccess.UserGroupApiV1;
import net.colt.sdwan.generated.model.identityaccess.UserGroupCreateRequestApiV1;
import net.colt.sdwan.identity.service.UserGroupService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
class UserGroupControllerTest {

    @InjectMocks
    private UserGroupController controller;

    @Mock
    private UserGroupService userGroupService;

    @Test
    void addUserGroupV1_shouldReturn201() {
        UserGroupCreateRequestApiV1 req = new UserGroupCreateRequestApiV1();
        req.setName("realm-a");
        req.setDisplayName("Realm A");

        ResponseEntity<UserGroupApiV1> resp = controller.addUserGroupV1(req);

        assertEquals(201, resp.getStatusCode().value());
        assertNull(resp.getBody());
        Mockito.verify(userGroupService).createRealm(req);
    }

    @Test
    void getUserGroupByIdV1_shouldReturnGroup() {
        UserGroupApiV1 group = new UserGroupApiV1("id1", "realm-a", "Realm A");
        Mockito.when(userGroupService.getUserGroupById("id1")).thenReturn(group);

        ResponseEntity<UserGroupApiV1> resp = controller.getUserGroupByIdV1("id1");

        assertEquals(200, resp.getStatusCode().value());
        assertEquals(group, resp.getBody());
        Mockito.verify(userGroupService).getUserGroupById("id1");
    }

    @Test
    void updateUserGroupV1_shouldReturnUpdated() {
        UserGroupApiV1 req = new UserGroupApiV1();
        req.setName("realm-b");
        req.setDisplayName("Realm B");

        UserGroupApiV1 updated = new UserGroupApiV1("id1", "realm-b", "Realm B");
        Mockito.when(userGroupService.patchUserGroupById("id1", req)).thenReturn(updated);

        ResponseEntity<UserGroupApiV1> resp = controller.updateUserGroupV1("id1", req);

        assertEquals(200, resp.getStatusCode().value());
        assertEquals(updated, resp.getBody());
        Mockito.verify(userGroupService).patchUserGroupById("id1", req);
    }

    @Test
    void userGroupsLookupV1_shouldReturnList() {
        List<UserGroupApiV1> list = List.of(new UserGroupApiV1("id1", "realm-a", "Realm A"));
        Mockito.when(userGroupService.listUserGroups()).thenReturn(list);

        ResponseEntity<List<UserGroupApiV1>> resp = controller.userGroupsLookupV1();

        assertEquals(200, resp.getStatusCode().value());
        assertEquals(list, resp.getBody());
        Mockito.verify(userGroupService).listUserGroups();
    }
}