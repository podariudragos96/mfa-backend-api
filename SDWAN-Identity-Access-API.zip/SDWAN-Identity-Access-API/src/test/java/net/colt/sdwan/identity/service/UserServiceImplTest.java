package net.colt.sdwan.identity.service;

import jakarta.ws.rs.core.Response;
import net.colt.sdwan.generated.model.identityaccess.UserApiV1;
import net.colt.sdwan.identity.dto.ExportUserDto;
import net.colt.sdwan.identity.service.impl.UserServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.RealmsResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.RealmRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

    @Mock
    private Keycloak keycloak;

    @Mock
    private RealmResource realmResource;

    @Mock
    private UsersResource usersResource;

    @Mock
    private UserResource userResource;

    @Mock private RealmsResource realmsResource;

    @InjectMocks
    private UserServiceImpl service;

    @Test
    void createUser_withPassword_shouldResetPasswordAndReturnUserWithoutPassword() {
        Mockito.when(keycloak.realm("realm-a")).thenReturn(realmResource);
        Mockito.when(realmResource.users()).thenReturn(usersResource);

        Response response = Mockito.mock(Response.class);
        Mockito.when(usersResource.create(Mockito.any(UserRepresentation.class))).thenReturn(response);
        Mockito.when(response.getStatus()).thenReturn(201);
        Mockito.when(response.getHeaderString("Location")).thenReturn("http://x/users/u1");

        Mockito.when(usersResource.get("u1")).thenReturn(userResource);

        UserApiV1 req = new UserApiV1();
        req.setUsername("john");
        req.setEmail("john@example.com");
        req.setPassword("pass");
        req.setPhoneNumber("+40712345678");

        UserApiV1 out = service.createUser("realm-a", req);

        assertEquals("u1", out.getId());
        assertEquals("john", out.getUsername());
        assertNull(out.getPassword(), "Password should be cleared from API response");
        assertFalse(Boolean.TRUE.equals(out.getEmailVerified()));

        Mockito.verify(userResource).resetPassword(Mockito.argThat(c ->
                "password".equalsIgnoreCase(c.getType())
                        && "pass".equals(c.getValue())
                        && Boolean.FALSE.equals(c.isTemporary())
        ));
        Mockito.verify(response).close();
    }

    @Test
    void createUser_withoutPassword_shouldTriggerUpdatePasswordEmail() {
        Mockito.when(keycloak.realm("realm-a")).thenReturn(realmResource);
        Mockito.when(realmResource.users()).thenReturn(usersResource);

        Response response = Mockito.mock(Response.class);
        Mockito.when(usersResource.create(Mockito.any(UserRepresentation.class))).thenReturn(response);
        Mockito.when(response.getStatus()).thenReturn(201);
        Mockito.when(response.getHeaderString("Location")).thenReturn("http://x/users/u1");
        Mockito.when(usersResource.get("u1")).thenReturn(userResource);

        UserApiV1 req = new UserApiV1();
        req.setUsername("john");
        req.setEmail("john@example.com");
        req.setPassword(null);

        UserApiV1 out = service.createUser("realm-a", req);

        assertEquals("u1", out.getId());
        Mockito.verify(userResource).executeActionsEmail(Mockito.eq(List.of("UPDATE_PASSWORD")));
        Mockito.verify(response).close();
    }

    @Test
    void listUsers_shouldResolveRealmByNameAndMapUsers() {
        RealmRepresentation r = new RealmRepresentation();
        r.setId("id1");
        r.setRealm("realm-a");
        r.setDisplayName("Realm A");

        Mockito.when(keycloak.realm("id1")).thenReturn(realmResource);
        Mockito.when(realmResource.users()).thenReturn(usersResource);

        UserRepresentation u = new UserRepresentation();
        u.setId("u1");
        u.setUsername("john");
        u.setEmail("john@example.com");
        u.setAttributes(Map.of("phone_number", List.of("+40712345678")));
        Mockito.when(usersResource.list()).thenReturn(List.of(u));

        List<UserApiV1> out = service.listUsers("id1");

        assertEquals(1, out.size());
        assertEquals("u1", out.get(0).getId());
        assertEquals("+40712345678", out.get(0).getPhoneNumber());
    }

    @Test
    void updateUser_shouldUpdateFieldsAndPasswordAndPhone() {
        RealmRepresentation r = new RealmRepresentation();
        r.setId("id1");
        r.setRealm("realm-a");
        Mockito.when(keycloak.realms()).thenReturn(realmsResource);
        Mockito.when(realmsResource.findAll()).thenReturn(List.of(r));
        Mockito.when(keycloak.realm("realm-a")).thenReturn(realmResource);
        Mockito.when(realmResource.users()).thenReturn(usersResource);
        Mockito.when(usersResource.get("u1")).thenReturn(userResource);

        UserRepresentation existing = new UserRepresentation();
        existing.setId("u1");
        existing.setUsername("john");

        java.util.Map<String, java.util.List<String>> attrs = new java.util.HashMap<>();
        attrs.put("phone_number", new java.util.ArrayList<>(java.util.List.of("+40711111111")));
        existing.setAttributes(attrs);

        Mockito.when(userResource.toRepresentation()).thenReturn(existing);

        UserRepresentation afterUpdate = new UserRepresentation();
        afterUpdate.setId("u1");
        afterUpdate.setUsername("johnny");
        afterUpdate.setAttributes(
                java.util.Map.of("phone_number", java.util.List.of("+40722222222"))
        );

        Mockito.when(userResource.toRepresentation()).thenReturn(existing, afterUpdate);

        UserApiV1 patch = new UserApiV1();
        patch.setUsername("johnny");
        patch.setPhoneNumber("+40722222222");
        patch.setPassword("newpass");

        UserApiV1 out = service.updateUser("id1", "u1", patch);

        assertEquals("johnny", out.getUsername());
        assertEquals("+40722222222", out.getPhoneNumber());

        Mockito.verify(userResource).update(Mockito.any(UserRepresentation.class));
        Mockito.verify(userResource).resetPassword(Mockito.argThat(c -> "newpass".equals(c.getValue())));
    }

    @Test
    void deleteUser_shouldDeleteById() {
        RealmRepresentation r = new RealmRepresentation();
        r.setId("id1");
        r.setRealm("realm-a");

        Mockito.when(keycloak.realms()).thenReturn(realmsResource);
        Mockito.when(realmsResource.findAll()).thenReturn(List.of(r));

        Mockito.when(keycloak.realm("realm-a")).thenReturn(realmResource);

        Response resp = Mockito.mock(Response.class);
        Mockito.when(realmResource.users()).thenReturn(usersResource);
        Mockito.when(usersResource.delete("u1")).thenReturn(resp);

        service.deleteUser("id1", "u1");

        Mockito.verify(usersResource).delete("u1");
        Mockito.verify(resp).close();
    }

    @Test
    void exportUsers_shouldBuildDisplayNamesAndNeverExportPasswords() {
        Mockito.when(keycloak.realm("realm-a")).thenReturn(realmResource);
        Mockito.when(realmResource.users()).thenReturn(usersResource);

        UserRepresentation u1 = new UserRepresentation();
        u1.setUsername("john");
        u1.setFirstName("John");
        u1.setLastName("Doe");

        UserRepresentation u2 = new UserRepresentation();
        u2.setUsername("noName");
        u2.setFirstName(" ");
        u2.setLastName(null);

        Mockito.when(usersResource.list()).thenReturn(List.of(u1, u2));

        List<ExportUserDto> out = service.exportUsers("realm-a");

        assertEquals(2, out.size());
        assertEquals("John Doe", out.get(0).getDisplayName());
        assertEquals("noName", out.get(1).getDisplayName());
        assertNull(out.get(0).getPassword());
    }
}