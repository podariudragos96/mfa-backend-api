package net.colt.sdwan.identity.service;

import jakarta.ws.rs.core.Response;
import net.colt.sdwan.generated.model.identityaccess.UserGroupApiV1;
import net.colt.sdwan.generated.model.identityaccess.UserGroupCreateRequestApiV1;
import net.colt.sdwan.identity.service.impl.UserGroupServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.*;
import org.keycloak.representations.idm.ClientRepresentation;
import org.keycloak.representations.idm.RealmRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class UserGroupServiceImplTest {

    @Mock
    private Keycloak keycloak;

    @Mock
    private RealmsResource realmsResource;

    @Mock
    private RealmResource realmResource;

    @Mock
    private ClientsResource clientsResource;

    @Mock
    private ClientResource clientResource;

    @Mock
    private UsersResource usersResource;

    @Mock
    private UserResource userResource;

    @Mock
    private RoleMappingResource roleMappingResource;

    @Mock
    private RoleScopeResource roleScopeResource;

    @Mock
    private RolesResource rolesResource;

    @Mock
    private RoleResource roleResource;

    @InjectMocks
    private UserGroupServiceImpl service;

    @Test
    void listUserGroups_shouldMapRealmsToApi() {
        RealmRepresentation r1 = new RealmRepresentation();
        r1.setId("id1");
        r1.setRealm("realm-a");
        r1.setDisplayName("Realm A");

        Mockito.when(keycloak.realms()).thenReturn(realmsResource);
        Mockito.when(realmsResource.findAll()).thenReturn(List.of(r1));

        List<UserGroupApiV1> out = service.listUserGroups();

        assertEquals(1, out.size());
        assertEquals("id1", out.get(0).getId());
        assertEquals("realm-a", out.get(0).getName());
        assertEquals("Realm A", out.get(0).getDisplayName());
    }

    @Test
    void getUserGroupById_shouldFindByRealmId() {
        RealmRepresentation r1 = new RealmRepresentation();
        r1.setId("id1");
        r1.setRealm("realm-a");
        r1.setDisplayName("Realm A");

        Mockito.when(keycloak.realms()).thenReturn(realmsResource);
        Mockito.when(realmsResource.findAll()).thenReturn(List.of(r1));

        UserGroupApiV1 out = service.getUserGroupById("id1");

        assertEquals("id1", out.getId());
        assertEquals("realm-a", out.getName());
        assertEquals("Realm A", out.getDisplayName());
    }

    @Test
    void patchUserGroupById_shouldUpdateRealmAndReturnUpdated() {
        RealmRepresentation existing = new RealmRepresentation();
        existing.setId("id1");
        existing.setRealm("realm-a");
        existing.setDisplayName("Realm A");

        Mockito.when(keycloak.realms()).thenReturn(realmsResource);
        Mockito.when(realmsResource.findAll()).thenReturn(List.of(existing));

        Mockito.when(keycloak.realm("realm-a")).thenReturn(realmResource);

        RealmRepresentation updatedRep = new RealmRepresentation();
        updatedRep.setId("id1");
        updatedRep.setRealm("realm-b");
        updatedRep.setDisplayName("Realm B");
        Mockito.when(keycloak.realm("realm-b")).thenReturn(realmResource);
        Mockito.when(realmResource.toRepresentation()).thenReturn(updatedRep);

        UserGroupApiV1 patch = new UserGroupApiV1();
        patch.setName("realm-b");
        patch.setDisplayName("Realm B");

        UserGroupApiV1 out = service.patchUserGroupById("id1", patch);

        Mockito.verify(realmResource).update(Mockito.any(RealmRepresentation.class));
        assertEquals("realm-b", out.getName());
        assertEquals("Realm B", out.getDisplayName());
    }

    @Test
    void deleteRealm_shouldCallKeycloakRemove() {
        Mockito.when(keycloak.realm("realm-a")).thenReturn(realmResource);

        service.deleteRealm("realm-a");

        Mockito.verify(realmResource).remove();
    }

    @Test
    void createRealm_shouldCreateRealmAndSetupMfaClient() {
        Mockito.when(keycloak.realms()).thenReturn(realmsResource);

        Mockito.when(keycloak.realm("realm-a")).thenReturn(realmResource);
        Mockito.when(realmResource.clients()).thenReturn(clientsResource);
        Mockito.when(realmResource.users()).thenReturn(usersResource);

        Response resp = Mockito.mock(Response.class);
        Mockito.when(clientsResource.create(Mockito.any(ClientRepresentation.class))).thenReturn(resp);
        Mockito.when(resp.getStatus()).thenReturn(201);
        Mockito.when(resp.getHeaderString("Location")).thenReturn("http://x/clients/c1");

        Mockito.when(clientsResource.get("c1")).thenReturn(clientResource);
        UserRepresentation svcAcct = new UserRepresentation();
        svcAcct.setId("svc1");
        Mockito.when(clientResource.getServiceAccountUser()).thenReturn(svcAcct);

        Mockito.when(usersResource.get("svc1")).thenReturn(userResource);
        Mockito.when(userResource.roles()).thenReturn(roleMappingResource);
        Mockito.when(roleMappingResource.clientLevel("rm-client-id")).thenReturn(roleScopeResource);

        ClientRepresentation realmMgmt = new ClientRepresentation();
        realmMgmt.setId("rm-client-id");
        Mockito.when(clientsResource.findByClientId("realm-management")).thenReturn(List.of(realmMgmt));

        Mockito.when(clientsResource.get("rm-client-id")).thenReturn(clientResource);
        Mockito.when(clientResource.roles()).thenReturn(rolesResource);
        Mockito.when(rolesResource.get("realm-admin")).thenReturn(roleResource);
        RoleRepresentation roleRep = new RoleRepresentation();
        roleRep.setName("realm-admin");
        Mockito.when(roleResource.toRepresentation()).thenReturn(roleRep);

        UserGroupCreateRequestApiV1 req = new UserGroupCreateRequestApiV1();
        req.setName("realm-a");
        req.setDisplayName("Realm A");

        service.createRealm(req);

        Mockito.verify(realmsResource).create(Mockito.argThat(r ->
                "realm-a".equals(r.getRealm()) && "Realm A".equals(r.getDisplayName()) && Boolean.TRUE.equals(r.isEnabled())
        ));
        Mockito.verify(roleScopeResource).add(Mockito.anyList());
        Mockito.verify(resp).close();
    }
}