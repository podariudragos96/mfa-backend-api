package net.colt.sdwan.identity.controller;

import net.colt.sdwan.generated.model.identityaccess.UserApiV1;
import net.colt.sdwan.identity.dto.ExportUserDto;
import net.colt.sdwan.identity.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
class UserControllerTest {

    @InjectMocks
    private UserController controller;

    @Mock
    private UserService userService;

    @Test
    void addUserV1_shouldReturn201AndBody() {
        String userGroupId = "realm-a";
        UserApiV1 req = new UserApiV1();
        req.setUsername("john");

        UserApiV1 created = new UserApiV1();
        created.setId("u1");
        created.setUsername("john");

        Mockito.when(userService.createUser(userGroupId, req)).thenReturn(created);

        ResponseEntity<UserApiV1> resp = controller.addUserV1(userGroupId, req);

        assertEquals(201, resp.getStatusCode().value());
        assertEquals(created, resp.getBody());
        Mockito.verify(userService).createUser(userGroupId, req);
    }

    @Test
    void usersLookupV1_shouldReturnList() {
        String userGroupId = "realm-a";
        List<UserApiV1> users = List.of(new UserApiV1().id("u1").username("john"));
        Mockito.when(userService.listUsers(userGroupId)).thenReturn(users);

        ResponseEntity<List<UserApiV1>> resp = controller.usersLookupV1(userGroupId);

        assertEquals(200, resp.getStatusCode().value());
        assertEquals(users, resp.getBody());
        Mockito.verify(userService).listUsers(userGroupId);
    }

    @Test
    void getUserByIdV1_shouldDelegateToService() {
        String userGroupId = "realm-a";
        String userId = "u1";
        UserApiV1 user = new UserApiV1().id(userId).username("john");
        Mockito.when(userService.getUser(userGroupId, userId)).thenReturn(user);

        ResponseEntity<UserApiV1> resp = controller.getUserByIdV1(userGroupId, userId);

        assertEquals(200, resp.getStatusCode().value());
        assertEquals(user, resp.getBody());
        Mockito.verify(userService).getUser(userGroupId, userId);
    }

    @Test
    void updateUserV1_shouldDelegateToService() {
        String userGroupId = "realm-a";
        String userId = "u1";
        UserApiV1 req = new UserApiV1().username("newName");
        UserApiV1 updated = new UserApiV1().id(userId).username("newName");
        Mockito.when(userService.updateUser(userGroupId, userId, req)).thenReturn(updated);

        ResponseEntity<UserApiV1> resp = controller.updateUserV1(userGroupId, userId, req);

        assertEquals(200, resp.getStatusCode().value());
        assertEquals(updated, resp.getBody());
        Mockito.verify(userService).updateUser(userGroupId, userId, req);
    }

    @Test
    void deleteUserByIdV1_shouldReturn204() {
        String userGroupId = "realm-a";
        String userId = "u1";

        ResponseEntity<Void> resp = controller.deleteUserByIdV1(userGroupId, userId);

        assertEquals(204, resp.getStatusCode().value());
        assertNull(resp.getBody());
        Mockito.verify(userService).deleteUser(userGroupId, userId);
    }

    @Test
    void triggerResetPassword_shouldReturn200() {
        ResponseEntity<Void> resp = controller.triggerResetPassword("realm-a", "u1");

        assertEquals(200, resp.getStatusCode().value());
        Mockito.verify(userService).sendResetPasswordEmail("realm-a", "u1");
    }

    @Test
    void triggerEmailVerification_shouldReturn200() {
        ResponseEntity<Void> resp = controller.triggerEmailVerification("realm-a", "u1");

        assertEquals(200, resp.getStatusCode().value());
        Mockito.verify(userService).sendVerifyEmail("realm-a", "u1");
    }

    @Test
    void exportUsers_shouldReturnList() {
        List<ExportUserDto> exported = List.of(new ExportUserDto("john", "John Doe", null));
        Mockito.when(userService.exportUsers("realm-a")).thenReturn(exported);

        ResponseEntity<List<ExportUserDto>> resp = controller.exportUsers("realm-a");

        assertEquals(200, resp.getStatusCode().value());
        assertEquals(exported, resp.getBody());
        Mockito.verify(userService).exportUsers("realm-a");
    }
}