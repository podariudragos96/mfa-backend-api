package net.colt.sdwan.identity.controller;

import net.colt.sdwan.generated.model.identityaccess.*;
import net.colt.sdwan.identity.dto.Attempt;
import net.colt.sdwan.identity.security.JwtService;
import net.colt.sdwan.identity.service.DirectGrantService;
import net.colt.sdwan.identity.service.SmsService;
import net.colt.sdwan.identity.util.EmailSender;
import net.colt.sdwan.identity.util.PendingMfaStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.RealmsResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.UserRepresentation;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.lang.reflect.Field;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class AuthControllerTest {

    @Mock
    private Keycloak keycloak;

    @Mock
    private DirectGrantService dgs;

    @Mock
    private PendingMfaStore store;
    @Mock
    private EmailSender emailSender;

    @Mock
    private JwtService jwt;

    @Mock
    private SmsService smsService;

    @Mock
    private RealmsResource realmsResource;

    @Mock
    private RealmResource realmResource;

    @Mock
    private UsersResource usersResource;

    @Mock
    private UserResource userResource;

    @InjectMocks
    private AuthController controller;

    @BeforeEach
    void setUp() throws Exception {
        setField(controller, "keycloakBaseUrlRaw", "http://localhost:8180");
        setField(controller, "browserClientId", "browser-client");
        setField(controller, "browserClientSecret", "secret");
        setField(controller, "browserRedirectUri", "http://localhost:4200/cb");
        setField(controller, "noOtpClientId", "no-otp-client");
        setField(controller, "noOtpClientSecret", "no-otp-secret");
    }

    @Test
    void authMfaEmailSend_invalidAttempt_shouldReturn400() {
        SendEmailReqApiV1 req = new SendEmailReqApiV1().loginAttemptId("a1");
        Mockito.when(store.get("a1")).thenReturn(null);

        ResponseEntity<?> resp = controller.authMfaEmailSend(req);

        assertEquals(400, resp.getStatusCode().value());
        assertTrue(resp.getBody() instanceof ErrorResponseApiV1);
        assertEquals("INVALID_ATTEMPT", ((ErrorResponseApiV1) resp.getBody()).getError());
    }

    @Test
    void authMfaEmailSend_noEmail_shouldReturn400() {
        Attempt a = Attempt.builder().realm("realm-a").userId("u1").username("john").build();
        Mockito.when(store.get("a1")).thenReturn(a);

        Mockito.when(keycloak.realms()).thenReturn(realmsResource);
        Mockito.when(realmsResource.realm("realm-a")).thenReturn(realmResource);
        Mockito.when(realmResource.users()).thenReturn(usersResource);
        Mockito.when(usersResource.get("u1")).thenReturn(userResource);

        UserRepresentation u = new UserRepresentation();
        u.setEmail(null);
        Mockito.when(userResource.toRepresentation()).thenReturn(u);

        ResponseEntity<?> resp = controller.authMfaEmailSend(new SendEmailReqApiV1().loginAttemptId("a1"));

        assertEquals(400, resp.getStatusCode().value());
        assertTrue(resp.getBody() instanceof ErrorResponseApiV1);
        assertEquals("NO_EMAIL_ON_ACCOUNT", ((ErrorResponseApiV1) resp.getBody()).getError());
        Mockito.verify(emailSender, Mockito.never()).sendOtp(Mockito.anyString(), Mockito.anyString());
    }

    @Test
    void authMfaEmailSend_success_shouldSendOtpAndReturnOk() {
        Mockito.when(keycloak.realms()).thenReturn(realmsResource);
        Mockito.when(realmsResource.realm("realm-a")).thenReturn(realmResource);
        Mockito.when(realmResource.users()).thenReturn(usersResource);
        Mockito.when(usersResource.get("u1")).thenReturn(userResource);

        Attempt a = Attempt.builder().realm("realm-a").userId("u1").username("john").build();
        Mockito.when(store.get("a1")).thenReturn(a);

        UserRepresentation u = new UserRepresentation();
        u.setEmail("john@example.com");
        Mockito.when(userResource.toRepresentation()).thenReturn(u);

        ResponseEntity<?> resp = controller.authMfaEmailSend(new SendEmailReqApiV1().loginAttemptId("a1"));

        assertEquals(200, resp.getStatusCode().value());
        assertTrue(resp.getBody() instanceof Map);

        @SuppressWarnings("unchecked")
        Map<String, Object> body = (Map<String, Object>) resp.getBody();
        assertEquals(Boolean.TRUE, body.get("sent"));

        Mockito.verify(store).setEmailOtp(Mockito.eq("a1"), Mockito.anyString(), Mockito.any());
        Mockito.verify(emailSender).sendOtp(Mockito.eq("john@example.com"), Mockito.anyString());
    }

    @Test
    void authMfaEmailVerify_invalidAttempt_shouldReturn400() {
        Mockito.when(store.get("a1")).thenReturn(null);

        ResponseEntity<?> resp = controller.authMfaEmailVerify(
                new VerifyEmailReqApiV1().loginAttemptId("a1").code("000000")
        );

        assertEquals(400, resp.getStatusCode().value());
        assertTrue(resp.getBody() instanceof ErrorResponseApiV1);
        assertEquals("INVALID_ATTEMPT", ((ErrorResponseApiV1) resp.getBody()).getError());
    }

    @Test
    void authMfaEmailVerify_invalidOtp_shouldReturn400() {
        Attempt a = Attempt.builder().realm("realm-a").userId("u1").username("john").build();
        Mockito.when(store.get("a1")).thenReturn(a);
        Mockito.when(store.consumeValidEmailOtp("a1", "000000")).thenReturn(false);

        ResponseEntity<?> resp = controller.authMfaEmailVerify(
                new VerifyEmailReqApiV1().loginAttemptId("a1").code("000000")
        );

        assertEquals(400, resp.getStatusCode().value());
        assertTrue(resp.getBody() instanceof ErrorResponseApiV1);
        assertEquals("INVALID_OR_EXPIRED_OTP", ((ErrorResponseApiV1) resp.getBody()).getError());
        Mockito.verify(jwt, Mockito.never()).issue(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
    }

    @Test
    void authMfaEmailVerify_success_shouldReturnTokenAndRemoveAttempt() {
        Attempt a = Attempt.builder().realm("realm-a").userId("u1").username("john").build();
        Mockito.when(store.get("a1")).thenReturn(a);
        Mockito.when(store.consumeValidEmailOtp("a1", "123456")).thenReturn(true);
        Mockito.when(jwt.issue("realm-a", "u1", "john")).thenReturn("jwt-token");

        ResponseEntity<?> resp = controller.authMfaEmailVerify(
                new VerifyEmailReqApiV1().loginAttemptId("a1").code("123456")
        );

        assertEquals(200, resp.getStatusCode().value());
        assertTrue(resp.getBody() instanceof FinalTokenResponseApiV1);
        assertEquals("jwt-token", ((FinalTokenResponseApiV1) resp.getBody()).getToken());
        Mockito.verify(store).remove("a1");
    }

    @Test
    void authMfaTotpVerify_passwordMissing_shouldReturn400() {
        Attempt a = Attempt.builder().realm("realm-a").userId("u1").username("john").password(" ").build();
        Mockito.when(store.get("a1")).thenReturn(a);

        ResponseEntity<?> resp = controller.authMfaTotpVerify(
                new VerifyTotpRequestApiV1().loginAttemptId("a1").code("123456")
        );

        assertEquals(400, resp.getStatusCode().value());
        assertTrue(resp.getBody() instanceof ErrorResponseApiV1);
        assertEquals("PASSWORD_MISSING", ((ErrorResponseApiV1) resp.getBody()).getError());
    }

    @Test
    void authMfaTotpVerify_invalidTotp_shouldReturn400() {
        Attempt a = Attempt.builder().realm("realm-a").userId("u1").username("john").password("pass").build();
        Mockito.when(store.get("a1")).thenReturn(a);
        Mockito.when(dgs.validateCredentialsWithTotp("realm-a", "john", "pass", "123456")).thenReturn(false);

        ResponseEntity<?> resp = controller.authMfaTotpVerify(
                new VerifyTotpRequestApiV1().loginAttemptId("a1").code("123456")
        );

        assertEquals(400, resp.getStatusCode().value());
        assertTrue(resp.getBody() instanceof ErrorResponseApiV1);
        assertEquals("INVALID_TOTP", ((ErrorResponseApiV1) resp.getBody()).getError());
    }

    @Test
    void authMfaTotpVerify_success_shouldReturnFinalToken() {
        Attempt a = Attempt.builder().realm("realm-a").userId("u1").username("john").password("pass").build();
        Mockito.when(store.get("a1")).thenReturn(a);
        Mockito.when(dgs.validateCredentialsWithTotp("realm-a", "john", "pass", "123456")).thenReturn(true);
        Mockito.when(jwt.issue("realm-a", "u1", "john")).thenReturn("jwt-token");

        ResponseEntity<?> resp = controller.authMfaTotpVerify(
                new VerifyTotpRequestApiV1().loginAttemptId("a1").code("123456")
        );

        assertEquals(200, resp.getStatusCode().value());
        assertTrue(resp.getBody() instanceof FinalTokenResponseApiV1);
        assertEquals("jwt-token", ((FinalTokenResponseApiV1) resp.getBody()).getToken());
        Mockito.verify(store).remove("a1");
    }

    private static void setField(Object target, String field, Object value) throws Exception {
        Field f = target.getClass().getDeclaredField(field);
        f.setAccessible(true);
        f.set(target, value);
    }
}