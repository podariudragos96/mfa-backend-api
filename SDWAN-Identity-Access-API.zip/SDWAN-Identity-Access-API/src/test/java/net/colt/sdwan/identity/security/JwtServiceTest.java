package net.colt.sdwan.identity.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.Test;

import javax.crypto.SecretKey;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class JwtServiceTest {

    @Test
    void issue_shouldCreateSignedJwtWithExpectedClaims() throws Exception {
        JwtService svc = new JwtService();

        String secret = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
        setField(svc, "secret", secret);
        setField(svc, "expMinutes", 10L);
        svc.initKey();

        String token = svc.issue("realm-a", "u1", "john");
        assertNotNull(token);

        SecretKey key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody();

        assertEquals("u1", claims.getSubject());
        assertEquals("realm-a", claims.get("realm", String.class));
        assertEquals("john", claims.get("username", String.class));

        Date iat = claims.getIssuedAt();
        Date exp = claims.getExpiration();
        assertNotNull(iat);
        assertNotNull(exp);
        assertTrue(exp.after(iat));
    }

    @Test
    void initKey_base64Prefix_shouldDecode() throws Exception {
        JwtService svc = new JwtService();

        String b64 = "base64:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=";
        setField(svc, "secret", b64);
        setField(svc, "expMinutes", 1L);
        svc.initKey();

        String token = svc.issue("realm-a", "u1", "john");
        assertNotNull(token);

        byte[] raw = java.util.Base64.getDecoder().decode(b64.substring("base64:".length()));
        Claims claims = Jwts.parserBuilder()
                .setSigningKey(Keys.hmacShaKeyFor(raw))
                .build()
                .parseClaimsJws(token)
                .getBody();

        assertEquals("u1", claims.getSubject());
    }

    private static void setField(Object target, String field, Object value) throws Exception {
        Field f = target.getClass().getDeclaredField(field);
        f.setAccessible(true);
        f.set(target, value);
    }
}