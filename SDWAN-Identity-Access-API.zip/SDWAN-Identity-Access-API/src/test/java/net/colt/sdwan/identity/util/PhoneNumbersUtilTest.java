package net.colt.sdwan.identity.util;

import net.colt.sdwan.identity.dto.PhoneNumber;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class PhoneNumbersUtilTest {

    @Test
    void getPhoneNumber_validRomaniaE164_shouldParse() {
        Optional<PhoneNumber> out = PhoneNumbersUtil.getPhoneNumber("+40712345678");
        assertTrue(out.isPresent());
        assertEquals(40, out.get().getCountryCode());
        assertEquals(712345678L, out.get().getNumber());
        assertEquals("40", out.get().getCountryCodeAsString());
        assertEquals("712345678", out.get().getNumberAsString());
    }

    @Test
    void getPhoneNumber_validWithoutPlus_shouldParse() {
        Optional<PhoneNumber> out = PhoneNumbersUtil.getPhoneNumber("40712345678");
        assertTrue(out.isPresent());
        assertEquals(40, out.get().getCountryCode());
    }

    @Test
    void getPhoneNumber_invalid_shouldReturnEmpty() {
        assertTrue(PhoneNumbersUtil.getPhoneNumber("abc").isEmpty());
        assertTrue(PhoneNumbersUtil.getPhoneNumber("+").isEmpty());
        assertTrue(PhoneNumbersUtil.getPhoneNumber("").isEmpty());
    }
}