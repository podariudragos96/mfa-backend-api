package net.colt.sdwan.identity.util;

import net.colt.sdwan.identity.dto.Attempt;
import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;

class PendingMfaStoreTest {

    @Test
    void create_get_remove_shouldWork() {
        PendingMfaStore store = new PendingMfaStore();

        String id = store.create("realm-a", "john", "u1", "pass");
        assertNotNull(id);

        Attempt a = store.get(id);
        assertNotNull(a);
        assertEquals("realm-a", a.getRealm());
        assertEquals("john", a.getUsername());
        assertEquals("u1", a.getUserId());
        assertEquals("pass", a.getPassword());
        assertNotNull(a.getCreatedAt());

        store.remove(id);
        assertNull(store.get(id));
    }

    @Test
    void emailOtp_shouldValidateAndConsume() {
        PendingMfaStore store = new PendingMfaStore();
        String id = store.create("realm-a", "john", "u1", "pass");

        store.setEmailOtp(id, "123456", Instant.now().plusSeconds(60));

        assertFalse(store.consumeValidEmailOtp(id, "000000"));
        assertTrue(store.consumeValidEmailOtp(id, "123456"));
        assertFalse(store.consumeValidEmailOtp(id, "123456"));
    }

    @Test
    void smsOtp_shouldExpire() {
        PendingMfaStore store = new PendingMfaStore();
        String id = store.create("realm-a", "john", "u1", "pass");

        store.setSmsOtp(id, "123456", Instant.now().minusSeconds(1));

        assertFalse(store.consumeValidSmsOtp(id, "123456"));
    }

    @Test
    void bindState_clearState_shouldNotThrow() {
        PendingMfaStore store = new PendingMfaStore();
        store.bindState("realm-a:state", "attempt1");
        store.clearState("realm-a:state");
    }
}