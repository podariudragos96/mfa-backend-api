package net.colt.sdwan.identity.controller;

import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SecureControllerTest {

    @Test
    void ping_shouldReturnMessage() {
        SecureController c = new SecureController();

        ResponseEntity<?> resp = c.ping();

        assertEquals(200, resp.getStatusCode().value());
        @SuppressWarnings("unchecked")
        Map<String, Object> body = (Map<String, Object>) resp.getBody();
        assertEquals("You are authenticated! 🎉", body.get("message"));
    }
}