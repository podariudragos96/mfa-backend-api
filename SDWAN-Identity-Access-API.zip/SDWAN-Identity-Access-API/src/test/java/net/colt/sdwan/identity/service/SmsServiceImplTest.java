package net.colt.sdwan.identity.service;

import net.colt.sdwan.identity.dto.SmsRequest;
import net.colt.sdwan.identity.dto.SmsResponse;
import net.colt.sdwan.identity.service.impl.SmsServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Locale;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class SmsServiceImplTest {

    @Test
    void sendSms_blankNumber_shouldNotSend() {
        MessageSource ms = Mockito.mock(MessageSource.class);
        RestTemplate rt = Mockito.mock(RestTemplate.class);

        SmsServiceImpl svc = new SmsServiceImpl(ms, rt, "http://sms", "token", false);

        svc.sendSms(" ", "site", "addr", "STATUS_KEY", Locale.ENGLISH);

        assertFalse(svc.wasSmsSent());
        Mockito.verifyNoInteractions(rt);
    }

    @Test
    void sendSms_validNumber_successResponse_shouldSetWasSmsSentTrue() {
        MessageSource ms = Mockito.mock(MessageSource.class);
        RestTemplate rt = Mockito.mock(RestTemplate.class);

        Mockito.when(ms.getMessage(Mockito.eq("STATUS_KEY"), Mockito.any(), Mockito.eq(Locale.ENGLISH)))
                .thenReturn("hello");

        ResponseEntity<SmsResponse> responseEntity = Mockito.mock(ResponseEntity.class);
        Mockito.when(responseEntity.getBody()).thenReturn(new SmsResponse("SUCCESS", null));

        Mockito.when(rt.exchange(
                Mockito.eq("http://sms"),
                Mockito.eq(HttpMethod.POST),
                Mockito.any(HttpEntity.class),
                Mockito.eq(SmsResponse.class),
                Mockito.anyMap()
        )).thenReturn(responseEntity);

        SmsServiceImpl svc = new SmsServiceImpl(ms, rt, "http://sms", "token", false);

        svc.sendSms("+40712345678", "site", "addr", "STATUS_KEY", Locale.ENGLISH);

        assertTrue(svc.wasSmsSent());

        Mockito.verify(rt).exchange(
                Mockito.eq("http://sms"),
                Mockito.eq(HttpMethod.POST),
                Mockito.argThat(e -> e.getBody() instanceof SmsRequest),
                Mockito.eq(SmsResponse.class),
                Mockito.anyMap()
        );
    }

    @Test
    void sendSms_restTemplateThrows_shouldSetWasSmsSentFalse() {
        MessageSource ms = Mockito.mock(MessageSource.class);
        RestTemplate rt = Mockito.mock(RestTemplate.class);

        Mockito.when(ms.getMessage(Mockito.eq("STATUS_KEY"), Mockito.any(), Mockito.eq(Locale.ENGLISH)))
                .thenReturn("hello");

        Mockito.when(rt.exchange(
                Mockito.anyString(),
                Mockito.eq(HttpMethod.POST),
                Mockito.any(HttpEntity.class),
                Mockito.eq(SmsResponse.class),
                Mockito.anyMap()
        )).thenThrow(new RuntimeException("boom"));

        SmsServiceImpl svc = new SmsServiceImpl(ms, rt, "http://sms", "token", true);

        svc.sendSms("+40712345678", "site", "addr", "STATUS_KEY", Locale.ENGLISH);

        assertFalse(svc.wasSmsSent());
    }
}