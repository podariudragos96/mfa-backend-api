package net.colt.sdwan.identity.service.impl;

import jakarta.ws.rs.core.Response;
import net.colt.sdwan.generated.model.identityaccess.UserGroupApiV1;
import net.colt.sdwan.generated.model.identityaccess.UserGroupCreateRequestApiV1;
import org.junit.jupiter.api.Test;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.*;
import org.keycloak.representations.idm.*;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class UserGroupServiceImplTest {

    @Test
    void listUserGroups_shouldMapFindAll() {
        Keycloak kc = mock(Keycloak.class);
        RealmsResource realms = mock(RealmsResource.class);
        when(kc.realms()).thenReturn(realms);

        RealmRepresentation r = new RealmRepresentation();
        r.setId("id1");
        r.setRealm("realmA");
        r.setDisplayName("Realm A");
        when(realms.findAll()).thenReturn(List.of(r));

        UserGroupServiceImpl svc = new UserGroupServiceImpl(kc);
        List<UserGroupApiV1> out = svc.listUserGroups();

        assertEquals(1, out.size());
        assertEquals("realmA", out.get(0).getName());
    }

    @Test
    void getUserGroupById_shouldFindByIdOrThrow() {
        Keycloak kc = mock(Keycloak.class);
        RealmsResource realms = mock(RealmsResource.class);
        when(kc.realms()).thenReturn(realms);

        RealmRepresentation r = new RealmRepresentation();
        r.setId("id1");
        r.setRealm("realmA");
        r.setDisplayName("Realm A");
        when(realms.findAll()).thenReturn(List.of(r));

        UserGroupServiceImpl svc = new UserGroupServiceImpl(kc);
        UserGroupApiV1 out = svc.getUserGroupById("id1");
        assertEquals("realmA", out.getName());

        assertThrows(RuntimeException.class, () -> svc.getUserGroupById("missing"));
    }

    @Test
    void patchUserGroupById_shouldUpdateRealmFields() {
        Keycloak kc = mock(Keycloak.class);
        RealmsResource realms = mock(RealmsResource.class);
        when(kc.realms()).thenReturn(realms);

        RealmRepresentation existing = new RealmRepresentation();
        existing.setId("id1");
        existing.setRealm("realmA");
        existing.setDisplayName("Realm A");
        when(realms.findAll()).thenReturn(List.of(existing));

        RealmResource realmRes = mock(RealmResource.class);
        when(kc.realm("realmA")).thenReturn(realmRes);

        RealmRepresentation updated = new RealmRepresentation();
        updated.setId("id1");
        updated.setRealm("realmB");
        updated.setDisplayName("Realm B");
        when(realmRes.toRepresentation()).thenReturn(updated);

        UserGroupServiceImpl svc = new UserGroupServiceImpl(kc);

        UserGroupApiV1 patch = new UserGroupApiV1();
        patch.setName("realmB");
        patch.setDisplayName("Realm B");

        UserGroupApiV1 out = svc.patchUserGroupById("id1", patch);
        assertEquals("realmB", out.getName());

        verify(realmRes).update(any(RealmRepresentation.class));
    }

    @Test
    void deleteRealm_shouldCallRemove() {
        Keycloak kc = mock(Keycloak.class);
        RealmResource rr = mock(RealmResource.class);
        when(kc.realm("realmA")).thenReturn(rr);

        UserGroupServiceImpl svc = new UserGroupServiceImpl(kc);
        svc.deleteUserGroupById("realmA");

        verify(rr).remove();
    }

    @Test
    void createRealm_shouldCreateRealmAndSetupMfaClient() {
        Keycloak kc = mock(Keycloak.class);

        RealmsResource realms = mock(RealmsResource.class);
        when(kc.realms()).thenReturn(realms);
        doNothing().when(realms).create(any(RealmRepresentation.class));

        RealmResource realm = mock(RealmResource.class);
        ClientsResource clients = mock(ClientsResource.class);
        when(kc.realm("realmA")).thenReturn(realm);
        when(realm.clients()).thenReturn(clients);

        Response resp = mock(Response.class);
        when(resp.getStatus()).thenReturn(201);
        when(resp.getHeaderString("Location")).thenReturn("http://x/clients/cuuid1");
        when(clients.create(any(ClientRepresentation.class))).thenReturn(resp);

        ClientResource createdClient = mock(ClientResource.class);
        when(clients.get("cuuid1")).thenReturn(createdClient);

        UserRepresentation svcAcct = new UserRepresentation();
        svcAcct.setId("svcUser1");
        when(createdClient.getServiceAccountUser()).thenReturn(svcAcct);

        ClientRepresentation rmClient = new ClientRepresentation();
        rmClient.setId("rmId");
        when(clients.findByClientId("realm-management")).thenReturn(List.of(rmClient));

        ClientResource rmClientRes = mock(ClientResource.class);
        when(clients.get("rmId")).thenReturn(rmClientRes);

        RolesResource roles = mock(RolesResource.class);
        RoleResource roleRes = mock(RoleResource.class);
        when(rmClientRes.roles()).thenReturn(roles);
        when(roles.get("realm-admin")).thenReturn(roleRes);
        when(roleRes.toRepresentation()).thenReturn(new RoleRepresentation("realm-admin", null, false));

        UsersResource users = mock(UsersResource.class);
        when(realm.users()).thenReturn(users);

        UserResource userRes = mock(UserResource.class);
        RoleMappingResource roleMapping = mock(RoleMappingResource.class);

        when(users.get("svcUser1")).thenReturn(userRes);
        when(userRes.roles()).thenReturn(roleMapping);

        UserGroupServiceImpl svc = new UserGroupServiceImpl(kc);

        UserGroupCreateRequestApiV1 req = new UserGroupCreateRequestApiV1();
        req.setName("realmA");
        req.setDisplayName("Realm A");

        svc.createRealm(req);

        verify(realms).create(any(RealmRepresentation.class));
        verify(clients).create(any(ClientRepresentation.class));
        verify(resp).close();
    }
}
