package net.colt.sdwan.identity.service.impl;

import jakarta.ws.rs.core.Response;
import net.colt.sdwan.generated.model.identityaccess.UserApiV1;
import net.colt.sdwan.identity.dto.ExportUserDto;
import org.junit.jupiter.api.Test;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.*;
import org.keycloak.representations.idm.*;
import org.mockito.ArgumentCaptor;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class UserServiceImplTest {

    @Test
    void createUser_shouldCreateAndSetPassword_whenProvided() {
        Keycloak kc = mock(Keycloak.class);
        RealmResource realm = mock(RealmResource.class);
        UsersResource users = mock(UsersResource.class);

        when(kc.realm("realmA")).thenReturn(realm);
        when(realm.users()).thenReturn(users);

        Response resp = mock(Response.class);
        when(resp.getStatus()).thenReturn(201);
        when(resp.getHeaderString("Location")).thenReturn("http://x/users/uid1");
        when(users.create(any(UserRepresentation.class))).thenReturn(resp);

        UserResource created = mock(UserResource.class);
        when(users.get("uid1")).thenReturn(created);

        UserServiceImpl svc = new UserServiceImpl(kc);

        UserApiV1 in = new UserApiV1();
        in.setUsername("alice");
        in.setEmail("alice@example.com");
        in.setPassword("Secret123!");
        in.setPhoneNumber("+40123456789");

        UserApiV1 out = svc.createUser("realmA", in);

        assertEquals("uid1", out.getId());
        assertNull(out.getPassword());
        assertFalse(out.getEmailVerified());

        ArgumentCaptor<CredentialRepresentation> credCap = ArgumentCaptor.forClass(CredentialRepresentation.class);
        verify(created).resetPassword(credCap.capture());
        assertEquals(CredentialRepresentation.PASSWORD, credCap.getValue().getType());
        verify(resp).close();
    }

    @Test
    void createUser_shouldTriggerUpdatePasswordEmail_whenPasswordMissing() {
        Keycloak kc = mock(Keycloak.class);
        RealmResource realm = mock(RealmResource.class);
        UsersResource users = mock(UsersResource.class);

        when(kc.realm("realmA")).thenReturn(realm);
        when(realm.users()).thenReturn(users);

        Response resp = mock(Response.class);
        when(resp.getStatus()).thenReturn(201);
        when(resp.getHeaderString("Location")).thenReturn("http://x/users/uid1");
        when(users.create(any(UserRepresentation.class))).thenReturn(resp);

        UserResource created = mock(UserResource.class);
        when(users.get("uid1")).thenReturn(created);

        UserServiceImpl svc = new UserServiceImpl(kc);

        UserApiV1 in = new UserApiV1();
        in.setUsername("bob");
        in.setEmail("bob@example.com");

        UserApiV1 out = svc.createUser("realmA", in);
        assertEquals("uid1", out.getId());

        verify(created).executeActionsEmail(eq(List.of("UPDATE_PASSWORD")));
        verify(resp).close();
    }

    @Test
    void getUser_shouldResolveUsernameToId() {
        Keycloak kc = mock(Keycloak.class);
        RealmsResource realms = mock(RealmsResource.class);
        when(kc.realms()).thenReturn(realms);

        RealmRepresentation realmRep = new RealmRepresentation();
        realmRep.setRealm("realmA");
        when(realms.findAll()).thenReturn(List.of(realmRep));

        RealmResource realm = mock(RealmResource.class);
        UsersResource users = mock(UsersResource.class);
        when(kc.realm("realmA")).thenReturn(realm);
        when(realm.users()).thenReturn(users);

        when(users.get("alice")).thenThrow(new RuntimeException("no id"));

        UserRepresentation u = new UserRepresentation();
        u.setId("uid1");
        u.setUsername("alice");
        u.setEmail("alice@example.com");
        u.setEmailVerified(true);
        u.setAttributes(Map.of("phone_number", List.of("+40123456789")));

        when(users.search(eq("alice"), eq(true))).thenReturn(List.of(u));

        UserResource ur = mock(UserResource.class);
        when(users.get("uid1")).thenReturn(ur);
        when(ur.toRepresentation()).thenReturn(u);

        UserServiceImpl svc = new UserServiceImpl(kc);

        UserApiV1 got = svc.getUser("realmA", "alice");
        assertEquals("uid1", got.getId());
        assertEquals("alice@example.com", got.getEmail());
        assertEquals("+40123456789", got.getPhoneNumber());
        assertTrue(got.getEmailVerified());
    }

    @Test
    void updateUser_shouldUpdateAttributesAndPassword() {
        Keycloak kc = mock(Keycloak.class);
        RealmsResource realms = mock(RealmsResource.class);
        when(kc.realms()).thenReturn(realms);

        RealmRepresentation realmRep = new RealmRepresentation();
        realmRep.setRealm("realmA");
        when(realms.findAll()).thenReturn(List.of(realmRep));

        RealmResource realm = mock(RealmResource.class);
        UsersResource users = mock(UsersResource.class);
        when(kc.realm("realmA")).thenReturn(realm);
        when(realm.users()).thenReturn(users);

        UserResource ur = mock(UserResource.class);
        when(users.get("uid1")).thenReturn(ur);

        UserRepresentation rep = new UserRepresentation();
        rep.setId("uid1");
        rep.setUsername("alice");
        rep.setAttributes(Map.of("phone_number", List.of("+40123456789")));
        when(ur.toRepresentation()).thenReturn(rep);

        UserApiV1 patch = new UserApiV1();
        patch.setPhoneNumber("");
        patch.setPassword("NewPass123!");

        UserRepresentation after = new UserRepresentation();
        after.setId("uid1");
        after.setUsername("alice");
        after.setAttributes(Map.of());
        when(ur.toRepresentation()).thenReturn(rep, after);

        UserServiceImpl svc = new UserServiceImpl(kc);
        UserApiV1 out = svc.updateUser("realmA", "uid1", patch);

        verify(ur).update(any(UserRepresentation.class));
        verify(ur).resetPassword(any(CredentialRepresentation.class));
        assertNull(out.getPhoneNumber());
    }
}
