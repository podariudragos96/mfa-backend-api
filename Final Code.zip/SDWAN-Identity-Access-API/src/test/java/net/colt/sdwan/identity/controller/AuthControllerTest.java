package net.colt.sdwan.identity.controller;

import net.colt.sdwan.generated.model.identityaccess.*;
import net.colt.sdwan.identity.service.AuthFlowService;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AuthControllerTest {

    @Test
    void authLogin_shouldDelegate() {
        AuthFlowService flow = mock(AuthFlowService.class);
        AuthController c = new AuthController(flow);

        LoginRequestApiV1 req = new LoginRequestApiV1();
        when(flow.authLogin(eq(req), eq(true))).thenReturn(ResponseEntity.ok(new LoginResponseApiV1()));

        ResponseEntity<LoginResponseApiV1> resp = c.authLogin(req, true);
        assertEquals(200, resp.getStatusCodeValue());
        verify(flow).authLogin(req, true);
    }

    @Test
    void authMfaEmailSend_shouldDelegate() {
        AuthFlowService flow = mock(AuthFlowService.class);
        AuthController c = new AuthController(flow);

        SendEmailReqApiV1 req = new SendEmailReqApiV1();
        when(flow.sendEmailOtp(req)).thenReturn(ResponseEntity.ok(new AuthMfaEmailSend200Response().sent(true)));

        ResponseEntity<AuthMfaEmailSend200Response> resp = c.authMfaEmailSend(req);
        assertEquals(200, resp.getStatusCodeValue());
        verify(flow).sendEmailOtp(req);
    }

    @Test
    void authMfaEmailVerify_shouldDelegate() {
        AuthFlowService flow = mock(AuthFlowService.class);
        AuthController c = new AuthController(flow);

        VerifyEmailReqApiV1 req = new VerifyEmailReqApiV1();
        when(flow.verifyEmailOtp(req)).thenReturn(ResponseEntity.ok().build());

        ResponseEntity<Void> resp = c.authMfaEmailVerify(req);
        assertEquals(200, resp.getStatusCodeValue());
        verify(flow).verifyEmailOtp(req);
    }
}
