package net.colt.sdwan.identity.service.impl;

import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.model.identityaccess.UserGroupApiV1;
import net.colt.sdwan.generated.model.identityaccess.UserGroupCreateRequestApiV1;
import net.colt.sdwan.identity.service.UserGroupService;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.representations.idm.ClientRepresentation;
import org.keycloak.representations.idm.RealmRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UserGroupServiceImpl implements UserGroupService {

    private final Keycloak keycloak;

    private static final String MFA_CLIENT_ID = "mfa-client";
    private static final String MFA_CLIENT_SECRET = "mfa-client-secret";

    @Override
    public UserGroupApiV1 createRealm(UserGroupCreateRequestApiV1 req) {
        if (req == null) {
            throw new IllegalArgumentException("UserGroupCreateRequestApiV1 body is required");
        }

        RealmRepresentation rep = new RealmRepresentation();
        rep.setRealm(req.getName());
        rep.setDisplayName(req.getDisplayName());
        rep.setEnabled(true);

        keycloak.realms().create(rep);

        setupMfaClientForRealm(req.getName());

        RealmRepresentation created = keycloak.realm(req.getName()).toRepresentation();
        return new UserGroupApiV1(created.getId(), created.getRealm(), created.getDisplayName());
    }

    @Override
    public List<UserGroupApiV1> listUserGroups() {
        return keycloak.realms().findAll().stream()
                .map(r -> new UserGroupApiV1(r.getId(), r.getRealm(), r.getDisplayName()))
                .toList();
    }

    @Override
    public UserGroupApiV1 getUserGroupById(String userGroupId) {
        RealmRepresentation realm = findRealmByIdOrName(userGroupId);
        return new UserGroupApiV1(realm.getId(), realm.getRealm(), realm.getDisplayName());
    }

    @Override
    public UserGroupApiV1 patchUserGroupById(String userGroupId, UserGroupApiV1 userGroupApiV1) {
        if (userGroupApiV1 == null) {
            throw new IllegalArgumentException("UserGroupApiV1 body is required");
        }

        RealmRepresentation existingRealm = findRealmByIdOrName(userGroupId);
        RealmResource realmResource = keycloak.realm(existingRealm.getRealm());

        if (userGroupApiV1.getName() != null && !userGroupApiV1.getName().isBlank()) {
            existingRealm.setRealm(userGroupApiV1.getName());
        }
        if (userGroupApiV1.getDisplayName() != null && !userGroupApiV1.getDisplayName().isBlank()) {
            existingRealm.setDisplayName(userGroupApiV1.getDisplayName());
        }

        realmResource.update(existingRealm);

        RealmRepresentation updated = keycloak.realm(existingRealm.getRealm()).toRepresentation();
        return new UserGroupApiV1(updated.getId(), updated.getRealm(), updated.getDisplayName());
    }

    @Override
    public void deleteUserGroupById(String userGroupId) {
        RealmRepresentation realm = findRealmByIdOrName(userGroupId);
        keycloak.realm(realm.getRealm()).remove();
    }

    private RealmRepresentation findRealmByIdOrName(String userGroupIdOrName) {
        String v = (userGroupIdOrName == null) ? "" : userGroupIdOrName.trim();
        if (v.isEmpty()) throw new RuntimeException("user_group_id is required");

        for (RealmRepresentation r : keycloak.realms().findAll()) {
            if (r.getId() != null && r.getId().equalsIgnoreCase(v)) return r;
        }
        for (RealmRepresentation r : keycloak.realms().findAll()) {
            if (r.getRealm() != null && r.getRealm().equalsIgnoreCase(v)) return r;
        }

        throw new RuntimeException("User group (realm) not found: " + v);
    }

    private void setupMfaClientForRealm(String realmName) {
        ClientRepresentation clientRep = new ClientRepresentation();
        clientRep.setClientId(MFA_CLIENT_ID);
        clientRep.setName("MFA Service Client");
        clientRep.setSecret(MFA_CLIENT_SECRET);
        clientRep.setServiceAccountsEnabled(true);
        clientRep.setPublicClient(false);
        clientRep.setProtocol("openid-connect");
        clientRep.setDirectAccessGrantsEnabled(false);
        clientRep.setEnabled(true);

        Response resp = keycloak.realm(realmName).clients().create(clientRep);
        try {
            if (resp.getStatus() >= 200 && resp.getStatus() < 300) {
                String clientUuid = getCreatedIdFromResponse(resp);
                if (clientUuid != null) {
                    String svcAcctUserId = keycloak.realm(realmName)
                            .clients().get(clientUuid)
                            .getServiceAccountUser().getId();

                    keycloak.realm(realmName).users().get(svcAcctUserId).roles()
                            .clientLevel(getRealmManagementClientId(realmName))
                            .add(Collections.singletonList(getRealmAdminRoleRep(realmName)));
                }
            } else {
                throw new RuntimeException("Failed to create MFA client in realm " + realmName + ": HTTP " + resp.getStatus());
            }
        } finally {
            resp.close();
        }
    }

    private String getCreatedIdFromResponse(Response response) {
        String location = response.getHeaderString("Location");
        if (location == null) return null;
        int idx = location.lastIndexOf('/');
        return (idx != -1) ? location.substring(idx + 1) : null;
    }

    private String getRealmManagementClientId(String realmName) {
        return keycloak.realm(realmName)
                .clients()
                .findByClientId("realm-management")
                .get(0)
                .getId();
    }

    private RoleRepresentation getRealmAdminRoleRep(String realmName) {
        RealmResource realm = keycloak.realm(realmName);
        ClientRepresentation client = realm.clients()
                .findByClientId("realm-management")
                .stream()
                .findFirst()
                .orElseThrow(() -> new RuntimeException("realm-management client not found"));

        return realm.clients()
                .get(client.getId())
                .roles()
                .get("realm-admin")
                .toRepresentation();
    }
}
