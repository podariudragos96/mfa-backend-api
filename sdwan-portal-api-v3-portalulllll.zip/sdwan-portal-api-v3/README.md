# SD-WAN Portal API

A Spring Boot microservice based on swagger that is the accessible by UI that manage authentication security and
interact with the other microservices

## API

Link to the swagger
file: [Yaml](https://gitlab.com/coltnovitas/sdwan-portal-api-v3/-/blob/5e2de39b8f05a1481adc8ca0f2379cd99f318a93/src/main/resources/swagger/openapi.yaml)

## Changes

Here are the lists of changes

**2020-09-03 WhiteLabel - host header**

- Add X-Forwarded-Host header that will allow tenant user to connect
- New dummy branding path to test header for now
- Upgrade to Spring Boot 2.3.3.RELEASE

- New optional environment variable whitelabel.required.x-forwarded-host default to true. If true a request without the
  X-Forwarded-Host will be rejected.

**2020-10-02 WhiteLabel - SSL Certificate**

- Add environment variable whitelabel.ssl.certificates.asset-root as location files for reseller certificates
- Add environment variable whitelabel.ssl.certificates.from.email a unique email sender
- Add environment variable whitelabel.ssl.certificates.to.emails email sender as list or unique email: gg@pp.fr;
  pp@gg.fr

**2020-10-05 WhiteLabel - host header renamed**

- Rename environment variable whitelabel.required.x-forwarded-host -> whitelabel.required.x-colt-host as the Header is
  renamed to X-Colt-Host.

**2020-10-14 WhiteLabel - Customer API service exposure**

- Duplicate and amend swagger definition of customer-api tenant/tenant-user services to the portal swagger definition

**2020-10-20 WhiteLabel - Tenant based permission**

- Change permission settings from Customer-To-Site to Tenant-To-Site
    - replace url property sdwan.servcie.api.customertosite.path by sdwan.servcie.api.tenanttosite.path

**2020-11-17 WhiteLabel - Dual Authentication**

- Adding X-Colt-Host header to authentication:
    - Tenant User authentication: reseller's domain (X-Colt-Host), username and password
    - Colt authentication: username and password

**2020-12-22 WhiteLabel - Swagger Definition Update**

- Remove Add Tenant
- Add Delete Tenant
- Get all tenant for connected user
- and more...

**2020-12-22 WhiteLabel - Dual Authentication Mechanism **

- X-Colt-Host header will be compare to the portal.ui.colt.host (currently "sd-wan.colt.net" in prod)
    - If equals then colt authentication will proceed
    - If different then tenant-user authentication will proceed
- New "portal.ui.colt.host" environment variable and property value to set the portal ui host.

**2021-01-18 WhiteLabel - Add domain to user search and creation **

- New variable: portal.ui.colt.host in environment and property table that defines default colt url domain

## RUN THE SERVICE LOCALLY(STEPs)

1st update the project

1. Update the projects sdwan-common which provides some common functionalities used in this project and
   sdwan-logback-props which provide log files configuration(pull out the latest version form remote repository,
   compile, package and install)
2. Pull out the latest changes from the remote repository and update the dependencies

2nd compile the project - generate the .jar file using maven (compile & package)

3rd Configure the environment variables (check the environment variables in the docker container running this api on
rancher) and start the spring boot application 


