package net.colt.sdwan.portal.client.feign.customer;


import net.colt.sdwan.portal.generated.customerapi.controllers.ApiUserApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "apiUserClient", url = "${sdwan.customer.api.baseurl}",
        configuration = CustomerFeignConfiguration.class)
public interface ApiUserFeign extends ApiUserApi {
}
