package net.colt.sdwan.portal.config;

import ch.qos.logback.classic.LoggerContext;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

import static net.colt.sdwan.common.logging.utils.LoggingUtils.addContextListener;
import static net.colt.sdwan.common.logging.utils.LoggingUtils.addJsonConsoleAppender;

/*
 * Configures the console log appender from the app properties
 */
@Configuration
public class LoggingConfig {

    public LoggingConfig(@Value("${logging.use-json-format:false}") Boolean isUseJsonFormat,
                         ObjectProvider<BuildProperties> buildProperties,
                         ObjectMapper mapper) throws JsonProcessingException {

        LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();

        Map<String, String> map = new HashMap<>();
        buildProperties.ifAvailable(it -> map.put("version", it.getVersion()));
        String customFields = mapper.writeValueAsString(map);

        if (Boolean.TRUE.equals(isUseJsonFormat)) {
            addJsonConsoleAppender(context, customFields);
            addContextListener(context, isUseJsonFormat, customFields);
        }
    }
}