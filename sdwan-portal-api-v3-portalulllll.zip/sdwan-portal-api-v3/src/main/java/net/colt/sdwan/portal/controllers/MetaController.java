package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.MetaApiApi;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.services.MetaService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@RequiredArgsConstructor
@Controller
public class MetaController implements MetaApiApi {

    private final MetaService metaService;

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<MetaApplicationPortalV1>> getAllApplicationsV1() {
        return ResponseEntity.ok(metaService.getAllApplications());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<UrlPredefinedCategoriesResponseV1> getAllURLCategoriesV1(MetadataCriteria criteria, Integer pageNumber, Integer pageSize) {
        return ResponseEntity.ok(metaService.getAllURLCategories(criteria, pageNumber, pageSize));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<FileTypeDetailsV1>> getAllFileTypesV1() {
        return ResponseEntity.ok(metaService.getAllFileTypes());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<MetadataExceptionSignaturesPortalResponseV1> getVulnerabilityExceptionSignaturesV1(@RequestParam(value = "offset") Integer offset,
                                                                                                             @RequestParam(value = "limit") Integer limit,
                                                                                                             @RequestParam(value = "search", required = false) String search) {
        return ResponseEntity.ok(metaService.getVulnerabilityExceptionSignaturesV1(offset, limit, search));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<String>> getVulnerabilityPredefinedProfileNamesV1() {
        return ResponseEntity.ok(metaService.getVulnerabilityPredefinedProfileNamesV1());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<String>> getVulnerabilityUserDefinedApplicationsV1() {
        return ResponseEntity.ok(metaService.getVulnerabilityUserDefinedApplicationsV1());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<String>> getVulnerabilityUserDefinedClassTypesV1() {
        return ResponseEntity.ok(metaService.getVulnerabilityUserDefinedClassTypesV1());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<MetaOperatingSystemsPortalV1>> getVulnerabilityUserDefinedOperatingSystemsV1() {
        return ResponseEntity.ok(metaService.getVulnerabilityUserDefinedOperatingSystemsV1());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<MetaProductPortalV1>> getVulnerabilityUserDefinedProductsV1() {
        return ResponseEntity.ok(metaService.getVulnerabilityUserDefinedProductsV1());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<MetaReferencePortalV1>> getVulnerabilityUserDefinedReferencesV1() {
        return ResponseEntity.ok(metaService.getVulnerabilityUserDefinedReferencesV1());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<Integer>> getVulnerabilityUserDefinedCveYearsV1() {
        return ResponseEntity.ok(metaService.getVulnerabilityUserDefinedCveYearsV1());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<MetaGeoIpCountryPortalV1>> getIpFilteringGeoIpCountriesV1() {
        return ResponseEntity.ok(metaService.getIpFilteringGeoIpCountriesV1());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<String>> getIpFilteringReputationsV1() {
        return ResponseEntity.ok(metaService.getIpFilteringReputationsV1());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<MetaQueryPatternsPortalV1>> getDnsProxyQueryPatternsV1() {
        return ResponseEntity.ok(metaService.getMetaQueryPatternsV1());
    }
}
