package net.colt.sdwan.portal.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import net.colt.sdwan.portal.enums.NovitasSystemStatus;
import net.colt.sdwan.portal.enums.SystemState;

import java.util.Date;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "SYSTEM_STATUS")
public class SystemStatus {

    @Id
    @GeneratedValue
    @Column(name = "ID")
    private Integer id;

    @Column(name = "MODULE", nullable = false)
    private String module;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATE", nullable = false)
    private SystemState state;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS", nullable = false)
    private NovitasSystemStatus status;

    @Column(name = "LAST_UPDATED", nullable = false)
    private Date lastUpdated;

    @Column(name = "NEXT_AVAILABLE_AT", nullable = false)
    private Date nextAvailableAt;

    @Column(name = "MESSAGE")
    private String message;

    @Column(name = "STATIC_MESSAGE")
    private String staticMessage;
}
