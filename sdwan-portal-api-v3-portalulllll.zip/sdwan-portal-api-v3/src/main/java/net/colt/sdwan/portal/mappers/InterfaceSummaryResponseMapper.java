package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.generated.model.service.CgwResponseV1;
import net.colt.sdwan.generated.model.service.InterfaceAdminStatusV1;
import net.colt.sdwan.generated.model.service.InterfaceOperationalStatusV1;
import net.colt.sdwan.generated.model.service.InterfaceResponseV1;
import net.colt.sdwan.portal.enums.InterfaceType;
import net.colt.sdwan.portal.model.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static java.lang.Boolean.TRUE;

@Component
public class InterfaceSummaryResponseMapper {

    static final Pattern p = Pattern.compile("[A-Z]{3}/[A-Z]{3}/[A-Z0-9-]+$");

    public InterfaceSummaryResponseV1 mapFromList(final List<InterfaceResponseV1> interfaceResponses,
                                                  final String networkId, final String siteType, final List<CgwResponseV1> cgw) {
        final InterfaceSummaryResponseV1 interfaceSummaryResponse = new InterfaceSummaryResponseV1();

        if (CollectionUtils.isNotEmpty(interfaceResponses)) {
            final List<InterfaceResponseV1> lanInterfaces;
            final List<InterfaceResponseV1> wanInterfaces = interfaceResponses.stream().filter(InterfaceResponseV1::getIsWan).toList();

            interfaceSummaryResponse.setWan(mapWanFromInterfaceResponses(wanInterfaces));
            // check if is shared Gateway site and filter by IPC
            if (SiteTypeV1.CLOUD_GATEWAY.toString().equalsIgnoreCase(siteType) && cgw != null) {
                lanInterfaces = getInterfaceResponseWhenSiteIsCloudGateway(interfaceResponses, networkId, cgw);
            } else if (SiteTypeV1.GATEWAY.toString().equalsIgnoreCase(siteType)) {
                lanInterfaces = interfaceResponses.stream().filter(ir -> !ir.getIsWan() && !Objects.isNull(ir.getVersaOrgName()) && ir.getVersaOrgName().equalsIgnoreCase(networkId)).toList();
            } else {
                lanInterfaces = interfaceResponses.stream().filter(ir -> !ir.getIsWan()).toList();
            }
            interfaceSummaryResponse.setLan(mapLanFromInterfaces(lanInterfaces));

        }
        return interfaceSummaryResponse;
    }

    private static List<InterfaceResponseV1> getInterfaceResponseWhenSiteIsCloudGateway(List<InterfaceResponseV1> interfaceResponses, String networkId, List<CgwResponseV1> cgw) {
        List<InterfaceResponseV1> lanInterfaces;
        List<InterfaceResponseV1> filteredResponse = new ArrayList<>();
        for (CgwResponseV1 cwResponse : cgw) {
            interfaceResponses.stream()
                    .filter(infcs -> (infcs.getIsWan() || (!infcs.getIsWan() && networkId.equals(infcs.getVersaOrgName()))))
                    .forEach(vrfs -> {
                        if (TRUE.equals(vrfs.getIsWan()))
                            filteredResponse.add(vrfs);
                        if (vrfs.getName().equals(cwResponse.getCgwInterfaceName()) || vrfs.getName()
                                .equals(cwResponse.getCgwInterfaceName() + "." + cwResponse.getGwCvlanId())) {
                            filteredResponse.add(vrfs);
                        }
                    });
        }
        lanInterfaces = filteredResponse.stream().filter(ir -> !ir.getIsWan() && !Objects.isNull(ir.getVersaOrgName()) && ir.getVersaOrgName().equalsIgnoreCase(networkId)).toList();
        return lanInterfaces;
    }

    private WanInterfaceSummaryV1 mapWanFromInterfaceResponses(final List<InterfaceResponseV1> wanInterfaces) {
        if (CollectionUtils.isEmpty(wanInterfaces)) {
            return new WanInterfaceSummaryV1().intUplinks(0).mplsUplinks(0).mpls(false).internet(false).cellular(false).status(InterfaceStatusV1.NONE);
        }

        Set<String> intUplinks = wanInterfaces.stream()
                .filter(wan -> wan.getCircuitName() != null && wan.getCircuitName().startsWith("INT-WAN") && !wan.getCircuitName().endsWith("Failover"))
                .map(InterfaceResponseV1::getCircuitName).collect(Collectors.toSet());

        Set<String> mplsUplinks = wanInterfaces.stream()
                .filter(wan -> wan.getCircuitName() != null && wan.getCircuitName().startsWith("MPLS-WAN") && !wan.getCircuitName().endsWith("Failover"))
                .map(InterfaceResponseV1::getCircuitName).collect(Collectors.toSet());

        return new WanInterfaceSummaryV1()
                .mpls(containsStringOfType(wanInterfaces, InterfaceType.MPLS.toString()))
                .intUplinks(intUplinks.size())
                .mplsUplinks(mplsUplinks.size())
                .internet(containsStringOfType(wanInterfaces, InterfaceType.INT.toString()))
                .cellular(containsStringOfType(wanInterfaces, InterfaceType.LTE.toString()))
                .status(mapStatusFromInterfaces(wanInterfaces))
                .circuitReferences(wanInterfaces.stream()
                        .filter(i -> Objects.nonNull(i) && StringUtils.isNotBlank(i.getCircuitReference()) && p.matcher(i.getCircuitReference()).matches())
                        .map(InterfaceResponseV1::getCircuitReference)
                        .toList());
    }

    private LanInterfaceSummaryV1 mapLanFromInterfaces(final List<InterfaceResponseV1> lanInterfaces) {
        if (CollectionUtils.isEmpty(lanInterfaces)) {
            return new LanInterfaceSummaryV1().dmz(false).status(InterfaceStatusV1.NONE);
        }
        Set<InterfaceDetailsV1> interfaceDetailsV1s = lanInterfaces.stream()
                .map(i -> new InterfaceDetailsV1().name(i.getName()).vrf(i.getVrf()).network(i.getNetwork()).friendlyName(i.getFriendlyName()))
                .collect(Collectors.toSet());

        return new LanInterfaceSummaryV1()
                .dmz(containsStringOfType(lanInterfaces, "DMZ"))
                .status(mapStatusFromInterfaces(lanInterfaces))
                ._list(List.copyOf(interfaceDetailsV1s));
    }

    private boolean containsStringOfType(final List<InterfaceResponseV1> interfaceResponses, final String interfaceType) {
        return interfaceResponses.stream()
                .anyMatch(ir -> Objects.nonNull(ir.getNetwork()) ? ir.getNetwork().startsWith(interfaceType) : Objects.nonNull(ir.getFriendlyName()) && ir.getFriendlyName().startsWith(interfaceType));
    }

    private InterfaceStatusV1 mapStatusFromInterfaces(final List<InterfaceResponseV1> interfaceResponses) {
        final long numberOfMonitoredInterfaces = interfaceResponses
                .stream()
                .filter(interfaceResponseV1 ->
                        InterfaceAdminStatusV1.UP.equals(interfaceResponseV1.getAdminStatus()))
                .toList()
                .size();

        final long numberOfOperationalInterfaces = interfaceResponses.stream()
                .filter(interfaceResponseV1 ->
                        InterfaceOperationalStatusV1.UP.equals(interfaceResponseV1.getOperationalStatus()))
                .count();

        if (numberOfMonitoredInterfaces > 0 && numberOfOperationalInterfaces == 0) {
            return InterfaceStatusV1.NONE;
        }

        final boolean anyInterfaceDegraded = interfaceResponses.stream()
                .anyMatch(
                        interfaceResponseV1 ->
                                InterfaceOperationalStatusV1.DOWN.equals(interfaceResponseV1.getOperationalStatus())
                                        && InterfaceAdminStatusV1.UP.equals(interfaceResponseV1.getAdminStatus()));

        return anyInterfaceDegraded ? InterfaceStatusV1.DEGRADED : InterfaceStatusV1.FULL;
    }
}
