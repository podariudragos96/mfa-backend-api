package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.RoutePatchDocumentV1;
import net.colt.sdwan.portal.model.RoutingProtocolV1;
import net.colt.sdwan.portal.model.RoutingTypeV1;

import java.util.List;

public interface RoutesService {
    CorrelationIdResponseV1 getRouteResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocol(
            String siteId, String deviceId, String interfaceId,
            RoutingProtocolV1 routingProtocol, RoutingTypeV1 routingType, Boolean formatted);

    CorrelationIdResponseV1 getNeighborResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocol(
            String siteId, String deviceId, String interfaceId, RoutingProtocolV1 routingProtocol, Boolean brief);

    CorrelationIdResponseV1 getStatisticsResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocol(
            String siteId, String deviceId, String interfaceId, RoutingProtocolV1 routingProtocol, Boolean brief);

    CorrelationIdResponseV1 addRouteResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocol(
            String siteId, String deviceId, String interfaceId, RoutingProtocolV1 routingProtocol,
            List<RoutePatchDocumentV1> body);
}
