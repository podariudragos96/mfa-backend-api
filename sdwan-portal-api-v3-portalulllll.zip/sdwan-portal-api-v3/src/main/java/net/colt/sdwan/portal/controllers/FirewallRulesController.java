package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.FirewallApiApi;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.FirewallRulesService;
import net.colt.sdwan.portal.services.URLFilterLogsService;
import net.colt.sdwan.portal.validator.model.FirewallRulesRequestValidatorV2;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;
import java.util.List;

import static org.springframework.http.HttpStatus.OK;

@RequiredArgsConstructor
@Controller
public class FirewallRulesController implements FirewallApiApi {

    private final FirewallRulesService firewallRulesService;
    private final URLFilterLogsService urlFilterLogsService;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setValidator(new FirewallRulesRequestValidatorV2());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<FirewallRuleSetResponseV2> getFirewallRulesBySiteIdV3(String siteId) {
        return new ResponseEntity<>(firewallRulesService.getFirewallRulesBySiteIdV3(siteId), OK);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<FirewallRuleSetResponseV2> getFirewallRulesHistoryBySiteIdAndRuleSetIdV2(String siteId, String id) {
        return new ResponseEntity<>(firewallRulesService.getFirewallRulesHistoryBySiteIdAndRuleSetIdV2(siteId, id), OK);
    }


    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<FirewallRuleHistoryResponseV1>> getFirewallRulesHistoryBySiteIdV1(String siteId) {
        return new ResponseEntity<>(firewallRulesService.getFirewallRulesHistoryBySiteIdV1(siteId), OK);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<FirewallRuleLogsResponseV1>> getFirewallRulesLogsBySiteIdAndRuleNameV1(String siteId,String ruleName,
            @RequestParam(value = "start", required = true, defaultValue = "null") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime start,
            @RequestParam(value = "end", required = true, defaultValue = "null") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime end) {
        return new ResponseEntity<>(firewallRulesService.getFirewallRulesLogsBySiteIdAndRuleName(siteId, ruleName, start, end), HttpStatus.OK);
    }

    @SDWanAsyncMethod("/v3/sites/{site_id}/firewall_rules")
    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateFirewallRulesBySiteIdV3(String siteId, FirewallRulesRequestV2 firewallRulesRequestV2) {
        return new ResponseEntity<>(firewallRulesService.updateFirewallRulesBySiteIdV3(siteId, firewallRulesRequestV2), OK);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<URLFilterLogsResponseV1>> getURLFilterLogsBySiteIdV1( String siteId,
            @RequestParam(value = "start_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDt,
            @RequestParam(value = "end_dt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDt) {
        return ResponseEntity.ok(urlFilterLogsService.getUrlFilterLogsResponseV1(siteId, startDt, endDt));
    }
}
