package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.client.model.customerapi.UserResponseV3;
import net.colt.sdwan.portal.model.AccountLookupRequestV1;
import net.colt.sdwan.portal.model.AccountLookupResponseV1;

public interface PortalAuthService {

    UserResponseV3 doAuthentication(String xColtHost, String username, String password);

    AccountLookupResponseV1 accountLookup(String domain, AccountLookupRequestV1 accountLookupRequestV1);

}
