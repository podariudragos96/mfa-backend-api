package net.colt.sdwan.portal.security.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.*;
import net.colt.sdwan.portal.client.model.customerapi.CountryCode;
import net.colt.sdwan.portal.client.model.customerapi.SupportedLanguage;
import net.colt.sdwan.portal.client.model.customerapi.UserStatus;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * UserAuth
 */
@EqualsAndHashCode
@ToString
@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserAuth implements Serializable {
    private static final long serialVersionUID = 8531372249898493831L;

    private Integer userId;
    private String title;
    private String name;
    private String username;
    private String email;
    private List<Role> roles;
    private List<Integer> accessibleTenantIds;
    private CountryCode countryCode;
    private SupportedLanguage preferredLanguage;
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    private LocalDateTime lastLoggedInDt;
    private UserStatus status;
    private String customisation;
    private String userHash;
    private String accessibleTenantIdsHash;
    private String domain;
    private String versaInstance;
    private List<String> features;

    public UserAuth userId(Integer userId) {
        this.userId = userId;
        return this;
    }

    public UserAuth addNewRole(final String role) {
        if (Objects.isNull(this.roles)) {
            this.roles = new ArrayList<>();
        }
        this.roles.add(new Role(role));
        return this;
    }
}
