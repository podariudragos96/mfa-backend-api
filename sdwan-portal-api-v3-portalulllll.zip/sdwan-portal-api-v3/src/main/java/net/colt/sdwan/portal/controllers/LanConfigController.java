package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.LanConfigApiApi;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.LanConfigurationRequestV1;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.LanConfigService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;

import static org.springframework.http.HttpStatus.OK;

@RequiredArgsConstructor
@Controller
public class LanConfigController implements LanConfigApiApi {

    private final LanConfigService lanConfigService;

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/lan_config")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateLansConfigurationsV1(String siteId, LanConfigurationRequestV1 lanConfigurationRequestV1) {
        return new ResponseEntity<>(lanConfigService.updateLansConfigs(siteId, lanConfigurationRequestV1), OK);
    }
}
