package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.DNSProxyRequestV1;
import net.colt.sdwan.portal.model.DNSProxyResponseV1;
import net.colt.sdwan.portal.model.DnsProxyHistoryResponseV1;

import java.util.List;

public interface DnsProxyService {

    DNSProxyResponseV1 getDNSProxiesV1(String siteId);

    CorrelationIdResponseV1 updateDNSProxiesV1(String siteId, DNSProxyRequestV1 dnsProxyRequestV1);

    List<DnsProxyHistoryResponseV1> getDnsProxiesHistoryV1(String siteId);

    DNSProxyResponseV1 getDnsProxyResponseHistoryByIdV1(String siteId, String ruleSetId);
}
