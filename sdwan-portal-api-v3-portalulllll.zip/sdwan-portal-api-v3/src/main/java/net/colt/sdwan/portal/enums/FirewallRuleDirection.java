package net.colt.sdwan.portal.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum FirewallRuleDirection {
    INBOUND("Inbound"),
    OUTBOUND("Outbound");

    private final String name;
}
