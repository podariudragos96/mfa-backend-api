package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.InternetProtectionRulesRequestV1;
import net.colt.sdwan.portal.model.InternetProtectionRulesResponseV1;

public interface SaseInternetProtectionRuleService {

    InternetProtectionRulesResponseV1 getInternetProtectionRulesV1(String tenantUuid);

    CorrelationIdResponseV1 updateInternetProtectionRulesV1(String tenantUuid, InternetProtectionRulesRequestV1 requestV1);

}
