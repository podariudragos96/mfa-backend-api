package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SaseBreakoutRequestV1;
import net.colt.sdwan.portal.model.SaseBreakoutResponseV1;
import net.colt.sdwan.portal.model.ZScalerBreakoutRequestV1;

public interface BreakoutService {

    CorrelationIdResponseV1 updateSaseBreakoutV1(String siteId, SaseBreakoutRequestV1 saseBreakoutRequestV1);

    CorrelationIdResponseV1 updateZScalerBreakoutV1(String siteId, ZScalerBreakoutRequestV1 zScalerBreakoutRequestV1);

    SaseBreakoutResponseV1 getSaseBreakoutV1(String siteId);
}
