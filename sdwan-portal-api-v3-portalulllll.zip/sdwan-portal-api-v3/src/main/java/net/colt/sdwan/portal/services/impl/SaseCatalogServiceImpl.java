package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.versa.sase.api.*;
import net.colt.sdwan.portal.client.feign.sase.SaseCatalogFeign;
import net.colt.sdwan.portal.enums.SaseOperation;
import net.colt.sdwan.portal.mappers.SaseCatalogMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.services.SaseCatalogService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class SaseCatalogServiceImpl implements SaseCatalogService {

    private final SaseCatalogFeign saseCatalogFeign;
    private final ResponseEntityValidator responseEntityValidator;
    private final SaseCatalogMapper saseCatalogMapper;

    public SaseGeoIpCountriesCatalogResponseV1 getGeoIpCountriesV1(String tenantUuid) {
        log.info("Getting sase geoip countries catalog via sase api for tenantUuid={}", tenantUuid);

        final ResponseEntity<GeoIpCountriesCatalogResponseApiV1> response = saseCatalogFeign.getGeoIpCountriesV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.CATALOG_GEOIP_COUNTRIES_GET.getName());

        log.info("Get sase geoip countries catalog request completed successfully for tenantUuid={}.", tenantUuid);
        return saseCatalogMapper.from(response.getBody());
    }

    public SaseUrlCategoriesCatalogResponseV1 getUrlCategoriesV1(String tenantUuid) {
        log.info("Getting sase url categories catalog via sase api for tenantUuid={}", tenantUuid);

        final ResponseEntity<UrlCategoriesCatalogResponseApiV1> response = saseCatalogFeign.getUrlCategoriesV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.CATALOG_URL_CATEGORIES_GET.getName());

        log.info("Get sase url categories catalog request completed successfully for tenantUuid={}.", tenantUuid);
        return saseCatalogMapper.from(response.getBody());
    }

    public SaseUrlReputationsCatalogResponseV1 getUrlReputationsV1(String tenantUuid) {
        log.info("Getting sase url reputations catalog via sase api for tenantUuid={}", tenantUuid);

        final ResponseEntity<UrlReputationsCatalogResponseApiV1> response = saseCatalogFeign.getUrlReputationsV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.CATALOG_URL_REPUTATIONS_GET.getName());

        log.info("Get sase url reputations catalog request completed successfully for tenantUuid={}.", tenantUuid);
        return saseCatalogMapper.from(response.getBody());
    }

    public SaseApplicationsCatalogResponseV1 getApplicationsV1(String tenantUuid) {
        log.info("Getting sase applications catalog via sase api for tenantUuid={}", tenantUuid);

        final ResponseEntity<ApplicationsCatalogResponseApiV1> response = saseCatalogFeign.getApplicationsV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.CATALOG_APPLICATIONS_GET.getName());

        log.info("Get sase applications catalog request completed successfully for tenantUuid={}.", tenantUuid);
        return saseCatalogMapper.from(response.getBody());
    }

    public SaseApplicationCategoriesCatalogResponseV1 getApplicationCategoriesV1(String tenantUuid) {
        log.info("Getting sase application categories catalog via sase api for tenantUuid={}", tenantUuid);

        final ResponseEntity<ApplicationCategoriesCatalogResponseApiV1> response = saseCatalogFeign.getApplicationCategoriesV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.CATALOG_APPLICATION_CATEGORIES_GET.getName());

        log.info("Get sase application categories catalog request completed successfully for tenantUuid={}.", tenantUuid);
        return saseCatalogMapper.from(response.getBody());
    }

    public SaseApplicationGroupsCatalogResponseV1 getApplicationGroupsV1(String tenantUuid) {
        log.info("Getting sase application groups catalog via sase api for tenantUuid={}", tenantUuid);

        final ResponseEntity<ApplicationGroupsCatalogResponseApiV1> response = saseCatalogFeign.getApplicationGroupsV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.CATALOG_APPLICATION_GROUPS_GET.getName());

        log.info("Get sase application groups catalog request completed successfully for tenantUuid={}.", tenantUuid);
        return saseCatalogMapper.from(response.getBody());
    }

    public SaseServicesCatalogResponseV1 getServicesV1(String tenantUuid) {
        log.info("Getting sase services catalog via sase api for tenantUuid={}", tenantUuid);

        final ResponseEntity<ServicesCatalogResponseApiV1> response = saseCatalogFeign.getServicesV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.CATALOG_SERVICES_GET.getName());

        log.info("Get sase services catalog request completed successfully for tenantUuid={}.", tenantUuid);
        return saseCatalogMapper.from(response.getBody());
    }

    public SaseSecurityProfilesCatalogResponseV1 getSecurityProfilesV1(String tenantUuid) {
        log.info("Getting sase security profiles catalog via sase api for tenantUuid={}", tenantUuid);

        final ResponseEntity<SecurityProfilesCatalogResponseApiV1> response = saseCatalogFeign.getSecurityProfilesV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.CATALOG_SECURITY_PROFILES_GET.getName());

        log.info("Get sase security profiles catalog request completed successfully for tenantUuid={}.", tenantUuid);
        return saseCatalogMapper.from(response.getBody());
    }

    public SaseStaticZonesCatalogResponseV1 getStaticZonesV1() {
        log.info("Getting sase static zones catalog via sase api");

        final ResponseEntity<StaticZonesCatalogResponseApiV1> response = saseCatalogFeign.getStaticZonesV1();
        responseEntityValidator.checkResponseEntity(response, SaseOperation.CATALOG_STATIC_ZONES_GET.getName());

        log.info("Get sase static zones catalog request completed successfully");
        return saseCatalogMapper.from(response.getBody());
    }

    public EndpointProtectionsCatalogResponseV1 getEndpointProtectionsV1(String tenantUuid) {
        log.info("Getting sase Endpoint Protections catalog via sase api for tenantUuid={}", tenantUuid);

        final ResponseEntity<EndpointProtectionsCatalogResponseApiV1> response = saseCatalogFeign.getEndpointProtectionsV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.CATALOG_ENDPOINT_PROTECTIONS_GET.getName());

        log.info("Get sase endpoint protections catalog request completed successfully for tenantUuid={}.", tenantUuid);
        return saseCatalogMapper.from(response.getBody());
    }

    public OperatingSystemsCatalogResponseV1 getOperatingSystemsV1(String tenantUuid) {
        log.info("Getting sase Operating Systems catalog via sase api for tenantUuid={}", tenantUuid);

        final ResponseEntity<OperatingSystemsCatalogResponseApiV1> response = saseCatalogFeign.getOperatingSystemsV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.CATALOG_OPERATING_SYSTEMS_GET.getName());

        log.info("Get sase endpoint operating systems request completed successfully for tenantUuid={}.", tenantUuid);
        return saseCatalogMapper.from(response.getBody());
    }

    public ApplicationsCatalogResponseV1 getSaseApplicationsV1(String tenantUuid) {
        log.info("Getting Sase Applications catalog via sase api for tenantUuid={}", tenantUuid);

        final ResponseEntity<SaseApplicationsCatalogResponseApiV1> response = saseCatalogFeign.getSaseApplicationsV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.CATALOG_SASE_APPLICATIONS_GET.getName());

        log.info("Get sase endpoint Sase Applications request completed successfully for tenantUuid={}.", tenantUuid);
        return saseCatalogMapper.from(response.getBody());
    }

}
