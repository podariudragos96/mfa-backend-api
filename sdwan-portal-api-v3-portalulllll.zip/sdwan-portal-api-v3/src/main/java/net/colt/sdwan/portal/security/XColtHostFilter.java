package net.colt.sdwan.portal.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.portal.util.XColtHostUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

@RequiredArgsConstructor
@Component
@Slf4j
public class XColtHostFilter extends OncePerRequestFilter {

    public static final String X_COLT_HOST = "X-COLT-HOST";
    private static final List<String> pathsWithHostHeader = Arrays.asList("/branding", "/session",
            "/legal_requirements","/api_key/renew");

    private final XColtHostUtil xColtHostUtil;

    /**
     * This method filters the /branding, /session, /legal_requirements APIs. Looks
     * if the X-Colt-Host header is provided when required.
     *
     * @param httpRequest  holding the X-Colt-Host if provided
     * @param httpResponse which will return a 403 if X-Colt-Host not provided, but
     *                     required
     * @param chain
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doFilterInternal(HttpServletRequest httpRequest, HttpServletResponse httpResponse, FilterChain chain)
            throws ServletException, IOException {
        if (isNotValid(httpRequest)) {
            log.debug("Add missing header {}  for: {}.", X_COLT_HOST, httpRequest.getServletPath());
            chain.doFilter(wrapperWithXColtHost(httpRequest), httpResponse);
        } else {
            chain.doFilter(httpRequest, httpResponse);
        }

    }

    private HttpServletRequestWrapper wrapperWithXColtHost(HttpServletRequest httpRequest) {
        return new HttpServletRequestWrapper(httpRequest) {
            @Override
            public Enumeration<String> getHeaders(String name) {
                if (X_COLT_HOST.equals(name)) {
                    return Collections.enumeration(Collections.singleton(getHeader(X_COLT_HOST)));
                } else {
                    return super.getHeaders(name);
                }
            }

            @Override
            public String getHeader(String name) {
                if (X_COLT_HOST.equals(name)) {
                    return xColtHostUtil.getDefaultDomain();
                } else {
                    return super.getHeader(name);
                }
            }

            @SuppressWarnings("unchecked")
            @Override
            public Enumeration<String> getHeaderNames() {
                return Collections.enumeration(CollectionUtils.union(Collections.list(super.getHeaderNames()), Collections.singleton(X_COLT_HOST)));
            }
        };
    }

    private boolean isNotValid(HttpServletRequest httpRequest) {
        String host = httpRequest.getHeader(X_COLT_HOST);
        return StringUtils.isEmpty(host)
                && pathsWithHostHeader.stream().anyMatch(path -> httpRequest.getServletPath().contains(path));
    }

}
