package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@EqualsAndHashCode
public class InterfaceAnalyticsRowResponse {

    @JsonProperty("site")
    private String site;

    @JsonProperty("access_circuit")
    private String accessCircuit;

    @JsonProperty("uplink_bandwidth")
    private String uplinkBandwidth;

    @JsonProperty("downlink_bandwidth")
    private String downlinkBandwidth;

    @JsonProperty("ip")
    private String ip;

    @JsonProperty("isp")
    private String isp;

    @JsonProperty("appliance")
    private String applicance;

    @JsonProperty("volume_tx")
    private String volumeTx;

    @JsonProperty("volume_rx")
    private String volumeRx;

    @JsonProperty("bandwidth_tx")
    private String bandwidthTx;

    @JsonProperty("bandwidth_rx")
    private String bandwidthRx;

}
