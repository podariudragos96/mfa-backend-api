package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.metadata.api.generated.model.MetaGeoIpCountryV1;
import net.colt.sdwan.metadata.api.generated.model.MetaOperatingSystemsV1;
import net.colt.sdwan.metadata.api.generated.model.MetaProductV1;
import net.colt.sdwan.metadata.api.generated.model.MetaReferenceV1;
import net.colt.sdwan.portal.model.MetaGeoIpCountryPortalV1;
import net.colt.sdwan.portal.model.MetaOperatingSystemsPortalV1;
import net.colt.sdwan.portal.model.MetaProductPortalV1;
import net.colt.sdwan.portal.model.MetaReferencePortalV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
@Component
public class SecurityProfilesMetaMapper {

    private final ModelMapper modelMapper;

    public List<MetaOperatingSystemsPortalV1> mapVulnerabilityOSResponseListToMetaOS(List<MetaOperatingSystemsV1> metaOperatingSystemsV1s) {
        List<MetaOperatingSystemsPortalV1> result = new ArrayList<>();
        for (MetaOperatingSystemsV1 metaOperatingSystemsV1 : metaOperatingSystemsV1s) {
            result.add(modelMapper.map(metaOperatingSystemsV1, MetaOperatingSystemsPortalV1.class));
        }
        return result;
    }


    public List<MetaProductPortalV1> mapVulnerabilityProductResponseListToMetaProduct(List<MetaProductV1> metaProductV1s) {
        List<MetaProductPortalV1> result = new ArrayList<>();
        for (MetaProductV1 metaProductV1 : metaProductV1s) {
            result.add(modelMapper.map(metaProductV1, MetaProductPortalV1.class));
        }
        return result;
    }

    public List<MetaReferencePortalV1> mapVulnerabilityReferenceResponseListToMetaReference(List<MetaReferenceV1> metaReferenceV1s) {
        List<MetaReferencePortalV1> result = new ArrayList<>();
        for (MetaReferenceV1 metaReferenceV1 : metaReferenceV1s) {
            result.add(modelMapper.map(metaReferenceV1, MetaReferencePortalV1.class));
        }
        return result;
    }

    public List<MetaGeoIpCountryPortalV1> mapIpFilteringGeoIpCountryResponseListToMetaGeoIpCountry(List<MetaGeoIpCountryV1> metaGeoIpCountryV1s) {
        List<MetaGeoIpCountryPortalV1> result = new ArrayList<>();
        for (MetaGeoIpCountryV1 metaGeoIpCountryV1 : metaGeoIpCountryV1s) {
            result.add(modelMapper.map(metaGeoIpCountryV1, MetaGeoIpCountryPortalV1.class));
        }
        return result;
    }
}
