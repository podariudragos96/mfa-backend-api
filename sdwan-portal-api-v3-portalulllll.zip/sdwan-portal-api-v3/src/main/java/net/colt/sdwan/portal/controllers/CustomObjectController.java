package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.CustomObjectApiApi;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.AddressGroupService;
import net.colt.sdwan.portal.services.AddressObjectService;
import net.colt.sdwan.portal.services.ServiceObjectService;
import net.colt.sdwan.portal.services.UrlCategoryObjectService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;

@Controller
@RequiredArgsConstructor
public class CustomObjectController implements CustomObjectApiApi {

    private final AddressGroupService addressGroupService;
    private final ServiceObjectService serviceObjectService;
    private final AddressObjectService addressObjectService;
    private final UrlCategoryObjectService urlCategoryObjectService;

    @Override
    @PreAuthorize("hasFeatureFlag('PORTAL_NETWORK_OBJECTS') && hasAnyAuthority('SD-WANReadOnlyRole', 'SD-WANReadWriteRole')")
    public ResponseEntity<ServicesResponseV1> getCustomServicesV1(
            String siteId, ServiceObjectCriteria criteria, Integer pageNumber, Integer pageSize) {
        return ResponseEntity.ok(serviceObjectService.getCustomServicesV1(siteId, criteria, pageNumber, pageSize));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/objects/service")
    @PreAuthorize("hasFeatureFlag('PORTAL_NETWORK_OBJECTS') && hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateCustomServicesV1(String siteId, ServicesRequestV1 servicesRequestV1) {
        return ResponseEntity.ok(serviceObjectService.updateCustomServicesV1(siteId, servicesRequestV1));
    }

    @PreAuthorize("hasFeatureFlag('PORTAL_NETWORK_OBJECTS') && hasAnyAuthority('SD-WANReadOnlyRole', 'SD-WANReadWriteRole')")
    @Override
    public ResponseEntity<AddressGroupsResponseV1> getAddressGroupsV1(
            String siteId, AddressGroupObjectCriteria criteria, Integer pageNumber, Integer pageSize) {
        return ResponseEntity.ok(addressGroupService.getAddressGroupsV1(siteId, criteria, pageNumber, pageSize));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/objects/address_group")
    @PreAuthorize("hasFeatureFlag('PORTAL_NETWORK_OBJECTS') && hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateAddressGroupsV1(String siteId, AddressGroupsRequestV1 request) {
        return ResponseEntity.ok(addressGroupService.updateAddressGroupsV1(siteId, request));
    }

    @Override
    @PreAuthorize("hasFeatureFlag('PORTAL_NETWORK_OBJECTS') && hasAnyAuthority('SD-WANReadOnlyRole', 'SD-WANReadWriteRole')")
    public ResponseEntity<AddressesResponseV1> getAddressV1(
            String siteId, AddressObjectCriteria criteria, Integer pageNumber, Integer pageSize) {
        return ResponseEntity.ok(addressObjectService.getAddressesV1(siteId, criteria, pageNumber, pageSize));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/objects/address")
    @PreAuthorize("hasFeatureFlag('PORTAL_NETWORK_OBJECTS') && hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateAddressV1(String siteId, AddressesRequestV1 addressesRequestV1) {
        return ResponseEntity.ok(addressObjectService.updateAddressV1(siteId, addressesRequestV1));
    }

    @Override
    @PreAuthorize("hasFeatureFlag('DECRYPT_BYPASS') && hasAnyAuthority('SD-WANReadOnlyRole', 'SD-WANReadWriteRole')")
    public ResponseEntity<UrlCategoriesResponseV1> getUserDefinedUrlCategoriesV1(String siteId, UrlCategoryObjectCriteria criteria, Integer pageNumber, Integer pageSize) {
        return ResponseEntity.ok(urlCategoryObjectService.getUserDefinedUrlCategoriesV1(siteId, criteria, pageNumber, pageSize));
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/objects/user_defined/url_category")
    @PreAuthorize("hasFeatureFlag('DECRYPT_BYPASS') && hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateUrlCategoryV1(String siteId, UrlCategoriesRequestV1 urlCategoriesRequestV1) {
        return ResponseEntity.ok(urlCategoryObjectService.updateUrlCategoryV1(siteId, urlCategoriesRequestV1));
    }

}
