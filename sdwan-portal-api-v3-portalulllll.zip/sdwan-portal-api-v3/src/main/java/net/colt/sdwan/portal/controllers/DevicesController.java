package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.DeviceApiApi;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.DeviceResponseV1;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.DeviceService;
import net.colt.sdwan.portal.services.NetFlowService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;

import java.util.List;

import static org.springframework.http.HttpStatus.OK;

@RequiredArgsConstructor
@Controller
public class DevicesController implements DeviceApiApi {

    private final DeviceService deviceService;
    private final NetFlowService netFlowService;

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> getSiteDeviceDynamicInfoBySiteIdAndDeviceIdV1( String siteId, String deviceId) {
        return ResponseEntity.ok().body(deviceService.getSiteDeviceDynamicInfoBySiteIdAndDeviceId(siteId, deviceId));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<DeviceResponseV1>> getSiteDevicesBySiteIdV1(String siteId) {
        List<DeviceResponseV1> deviceResponseList = deviceService.getSiteDevicesBySiteId(siteId);
        return new ResponseEntity<>(deviceResponseList, OK);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<DeviceResponseV1> getSiteDeviceBySiteIdAndDeviceIdV1(String siteId, String deviceId) {
        return new ResponseEntity<>(deviceService.getSiteDeviceBySiteIdAndDeviceId(siteId, deviceId), OK);
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> getExtensiveMOSSessionsResponseBySiteIdAndDeviceIdV1(String siteId, String deviceId) {
        return ResponseEntity.ok(deviceService.getExtensiveMOSSessionsResponseBySiteIdAndDeviceIdV1(siteId, deviceId));
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> getDeviceCollectorStatisticsByNumberV1(
            String siteId, String deviceId, Integer collectorNumber) {
        return ResponseEntity.ok(netFlowService.getNetflowRulesStatisticsV1(siteId, deviceId, collectorNumber));
    }
}
