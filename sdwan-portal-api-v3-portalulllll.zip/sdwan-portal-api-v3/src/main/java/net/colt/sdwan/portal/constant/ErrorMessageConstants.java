package net.colt.sdwan.portal.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ErrorMessageConstants {

    public static final String CUSTOMER_OR_SITE_OR_DEVICE_NOT_FOUND_MESSAGE_TEMPLATE = "User customer not found or no valid site/device found for this siteid %s";
    public static final String FAILED_TO_CREATE_USER = "Failed to create user";
    public static final String FAILED_TO_GET_SLA_METRICS_TABLE_DATA = "Failed to get Sla Metrics table data";
    public static final String FAILED_TO_GET_FIREWALL_ZONES_ANALYTICS = "Failed to get Firewall Zones Analytics";
    public static final String FAILED_TO_GET_USERS_ANALYTICS = "Failed to get Users Analytics";
}
