package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class NatRuleSet {

    @JsonProperty("last_updated")
    private String lastUpdated;

    @JsonProperty("updated_by")
    private String updatedBy;

    @JsonProperty("description")
    private String description;

    @JsonProperty("destination_rules")
    private List<DestinationNatRuleResponse> destinationNatRuleResponseList;

    @JsonProperty("static_rules")
    private List<StaticNatRuleResponse> staticNatRuleResponseList;
}
