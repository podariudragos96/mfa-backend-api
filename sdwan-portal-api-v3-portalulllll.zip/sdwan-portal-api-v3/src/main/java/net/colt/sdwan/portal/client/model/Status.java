package net.colt.sdwan.portal.client.model;

public enum Status {

    ACTIVE("ACTIVE"),
    LOCKED("LOCKED"),
    INACTIVE("INACTIVE"),
    ARCHIVED("ARCHIVED"),
    ORDERED("ORDERED"),
    RETIRED("RETIRED");

    private final String value;

    Status(String v) {
        value = v;
    }

    public static Status fromValue(String v) {
        for (Status c : Status.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

    public String value() {
        return value;
    }
}
