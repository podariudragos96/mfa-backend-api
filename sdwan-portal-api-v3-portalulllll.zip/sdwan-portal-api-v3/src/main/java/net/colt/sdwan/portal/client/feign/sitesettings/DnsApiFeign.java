package net.colt.sdwan.portal.client.feign.sitesettings;

import net.colt.sdwan.sitesettings.api.generated.api.DnsProxyApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "dnsApiClient",
        url = "${sdwan.site.settings.api.baseurl}",
        configuration = SiteSettingsApiFeignConfiguration.class)
public interface DnsApiFeign extends DnsProxyApiApi {
}
