package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.client.model.DDoSRulesTimeSeries;
import net.colt.sdwan.portal.model.DdosAnalyticsDataResponseV1;
import net.colt.sdwan.portal.model.DdosAnalyticsLabelV1;
import net.colt.sdwan.portal.model.DdosAnalyticsMetricV1;
import net.colt.sdwan.portal.model.DdosAnalyticsTimeSeriesResponseV1;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
public class DdosAnalyticsMapper extends CommonMapper {

    public DdosAnalyticsTimeSeriesResponseV1 mapToTimeSeriesResponse(DDoSRulesTimeSeries dDoSRulesTimeSeries) {
        return new DdosAnalyticsTimeSeriesResponseV1()
                .label(DdosAnalyticsLabelV1.COUNT)
                .metric(DdosAnalyticsMetricV1.NUMBER_OF_ATTACKS)
                .data(mapToTimeSeriesData(dDoSRulesTimeSeries.getData()));
    }

    private List<DdosAnalyticsDataResponseV1> mapToTimeSeriesData(List<List<BigDecimal>> data) {
        List<DdosAnalyticsDataResponseV1> timeSeriesData = new ArrayList<>();
        if (Objects.nonNull(data)) {
            for (List<BigDecimal> dataInterval : data) {
                if (dataInterval.get(0) != null) {
                    timeSeriesData.add(new DdosAnalyticsDataResponseV1().time(dataInterval.get(0).longValue())
                            .value(dataInterval.get(1).doubleValue()));
                }
            }
        }
        return timeSeriesData;
    }
}
