package net.colt.sdwan.portal.enums;

public enum Direction {
    INBOUND,
    OUTBOUND,
    NONE,
    EAST_WEST
}
