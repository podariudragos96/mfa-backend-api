package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.metadata.api.generated.model.*;
import net.colt.sdwan.portal.model.VulnerabilityOperatingSystemV1;
import net.colt.sdwan.portal.model.VulnerabilityProductV1;
import net.colt.sdwan.portal.model.VulnerabilityReferenceV1;
import org.apache.commons.collections4.CollectionUtils;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class MetaMapper {

    private final ModelMapper modelMapper;

    public MetadataValidateListRequestV1 mapToMetadataValidateListRequestV1(
            final List<String> targetList) {
        MetadataValidateListRequestV1 metadataValidateListRequestV1 = new MetadataValidateListRequestV1();
        if (CollectionUtils.isNotEmpty(targetList)) {
            metadataValidateListRequestV1.data(targetList);
        }
        return metadataValidateListRequestV1;
    }

    public MetadataValidateIntListRequestV1 mapToMetadataValidateIntListRequestV1(
            final List<Integer> targetList) {
        MetadataValidateIntListRequestV1 metadataValidateListRequestV1 = new MetadataValidateIntListRequestV1();
        if (CollectionUtils.isNotEmpty(targetList)) {
            metadataValidateListRequestV1.data(targetList);
        }
        return metadataValidateListRequestV1;
    }

    public MetadataValidateOSRequestV1 mapToMetadataValidateOSRequest(
            final List<VulnerabilityOperatingSystemV1> operatingSystemV1s) {
        MetadataValidateOSRequestV1 metadataValidateOSRequestV1 = new MetadataValidateOSRequestV1();
        if (CollectionUtils.isNotEmpty(operatingSystemV1s)) {
            metadataValidateOSRequestV1.operatingSystems(mapToMetadataValidateOS(operatingSystemV1s));
        }
        return metadataValidateOSRequestV1;
    }

    private List<MetaOperatingSystemsValidateV1> mapToMetadataValidateOS(
            final List<VulnerabilityOperatingSystemV1> operatingSystems) {
        List<MetaOperatingSystemsValidateV1> result = new ArrayList<>();
        for (VulnerabilityOperatingSystemV1 operatingSystemV1 : operatingSystems) {
            result.add(modelMapper.map(operatingSystemV1, MetaOperatingSystemsValidateV1.class));
        }
        return result;
    }

    public MetadataValidateProductRequestV1 mapToMetadataValidateProductsRequest(
            final List<VulnerabilityProductV1> products) {
        MetadataValidateProductRequestV1 metadataValidateProductRequestV1 = new MetadataValidateProductRequestV1();
        if (CollectionUtils.isNotEmpty(products)) {
            metadataValidateProductRequestV1.products(mapToMetadataValidateProducts(products));
        }
        return metadataValidateProductRequestV1;
    }

    private List<MetaProductValidateV1> mapToMetadataValidateProducts(
            final List<VulnerabilityProductV1> products) {
        List<MetaProductValidateV1> result = new ArrayList<>();
        for (VulnerabilityProductV1 product : products) {
            result.add(modelMapper.map(product, MetaProductValidateV1.class));
        }
        return result;
    }

    public MetadataValidateReferenceRequestV1 mapToMetadataValidateReferencesRequest(
            final List<VulnerabilityReferenceV1> references) {
        MetadataValidateReferenceRequestV1 metadataValidateReferenceRequestV1 = new MetadataValidateReferenceRequestV1();
        if (CollectionUtils.isNotEmpty(references)) {
            metadataValidateReferenceRequestV1.references(mapToMetadataValidateReferences(references));
        }
        return metadataValidateReferenceRequestV1;
    }

    private List<MetaReferenceValidateV1> mapToMetadataValidateReferences(
            final List<VulnerabilityReferenceV1> references) {
        List<MetaReferenceValidateV1> result = new ArrayList<>();
        for (VulnerabilityReferenceV1 reference : references) {
            MetaReferenceValidateV1 metaReferenceValidateV1 = new MetaReferenceValidateV1();
            metaReferenceValidateV1.setName(reference.getType());
            metaReferenceValidateV1.setValue(reference.getValue());
            result.add(metaReferenceValidateV1);
        }
        return result;
    }
}
