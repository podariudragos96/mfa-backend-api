package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Setter
@Getter
@Builder
@EqualsAndHashCode
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class LocalInternetBreakoutPreferences {

    @JsonProperty("wan_interface")
    private String wanInterface;

    @JsonProperty("action")
    private String action;

    @JsonProperty("preference")
    private Integer preference;
}
