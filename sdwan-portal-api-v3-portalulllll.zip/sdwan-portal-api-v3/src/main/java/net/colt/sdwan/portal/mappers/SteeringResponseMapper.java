package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.model.SteeringPolicyResponseV1;
import net.colt.sdwan.steering.api.generated.model.SteeringPolicyApiResponseV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SteeringResponseMapper {

    private final ModelMapper modelMapper;

    public SteeringPolicyResponseV1 mapPolicyResponseV1(SteeringPolicyApiResponseV1 steeringPolicyApiResponseV1) {
        return modelMapper.map(steeringPolicyApiResponseV1, SteeringPolicyResponseV1.class);
    }
}
