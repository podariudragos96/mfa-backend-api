package net.colt.sdwan.portal.client.feign.security;

import net.colt.sdwan.security.api.generated.api.SslDecryptionCertificateApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "SslDecryptionCertificateApiFeign", url = "${sdwan.security.api.baseurl}",
        configuration = SecurityApiFeignConfiguration.class)
public interface SslDecryptionCertificateApiFeign extends SslDecryptionCertificateApiApi {
}
