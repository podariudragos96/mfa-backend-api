package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.model.service.LoggingV1;
import net.colt.sdwan.generated.model.service.SecurityResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1SiteFeatures;
import net.colt.sdwan.portal.model.DdosRuleHistoryResponseV1;
import net.colt.sdwan.portal.model.DdosRuleSetResponseV1;
import net.colt.sdwan.portal.model.DdosRulesRequestV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.security.api.generated.model.DdosRuleHistoryApiResponseV1;
import net.colt.sdwan.security.api.generated.model.DdosRulesApiRequestV1;
import net.colt.sdwan.security.api.generated.model.DdosRulesApiResponseV1;
import net.colt.sdwan.security.api.generated.model.LoggerType;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class DdosRulesMapper {

    private final ModelMapper modelMapper;

    public DdosRuleSetResponseV1 from(DdosRulesApiResponseV1 ddosRuleSetApiResponse) {
        return modelMapper.map(ddosRuleSetApiResponse, DdosRuleSetResponseV1.class);
    }

    public List<DdosRuleHistoryResponseV1> from(List<DdosRuleHistoryApiResponseV1> ddosRuleHistory) {
        return Optional.ofNullable(ddosRuleHistory).map(history -> history.stream().map(this::from).toList()).orElseGet(ArrayList::new);
    }

    private DdosRuleHistoryResponseV1 from(DdosRuleHistoryApiResponseV1 history) {
        return modelMapper.map(history, DdosRuleHistoryResponseV1.class);
    }

    public DdosRulesApiRequestV1 from(DdosRulesRequestV1 ddosRulesRequestV, SiteResponseV1 siteResponse) {
        return ddosRulesRequestV.getRuleSet().stream()
                .findFirst()
                .map(ddosRuleSetRequestV1 -> modelMapper
                        .map(ddosRuleSetRequestV1, DdosRulesApiRequestV1.class)
                        .loggerType(Optional.ofNullable(siteResponse.getSiteFeatures())
                                .map(SiteResponseV1SiteFeatures::getSecurity)
                                .map(SecurityResponseV1::getLogging)
                                .map(LoggingV1::getLoggingType)
                                .map(LoggerType::fromValue)
                                .orElse(LoggerType.DEFAULT))
                        .initiatedUserId(Objects.requireNonNull(AuthUserHelper.getAuthUser()).getUsername()))
                .orElseGet(DdosRulesApiRequestV1::new);
    }

}
