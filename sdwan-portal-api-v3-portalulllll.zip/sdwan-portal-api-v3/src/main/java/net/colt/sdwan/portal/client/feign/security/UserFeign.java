package net.colt.sdwan.portal.client.feign.security;

import net.colt.sdwan.portal.client.feign.customer.CustomerFeignConfiguration;
import net.colt.sdwan.portal.generated.customerapi.controllers.UserApiV3Api;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "userClient", url = "${sdwan.customer.api.baseurl}", configuration = CustomerFeignConfiguration.class)
public interface UserFeign extends UserApiV3Api {


}
