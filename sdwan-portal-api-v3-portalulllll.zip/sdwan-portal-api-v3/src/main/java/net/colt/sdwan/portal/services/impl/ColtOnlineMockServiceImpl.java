package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.coltonlinemock.api.generated.model.AuthenticationMockRequestV1;
import net.colt.sdwan.coltonlinemock.api.generated.model.ColtOnlineMockUserResponseV1;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.common.exceptions.exception.SdwanForbiddenException;
import net.colt.sdwan.portal.client.feign.coltonlinemock.ColtOnlineMockAuthenticationApiFeign;
import net.colt.sdwan.portal.client.feign.coltonlinemock.ColtOnlineMockUserApiFeign;
import net.colt.sdwan.portal.client.model.customerapi.CustomerSummaryResponseV1;
import net.colt.sdwan.portal.client.model.customerapi.UserResponseV3;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.ColtOnlineAuthService;
import net.colt.sdwan.portal.services.CustomerService;
import net.colt.sdwan.portal.services.UserService;
import net.colt.sdwan.portal.util.XColtHostUtil;
import net.colt.sdwan.portal.validator.NovitasAccessRoleValidator;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.util.List;

import static java.util.Objects.nonNull;
import static org.apache.commons.collections4.CollectionUtils.isNotEmpty;

/**
 * This class is mainly use to promote the Authentication in SD-WAN Portal via UI and API Key, for Non-Prod env.
 * (DEV, QA, QA-MOCK, SIT, RFS, DEMO)
 */
@Service
@Slf4j
@RequiredArgsConstructor
@ConditionalOnProperty(name = "colt-online.webservice.auth.enabled", havingValue = "false", matchIfMissing = true)
public class ColtOnlineMockServiceImpl implements ColtOnlineAuthService {

    private final ColtOnlineMockAuthenticationApiFeign coltOnlineMockAuthenticationApiFeign;
    private final ColtOnlineMockUserApiFeign coltOnlineMockUserApiFeign;
    private final UserService userService;
    private final CustomerService customerService;
    private final XColtHostUtil xColtHostUtil;

    @Override
    public UserResponseV3 doAuthentication(String username, String password) {
        final ColtOnlineMockUserResponseV1 coltOnlineMockUser = authenticateUser(username, password);

        log.debug("Check for authorisation for authenticated user: {}", username);
        List<String> ocns = userService.collectOcnList(coltOnlineMockUser);

        try {
            NovitasAccessRoleValidator.hasNovitasAccessRole(coltOnlineMockUser);
            //Check for valid ocns
            List<String> validatedOcns = validateCustomerOcn(username, ocns);
            ocns = ocns.stream()
                    .filter(validatedOcns::contains)
                    .toList();

        } catch (AccessDeniedException ex) {
            throw new SdwanForbiddenException(
                    "No Novitas Access Role for username='%s' and ocns '%s' while authenticating to Colt Online Mock"
                            .formatted(username, ocns), ex);

        } catch (SdwanBadRequestException ex) {
            throw new SdwanBadRequestException(
                    "An error has occurred when validating Novitas Access Role for username='%s' and ocns '%s' while authenticating to Colt Online Mock"
                            .formatted(username, ocns), ex);
        }

        final UserResponseV3 user = userService.getUserByUsernameAndDomain(username, xColtHostUtil.getDefaultDomain());

        if (nonNull(user)) {
            userService.updateExistingUser(user, coltOnlineMockUser.getRoles(), ocns);
            UserResponseV3 result = userService.getUserById(user.getUserId());
            // Add domain that is required for later use
            if (StringUtils.isEmpty(result.getDomain())) {
                result.setDomain(xColtHostUtil.getDefaultDomain());
            }
            // Add feature flags for auth purposes
            result.setFeatures(user.getFeatures());
            return result;

        } else {
            return userService.createUser(coltOnlineMockUser, ocns);
        }
    }

    @Override
    public UserAuth accessUserAuthorities(final String username) {
        final UserAuth userAuth = UserAuth.builder().username(username).build();

        final ColtOnlineMockUserResponseV1 coltOnlineMockUser = getUserByUserId(username);

        if (nonNull(coltOnlineMockUser) && isNotEmpty(coltOnlineMockUser.getRoles())) {
            coltOnlineMockUser.getRoles()
                    .forEach(userAuth::addNewRole);
        }

        return userAuth;
    }

    private ColtOnlineMockUserResponseV1 authenticateUser(String username, String password) {
        final AuthenticationMockRequestV1 requestV1 = new AuthenticationMockRequestV1(username, password);
        final ResponseEntity<ColtOnlineMockUserResponseV1> response = coltOnlineMockAuthenticationApiFeign.loginV1(requestV1);

        if (nonNull(response) && nonNull(response.getBody())) {
            return response.getBody();
        }

        throw new SdwanForbiddenException("Failed to retrieve user details (roles and ocns) after login for username='%s'.".formatted(username));
    }

    private List<String> validateCustomerOcn(String username, List<String> ocns) {
        List<CustomerSummaryResponseV1> customers = customerService.findAllByOcnList(ocns);
        if (CollectionUtils.isEmpty(customers)) {
            log.debug("No valid OCN found: {}", username);
            throw new SdwanBadRequestException("No OCN found.");
        }
        return customers.stream()
                .map(CustomerSummaryResponseV1::getOcn)
                .toList();
    }

    private ColtOnlineMockUserResponseV1 getUserByUserId(String userId) {
        final ResponseEntity<ColtOnlineMockUserResponseV1> responseEntity =
                coltOnlineMockUserApiFeign.getUserByUserIdV1(userId);

        final ColtOnlineMockUserResponseV1 coltOnlineMockUser = responseEntity.getBody();

        if (nonNull(coltOnlineMockUser)) {
            return coltOnlineMockUser;
        }

        return null;
    }

}
