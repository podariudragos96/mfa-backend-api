package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DDoSRuleSet {

    @JsonProperty("id")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String id;

    @JsonProperty("updated_by")
    private String updatedBy;

    @JsonProperty("last_updated")
    private String lastUpdated;

    @JsonProperty("description")
    private String description;

    @Valid
    @NotNull(message = "ddos-rules can't be null.")
    @Size(min = 0, max = 1000, message = "Minimum and Maximum limit for ddos-rules is 0 to 1000.")
    @JsonProperty("ddos-rules")
    private List<DDoSRule> ddosRuleList;

}
