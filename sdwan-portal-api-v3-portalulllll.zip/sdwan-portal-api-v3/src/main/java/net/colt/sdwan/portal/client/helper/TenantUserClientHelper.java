package net.colt.sdwan.portal.client.helper;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.common.data.criteria.filter.IntegerFilter;
import net.colt.sdwan.portal.client.feign.customer.TenantUserFeign;
import net.colt.sdwan.portal.client.model.customerapi.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@RequiredArgsConstructor
@Component
public class TenantUserClientHelper {

    private final TenantUserFeign tenantUserFeign;

    private static final Integer PAGE = 0;
    private static final Integer SIZE = 10;

    public ResponseEntity<TenantUsersResponseApiV1> getTenantUsers(TenantUsersCriteriaApiV1 criteriaApiV1, Integer pageNumber, Integer pageSize) {
        return tenantUserFeign.getTenantUsersV1(criteriaApiV1, pageNumber, pageSize);
    }


    public TenantUserApiV1 getTenantUserById(Integer tenantUserId) {
        final IntegerFilter tenantUserIdFilter = new IntegerFilter();
        tenantUserIdFilter.setIn(List.of(tenantUserId));

        final TenantUsersCriteriaApiV1 criteria =
                TenantUsersCriteriaApiV1.builder()
                        .tenantUserId(tenantUserIdFilter)
                        .build();

        final ResponseEntity<TenantUsersResponseApiV1> response =
                tenantUserFeign.getTenantUsersV1(criteria, PAGE, SIZE);

        if (Objects.isNull(response)
                || !HttpStatus.OK.equals(response.getStatusCode())
                || Objects.isNull(response.getBody())) {
            return null;
        }

        return Optional.ofNullable(response.getBody().getTenantUsers())
                .orElse(List.of())
                .stream()
                .filter(t -> tenantUserId.equals(t.getTenantUserId()))
                .findFirst()
                .orElse(null);
    }

    public CreateTenantUserResponseV1 createTenantUser(Integer tenantId, CreateTenantUserRequestV1 createTenantUserRequestV1) {
        final ResponseEntity<CreateTenantUserResponseV1> response = tenantUserFeign.addTenantUserV1(tenantId, createTenantUserRequestV1);
        CreateTenantUserResponseV1 body = null;

        if (Objects.nonNull(response)) {
            body = response.getBody();
        }
        return body;
    }

    public void editTenantUser(Integer tenantUserId, EditTenantUserRequestV1 editTenantUserRequestV1) {
        tenantUserFeign.editTenantUserV1(tenantUserId, editTenantUserRequestV1);
    }

    public void deleteTenantUserByIdV1(Integer tenantUserId) {
        tenantUserFeign.deleteTenantUserByIdV1(tenantUserId);
    }

}
