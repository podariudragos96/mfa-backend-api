package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class CgwDetails {

    @JsonProperty("cgw_name")
    private String cgwName;

    @JsonProperty("cgw_node")
    private String cgwNode;

    @JsonProperty("cgw_fqdn_name")
    private String cgwFdqnName;

    @JsonProperty("cgw_interface_name")
    private String cgwInterfaceName;

    @JsonProperty("csp_name")
    private String cspName;

    @JsonProperty("csp_as_number")
    private String cspAsNumber;

    @JsonProperty("csp_md5_authentication")
    private String cspMd5Authentication;

    @JsonProperty("csp_service_key")
    private String cspId;

    @JsonProperty("csp_address")
    private String cspAddress;

    @JsonProperty("csp_location")
    private String cspLocation;

    @JsonProperty("csp_peering_ip")
    private String cspPeeringIp;

    @JsonProperty("csp_bearer_circuit_id")
    private String cspBearerCircuitId;

    @JsonProperty("csp_peering_interface")
    private String cspPeeringInterface;

    @JsonProperty("svlan_id")
    private String sVlanId;

    @JsonProperty("cvlan_id")
    private String cVlanId;

    @JsonProperty("gw_ip_address")
    private String gwIpAddress;

    @JsonProperty("gw_cvlan_id")
    private String gwCVlanId;

    @JsonProperty("sdwan_vpn_id")
    private String sdwanVpnId;

    @JsonProperty("routing_domain")
    private String routingDomain;
}
