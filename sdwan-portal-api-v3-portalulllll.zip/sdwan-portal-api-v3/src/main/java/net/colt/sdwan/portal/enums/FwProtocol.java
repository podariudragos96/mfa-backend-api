package net.colt.sdwan.portal.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum FwProtocol {

    ICMP("ICMP"),
    TCP("TCP"),
    UDP("UDP"),
    RDP("RDP"),
    AH("AH"),
    ESP("ESP"),
    ANY("Any"),
    TCP_OR_UDP("TCP_OR_UDP");

    private final String name;

    public static boolean contains(String value) {

        for (FwProtocol p : FwProtocol.values()) {
            if (p.name().equals(value)) {
                return true;
            }
        }

        return false;
    }
}
