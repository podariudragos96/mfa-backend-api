package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import lombok.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * NetFlowHistoryResponseV1
 */
@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NetFlowHistoryResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("rule_sets")
    @Valid
    private List<NetFlowResponse> ruleSets = new ArrayList<>();
}

