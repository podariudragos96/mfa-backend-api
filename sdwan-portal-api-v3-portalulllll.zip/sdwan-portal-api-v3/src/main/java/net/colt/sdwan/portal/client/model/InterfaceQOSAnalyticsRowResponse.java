package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class InterfaceQOSAnalyticsRowResponse {

    @JsonProperty("circuitName")
    private String circuitName;

    @JsonProperty("sessions")
    private String sessions;

    @JsonProperty("volume_rx")
    private String volumeRx;

    @JsonProperty("volume_tx")
    private String volumeTx;

    @JsonProperty("duration")
    private String duration;

    @JsonProperty("volume")
    private String volume;

    @JsonProperty("bw_rx")
    private String bwRx;

    @JsonProperty("bw_tx")
    private String bwTx;

    @JsonProperty("bandwidth")
    private String bandwidth;
}
