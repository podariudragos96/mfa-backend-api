package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.model.DecryptionRuleSetRequestV1;
import net.colt.sdwan.portal.model.DecryptionRuleSetResponseV1;
import net.colt.sdwan.portal.model.DecryptionRulesHistoryResponseV1;
import net.colt.sdwan.security.api.generated.model.DecryptionRuleSetApiResponseV1;
import net.colt.sdwan.security.api.generated.model.DecryptionRulesHistoryApiResponseV1;
import net.colt.sdwan.security.api.generated.model.DecryptionRulesRequestApiV1;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper
public interface DecryptionMapper {

    @Mapping(source = "updatedAt", target = "updatedDt")
    DecryptionRuleSetResponseV1 from(DecryptionRuleSetApiResponseV1 body);

    @Mapping(source = "updatedAt", target = "updatedDt")
    DecryptionRulesHistoryResponseV1 from(DecryptionRulesHistoryApiResponseV1 historyApiResponseV1);

    List<DecryptionRulesHistoryResponseV1> from(List<DecryptionRulesHistoryApiResponseV1> body);

    DecryptionRulesRequestApiV1 from(DecryptionRuleSetRequestV1 request);
}
