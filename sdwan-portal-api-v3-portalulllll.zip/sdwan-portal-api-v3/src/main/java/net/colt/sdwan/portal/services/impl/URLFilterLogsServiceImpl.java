package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.common.async.utils.ThreadUtils;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.AnalyticsApiClient;
import net.colt.sdwan.portal.client.model.URLFilterLogsResponse;
import net.colt.sdwan.portal.model.FirewallV1;
import net.colt.sdwan.portal.model.URLFilterLogsResponseV1;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.services.URLFilterLogsService;
import net.colt.sdwan.portal.util.CompletableFutureUtil;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static net.colt.sdwan.portal.util.LocalDateTimeOperations.mapTimestamp;

@RequiredArgsConstructor
@Service
public class URLFilterLogsServiceImpl implements URLFilterLogsService {

    private final SitesService sitesService;
    private final AnalyticsApiClient analyticsApiClient;
    private final SiteResponseValidator siteResponseValidator;

    @Override
    public List<URLFilterLogsResponseV1> getUrlFilterLogsResponseV1(String siteId, LocalDateTime startDt, LocalDateTime endDt) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final boolean hasAdvancedFirewall = FirewallV1.ADVANCED.getValue().equals(siteResponse.getSiteFeatures().getSecurity().getFirewall().getValue());

        siteResponseValidator.validateSecurityProfileFeatureSupport(hasAdvancedFirewall, siteResponse.getSiteFeatures().getSecurity().getUrlFilteringEnabled());

        if (StringUtils.isBlank(siteResponse.getNetworkId()) || startDt.isAfter(endDt)) {
            throw new SdwanBadRequestException("Empty versa org name for siteId: " + siteId);
        }

        final List<CompletableFuture<List<URLFilterLogsResponse>>> responses = siteResponse.getDevices().stream()
                .map(device -> CompletableFuture.supplyAsync(ThreadUtils.withMdc(() -> analyticsApiClient
                        .getURLLogsResponses(siteResponse, device.getResourceName(), startDt, endDt))))
                .toList();

        final List<URLFilterLogsResponse> urlFilterLogsResponses = CompletableFutureUtil.getCompletableFutureValues(responses)
                .stream()
                .flatMap(List::stream)
                .toList();

        return urlFilterLogsResponses.stream()
                .map(logs -> {
                    URLFilterLogsResponseV1 response = new ModelMapper().map(logs, URLFilterLogsResponseV1.class);
                    response.setReceiveTime(mapTimestamp(logs.getReceiveTime()));
                    return response;
                })
                .toList();
    }
}
