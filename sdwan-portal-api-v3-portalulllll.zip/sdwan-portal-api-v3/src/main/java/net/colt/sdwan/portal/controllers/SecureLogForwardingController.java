package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.SecureLogForwardingApiApi;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SecureLogForwardingHistoryResponseV1;
import net.colt.sdwan.portal.model.SecureLogForwardingRequestV1;
import net.colt.sdwan.portal.model.SecureLogForwardingResponseV1;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.SecureLogForwardingService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;


@Controller
@RequiredArgsConstructor
public class SecureLogForwardingController implements SecureLogForwardingApiApi {

    private final SecureLogForwardingService secureLogForwardingService;

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/secure_log_forwarding")
    @PreAuthorize("hasFeatureFlag('SECURE_LOG_FORWARDING') && hasAnyAuthority('SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateSecureLogForwardingV1(String siteId,
                                                                               @RequestBody SecureLogForwardingRequestV1 secureLogForwardingRequestV1) {
        return ResponseEntity.ok(secureLogForwardingService.updateSecureLogForwardingV1(siteId, secureLogForwardingRequestV1));
    }

    @Override
    @PreAuthorize("hasFeatureFlag('SECURE_LOG_FORWARDING') &&  hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<SecureLogForwardingResponseV1> getSecureLogForwardingV1(String siteId) {

        return ResponseEntity.ok(secureLogForwardingService.getSecureLogForwardingV1(siteId));
    }

    @Override
    @PreAuthorize("hasFeatureFlag('SECURE_LOG_FORWARDING') && hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<SecureLogForwardingHistoryResponseV1>> getSecureLogForwardingHistoryBySiteIdV1(String siteId) {
        return ResponseEntity.ok(secureLogForwardingService.getSecureLogForwardingHistoryBySiteIdV1(siteId));
    }

    @Override
    @PreAuthorize("hasFeatureFlag('SECURE_LOG_FORWARDING') && hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<SecureLogForwardingResponseV1> getSecureLogForwardingHistoryBySiteIdAndRuleSetIdV1(String siteId, String id) {
        return ResponseEntity.ok(secureLogForwardingService.getSecureLogForwardingHistoryBySiteIdAndRuleSetIdV1(siteId, id));
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasFeatureFlag('SECURE_LOG_FORWARDING') && hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> getSlfCollectorStatisticsByNumberV1(
            String siteId,
            String deviceId,
            Integer collectorNumber) {
        return ResponseEntity.ok(secureLogForwardingService.getSecureLogForwardingStatisticsV1(siteId, deviceId, collectorNumber));
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasFeatureFlag('SECURE_LOG_FORWARDING') && hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> getCollectorStatusByNumberV1(
            String siteId,
            String deviceId,
            Integer collectorNumber) {
        return ResponseEntity.ok(secureLogForwardingService.getSecureLogForwardingStatusV1(siteId, deviceId, collectorNumber));
    }
}
