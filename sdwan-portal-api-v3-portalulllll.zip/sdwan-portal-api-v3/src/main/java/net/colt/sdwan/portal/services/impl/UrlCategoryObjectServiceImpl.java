package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.feign.sitesettings.CustomObjectApiFeign;
import net.colt.sdwan.portal.mappers.UrlCategoryObjectMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.services.UrlCategoryObjectService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.portal.validator.access.CustomObjectValidator;
import net.colt.sdwan.sitesettings.api.generated.model.UrlCategoriesResponseApiV1;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;

@Service
@Slf4j
@RequiredArgsConstructor
public class UrlCategoryObjectServiceImpl implements UrlCategoryObjectService {

    private final SitesService sitesService;
    private final UrlCategoryObjectMapper mapper;
    private final CustomObjectApiFeign customObjectApiFeign;
    private final SiteResponseValidator siteResponseValidator;
    private final ResponseEntityValidator responseEntityValidator;

    @Override
    public UrlCategoriesResponseV1 getUserDefinedUrlCategoriesV1(String siteId, UrlCategoryObjectCriteria criteria, Integer pageNumber, Integer pageSize) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        CustomObjectValidator.validateAccess(siteResponse);
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        final ResponseEntity<UrlCategoriesResponseApiV1> response = customObjectApiFeign.getUrlCategoriesV1(
                Integer.valueOf(siteId), siteResponse.getNetworkId(), mapper.from(criteria), pageNumber, pageSize);
        return mapper.from(response.getBody());
    }

    @Override
    public CorrelationIdResponseV1 updateUrlCategoryV1(String siteId, UrlCategoriesRequestV1 urlCategoriesRequestV1) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        CustomObjectValidator.validateAccess(siteResponse);
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        try {
            sitesService.updateOngoingAction(siteId, OnGoingActionV2.MODIFYING_URL_CATEGORY_OBJECTS);

            final ResponseEntity<Void> responseEntity = customObjectApiFeign.updateUrlCategoryV1(
                    Integer.valueOf(siteId), siteResponse.getNetworkId(), AuthUserHelper.getAuthUser().getUsername(),
                    sitesService.getDeviceNamesFromSiteResponse(siteResponse), mapper.from(urlCategoriesRequestV1));
            responseEntityValidator.checkResponseEntity(responseEntity, "customObjectApiFeign.updateUrlCategoryV1");
        } catch (Exception ex) {
            log.error("Failed to updateUrlCategoryV1 for siteId='{}'.", siteId, ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

}
