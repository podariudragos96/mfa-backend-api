package net.colt.sdwan.portal.client.feign.sase;

import net.colt.sdwan.generated.controller.versa.sase.api.AuthenticationProfileApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "saseAuthenticationProfileFeign",
        url = "${sdwan.sase.api.baseurl}",
        configuration = SaseApiFeignConfiguration.class)
public interface SaseAuthenticationProfileFeign extends AuthenticationProfileApiApi {
}
