package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.TenantPortalApiApi;
import net.colt.sdwan.portal.model.EditTenantPortalRequestV1;
import net.colt.sdwan.portal.model.TenantPortalResponseV1;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.TenantService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@RequiredArgsConstructor
@Controller
@PreAuthorize("hasAnyAuthority('SD-WANRWWLTenantRole')")
public class TenantPortalController implements TenantPortalApiApi {

    private final TenantService tenantService;

    @Override
    public ResponseEntity<TenantPortalResponseV1> getTenantByIdV1(Integer tenantId) {
        return ResponseEntity.ok(tenantService.getTenantById(tenantId));
    }

    @Override
    public ResponseEntity<List<TenantPortalResponseV1>> getResellerTenantsV1() {
        return ResponseEntity.ok(tenantService.getAccessibleResellerTenants());
    }

    @Override
    @SDWanAsyncMethod("/v1/tenant/{tenant_id}")
    public ResponseEntity<Void> editTenantV1(Integer tenantId,
            @RequestBody EditTenantPortalRequestV1 editTenantPortalRequestV1) {
        tenantService.editTenant(tenantId, editTenantPortalRequestV1);
        return ResponseEntity.ok().build();
    }

}
