package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * Range
 */
@Setter
@Getter
@NoArgsConstructor
public class Range implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("from")
    private Integer from;

    @JsonProperty("to")
    private Integer to;
}