package net.colt.sdwan.portal.mappers;

import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.model.FirewallRule;
import net.colt.sdwan.portal.client.model.FirewallRules;
import net.colt.sdwan.portal.client.model.FwAction;
import net.colt.sdwan.portal.model.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.IntStream;

import static net.colt.sdwan.portal.util.PortStringSerializer.fromCSV;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Component
@Slf4j
public class FirewallRulesMapper extends SecurityCommonMapper {

    public List<FirewallRuleHistoryResponseV1> mapFromRuleSetListV2(final List<FirewallRules> firewallRules) {
        return firewallRules.stream().map(this::mapFromFirewallRulesV2).toList();
    }

    public FirewallRuleHistoryResponseV1 mapFromFirewallRulesV2(final FirewallRules firewallRules) {
        log.debug("Calling mapFromFirewallRules with {}", firewallRules);
        return new FirewallRuleHistoryResponseV1()
                .id(firewallRules.getId())
                .updatedDt(mapStrToLocalDateTime(firewallRules.getLastUpdated()))
                .updatedBy(firewallRules.getUpdatedBy())
                .sdwanFwEnabled(firewallRules.isSdwanEnabled())
                .description(mapNullableString(firewallRules.getDescription()));
    }

    public FirewallRuleSetResponseV2 mapFromFirewallRulesV3(final FirewallRules firewallRules, final SiteResponseV1 siteResponse) {
        log.debug("Calling mapFromFirewallRulesV3({}, {})", firewallRules, siteResponse);
        return new FirewallRuleSetResponseV2()
                .id(firewallRules.getId())
                .updatedDt(mapStrToLocalDateTime(firewallRules.getLastUpdated()))
                .updatedBy(firewallRules.getUpdatedBy())
                .sdwanFwEnabled(firewallRules.isSdwanEnabled())
                .description(mapNullableString(firewallRules.getDescription()))
                .rules(mapFromFirewallRuleList2(firewallRules.getFwRules(), siteResponse));
    }

    private List<FirewallRuleResponseV2> mapFromFirewallRuleList2(final List<FirewallRule> firewallRules, final SiteResponseV1 siteResponse) {
        List<FirewallRuleResponseV2> firewallRuleResponses = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(firewallRules)) {
            IntStream.range(0, firewallRules.size()).sequential().forEach(
                    i -> firewallRuleResponses.add(mapFromFirewallRuleV2(firewallRules.get(i), siteResponse, i + 1))
            );
        }
        return firewallRuleResponses;
    }

    private FirewallRuleResponseV2 mapFromFirewallRuleV2(final FirewallRule firewallRule, final SiteResponseV1 siteResponse, final int priority) {
        log.debug("Calling mapFromFirewallRuleV2({}, {}, {})", firewallRule, siteResponse, priority);

        return new FirewallRuleResponseV2()
                .priority(priority)
                .action(mapActionFromClientEnum(firewallRule.getAction()))
                .sourceNetwork(mapNetwork(firewallRule.getSourceNetwork(), firewallRule.getDestinationNetwork(), firewallRule.getSourceNetwork(), siteResponse))
                .destinationNetwork(mapNetwork(firewallRule.getDestinationNetwork(), firewallRule.getDestinationNetwork(), firewallRule.getDestinationNetwork(), siteResponse))
                .name(mapNullableString(firewallRule.getName()))
                .description(mapNullableString(firewallRule.getDescription()))
                .application(mapNullableList(firewallRule.getApplications()))
                .logging(mapFirewallLoggingEventTrigger(firewallRule.getLoggingEvent()))
                .editable(!isDefaultRule(firewallRule.getName(), siteResponse))
                .enabled(mapNullableBoolean(firewallRule.getRuleEnabled()))
                .antivirusProfile(firewallRule.getAntivirusProfile())
                .urlFilteringProfile(firewallRule.getUrlFilteringProfile())
                .predefinedIpsProfile(firewallRule.getPredefinedIpsProfile())
                .predefinedIpsProfileOverride(firewallRule.getPredefinedIpsProfileOverride())
                .userDefinedIpsProfile(firewallRule.getUserDefinedIpsProfile())
                .ipFilteringProfile(firewallRule.getIpFilteringProfile())
                .serviceConfiguration(mapServiceConfigurationFrom(firewallRule))
                .addressConfiguration(mapAddressConfiguration(firewallRule));
    }

    private NetworkAddressConfigurationV1 mapAddressConfiguration(FirewallRule firewallRule) {
        final var addrConfig = new NetworkAddressConfigurationV1().source(new NetworkAddressV1()).destination(new NetworkAddressV1());

        Optional.ofNullable(firewallRule.getCustomSourceAddresses())
                .filter(CollectionUtils::isNotEmpty)
                .ifPresent(source -> addrConfig.getSource().setAddressObjects(source));

        Optional.ofNullable(firewallRule.getCustomSourceAddressGroups())
                .filter(CollectionUtils::isNotEmpty)
                .ifPresent(source -> addrConfig.getSource().setAddressGroupObjects(source));

        Optional.ofNullable(firewallRule.getSourceIp())
                .filter(CollectionUtils::isNotEmpty)
                .ifPresent(source -> addrConfig.getSource().setIps(new HashSet<>(source)));

        Optional.ofNullable(firewallRule.getCustomDestinationAddresses())
                .filter(CollectionUtils::isNotEmpty)
                .ifPresent(destination -> addrConfig.getDestination().setAddressObjects(destination));

        Optional.ofNullable(firewallRule.getCustomDestinationAddressGroups())
                .filter(CollectionUtils::isNotEmpty)
                .ifPresent(destination -> addrConfig.getDestination().setAddressGroupObjects(destination));

        Optional.ofNullable(firewallRule.getDestinationIp())
                .filter(CollectionUtils::isNotEmpty)
                .ifPresent(source -> addrConfig.getDestination().setIps(new HashSet<>(source)));

        addrConfig.setType(CollectionUtils.isNotEmpty(firewallRule.getCustomSourceAddresses()) ||
                CollectionUtils.isNotEmpty(firewallRule.getCustomDestinationAddresses()) ||
                CollectionUtils.isNotEmpty(firewallRule.getCustomSourceAddressGroups()) ||
                CollectionUtils.isNotEmpty(firewallRule.getCustomDestinationAddressGroups()) ? NetworkConfigTypeV1.OBJECT : NetworkConfigTypeV1.MANUAL);

        return addrConfig;
    }

    private FirewallServiceConfigurationV1 mapServiceConfigurationFrom(FirewallRule firewallRule) {
        return new FirewallServiceConfigurationV1().serviceObjects(firewallRule.getCustomServices())
                .protocol(mapProtocolFromString(firewallRule.getProtocol()))
                .sourcePort(fromCSV(firewallRule.getSourcePort()))
                .destinationPort(fromCSV(firewallRule.getDestinationPort()))
                .type(CollectionUtils.isNotEmpty(firewallRule.getCustomServices()) ? NetworkConfigTypeV1.OBJECT : NetworkConfigTypeV1.MANUAL);
    }

    private FirewallLoggingEventTrigger mapFirewallLoggingEventTrigger(String loggingEvent) {
        return isNotBlank(loggingEvent) ? FirewallLoggingEventTrigger.fromValue(loggingEvent) : FirewallLoggingEventTrigger.NEVER;
    }

    private FirewallAction mapActionFromClientEnum(final FwAction action) {
        FirewallAction actionEnum = null;
        if (Objects.nonNull(action)
                && (FwAction.allow.equals(action) || FwAction.deny.equals(action) || FwAction.apply_security_profile.equals(action))) {
            actionEnum = FirewallAction.fromValue(action.name().toUpperCase());
        }
        return actionEnum;
    }

    private FirewallProtocol mapProtocolFromString(final String protocolStr) {
        FirewallProtocol network = FirewallProtocol.ANY;
        if (StringUtils.isNotEmpty(protocolStr)) {
            network = FirewallProtocol.fromValue(protocolStr.toUpperCase());
        }
        return network;
    }

}
