package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.ServiceObjectCriteria;
import net.colt.sdwan.portal.model.ServicesRequestV1;
import net.colt.sdwan.portal.model.ServicesResponseV1;

public interface ServiceObjectService {

    ServicesResponseV1 getCustomServicesV1(String siteId, ServiceObjectCriteria criteria, Integer pageNumber, Integer pageSize);

    CorrelationIdResponseV1 updateCustomServicesV1(String siteId, ServicesRequestV1 servicesRequestV1);

}
