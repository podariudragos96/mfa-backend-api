package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.AntivirusProfileLogsResponseV1;
import net.colt.sdwan.portal.model.AntivirusProfileResponseV1;
import net.colt.sdwan.portal.model.AntivirusProfilesRequestV1;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;

import java.util.List;

public interface AntivirusService {

    AntivirusProfileResponseV1 getAntivirusProfilesBySiteIdV1(final String siteId);

    CorrelationIdResponseV1 updateAntivirusProfilesBySiteIdV1(String siteId, AntivirusProfilesRequestV1 antivirusProfilesRequestV1);

    List<AntivirusProfileLogsResponseV1> getAntivirusProfileLogsV1(String siteId, String profileName);

}
