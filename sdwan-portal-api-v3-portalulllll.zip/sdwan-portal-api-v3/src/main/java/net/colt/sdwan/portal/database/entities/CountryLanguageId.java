package net.colt.sdwan.portal.database.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

@EqualsAndHashCode
@Embeddable
public class CountryLanguageId implements Serializable {

    private static final long serialVersionUID = -1389309770539003113L;

    @Column(name = "COUNTRY_CODE")
    private String countryCode;

    @Column(name = "LANGUAGE_CODE")
    private String languageCode;

    public CountryLanguageId() {
    }

    public CountryLanguageId(String countryCode, String languageCode) {
        this.countryCode = countryCode;
        this.languageCode = languageCode;
    }

    /**
     * @return the countryCode
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * @param countryCode the countryCode to set
     */
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    /**
     * @return the languageCode
     */
    public String getLanguageCode() {
        return languageCode;
    }

    /**
     * @param languageCode the languageCode to set
     */
    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CountryLanguageId [countryCode=" + countryCode
                + ", languageCode=" + languageCode + "]";
    }
}
