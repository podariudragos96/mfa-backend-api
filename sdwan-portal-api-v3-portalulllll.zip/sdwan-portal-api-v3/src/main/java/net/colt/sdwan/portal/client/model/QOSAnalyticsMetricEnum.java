package net.colt.sdwan.portal.client.model;

public enum QOSAnalyticsMetricEnum {

    BEST_EFFORT_TX("BEST_EFFORT_TX"),

    EXPEDITED_FORWARDING_TX("EXPEDITED_FORWARDING_TX"),

    ASSURED_FORWARDING_TX("ASSURED_FORWARDING_TX"),

    NETWORK_CONTROL_TX("NETWORK_CONTROL_TX"),

    BEST_EFFORT_TX_DROPPED("BEST_EFFORT_TX_DROPPED"),

    EXPEDITED_FORWARDING_TX_DROPPED("EXPEDITED_FORWARDING_TX_DROPPED"),

    ASSURED_FORWARDING_TX_DROPPED("ASSURED_FORWARDING_TX_DROPPED"),

    NETWORK_CONTROL_TX_DROPPED("NETWORK_CONTROL_TX_DROPPED"),

    BEST_EFFORT_BANDWIDTH("BEST_EFFORT_BANDWIDTH"),

    EXPEDITED_FORWARDING_BANDWIDTH("EXPEDITED_FORWARDING_BANDWIDTH"),

    ASSURED_FORWARDING_BANDWIDTH("ASSURED_FORWARDING_BANDWIDTH"),

    NETWORK_CONTROL_BANDWIDTH("NETWORK_CONTROL_BANDWIDTH");

    private String value;

    QOSAnalyticsMetricEnum(String value) {
        this.value = value;
    }

    public static QOSAnalyticsMetricEnum fromValue(String text) {
        for (QOSAnalyticsMetricEnum b : QOSAnalyticsMetricEnum.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        throw new IllegalArgumentException("Unexpected value '" + text + "'");
    }
}
