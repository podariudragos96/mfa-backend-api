package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.*;

public interface SaseCatalogService {

    SaseServicesCatalogResponseV1 getServicesV1(String tenantUuid);

    SaseSecurityProfilesCatalogResponseV1 getSecurityProfilesV1(String tenantUuid);

    SaseStaticZonesCatalogResponseV1 getStaticZonesV1();

    SaseGeoIpCountriesCatalogResponseV1 getGeoIpCountriesV1(String tenantUuid);

    SaseUrlCategoriesCatalogResponseV1 getUrlCategoriesV1(String tenantUuid);

    SaseUrlReputationsCatalogResponseV1 getUrlReputationsV1(String tenantUuid);

    SaseApplicationsCatalogResponseV1 getApplicationsV1(String tenantUuid);

    SaseApplicationCategoriesCatalogResponseV1 getApplicationCategoriesV1(String tenantUuid);

    SaseApplicationGroupsCatalogResponseV1 getApplicationGroupsV1(String tenantUuid);

    EndpointProtectionsCatalogResponseV1 getEndpointProtectionsV1(String tenantUuid);

    OperatingSystemsCatalogResponseV1 getOperatingSystemsV1(String tenantUuid);

    ApplicationsCatalogResponseV1 getSaseApplicationsV1(String tenantUuid);

}
