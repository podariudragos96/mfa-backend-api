package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.ReleaseNotesResponseV1;

import java.time.LocalDateTime;
import java.util.List;

public interface ReleaseNotesService {

    List<ReleaseNotesResponseV1> getReleaseNotes();

    LocalDateTime getLastReleaseDateTime();
}
