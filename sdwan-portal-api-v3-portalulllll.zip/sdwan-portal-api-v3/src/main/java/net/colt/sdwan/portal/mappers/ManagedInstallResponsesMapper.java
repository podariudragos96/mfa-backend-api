package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.model.ManagedInstallResponseV1;
import net.colt.sdwan.portal.model.ManagedInstallStatusV1;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.nonNull;

@Component
public class ManagedInstallResponsesMapper extends CommonMapper {

    public List<ManagedInstallResponseV1> mapFromZTPDeviceResponses(final List<net.colt.sdwan.generated.model.service.ManagedInstallResponseV1> installResponseV1s) {
        List<ManagedInstallResponseV1> managedInstallResponses = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(installResponseV1s)) {
            managedInstallResponses.addAll(
                    installResponseV1s.stream()
                            .map(this::mapFromZTPDeviceResponse)
                            .toList());
        }
        return managedInstallResponses;
    }

    public ManagedInstallResponseV1 mapFromZTPDeviceResponse(final net.colt.sdwan.generated.model.service.ManagedInstallResponseV1 installResponseV1) {
        return new ManagedInstallResponseV1()
                .id(installResponseV1.getId().intValue())
                .networkId(installResponseV1.getNetworkId())
                .orderReference(installResponseV1.getOrderReference())
                .deviceName(installResponseV1.getDeviceName())
                .siteName(installResponseV1.getSiteName())
                .siteAddress(installResponseV1.getSiteAddress())
                .status(mapFromZDTPStringStatus(installResponseV1.getStatus()))
                .updatedDt(installResponseV1.getUpdatedDt())
                .activationPhrase(installResponseV1.getActivationPhrase())
                .installerMobileNo(installResponseV1.getInstallerMobileNo())
                .ztpUrl(installResponseV1.getZtpUrl());
    }


    public ManagedInstallStatusV1 mapFromZDTPStringStatus(final net.colt.sdwan.generated.model.service.ManagedInstallStatusV1 status) {
        ManagedInstallStatusV1 managedInstallStatus = null;
        if (nonNull(status)) {
            managedInstallStatus = ManagedInstallStatusV1.valueOf(status.getValue());
        }
        return managedInstallStatus;
    }

}
