package net.colt.sdwan.portal.mappers;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.model.DNSProxyRequestV1;
import net.colt.sdwan.portal.model.DNSProxyResponseV1;
import net.colt.sdwan.portal.model.DnsProxyHistoryResponseV1;
import net.colt.sdwan.sitesettings.api.generated.model.DNSProxyRequestApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.DNSProxyResponseApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.DnsProxyHistoryResponseApiV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;


@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
@Component
public class DnsProxyMapper {

    private final ModelMapper modelMapper;

    public DNSProxyResponseV1 from(DNSProxyResponseApiV1 dnsProxyResponseApiV1) {
        return modelMapper.map(dnsProxyResponseApiV1, DNSProxyResponseV1.class);
    }

    public DNSProxyRequestApiV1 from(DNSProxyRequestV1 dnsProxyRequestV1) {
        return modelMapper.map(dnsProxyRequestV1, DNSProxyRequestApiV1.class);
    }

    public List<DnsProxyHistoryResponseV1> from(List<DnsProxyHistoryResponseApiV1> dnsProxyRequestV1) {
        return Arrays.asList(modelMapper.map(dnsProxyRequestV1, DnsProxyHistoryResponseV1[].class));
    }

}
