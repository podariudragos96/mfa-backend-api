package net.colt.sdwan.portal.client.feign.async;

import net.colt.sdwan.async.response.api.generated.api.RequestApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "asyncResponseApiClient", url = "${sdwan.async.response.api.baseurl}",
        configuration = AsyncResponseApiFeignConfiguration.class)
public interface AsyncResponseApiFeign extends RequestApi {
}
