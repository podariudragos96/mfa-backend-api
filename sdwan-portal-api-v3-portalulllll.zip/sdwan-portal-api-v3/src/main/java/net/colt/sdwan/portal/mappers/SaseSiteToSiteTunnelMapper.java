package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.model.versa.sase.api.SiteToSiteTunnelsResponseApiV1;
import net.colt.sdwan.portal.model.SaseSiteToSiteTunnelsResponseV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SaseSiteToSiteTunnelMapper {

    private final ModelMapper modelMapper;

    public SaseSiteToSiteTunnelsResponseV1 from(SiteToSiteTunnelsResponseApiV1 tasksResponseApiV1) {
        return modelMapper.map(tasksResponseApiV1, SaseSiteToSiteTunnelsResponseV1.class);
    }

}
