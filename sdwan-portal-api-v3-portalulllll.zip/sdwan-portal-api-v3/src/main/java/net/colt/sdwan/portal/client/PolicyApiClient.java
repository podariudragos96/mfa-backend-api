package net.colt.sdwan.portal.client;

import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.common.logging.service.LoggingService;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.InterfaceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.model.*;
import net.colt.sdwan.portal.enums.StatName;
import net.colt.sdwan.portal.model.CommandRequestModel;
import net.colt.sdwan.portal.model.RoutingCommandRequestModel;
import net.colt.sdwan.portal.security.AuthUserHelper;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.*;

import static java.util.Objects.isNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.client.ParamsLabels.*;
import static net.colt.sdwan.portal.client.ServicesUrlProperties.*;
import static net.colt.sdwan.portal.constant.Constants.SLASH;
import static net.colt.sdwan.portal.util.CGWUtil.isCloudGateway;


@Component
public class PolicyApiClient extends AbstractRestApiClient {

    private final PolicyApiCallBuilder callBuilder;
    private final ApplicationCache applicationCache;
    private final ServiceApiClient serviceApiClient;
    private final AuthHeaderGenerator authHeaderGen;

    @Value("${policy.api.base.url}")
    private String policyApiBaseUrl;

    public PolicyApiClient(AuthHeaderGenerator authHeaderGenerator,
                           RestTemplate restTemplate,
                           LoggingService loggingService,
                           PolicyApiCallBuilder callBuilder,
                           ApplicationCache applicationCache,
                           ServiceApiClient serviceApiClient,
                           AuthHeaderGenerator authHeaderGen) {
        super(authHeaderGenerator, restTemplate, loggingService);
        this.callBuilder = callBuilder;
        this.applicationCache = applicationCache;
        this.serviceApiClient = serviceApiClient;
        this.authHeaderGen = authHeaderGen;
    }

    public void getPingOrTracerouteInterface(CommandRequestModel requestModel, final DeviceResponseV1 deviceResponse, final String versaInstanceAddress, final InterfaceResponseV1 interfaceResponse) {
        Map<String, Object> params = callBuilder.buildCommonsParamsMap(deviceResponse.getManagementIpv4());
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(TARGET_IP, requestModel.getTargetIP());
        params.put(VRF, requestModel.getVrf());
        if (!isNull(interfaceResponse.getDhcp()) && Boolean.TRUE.equals(interfaceResponse.getDhcp())) {
            params.put(INTERFACE_NAME, interfaceResponse.getName());
        }
        if (!isNull(requestModel.getSrcIp()) && StringUtils.isNotBlank(requestModel.getSrcIp())) {
            params.put(SRC_IP, requestModel.getSrcIp());
        }
        String url = callBuilder.buildPingOrTraceroutePath(requestModel.isPing(), versaInstanceAddress);
        get(url, StringUtils.EMPTY, params, Object.class, getHttpEntity());
    }

    public ResponseEntity<Object> getDynamicStats(final DeviceResponseV1 deviceResponse, final SiteResponseV1 siteResponse,
                                                  final InterfaceResponseV1 interfaceResponse, final String stats) {
        final boolean isIPV6 = SiteResponseV1.IpAddressFamilyEnum.IPDUAL.getValue()
                .equals(siteResponse.getIpAddressFamily().getValue());

        Map<String, Object> params = callBuilder.buildCommonsParamsMap(deviceResponse.getManagementIpv4());
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(CUSTOMER, siteResponse.getNetworkId());
        params.put(IPV6_ENABLED, isIPV6);
        params.put(ASYNC, true);
        if (StringUtils.isNotEmpty(interfaceResponse.getName())) {
            params.put(INTERFACE, interfaceResponse.getName());
        }
        if (StringUtils.isNotEmpty(interfaceResponse.getVrf())) {
            params.put(VRF, interfaceResponse.getVrf());
        }

        if (StringUtils.isNotEmpty(stats)) {
            String finalStats = stats.toLowerCase();
            if (finalStats.equals("rxtx")) {
                finalStats = "tx";
            }
            params.put(STATS, finalStats);
        }
        return get(getPolicyUrl(siteResponse), POLICY_API_DYNAMIC_STATS_URI.concat(SLASH).concat(deviceResponse.getResourceName()),
                params, Object.class, getHttpEntity());
    }

    public void getRoutingCommandDynamicStats(final DeviceResponseV1 deviceResponse, final SiteResponseV1 siteResponse, final InterfaceResponseV1 interfaceResponse,
                                              final RoutingCommandRequestModel requestModel) {

        final boolean isIPV6 = SiteResponseV1.IpAddressFamilyEnum.IPDUAL.getValue()
                .equals(siteResponse.getIpAddressFamily().getValue());

        Map<String, Object> params = callBuilder.buildCommonsParamsMap(deviceResponse.getManagementIpv4());
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(CUSTOMER, siteResponse.getNetworkId());
        params.put(IPV6_ENABLED, isIPV6);
        params.put(IS_CGW, isCloudGateway(siteResponse.getSiteType().getValue()));

        if (StringUtils.isNotEmpty(interfaceResponse.getName())) {
            params.put(INTERFACE, interfaceResponse.getName());
        }
        if (StringUtils.isNotEmpty(interfaceResponse.getVrf())) {
            params.put(VRF, interfaceResponse.getVrf());
        }
        params = callBuilder.putRoutingProtocolValues(params, requestModel.getRoutingProtocol(),
                requestModel.getRoutingType(), requestModel.getFormatted());
        params = callBuilder.putNeighborCommandValues(params, requestModel.getRoutingProtocol(),
                requestModel.getStatsType(), requestModel.getBrief(), siteResponse.getNetworkId());
        params.put(STATS, requestModel.getStatsType());
        get(getPolicyUrl(siteResponse), POLICY_API_DYNAMIC_STATS_URI.concat(SLASH).concat(deviceResponse.getResourceName()),
                params, Object.class, getHttpEntity());
    }

    public ApplicationResponse getApplicationDetails() {
        final List<Integer> tenantIds = Objects.requireNonNull(AuthUserHelper.getAuthUser()).getAccessibleTenantIds();

        final List<SiteResponseV1> siteResponseV1s = serviceApiClient.getSitesByTenantIds(tenantIds);

        final List<String> versaInstances = siteResponseV1s.stream()
                .map(SiteResponseV1::getVersaInstance)
                .toList();

        ApplicationResponse result;
        if (CollectionUtils.isNotEmpty(versaInstances)) {
            result = applicationCache.getApplicationsFromVersa(versaInstances.get(0));
        } else {
            result = new ApplicationResponse();
        }
        return result;
    }


    public RuleSet getVersaDirectoryV2(final SiteResponseV1 siteResponse, InterfaceResponseV1 interfaceResponse) {
        final String path = callBuilder.buildPolicyApiPathV2(siteResponse.getSiteType().getValue(), siteResponse.getId().toString());
        final Map<String, Object> params = callBuilder.buildPoliciesParamsMap(siteResponse, interfaceResponse, false);
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(DEVICES_PARAMS, callBuilder.buildDeviceNamesParam(new ArrayList<>(siteResponse.getDevices())));
        params.put(IGNORE_SEMAPHORE, true);
        ResponseEntity<RuleSet> responseEntity =
                get(getPolicyUrl(siteResponse), path, params, RuleSet.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException(POLICY_RESP);
    }

    public List<RuleSet> getVersaDirectoryHistoryV2(final SiteResponseV1 siteResponse, InterfaceResponseV1 interfaceResponse) {
        final String path = callBuilder.buildPolicyApiPathV2(siteResponse.getSiteType().getValue(), siteResponse.getId().toString());
        final Map<String, Object> params = callBuilder.buildPoliciesParamsMap(siteResponse, interfaceResponse, false);
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(DEVICES_PARAMS, callBuilder.buildDeviceNamesParam(new ArrayList<>(siteResponse.getDevices())));
        params.put(IGNORE_SEMAPHORE, true);
        ResponseEntity<RuleSet[]> responseEntity =
                get(getPolicyUrl(siteResponse), path + POLICY_API_POLICIES_HISTORY, params, RuleSet[].class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return new ArrayList<>(Arrays.asList(responseEntity.getBody()));
        }
        throw new SdwanNotFoundException(POLICY_RESP);
    }

    public RuleSet getVersaDirectoryHistoryByRuleSetIdV2(final SiteResponseV1 siteResponse, InterfaceResponseV1 interfaceResponse, String ruleSetId) {
        final String path = callBuilder.buildPolicyApiPathV2(siteResponse.getSiteType().getValue(), siteResponse.getId().toString());
        final Map<String, Object> params = callBuilder.buildPoliciesParamsMap(siteResponse, interfaceResponse, false);
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(DEVICES_PARAMS, callBuilder.buildDeviceNamesParam(new ArrayList<>(siteResponse.getDevices())));
        params.put(IGNORE_SEMAPHORE, true);
        ResponseEntity<RuleSet> responseEntity =
                get(getPolicyUrl(siteResponse), path + POLICY_API_POLICIES_HISTORY + SLASH + ruleSetId, params, RuleSet.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException(POLICY_RESP);
    }

    public FirewallRules getFirewallRulesV2(final SiteResponseV1 siteResponse, InterfaceResponseV1 interfaceResponse) {
        final String path = callBuilder.buildFirewallRulesApiPathV2(siteResponse.getSiteType().getValue(), siteResponse.getId().toString());
        final Map<String, Object> params = callBuilder.buildPoliciesParamsMap(siteResponse, interfaceResponse, false);
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(DEVICES_PARAMS, callBuilder.buildDeviceNamesParam(new ArrayList<>(siteResponse.getDevices())));
        params.put(IGNORE_SEMAPHORE, true);
        ResponseEntity<FirewallRules> responseEntity =
                get(getPolicyUrl(siteResponse), path, params, FirewallRules.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        return new FirewallRules();
    }

    public List<FirewallRules> getFirewallHistoryRules(final SiteResponseV1 siteResponse, InterfaceResponseV1 interfaceResponse) {
        final String path = callBuilder.buildFirewallRulesHistoryApiPath(siteResponse.getSiteType().getValue(), siteResponse.getId().toString());
        final Map<String, Object> params = callBuilder.buildPoliciesParamsMap(siteResponse, interfaceResponse, false);
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(DEVICES_PARAMS, callBuilder.buildDeviceNamesParam(new ArrayList<>(siteResponse.getDevices())));
        params.put(IGNORE_SEMAPHORE, true);
        ResponseEntity<FirewallRules[]> responseEntity =
                get(getPolicyUrl(siteResponse), path, params, FirewallRules[].class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return new ArrayList<>(Arrays.asList(responseEntity.getBody()));
        }
        return Collections.emptyList();
    }

    public FirewallRules getFirewallHistoryByIdRules(final SiteResponseV1 siteResponse, InterfaceResponseV1 interfaceResponse, final String ruleSetId) {
        final String path = callBuilder.buildFirewallRulesHistoryByIdApiPath(siteResponse.getSiteType().getValue(), siteResponse.getId().toString(), ruleSetId);
        final Map<String, Object> params = callBuilder.buildPoliciesParamsMap(siteResponse, interfaceResponse, false);
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(DEVICES_PARAMS, callBuilder.buildDeviceNamesParam(new ArrayList<>(siteResponse.getDevices())));
        params.put(IGNORE_SEMAPHORE, true);
        ResponseEntity<FirewallRules> responseEntity =
                get(getPolicyUrl(siteResponse), path, params, FirewallRules.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        return new FirewallRules();
    }

    /**
     * @param siteResponse
     * @param interfaceResponse
     * @return
     * @deprecated
     */
    @SuppressWarnings("java:S1133")
    @Deprecated(forRemoval = true)
    public NatRuleResponse getNatRulesBySiteId(final SiteResponseV1 siteResponse, final InterfaceResponseV1 interfaceResponse) {
        final Map<String, Object> params = callBuilder.buildPoliciesParamsMap(siteResponse, interfaceResponse, false);
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(DEVICES_PARAMS, callBuilder.buildDeviceNamesParam(new ArrayList<>(siteResponse.getDevices())));
        params.put(IGNORE_SEMAPHORE, true);
        String primaryDeviceName = callBuilder.findPrimaryDeviceName(siteResponse.getDevices());
        if (StringUtils.isNotEmpty(primaryDeviceName)) {
            params.put(PRIMARY_DEVICE, primaryDeviceName);
        }
        params.put(DUALHYBRIDCPE, Objects.nonNull(siteResponse.getIsDualSite()) && siteResponse.getIsDualSite());
        params.put(SITE_TYPE, siteResponse.getSiteType().getValue());
        params.put(IS_CGW, isCloudGateway(siteResponse.getSiteType().getValue()));
        ResponseEntity<NatRuleResponse> responseEntity = get(getPolicyUrl(siteResponse),
                POLICY_API_NAT_URI.concat(SLASH).concat(siteResponse.getId().toString()), params, NatRuleResponse.class, getHttpEntity());

        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException(POLICY_RESP);
    }

    public NatRuleSet getNatRulesBySiteIdV2(final SiteResponseV1 siteResponse, final InterfaceResponseV1 interfaceResponse) {
        final Map<String, Object> params = callBuilder.buildPoliciesParamsMap(siteResponse, interfaceResponse, false);
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(DEVICES_PARAMS, callBuilder.buildDeviceNamesParam(new ArrayList<>(siteResponse.getDevices())));
        params.put(IGNORE_SEMAPHORE, true);
        String primaryDeviceName = callBuilder.findPrimaryDeviceName(siteResponse.getDevices());
        if (StringUtils.isNotEmpty(primaryDeviceName)) {
            params.put(PRIMARY_DEVICE, primaryDeviceName);
        }
        params.put(DUALHYBRIDCPE, Objects.nonNull(siteResponse.getIsDualSite()) && siteResponse.getIsDualSite());
        params.put(SITE_TYPE, siteResponse.getSiteType().getValue());
        params.put(IS_CGW, isCloudGateway(siteResponse.getSiteType().getValue()));
        ResponseEntity<NatRuleSet> responseEntity = get(getPolicyUrl(siteResponse), POLICY_API_V2 +
                POLICY_API_NAT_URI.concat(SLASH).concat(siteResponse.getId().toString()), params, NatRuleSet.class, getHttpEntity());

        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException(POLICY_RESP);
    }

    public List<NatRuleSet> getNatRulesHistoryBySiteIdV2(final SiteResponseV1 siteResponse, final InterfaceResponseV1 interfaceResponse) {
        final Map<String, Object> params = callBuilder.buildPoliciesParamsMap(siteResponse, interfaceResponse, false);
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(DEVICES_PARAMS, callBuilder.buildDeviceNamesParam(new ArrayList<>(siteResponse.getDevices())));
        params.put(IGNORE_SEMAPHORE, true);
        String primaryDeviceName = callBuilder.findPrimaryDeviceName(siteResponse.getDevices());
        if (StringUtils.isNotEmpty(primaryDeviceName)) {
            params.put(PRIMARY_DEVICE, primaryDeviceName);
        }
        params.put(DUALHYBRIDCPE, Objects.nonNull(siteResponse.getIsDualSite()) && siteResponse.getIsDualSite());
        params.put(SITE_TYPE, siteResponse.getSiteType().getValue());
        params.put(IS_CGW, isCloudGateway(siteResponse.getSiteType().getValue()));
        ResponseEntity<NatRuleSet[]> responseEntity = get(getPolicyUrl(siteResponse), POLICY_API_V2 +
                POLICY_API_NAT_URI.concat(SLASH).concat(siteResponse.getId().toString()).concat(POLICY_API_NAT_HISTORY), params, NatRuleSet[].class, getHttpEntity());

        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return Arrays.asList(responseEntity.getBody());
        }
        throw new SdwanNotFoundException(POLICY_RESP);
    }


    public NatRuleSet getNatRulesHistoryBySiteIdAndRuleSetIdV1(final SiteResponseV1 siteResponse, final InterfaceResponseV1 interfaceResponse, String ruleSetId) {
        final Map<String, Object> params = callBuilder.buildPoliciesParamsMap(siteResponse, interfaceResponse, false);
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(DEVICES_PARAMS, callBuilder.buildDeviceNamesParam(new ArrayList<>(siteResponse.getDevices())));
        params.put(IGNORE_SEMAPHORE, true);
        String primaryDeviceName = callBuilder.findPrimaryDeviceName(siteResponse.getDevices());
        if (StringUtils.isNotEmpty(primaryDeviceName)) {
            params.put(PRIMARY_DEVICE, primaryDeviceName);
        }
        params.put(DUALHYBRIDCPE, Objects.nonNull(siteResponse.getIsDualSite()) && siteResponse.getIsDualSite());
        params.put(SITE_TYPE, siteResponse.getSiteType().getValue());
        params.put(IS_CGW, isCloudGateway(siteResponse.getSiteType().getValue()));
        ResponseEntity<NatRuleSet> responseEntity = get(getPolicyUrl(siteResponse), POLICY_API_V2 +
                POLICY_API_NAT_URI.concat(SLASH).concat(siteResponse.getId().toString()).concat(POLICY_API_NAT_HISTORY).concat(SLASH).concat(ruleSetId), params, NatRuleSet.class, getHttpEntity());

        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException(POLICY_RESP);
    }

    /**
     * @param siteResponse
     * @param interfaceResponse
     * @param request
     * @deprecated
     */
    @SuppressWarnings("java:S1133")
    @Deprecated(forRemoval = true)
    public void updateNatRules(final SiteResponseV1 siteResponse, final InterfaceResponseV1 interfaceResponse,
                               final NatRuleRequest request) {
        final Map<String, Object> params = callBuilder.buildPoliciesParamsMap(siteResponse, interfaceResponse, true);
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(DEVICES_PARAMS, callBuilder.buildDeviceNamesParam(new ArrayList<>(siteResponse.getDevices())));
        params.put(IGNORE_SEMAPHORE, true);
        params.put(DUALHYBRIDCPE, Objects.nonNull(siteResponse.getIsDualSite()) && siteResponse.getIsDualSite());
        params.put(SITE_TYPE, siteResponse.getSiteType().getValue());
        String cpsPeering = callBuilder.getCpsPeeringInterface(siteResponse.getDevices(), siteResponse.getCgw(), interfaceResponse);
        params.put(CSP_PEERING_INTERFACE, cpsPeering);
        params.put(ZONES_TEMPLATE_KEY, siteResponse.getZonesTplKey());
        params.put(IS_CGW, isCloudGateway(siteResponse.getSiteType().getValue()));
        put(getPolicyUrl(siteResponse), POLICY_API_NAT_URI.concat(SLASH).concat(siteResponse.getId().toString()), params, Object.class, getHttpEntity(request));

    }

    public void updateNatRulesV2(final SiteResponseV1 siteResponse, final InterfaceResponseV1 interfaceResponse,
                                 final NatRuleRequest request) {
        final Map<String, Object> params = callBuilder.buildPoliciesParamsMap(siteResponse, interfaceResponse, true);
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(DEVICES_PARAMS, callBuilder.buildDeviceNamesParam(new ArrayList<>(siteResponse.getDevices())));
        params.put(IGNORE_SEMAPHORE, true);
        params.put(DUALHYBRIDCPE, Objects.nonNull(siteResponse.getIsDualSite()) && siteResponse.getIsDualSite());
        params.put(SITE_TYPE, siteResponse.getSiteType().getValue());
        String cpsPeering = callBuilder.getCpsPeeringInterface(siteResponse.getDevices(), siteResponse.getCgw(), interfaceResponse);
        params.put(CSP_PEERING_INTERFACE, cpsPeering);
        params.put(ZONES_TEMPLATE_KEY, siteResponse.getZonesTplKey());
        params.put(IS_CGW, isCloudGateway(siteResponse.getSiteType().getValue()));
        put(getPolicyUrl(siteResponse), POLICY_API_V2.concat(POLICY_API_NAT_URI).concat(SLASH).concat(siteResponse.getId().toString()), params, Object.class, getHttpEntity(request));

    }

    public void updateFirewallRulesV2(final FirewallRules request, final SiteResponseV1 siteResponse, final InterfaceResponseV1 interfaceResponse,
                                      final String zonesTemplateKey, final String ocn) {
        final String path = callBuilder.buildFirewallRulesApiPathV2(siteResponse.getSiteType().getValue(), siteResponse.getId().toString());
        final Map<String, Object> params = callBuilder.buildPoliciesParamsMap(siteResponse, interfaceResponse, true);
        params.put(ZONES_TEMPLATE_KEY, zonesTemplateKey);
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(DEVICES_PARAMS, callBuilder.buildDeviceNamesParam(new ArrayList<>(siteResponse.getDevices())));
        params.put(IGNORE_SEMAPHORE, true);
        params.put(SITE_TYPE, siteResponse.getSiteType().getValue());
        params.put(OCN, ocn);
        params.put(EVENT_ID, MDC.get(CORRELATION_ID));

        String primaryDeviceName = callBuilder.findPrimaryDeviceName(siteResponse.getDevices());

        if (StringUtils.isNotEmpty(primaryDeviceName)) {
            params.put(PRIMARY_DEVICE, primaryDeviceName);
        }

        boolean isDualCpe = false;
        if (Objects.nonNull(siteResponse.getIsDualSite()) && Boolean.TRUE.equals(siteResponse.getIsDualSite())) {
            isDualCpe = true;
        }
        params.put(DUALHYBRIDCPE, isDualCpe);
        post(getPolicyUrl(siteResponse), path, params, Object.class, getHttpEntity(request));
    }

    public void updateDDoSRulesV2(final DDoSRuleSetHistory request, final SiteResponseV1 siteResponse) {
        final Map<String, Object> params = callBuilder.buildUserRolesParamsMap();
        params.put(DEVICES_PARAMS, callBuilder.buildDeviceNamesParam(new ArrayList<>(siteResponse.getDevices())));
        params.put(IGNORE_SEMAPHORE, true);
        params.put(CUSTOMER, request.getCustomer());
        params.put(ASYNC, true);
        params.put(EVENT_ID, MDC.get(CORRELATION_ID));

        put(getPolicyUrl(siteResponse),
                POLICY_API_V2.concat(POLICY_API_DDOS_URI).concat(SLASH).concat(siteResponse.getId().toString()), params, Object.class, getHttpEntity(request));

    }

    public Object updateInterfaceStats(final StatName statName, final SiteResponseV1 siteResponseV1, final DeviceResponseV1 deviceResponse, final String vrf) {
        Map<String, Object> params = callBuilder.buildUserRolesParamsMap();
        params.put(MANAGEMENT_IPV4, deviceResponse.getManagementIpv4());
        params.put(VRF, vrf);
        params.put(STATS, statName.getValue());
        ResponseEntity<Object> responseEntity = post(getPolicyUrl(siteResponseV1),
                POLICY_API_CLEAR_STATS_URI.concat(SLASH).concat(deviceResponse.getResourceName()), params, Object.class, getHttpEntity());
        if (Objects.nonNull(responseEntity) && Objects.nonNull(responseEntity.getBody())) {
            return responseEntity.getBody();
        }
        throw new SdwanNotFoundException(POLICY_RESP);
    }

    public void updateRoutesByDeviceId(final SiteResponseV1 siteResponseV1, final DeviceResponseV1 deviceResponse, final List<StaticRoutesRequest> request,
                                       final boolean isUpdate) {
        Map<String, Object> params = callBuilder.buildUserRolesParamsMap();
        params.put(MANAGEMENT_IPV4, deviceResponse.getManagementIpv4());
        if (isUpdate) {
            put(getPolicyUrl(siteResponseV1),
                    POLICY_DYNAMIC_NAT_URI.concat(SLASH).concat(deviceResponse.getResourceName()), params, Object.class, getHttpEntity(request));
        } else {
            delete(getPolicyUrl(siteResponseV1),
                    POLICY_DYNAMIC_NAT_URI.concat(SLASH).concat(deviceResponse.getResourceName()), params, Object.class, getHttpEntity(request));
        }
    }

    public void getExtensiveMOSSessions(final DeviceResponseV1 deviceResponse, final SiteResponseV1 siteResponseV1) {
        Map<String, Object> params = callBuilder.buildCommonsParamsMap(deviceResponse.getManagementIpv4());
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(NETWORK_ID, siteResponseV1.getNetworkId());
        get(getPolicyUrl(siteResponseV1), POLICY_API_MOS_EXTENSION_URI,
                params, Object.class, getHttpEntity());
    }

    protected HttpEntity<Object> getHttpEntity() {
        return new HttpEntity<>(authHeaderGen.createSDWANPolicyHeaders());
    }

    HttpEntity<Object> getHttpEntity(Object body) {
        if (Objects.nonNull(body)) {
            return new HttpEntity<>(body, authHeaderGen.createSDWANPolicyHeaders());
        }
        return new HttpEntity<>(authHeaderGen.createSDWANPolicyHeaders());
    }

    String getPolicyUrl(final SiteResponseV1 site) {
        return policyApiBaseUrl.concat(SLASH + site.getVersaInstance());
    }

    public void getShowInterfaceV1(SiteResponseV1 siteResponse, DeviceResponseV1 deviceResponse, InterfaceResponseV1 interfaceResponse) {
        Map<String, Object> params = callBuilder.buildCommonsParamsMap(deviceResponse.getManagementIpv4());
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(MANAGEMENT_IPV4, deviceResponse.getManagementIpv4());
        params.put(INTERFACE_NAME, interfaceResponse.getName());
        get(getPolicyUrl(siteResponse), POLICY_API_SHOW_INTERFACE, params, Object.class, getHttpEntity());
    }

    public void getPppoeStatsV1(SiteResponseV1 siteResponse, DeviceResponseV1 deviceResponse, String type) {
        Map<String, Object> params = callBuilder.buildCommonsParamsMap(deviceResponse.getManagementIpv4());
        params.putAll(callBuilder.buildUserRolesParamsMap());
        params.put(MANAGEMENT_IPV4, deviceResponse.getManagementIpv4());
        params.put("type", type);
        get(getPolicyUrl(siteResponse), POLICY_API_PPPOE_STAT, params, Object.class, getHttpEntity());
    }

}
