package net.colt.sdwan.portal.mappers;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.model.IPFilteringProfileV1;
import net.colt.sdwan.portal.model.IPFilteringProfilesResponseV1;
import net.colt.sdwan.security.api.generated.model.IPFilteringProfileApiV1;
import net.colt.sdwan.security.api.generated.model.IPFilteringProfilesRequestApiV1;
import net.colt.sdwan.security.api.generated.model.IPFilteringProfilesResponseApiV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class IpFilteringMapper {

    private final ModelMapper modelMapper;

    public IPFilteringProfilesResponseV1 from(IPFilteringProfilesResponseApiV1 ipFilteringProfilesResponseApiV1) {
        return modelMapper.map(ipFilteringProfilesResponseApiV1, IPFilteringProfilesResponseV1.class);
    }

    public IPFilteringProfilesRequestApiV1 from(List<IPFilteringProfileV1> ipFilteringProfileV1s) {
        final IPFilteringProfilesRequestApiV1 ipFilteringProfilesRequestApiV1 = new IPFilteringProfilesRequestApiV1();

        if (!ipFilteringProfileV1s.isEmpty()) {
            ipFilteringProfileV1s.stream()
                    .map(ipFilteringProfileV1 -> modelMapper.map(ipFilteringProfileV1, IPFilteringProfileApiV1.class))
                    .forEach(ipFilteringProfilesRequestApiV1::addIpFilteringProfilesItem);
        }
        return ipFilteringProfilesRequestApiV1;
    }
}
