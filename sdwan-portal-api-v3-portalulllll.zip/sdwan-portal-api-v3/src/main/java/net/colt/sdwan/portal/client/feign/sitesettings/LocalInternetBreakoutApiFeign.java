package net.colt.sdwan.portal.client.feign.sitesettings;

import net.colt.sdwan.sitesettings.api.generated.api.LocalInternetBreakoutApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "localInternetBreakoutApiClient",
        url = "${sdwan.site.settings.api.baseurl}",
        configuration = SiteSettingsApiFeignConfiguration.class)
public interface LocalInternetBreakoutApiFeign extends LocalInternetBreakoutApiApi {
}
