package net.colt.sdwan.portal.database.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "PLANNED_MESSAGE")
public class PlannedMessage extends BaseEntity {

    @Column(name = "MESSAGE", nullable = false)
    private String message;

    @Column(name = "LANGUAGE", nullable = false)
    private String language;

    @Column(name = "START_DT", nullable = false)
    private LocalDateTime startDt;

    @Column(name = "END_DT", nullable = false)
    private LocalDateTime endDt;

    @Column(name = "TYPE", nullable = false)
    private String type;

}
