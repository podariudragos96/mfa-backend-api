package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.client.feign.customer.BrandingFeign;
import net.colt.sdwan.portal.client.model.customerapi.BrandingResponseV1;
import net.colt.sdwan.portal.model.BrandingPortalResponseV1;
import net.colt.sdwan.portal.services.BrandingService;
import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Objects;

@RequiredArgsConstructor
@Service
public class BrandingServiceImpl implements BrandingService {

    private final ModelMapper modelMapper;
    private final BrandingFeign brandingFeign;

    /**
     * GetBranding Details from xColtHost header.
     *
     * @param xColtHost domain name of the reseller
     * @return
     */
    @Override
    public BrandingPortalResponseV1 getBranding(String xColtHost) {
        ResponseEntity<BrandingResponseV1> response = brandingFeign.getBrandingByDomainV1(xColtHost);

        BrandingResponseV1 body = null;
        if (Objects.nonNull(response)) {
            body = response.getBody();
        }

        return modelMapper.map(body, BrandingPortalResponseV1.class);
    }

}
