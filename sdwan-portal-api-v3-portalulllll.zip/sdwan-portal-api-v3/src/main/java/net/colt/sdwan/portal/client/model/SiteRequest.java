package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@EqualsAndHashCode
public class SiteRequest {

    @JsonProperty("id")
    private String id;

    @JsonProperty("friendly_name")
    private String friendlyName;

    @JsonProperty("locked")
    private Boolean locked;

    @JsonProperty("locked_user")
    private String lockedUser;

    @JsonProperty("locked_dt")
    private String lockedDt;

    @JsonProperty("ongoing_action")
    private String onGoingAction;

    @JsonProperty("logging_profile")
    private String loggingProfile;

    @JsonProperty("logging_event")
    private String loggingEvent;

}
