package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SecureLogForwardingHistoryResponseV1;
import net.colt.sdwan.portal.model.SecureLogForwardingRequestV1;
import net.colt.sdwan.portal.model.SecureLogForwardingResponseV1;

import java.util.List;

public interface SecureLogForwardingService {

    CorrelationIdResponseV1 updateSecureLogForwardingV1(String siteId, SecureLogForwardingRequestV1 secureLogForwardingRequestV1);

    SecureLogForwardingResponseV1 getSecureLogForwardingV1(String siteId);

    List<SecureLogForwardingHistoryResponseV1> getSecureLogForwardingHistoryBySiteIdV1(String siteId);

    SecureLogForwardingResponseV1 getSecureLogForwardingHistoryBySiteIdAndRuleSetIdV1(String siteId, String ruleSetId);

    CorrelationIdResponseV1 getSecureLogForwardingStatisticsV1(String siteId, String deviceId, Integer collectorNumber);

    CorrelationIdResponseV1 getSecureLogForwardingStatusV1(String siteId, String deviceId, Integer collectorNumber);

}
