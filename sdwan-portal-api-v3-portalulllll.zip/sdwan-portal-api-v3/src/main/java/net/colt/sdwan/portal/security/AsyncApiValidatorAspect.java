package net.colt.sdwan.portal.security;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.async.response.api.generated.model.CustomerRequestV1;
import net.colt.sdwan.common.data.criteria.filter.StringFilter;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.generated.model.service.SiteCriteria;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.generated.model.service.SiteStatusV1;
import net.colt.sdwan.portal.client.ServiceApiClient;
import net.colt.sdwan.portal.client.feign.async.AsyncResponseApiFeign;
import net.colt.sdwan.portal.client.feign.customer.TenantFeign;
import net.colt.sdwan.portal.client.model.customerapi.TenantResponseV1;
import net.colt.sdwan.portal.model.ApiUserKeyResponseModel;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.ApiUserService;
import net.colt.sdwan.portal.util.MCVEReflect;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.HandlerMapping;

import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Aspect
@Component
@Slf4j
@RequiredArgsConstructor
public class AsyncApiValidatorAspect {

    private static final String ERROR = "Error on async request. Please contact the support team.";
    private static final String SITE_ID = "site_id";
    private static final String NETWORK_ID = "network_id";
    private static final String X_AUTH_TOKEN = "x-auth-token";
    private static final String API_CLIENT="api-client";

    private final AsyncResponseApiFeign asyncResponseApiFeign;
    private final ServiceApiClient serviceApiClient;
    private final TenantFeign tenantFeign;
    private final ApiUserService apiUserService;

    private static HttpServletRequest getHttpServletRequest() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes != null ? attributes.getRequest() : null;

        if (request == null) {
            throw new SdwanInternalServerErrorException(ERROR);
        }
        return request;
    }

    @Around("@annotation(net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod)")
    public Object validateResponse(ProceedingJoinPoint joinPoint) throws Throwable {

        LocalDateTime createDate=LocalDateTime.now();

        HttpServletRequest request=getHttpServletRequest();
        String coltUserAgent=request.getHeader("x-colt-user-agent");
        final String token=request.getHeader(X_AUTH_TOKEN);
        boolean isApiUserAgent=StringUtils.isNotBlank(coltUserAgent) && coltUserAgent.endsWith(API_CLIENT);
        if (isApiUserAgent) {
            ApiUserKeyResponseModel responseV1=apiUserService.getApiUserBasedOnKey(token, coltUserAgent);
            if (Objects.nonNull(responseV1)) {
                log.info("Called Async Response API");

                CustomerRequestV1 customerRequestV1=new CustomerRequestV1();

                MethodSignature signature=(MethodSignature) joinPoint.getSignature();
                Method method=signature.getMethod();

                SDWanAsyncMethod sdWanAsyncMethod=method.getAnnotation(SDWanAsyncMethod.class);
                String redirectUrl=sdWanAsyncMethod.value();

                RequestMapping requestMapping=MCVEReflect.getAnnotation(method, RequestMapping.class);
                String requestMethod=requestMapping.method()[0].toString();

                process(createDate, request, customerRequestV1, redirectUrl, requestMethod);
            }
        }
        Object object;

        try {
            object=joinPoint.proceed();
        } catch (Throwable t) {
            if (coltUserAgent == null || isApiUserAgent) {
                asyncResponseApiFeign.deleteRequestV1(MDC.get("correlationId"));
            }
            throw t;
        }

        return object;
    }

    private void process(LocalDateTime createDate, HttpServletRequest request, CustomerRequestV1 customerRequestV1, String redirectUrl, String requestMethod) {
        Map<String, String> vars=(Map<String, String>) request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);

        if (vars != null) {
            if (vars.containsKey(SITE_ID)) {
                handleWithSiteId(createDate, request, customerRequestV1, redirectUrl, requestMethod, vars);
            } else if (vars.containsKey(NETWORK_ID)) {
                handleWithNetworkId(createDate, request, customerRequestV1, redirectUrl, requestMethod, vars);
            } else {
                log.error("Could not determine tenant for this API");
                throw new SdwanInternalServerErrorException(ERROR);
            }
        }
    }

    private void handleWithSiteId(LocalDateTime createDate, HttpServletRequest request, CustomerRequestV1 customerRequestV1, String redirectUrl, String requestMethod, Map<String, String> vars) {
        SiteResponseV1 site = serviceApiClient.getSiteDetailsById(vars.get(SITE_ID));
        List<Integer> accessibleTenantIds = AuthUserHelper.getAuthUser().getAccessibleTenantIds();
        redirectUrl = redirectUrl.replace("{" + SITE_ID + "}", vars.get(SITE_ID));

        List<Integer> matchingTenantIds = accessibleTenantIds.stream()
                .filter(e -> Long.valueOf(e).equals(site.getTenantId()))
                .toList();

        if (matchingTenantIds.size() != 1) {
            log.error("Unable to identify correct TenantId. {}", matchingTenantIds);
            throw new SdwanInternalServerErrorException(ERROR);
        }

        ResponseEntity<TenantResponseV1> tenantResponseEntityV1 = tenantFeign.getTenantByIdV1(matchingTenantIds.get(0));
        TenantResponseV1 tenantResponseV1 = tenantResponseEntityV1.getBody() == null ? new TenantResponseV1() : tenantResponseEntityV1.getBody();


        sendRequest(createDate, request, redirectUrl, requestMethod, customerRequestV1, matchingTenantIds, tenantResponseV1);
    }

    private void handleWithNetworkId(LocalDateTime createDate, HttpServletRequest request, CustomerRequestV1 customerRequestV1, String redirectUrl, String requestMethod, Map<String, String> vars) {
        StringFilter versaOrgFilter = new StringFilter();
        versaOrgFilter.setEquals(vars.get(NETWORK_ID));

        StringFilter statusFilter = new StringFilter();
        statusFilter.setEquals(SiteStatusV1.ACTIVE.getValue());

        SiteCriteria siteCriteria = new SiteCriteria();
        siteCriteria.setVersaOrg(versaOrgFilter);
        siteCriteria.setSiteStatus(statusFilter);

        List<SiteResponseV1> sites = serviceApiClient.getSiteDetailsByCriteria(siteCriteria);
        Set<Long> tenantIds = sites.stream().map(SiteResponseV1::getTenantId).collect(Collectors.toSet());
        List<Integer> accessibleTenantIds = AuthUserHelper.getAuthUser().getAccessibleTenantIds();
        redirectUrl = redirectUrl.replace("{" + NETWORK_ID + "}", vars.get(NETWORK_ID));

        List<Integer> matchingTenantIds = accessibleTenantIds.stream()
                .filter(e -> tenantIds.stream().anyMatch(Long.valueOf(e)::equals))
                .toList();

        if (matchingTenantIds.size() != 1) {
            log.error("Unable to identify correct TenantId. {}", matchingTenantIds);
            throw new SdwanInternalServerErrorException(ERROR);
        }

        ResponseEntity<TenantResponseV1> tenantResponseEntityV1 = tenantFeign.getTenantByIdV1(matchingTenantIds.get(0));
        TenantResponseV1 tenantResponseV1 = tenantResponseEntityV1.getBody() == null ? new TenantResponseV1() : tenantResponseEntityV1.getBody();


        sendRequest(createDate, request, redirectUrl, requestMethod, customerRequestV1, matchingTenantIds, tenantResponseV1);
    }

    private void sendRequest(LocalDateTime createDate, HttpServletRequest request, String redirectUrl, String requestMethod, CustomerRequestV1 customerRequestV1, List<Integer> matchingTenantIds, TenantResponseV1 tenantResponseV1) {
        customerRequestV1.setCorrelationId(MDC.get("correlationId"));
        customerRequestV1.setTenantId(matchingTenantIds.get(0));
        customerRequestV1.setCustomerId(tenantResponseV1.getCustomerId());
        customerRequestV1.setCustomerPrimaryUrl(tenantResponseV1.getAsyncPrimaryUrl());
        customerRequestV1.setCustomerBackupUrl(tenantResponseV1.getAsyncBackupUrl());
        customerRequestV1.setRequestUrl(request.getRequestURL().toString());
        customerRequestV1.setRequestMethod(requestMethod);
        customerRequestV1.setRedirectUrl(redirectUrl);
        customerRequestV1.setRemoteAddress(request.getRemoteAddr());
        customerRequestV1.setUser(AuthUserHelper.getAuthUser().getUsername());
        customerRequestV1.setCreateDate(createDate);
        customerRequestV1.setUpdateDate(createDate);
        customerRequestV1.setOauthRegistrationId(tenantResponseV1.getOauthRegistrationId());
        customerRequestV1.setMaxRetries(tenantResponseV1.getAsyncMaxRetries());

        asyncResponseApiFeign.requestV1(customerRequestV1);
    }
}
