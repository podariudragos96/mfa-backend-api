package net.colt.sdwan.portal.services.impl;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.utils.SdwanExceptionUtils;
import net.colt.sdwan.generated.model.versa.sase.api.InternetProtectionRulesResponseApiV1;
import net.colt.sdwan.portal.client.feign.sase.SaseInternetProtectionRuleFeign;
import net.colt.sdwan.portal.enums.SaseOperation;
import net.colt.sdwan.portal.mappers.SaseInternetProtectionRuleMapper;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.InternetProtectionRulesRequestV1;
import net.colt.sdwan.portal.model.InternetProtectionRulesResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.SaseInternetProtectionRuleService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;

@Service
@RequiredArgsConstructor
@Slf4j
public class SaseInternetProtectionRuleServiceImpl implements SaseInternetProtectionRuleService {

    private final SaseInternetProtectionRuleFeign feign;

    private final SaseInternetProtectionRuleMapper mapper;

    private final ResponseEntityValidator responseEntityValidator;

    @Override
    public InternetProtectionRulesResponseV1 getInternetProtectionRulesV1(String tenantUuid) {
        log.info("Getting internet protection rules via sase-api for tenantUuid={}", tenantUuid);

        final ResponseEntity<InternetProtectionRulesResponseApiV1> saseApiResp = feign.getInternetProtectionRulesV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(saseApiResp, SaseOperation.INTERNET_PROTECTION_RULES_GET.getName());

        log.info("Get internet protection rules request completed successfully for tenantUuid={}.", tenantUuid);
        return mapper.from(requireNonNull(saseApiResp.getBody()));
    }

    @Override
    public CorrelationIdResponseV1 updateInternetProtectionRulesV1(String tenantUuid, InternetProtectionRulesRequestV1 requestV1) {
        log.info("Updating internet protection rules for tenantUuid={} ...", tenantUuid);

        try {
            final UserAuth userAuth = requireNonNull(AuthUserHelper.getAuthUser());

            feign.updateInternetProtectionRulesV1(userAuth.getUsername(), tenantUuid, mapper.from(requestV1));
            log.info("Update sase internet protection rules request was completed successfully for initiatedUserId={} and tenantUuid={}.",
                    userAuth.getUsername(), tenantUuid);

        } catch (FeignException e) {
            final String errorMsg = String.format("Failed to update internet protection rules for tenantUuid=%s.", tenantUuid);
            throw SdwanExceptionUtils.buildSdwanException(e.status(), errorMsg);
        }

        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }
}
