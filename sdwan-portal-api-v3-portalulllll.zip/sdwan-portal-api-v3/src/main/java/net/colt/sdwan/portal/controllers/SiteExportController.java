package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.portal.generated.controllers.ExportApiApi;

import net.colt.sdwan.portal.model.SiteExportCriteria;
import net.colt.sdwan.portal.model.SupportedLanguageV1;
import net.colt.sdwan.portal.services.SiteExportService;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@RequiredArgsConstructor
public class SiteExportController implements ExportApiApi {

    private final SiteExportService siteExportService;

    @Override
    public ResponseEntity<Resource> exportSitesV1(String accept, SupportedLanguageV1 acceptLanguage, SiteExportCriteria siteExportCriteria) {
        return siteExportService.exportSite(accept, acceptLanguage, siteExportCriteria);

    }
}
