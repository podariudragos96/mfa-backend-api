package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.model.FirewallRuleHistoryResponseV1;
import net.colt.sdwan.portal.model.FirewallRuleSetResponseV2;
import net.colt.sdwan.portal.model.FirewallRulesRequestV1;
import net.colt.sdwan.security.api.generated.model.FirewallRuleSetResponseV1;
import net.colt.sdwan.security.api.generated.model.FirewallRulesRequestV2;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@RequiredArgsConstructor
@Component
public class FirewallModelMapper {

    private final ModelMapper modelMapper;

    public FirewallRulesRequestV1 from(net.colt.sdwan.portal.model.FirewallRulesRequestV1 firewallRules) {
        return modelMapper.map(firewallRules, FirewallRulesRequestV1.class);
    }

    public FirewallRulesRequestV2 from(net.colt.sdwan.portal.model.FirewallRulesRequestV2 firewallRules) {
        return modelMapper.map(firewallRules, FirewallRulesRequestV2.class);
    }

    public FirewallRuleSetResponseV1 from(net.colt.sdwan.security.api.generated.model.FirewallRuleSetResponseV1 firewallRules) {
        return modelMapper.map(firewallRules, FirewallRuleSetResponseV1.class);
    }

    public FirewallRuleHistoryResponseV1 fromSecurityApi(net.colt.sdwan.security.api.generated.model.FirewallRuleSetResponseV1 firewallRules) {
        return modelMapper.map(firewallRules, FirewallRuleHistoryResponseV1.class);
    }

    public FirewallRuleSetResponseV2 from(net.colt.sdwan.security.api.generated.model.FirewallRuleSetResponseV2 firewallRules) {
        return modelMapper.map(firewallRules, FirewallRuleSetResponseV2.class);
    }
}
