package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.*;

import java.time.LocalDateTime;
import java.util.List;

public interface DDOSRulesService {

    DdosRuleSetResponseV1 getDDOSRulesBySiteIdV2(final String siteId);

    List<DdosRuleHistoryResponseV1> getDDOSRulesHistoryBySiteIdV1(final String siteId);

    DdosRuleSetResponseV1 getDDOSRulesHistoryBySiteIdAndRuleSetIdV1(String siteId, String ruleSetId);

    CorrelationIdResponseV1 updateDDOSRulesBySiteIdV2(final String siteId, final DdosRulesRequestV1 ddosRulesRequest);

    CorrelationIdResponseV1 updateDDOSRulesBySiteIdV3(final String siteId, final DdosRulesRequestV1 ddosRulesRequest);

    DdosEventLogsResponseV1 getDdosEventLogsBySiteIdV1(String siteId, LocalDateTime startDate, LocalDateTime endDate);
}
