package net.colt.sdwan.portal.client.feign.customer;

import net.colt.sdwan.portal.generated.customerapi.controllers.TenantApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "tenantClient", url = "${sdwan.customer.api.baseurl}", configuration = CustomerFeignConfiguration.class)
public interface TenantFeign extends TenantApiApi {

}