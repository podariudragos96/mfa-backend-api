package net.colt.sdwan.portal.mappers;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import net.colt.sdwan.portal.enums.LIBPreference;
import net.colt.sdwan.portal.model.LocalInternetBreakoutPreferencesDetailsV1;
import net.colt.sdwan.portal.model.LocalInternetBreakoutPreferencesV1;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.nonNull;

/**
 * Local Internet Breakout response mapper
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class LIBMapper {

    public static LocalInternetBreakoutPreferencesV1 mapToLIBPreferences(final net.colt.sdwan.generated.model.service.LocalInternetBreakoutPreferencesV1 portalPreferencesResponse) {
        if (nonNull(portalPreferencesResponse)) {
            return new LocalInternetBreakoutPreferencesV1()
                    .lanInterface(portalPreferencesResponse.getLanInterface())
                    .vrf(portalPreferencesResponse.getVrf())
                    .cloudLookupEnabled(Boolean.TRUE.equals(portalPreferencesResponse.getCloudLookupEnabled()))
                    .preferences(mapToListOfPreferencesDetails(portalPreferencesResponse.getPreferences()));
        }
        return new LocalInternetBreakoutPreferencesV1();
    }

    public static List<LocalInternetBreakoutPreferencesV1> mapToListOfLibPreferences(
            final List<net.colt.sdwan.generated.model.service.LocalInternetBreakoutPreferencesV1> libPreferencesResponse) {
        if (CollectionUtils.isNotEmpty(libPreferencesResponse)) {
            return libPreferencesResponse.stream()
                    .map(LIBMapper::mapToLIBPreferences)
                    .toList();
        }
        return new ArrayList<>();
    }

    private static LocalInternetBreakoutPreferencesDetailsV1 mapToLIBPreferenceDetails(
            final net.colt.sdwan.generated.model.service.LocalInternetBreakoutPreferencesDetailsV1 libPreference) {
        if (nonNull(libPreference)) {
            return new LocalInternetBreakoutPreferencesDetailsV1()
                    .wanInterface(libPreference.getWanInterface())
                    .action(mapToLIBActionEnum(libPreference.getAction() != null ? libPreference.getAction().getValue() : null))
                    .preference(mapToLIBPreferenceEnum(libPreference.getPreference()));
        }
        return new LocalInternetBreakoutPreferencesDetailsV1();
    }

    private static List<LocalInternetBreakoutPreferencesDetailsV1> mapToListOfPreferencesDetails(
            final List<net.colt.sdwan.generated.model.service.LocalInternetBreakoutPreferencesDetailsV1> preferences) {
        if (CollectionUtils.isNotEmpty(preferences)) {
            return preferences.stream()
                    .map(LIBMapper::mapToLIBPreferenceDetails)
                    .toList();
        }
        return new ArrayList<>();
    }

    private static LocalInternetBreakoutPreferencesDetailsV1.ActionEnum mapToLIBActionEnum(final String libAction) {
        LocalInternetBreakoutPreferencesDetailsV1.ActionEnum actionEnum = null;
        if (StringUtils.isNotEmpty(libAction)) {
            actionEnum = LocalInternetBreakoutPreferencesDetailsV1.ActionEnum.fromValue(libAction.toUpperCase());
        }
        return actionEnum;
    }

    private static LocalInternetBreakoutPreferencesDetailsV1.PreferenceEnum mapToLIBPreferenceEnum(final Integer libPreference) {
        LocalInternetBreakoutPreferencesDetailsV1.PreferenceEnum preferenceEnum =
                LocalInternetBreakoutPreferencesDetailsV1.PreferenceEnum.NO_PRIORITY;
        if (nonNull(libPreference) && LIBPreference.contains(libPreference)) {
            preferenceEnum = LIBPreference.fromValue(libPreference);
        }
        return preferenceEnum;
    }

}
