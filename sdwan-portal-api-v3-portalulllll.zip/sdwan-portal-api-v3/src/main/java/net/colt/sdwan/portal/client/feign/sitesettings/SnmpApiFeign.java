package net.colt.sdwan.portal.client.feign.sitesettings;

import net.colt.sdwan.sitesettings.api.generated.api.SnmpApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "snmpApiClient",
        url = "${sdwan.site.settings.api.baseurl}",
        configuration = SiteSettingsApiFeignConfiguration.class)
public interface SnmpApiFeign extends SnmpApiApi {
}
