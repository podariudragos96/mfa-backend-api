package net.colt.sdwan.portal.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class BreakoutConstants {

    // Breakout types
    public static final String SASE_BREAKOUT = "SASE BREAKOUT";
    public static final String ZSCALER_BREAKOUT = "ZSCALER BREAKOUT";

    // Error messages
    public static final String BREAKOUT_ONLY_AVAILABLE_ON_BRANCH_SITES = "Breakout is only available for sites of type branch";
    public static final String SASE_BREAKOUT_ONLY_AVAILABLE_ON_SASE_ENABLED = "Sase Breakout is only available when Sase is enabled";
    public static final String SASE_BREAKOUT_ACTIVE_MUST_HAVE_AT_LEAST_ONE_TUNNEL_UP = "Enable shall work only if at least 1 x SASE IPSEC Tunnel is active on site";
    public static final String ZSCALER_BREAKOUT_ONLY_AVAILABLE_ON_ZSCALER_ENABLED = "ZScaler Breakout is only available when ZScaler is enabled";
    public static final String ZSCALER_BREAKOUT_ACTIVE_MUST_HAVE_AT_LEAST_ONE_TUNNEL_UP = "Enable shall work only if at least 1 x ZScaler GRE Tunnel is active on site";
}
