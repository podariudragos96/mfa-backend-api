package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.InterfaceApiApi;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.InterfaceService;
import net.colt.sdwan.portal.services.RoutesService;
import net.colt.sdwan.portal.validator.model.RoutePatchDocumentValidator;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

import static org.springframework.http.HttpStatus.OK;

@RequiredArgsConstructor
@Controller
public class InterfacesController implements InterfaceApiApi {

    private final InterfaceService interfaceService;
    private final RoutesService routesService;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setValidator(new RoutePatchDocumentValidator());
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/devices/{device_id}/interfaces/{interface_id}/commands/route")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> addRouteResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocolV1(String siteId,
                                                                                                                         String deviceId, String interfaceId,
            @RequestParam(value = "routing_protocol", defaultValue = "null") RoutingProtocolV1 routingProtocol,
            @RequestBody List<RoutePatchDocumentV1> routePatchDocument) {
        return new ResponseEntity<>(routesService.addRouteResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocol(siteId, deviceId, interfaceId, routingProtocol, routePatchDocument), HttpStatus.OK);
    }


    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<InterfaceResponseV1>> getInterfaceBySiteIdAndDeviceIdV1(String siteId, String deviceId) {
        return new ResponseEntity<>(interfaceService.getInterfaceBySiteIdAndDeviceId(siteId, deviceId), OK);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<InterfaceResponseV1> getInterfaceBySiteIdAndDeviceIdAndInterfaceIdV1(String siteId, String deviceId, String interfaceId) {
        InterfaceResponseV1 interfaceResponse = interfaceService.getInterfaceBySiteIdAndDeviceIdAndInterfaceId(siteId, deviceId, interfaceId);
        return new ResponseEntity<>(interfaceResponse, OK);
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> getInterfaceDynamicInfoBySiteIdAndDeviceIdAndInterfaceIdV1(String siteId,
                                                                                                              String deviceId,
                                                                                                              String interfaceId) {
        return new ResponseEntity<>(interfaceService.getInterfaceDynamicInfoBySiteIdAndDeviceIdAndInterfaceId(siteId, deviceId, interfaceId), OK);
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> getNeighborResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocolV1(
            String siteId,
            String deviceId,
            String interfaceId,
            RoutingProtocolV1 routingProtocol,
            @RequestParam(value = "brief") Boolean brief) {
        return new ResponseEntity<>(routesService.getNeighborResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocol(siteId, deviceId, interfaceId, routingProtocol, brief), HttpStatus.OK);
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> getStatisticsResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocolV1(
            String siteId,
            String deviceId,
            String interfaceId,
            RoutingProtocolV1 routingProtocol,
            @RequestParam(value = "brief") Boolean brief) {
        return new ResponseEntity<>(routesService.getStatisticsResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocol(siteId, deviceId, interfaceId, routingProtocol, brief), OK);
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> getRouteResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocolV1(
            String siteId,
            String deviceId,
            String interfaceId,
            @RequestParam(value = "routing_protocol", required = false) RoutingProtocolV1 routingProtocol,
            @RequestParam(value = "routing_type", required = false) RoutingTypeV1 routingType,
            @RequestParam(value = "formatted", required = false) Boolean formatted) {
        return new ResponseEntity<>(routesService.getRouteResponseBySiteIdAndDeviceIdAndInterfaceIdAndRoutingProtocol(siteId, deviceId, interfaceId, routingProtocol, routingType, formatted), HttpStatus.OK);
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> getShowInterfaceResponseBySiteIdAndDeviceIdAndInterfaceIdV1(
            String siteId,
            String deviceId,
            String interfaceId) {
        return new ResponseEntity<>(interfaceService.getShowInterfaceResponseBySiteIdAndDeviceIdAndInterfaceId(siteId, deviceId, interfaceId), HttpStatus.OK);
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> getPppoeStatsResponseBySiteIdAndDeviceIdAndInterfaceIdV1(
            String siteId,
            String deviceId,
            String interfaceId,
            String type) {
        return new ResponseEntity<>(interfaceService.getPppoeStatsResponseBySiteIdAndDeviceIdAndInterfaceId(siteId, deviceId, interfaceId, type), HttpStatus.OK);
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> getStatsBySiteIdAndDeviceIdAndInterfaceIdAndStatNameV1(
            String siteId, String deviceId, String interfaceId, String statName) {
        return new ResponseEntity<>(interfaceService.getStatsBySiteIdAndDeviceIdAndInterfaceIdAndStatName(siteId, deviceId, interfaceId, statName), OK);
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> getTracerouteResponseBySiteIdAndDeviceIdAndInterfaceIdAndTargetIpV1(
            String siteId,String deviceId,
            String interfaceId, @RequestParam("target_ip") String targetIp) {
        CommandRequestModel commandRequestModel = CommandRequestModel.builder()
                .siteId(siteId)
                .deviceId(deviceId)
                .interfaceId(interfaceId)
                .targetIP(targetIp)
                .isPing(false)
                .build();
        return new ResponseEntity<>(interfaceService.getPingOrTracerouteResponse(commandRequestModel), OK);
    }

    @Override
    @SDWanAsyncMethod("/v1/sites/{site_id}/devices/{device_id}/interfaces/{interface_id}/stats/{stat_name}")
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateStatsBySiteIdAndDeviceIdAndInterfaceIdAndStatNameV1(
            String siteId,
            String deviceId,
            String interfaceId,
            String statName) {
        CorrelationIdResponseV1 response = interfaceService.updateStatsBySiteIdAndDeviceIdAndInterfaceIdAndStatName(siteId, deviceId, interfaceId, statName);
        return new ResponseEntity<>(response, OK);
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> getPingResponseBySiteIdAndDeviceIdAndInterfaceIdAndTargetIpV1(
            String siteId,
            String deviceId,
            String interfaceId,
            @RequestParam("target_ip") String targetIp) {
        CommandRequestModel commandRequestModel = CommandRequestModel.builder()
                .siteId(siteId)
                .deviceId(deviceId)
                .interfaceId(interfaceId)
                .targetIP(targetIp)
                .isPing(true)
                .build();
        return new ResponseEntity<>(interfaceService.getPingOrTracerouteResponse(commandRequestModel), OK);
    }

}
