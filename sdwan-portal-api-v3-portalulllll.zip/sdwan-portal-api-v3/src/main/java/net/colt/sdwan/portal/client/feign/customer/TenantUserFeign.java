package net.colt.sdwan.portal.client.feign.customer;

import net.colt.sdwan.portal.generated.customerapi.controllers.TenantUserApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "tenantUserClient", url = "${sdwan.customer.api.baseurl}", configuration = CustomerFeignConfiguration.class)
public interface TenantUserFeign extends TenantUserApiApi {

}
