package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.generated.model.service.InterfaceResponseV1;
import net.colt.sdwan.portal.client.model.StaticRoutesRequest;
import net.colt.sdwan.portal.model.RoutePatchDocumentV1;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class StaticRoutesRequestMapper {

    public List<StaticRoutesRequest> mapFromRoutePatchDocument(final RoutePatchDocumentV1 routePatchDocument, final InterfaceResponseV1 interfaceResponse) {
        List<StaticRoutesRequest> staticRoutesRequestList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(routePatchDocument.getValue().getRoute())) {
            staticRoutesRequestList = routePatchDocument.getValue().getRoute().stream()
                    .map(
                            routeDetail -> {
                                StaticRoutesRequest staticRoutesRequest = new StaticRoutesRequest();
                                staticRoutesRequest.setVniInterface(interfaceResponse.getName());
                                staticRoutesRequest.setVrf(interfaceResponse.getVrf());
                                staticRoutesRequest.setDestination(routeDetail.getDestination());
                                staticRoutesRequest.setNextHop(routeDetail.getNextHop());
                                return staticRoutesRequest;
                            })
                    .toList();
        }
        return staticRoutesRequestList;
    }
}
