package net.colt.sdwan.portal.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class SecurityConstants {

    public static final String SECURITY_ANTIVIRUS_PROFILES = "Security Antivirus profiles";
    public static final String SECURITY_VULNERABILITY_PROFILES = "Security Vulnerability profiles";
    public static final String IP_FILTERING_PROFILES = "IP Filtering profiles";
    public static final String NETFLOW_IP_FIX_PROFILES = "NetFlow IPFIX profiles";
    public static final String SECURE_LOG_FORWARDING_PROFILES = "Secure Log Forwarding profiles";
    public static final String STEERING_PROFILES = "Steering profiles";
    public static final String FAILED_TO_UPDATED_FIREWALL_RULES = "Failed to update Firewall Rules";
    public static final String NAT_RULES_ONLY_ALLOWED_FOR_BRANCH_AND_GATEWAY = "Invalid siteType : NAT rules requests are only allowed for Branch and Gateway sites";
}
