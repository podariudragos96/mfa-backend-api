package net.colt.sdwan.portal.client.webservice;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanException;
import net.colt.sdwan.common.exceptions.exception.SdwanInternalServerErrorException;
import net.colt.sdwan.common.exceptions.exception.SdwanUnauthorizedException;
import net.colt.xml.ns.cum.v1.UserType;
import net.colt.xml.ns.cumf.v1.AuthenticationRequest;
import net.colt.xml.ns.cumf.v1.AuthenticationResponse;
import net.colt.xml.ns.cumf.v1.GetUserRequest;
import net.colt.xml.ns.cumf.v1.GetUserResponse;
import net.colt.xml.ns.cumf.v1.UserService;
import org.springframework.stereotype.Component;

import java.util.Objects;

import static java.util.Objects.isNull;

@RequiredArgsConstructor
@Component
@Slf4j
public class UserServicesWebserviceClient {

    public static final String SUCCESS = "SUCCESS";

    private final UserService userService;

    /**
     * Colt Online WS Authentication
     *
     * @param username Colt Online Username
     * @param password Colt Online User's Password
     */
    public void authenticate(String username, String password) {
        log.info("Calling external Colt Online WS authentication method {} {}",
                UserService.class.getName(), "authentication");
        try {
            final AuthenticationRequest authenticationRequest = new AuthenticationRequest();
            authenticationRequest.setUserId(username);
            authenticationRequest.setPassword(password);

            final AuthenticationResponse authResponse = userService.authentication(authenticationRequest);

            if (isNull(authResponse) || !SUCCESS.equalsIgnoreCase(authResponse.getStatus())) {
                throw new SdwanUnauthorizedException("Unauthorized access for username: %s".formatted(username));
            }

        } catch (SdwanException se) {
            throw se;

        } catch (Exception ex) {
            throw new SdwanInternalServerErrorException("Failed to get response from Colt Online WS", ex);
        }
    }

    public UserType getUserType(String userId) {
        log.debug("Calling external Colt Online WS to retrieve user's details for userId {}", userId);
        final GetUserRequest getUserRequest = new GetUserRequest();
        getUserRequest.setUserid(userId);

        try {
            final GetUserResponse userResponse = userService.getUser(getUserRequest);

            if (Objects.nonNull(userResponse)) {
                log.debug("Received a response from external Colt Online WS with user's details: {}",
                        new ObjectMapper().writeValueAsString(userResponse));

                return userResponse.getUser();
            }

        } catch (Exception ex) {
            log.error("Failed to get response from Colt Online WS", ex);
        }

        return null;
    }

}
