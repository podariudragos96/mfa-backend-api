package net.colt.sdwan.portal.client;

public class ParamsLabels {
    public static final String CUSTOMER = "customer";
    public static final String USERNAME = "username";
    public static final String ORG = "org";
    public static final String IS_LTE = "is_lte";
    public static final String IS_CGW = "is_cgw";
    public static final String TENANTID = "tenantid";
    public static final String TENANT_ID = "tenant_id";
    public static final String CUSTOMERID = "customerid";
    public static final String CUSTOMER_ID = "customer_id";
    public static final String SITEID = "siteid";
    public static final String SITE_NAME = "site_name";
    public static final String DEVICE_NAME = "device_name";
    public static final String SITE_TYPE = "site_type";
    public static final String DUALHYBRIDCPE = "dualhybridcpe";
    public static final String SITE = "site";
    public static final String DEVICE = "device";
    public static final String DEVICE_ID = "device_id";
    public static final String TYPE = "type";
    public static final String MANAGEMENT_IPV4 = "management_ipv4";
    public static final String ACTION = "action";
    public static final String INITIATED_USER_ID = "initiated_user_id";
    public static final String INITIATED_USER_ROLE = "initiated_user_role";
    public static final String OCN = "ocn";
    public static final String ASYNC = "async";
    public static final String EVENT_ID = "event_id";
    public static final String NETWORK_ID = "network_id";
    public static final String EVENT = "event";
    public static final String CONFIGURED = "configured";
    public static final String BRIEF = "brief";
    public static final String CSP_PEERING_INTERFACE = "csp_peering_interface";
    public static final String DEVICE_PATH = "&device=";
    public static final String REMOTE_DEVICE_NAME = "remoteDeviceName";
    public static final String TARGET_IP = "target_ip";
    public static final String VRF = "vrf";
    public static final String SRC_IP = "src_ip";
    public static final String IPV6_ENABLED = "ipv6_enabled";
    public static final String NEIGHBOR_IP = "neighbor_ip";
    public static final String INTERFACE = "interface";
    public static final String INTERFACE_NAME = "interface_name";
    public static final String INTERFACES = "interfaces";
    public static final String STATS = "stats";
    public static final String ZONES_TEMPLATE_KEY = "zones_template_key";
    public static final String DEVICES_PARAMS = "devicesParams";
    public static final String CERTIFICATE_TYPE = "type";
    public static final String DEVICE_SOFTWARE_VERSION = "device_software_version";
    public static final String ROUTING_PROTOCOL = "routing_protocol";
    public static final String BGP_TYPE = "bgp_type";
    public static final String FORMATTED = "formatted";
    public static final String PRIMARY_DEVICE = "primary_device";
    public static final String POLICY_RESP = "Could not get any content from policyApi";
    public static final String START_DATE = "start_date";
    public static final String START = "start";
    public static final String END_DATE = "end_date";
    public static final String END = "end";
    public static final String FROM = "from";
    public static final String TO = "to";
    public static final String METRICS = "metrics";
    public static final String COUNT = "count";
    public static final String APPLICATIONS = "applications";
    public static final String TOP_COUNT = "top_count";
    public static final String FORMAT = "format";
    public static final String DIA = "dia";
    public static final String AUTH_TOKEN = "Auth-token";
    public static final String STATUS = "status";
    public static final String LEGAL_NAME = "legal_name";
    public static final String IGNORE_SEMAPHORE = "remove_lock";
    public static final String TENANT_ID_LIST = "tenant_id_list";
    public static final String VERSA_INSTANCE = "versa_instance";


    private ParamsLabels() {
    }
}
