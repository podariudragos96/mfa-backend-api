package net.colt.sdwan.portal.services;

import net.colt.sdwan.metadata.api.generated.model.*;
import net.colt.sdwan.portal.model.*;

import java.util.List;
import java.util.Map;

public interface MetaService {
    List<MetaApplicationPortalV1> getAllApplications();

    UrlPredefinedCategoriesResponseV1 getAllURLCategories(MetadataCriteria criteria, Integer pageNumber, Integer pageSize);

    List<FileTypeDetailsV1> getAllFileTypes();

    MetadataExceptionSignaturesPortalResponseV1 getVulnerabilityExceptionSignaturesV1(Integer offset, Integer limit, String search);

    Map<String, String> getVulnerabilityExceptionSignaturesByIdsV1(List<String> signatureIds);

    List<String> getVulnerabilityPredefinedProfileNamesV1();

    List<String> getVulnerabilityUserDefinedApplicationsV1();

    List<String> getVulnerabilityUserDefinedClassTypesV1();

    List<MetaOperatingSystemsPortalV1> getVulnerabilityUserDefinedOperatingSystemsV1();

    List<MetaProductPortalV1> getVulnerabilityUserDefinedProductsV1();

    List<MetaReferencePortalV1> getVulnerabilityUserDefinedReferencesV1();

    List<Integer> getVulnerabilityUserDefinedCveYearsV1();

    List<MetaGeoIpCountryPortalV1> getIpFilteringGeoIpCountriesV1();

    List<String> getIpFilteringReputationsV1();

    List<MetaQueryPatternsPortalV1> getMetaQueryPatternsV1();

    void validateVulnerabilityPredefinedProfileNamesV1(MetadataValidateListRequestV1 metadataValidateListRequestV1);

    void validateVulnerabilityExceptionSignaturesV1(MetadataValidateListRequestV1 metadataValidateListRequestV1);

    void validateVulnerabilityUserDefinedClassTypesV1(MetadataValidateListRequestV1 metadataValidateListRequestV1);

    void validateVulnerabilityUserDefinedApplicationsV1(MetadataValidateListRequestV1 metadataValidateListRequestV1);

    void validateVulnerabilityUserDefinedProductsV1(MetadataValidateProductRequestV1 metadataValidateProductRequestV1);

    void validateVulnerabilityUserDefinedOperatingSystemsV1(MetadataValidateOSRequestV1 metadataValidateOSRequestV1);

    void validateVulnerabilityUserDefinedReferencesV1(MetadataValidateReferenceRequestV1 metadataValidateReferenceRequestV1);

    void validateVulnerabilityUserDefinedCveYearsV1(MetadataValidateIntListRequestV1 metadataValidateIntListRequestV1);

    void validateIpFilteringGeoIpCountriesV1(MetadataValidateListRequestV1 metadataValidateListRequestV1);

    void validateIpFilteringReputationsV1(MetadataValidateListRequestV1 metadataValidateListRequestV1);
}
