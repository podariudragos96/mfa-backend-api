package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.SslDecryptionCertificateApiApi;
import net.colt.sdwan.portal.model.CertificateTypeV1;
import net.colt.sdwan.portal.model.DeviceCustomerManagedCertificateRequestV1;
import net.colt.sdwan.portal.model.DeviceSelfSignedCertificateRequestV1;
import net.colt.sdwan.portal.model.DeviceSelfSignedCertificateResponseV1;
import net.colt.sdwan.portal.services.CertificateService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

@RequiredArgsConstructor
@Controller
public class SslDecryptionCertificateController implements SslDecryptionCertificateApiApi {

    private final CertificateService certificateService;

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<DeviceSelfSignedCertificateResponseV1> getCertificateBySiteIdAndDeviceIdV1(String siteId, String deviceId, CertificateTypeV1 certificateType) {
        return ResponseEntity.ok(certificateService.getCertificateBySiteIdAndDeviceIdV1(siteId, deviceId, certificateType));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<Void> createSelfSignedCertificateBySiteIdAndDeviceIdV1(
            String siteId,
            String deviceId,
            @RequestBody DeviceSelfSignedCertificateRequestV1 deviceSelfSignedCertificateRequestV1) {
        certificateService.createSelfSignedCertificateBySiteIdAndDeviceIdV1(siteId, deviceId, deviceSelfSignedCertificateRequestV1);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<Void> createCustomerManagedCertificateBySiteIdAndDeviceIdV1(
            String siteId,
            String deviceId,
            DeviceCustomerManagedCertificateRequestV1 deviceCustomerManagedCertificateRequestV1) {
        certificateService.uploadCustomerCertificateBySiteIdAndDeviceIdV1(siteId, deviceId, deviceCustomerManagedCertificateRequestV1);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
