package net.colt.sdwan.portal.client.feign.mfa;

import feign.auth.BasicAuthRequestInterceptor;
import net.colt.sdwan.common.data.criteria.config.AbstractCriteriaApiFeignConfiguration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

public class IdentityAccessFeignConfiguration extends AbstractCriteriaApiFeignConfiguration {
    private final String username;
    private final String password;

    public IdentityAccessFeignConfiguration(
            @Value("${sdwan.identity-access.api.user}") String username,
            @Value("${sdwan.identity-access.api.pwd}") String password
    ) {
        this.username = username;
        this.password = password;
    }

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        return new BasicAuthRequestInterceptor(username, password);
    }
}
