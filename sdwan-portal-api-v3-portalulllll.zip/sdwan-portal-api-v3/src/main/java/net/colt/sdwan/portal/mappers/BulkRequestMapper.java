package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.client.model.bulkapi.BulkCopyRequestRequestV2;
import net.colt.sdwan.portal.client.model.bulkapi.BulkCopyRequestSiteIdRequestV1;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.models.UserAuth;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
public class BulkRequestMapper {

    public List<BulkCopyRequestResponseV2> mapBulkCopyRequestResponse(List<net.colt.sdwan.portal.client.model.bulkapi.BulkCopyRequestResponseV2> bulkCopyRequestResponseList) {
        if (CollectionUtils.isEmpty(bulkCopyRequestResponseList)) {
            return new ArrayList<>();
        }
        return bulkCopyRequestResponseList.stream()
                .map(this::mapToPortalAPIBulkCopyRequestResponse)
                .toList();
    }


    public List<BulkCopyRequestsResponseV1> mapBulkCopyRequestsResponse(List<net.colt.sdwan.portal.client.model.bulkapi.BulkCopyRequestsResponseV1> bulkCopyRequestsResponseList) {
        if (CollectionUtils.isEmpty(bulkCopyRequestsResponseList)) {
            return new ArrayList<>();
        }
        return bulkCopyRequestsResponseList.stream()
                .map(this::mapToPortalAPIBulkCopyRequestsResponse)
                .toList();
    }

    private BulkCopyRequestsResponseV1 mapToPortalAPIBulkCopyRequestsResponse(net.colt.sdwan.portal.client.model.bulkapi.BulkCopyRequestsResponseV1 bulkCopyRequestsResponseV1) {
        return new BulkCopyRequestsResponseV1()
                .requestId(bulkCopyRequestsResponseV1.getRequestId())
                .sourceSiteId(bulkCopyRequestsResponseV1.getSourceSiteId())
                .requestStatus(BulkCopyRequestStatusV1.fromValue(bulkCopyRequestsResponseV1.getRequestStatus().toString()))
                .requestedDt(bulkCopyRequestsResponseV1.getRequestedDt())
                .completedDt(bulkCopyRequestsResponseV1.getCompletedDt())
                .requestedBy(bulkCopyRequestsResponseV1.getRequestedBy())
                .lastUpdatedDt(bulkCopyRequestsResponseV1.getLastUpdatedDt());
    }

    private BulkCopyRequestResponseV2 mapToPortalAPIBulkCopyRequestResponse(net.colt.sdwan.portal.client.model.bulkapi.BulkCopyRequestResponseV2 bulkCopyRequestResponse) {
        return new BulkCopyRequestResponseV2()
                .completedDt(bulkCopyRequestResponse.getCompletedDt())
                .requestId(bulkCopyRequestResponse.getRequestId())
                .ddosRuleSetId(bulkCopyRequestResponse.getDdosRuleSetId())
                .requestedDt(bulkCopyRequestResponse.getRequestedDt())
                .destinationSites(mapDestinationSites(bulkCopyRequestResponse.getDestinationSites()))
                .firewallRuleSetId(bulkCopyRequestResponse.getFirewallRuleSetId())
                .netflowRuleSetId(bulkCopyRequestResponse.getNetflowRuleSetId())
                .lastUpdatedDt(bulkCopyRequestResponse.getLastUpdatedDt())
                .qosRuleSetId(bulkCopyRequestResponse.getQosRuleSetId())
                .secureLogForwardingSetId(bulkCopyRequestResponse.getSecureLogForwardingSetId())
                .snmpRuleSetId(bulkCopyRequestResponse.getSnmpRuleSetId())
                .dnsProxyRuleSetId(bulkCopyRequestResponse.getDnsProxyRuleSetId())
                .steeringRuleSetId(bulkCopyRequestResponse.getSteeringRuleSetId())
                .copyServiceObjectsFlag(bulkCopyRequestResponse.getCopyServiceObjectsFlag())
                .copyAddressObjectsFlag(bulkCopyRequestResponse.getCopyAddressObjectsFlag())
                .copyAddressGroupObjectsFlag(bulkCopyRequestResponse.getCopyAddressGroupObjectsFlag())
                .copyUrlCategoryObjectsFlag(bulkCopyRequestResponse.getCopyUrlCategoryObjectsFlag())
                .sourceSiteId(bulkCopyRequestResponse.getSourceSiteId());
    }

    private List<BulkCopyRequestSiteResponseV2> mapDestinationSites(List<net.colt.sdwan.portal.client.model.bulkapi.BulkCopyRequestSiteResponseV2> destinationSites) {
        return destinationSites.stream()
                .map(this::toDestinationSite)
                .toList();
    }

    private BulkCopyRequestSiteResponseV2 toDestinationSite(net.colt.sdwan.portal.client.model.bulkapi.BulkCopyRequestSiteResponseV2 bulkCopyRequestSiteResponse) {
        return new BulkCopyRequestSiteResponseV2()
                .siteId(bulkCopyRequestSiteResponse.getSiteId())
                .firewallRuleSetStatus(BulkCopyRuleStatusV1.fromValue(bulkCopyRequestSiteResponse.getFirewallRuleSetStatus().toString()))
                .netflowRuleSetStatus(BulkCopyRuleStatusV1.fromValue(bulkCopyRequestSiteResponse.getNetflowRuleSetStatus().toString()))
                .ddosRuleSetStatus(BulkCopyRuleStatusV1.fromValue(bulkCopyRequestSiteResponse.getDdosRuleSetStatus().toString()))
                .qosRuleSetStatus(bulkCopyRequestSiteResponse.getQosRuleSetStatus() == null ? null :
                        BulkCopyRuleStatusV1.fromValue(bulkCopyRequestSiteResponse.getQosRuleSetStatus().toString()))
                .secureLogForwardingSetStatus(BulkCopyRuleStatusV1.fromValue(bulkCopyRequestSiteResponse.getSecureLogForwardingSetStatus().toString()))
                .snmpRuleSetStatus(bulkCopyRequestSiteResponse.getSnmpRuleSetStatus() == null ? null :
                        BulkCopyRuleStatusV1.fromValue(bulkCopyRequestSiteResponse.getSnmpRuleSetStatus().toString()))
                .dnsProxyRuleSetStatus(bulkCopyRequestSiteResponse.getDnsProxyRuleSetStatus() == null ? null :
                        BulkCopyRuleStatusV1.fromValue(bulkCopyRequestSiteResponse.getDnsProxyRuleSetStatus().toString()))
                .steeringRuleSetStatus(bulkCopyRequestSiteResponse.getSteeringRuleSetStatus() == null ? null :
                        BulkCopyRuleStatusV1.fromValue(bulkCopyRequestSiteResponse.getSteeringRuleSetStatus().toString()))
                .serviceObjectsCopyStatus(Optional.ofNullable(bulkCopyRequestSiteResponse.getServiceObjectsCopyStatus())
                        .map(status -> BulkCopyRuleStatusV1.fromValue(status.toString()))
                        .orElse(null))
                .addressObjectsCopyStatus(Optional.ofNullable(bulkCopyRequestSiteResponse.getAddressObjectsCopyStatus())
                        .map(status -> BulkCopyRuleStatusV1.fromValue(status.toString()))
                        .orElse(null))
                .addressGroupObjectsCopyStatus(Optional.ofNullable(bulkCopyRequestSiteResponse.getAddressGroupObjectsCopyStatus())
                        .map(status -> BulkCopyRuleStatusV1.fromValue(status.toString()))
                        .orElse(null))
                .urlCategoryObjectsCopyStatus(Optional.ofNullable(bulkCopyRequestSiteResponse.getUrlCategoryObjectsCopyStatus())
                        .map(status -> BulkCopyRuleStatusV1.fromValue(status.toString()))
                        .orElse(null));
    }

    public BulkCopyRequestRequestV2 mapBulkApiRequest(UserAuth authUser, String networkId, net.colt.sdwan.portal.model.BulkCopyRequestRequestV2 bulkCopyRequestRequest) {
        return new BulkCopyRequestRequestV2()
                .userEmail(authUser.getUsername())
                .networkId(networkId)
                .sourceSiteId(bulkCopyRequestRequest.getSourceSiteId())
                .destinationSites(mapBulkApiDestinationSites(bulkCopyRequestRequest.getDestinationSites()))
                .firewallRuleSetId(bulkCopyRequestRequest.getFirewallRuleSetId())
                .netflowRuleSetId(bulkCopyRequestRequest.getNetflowRuleSetId())
                .ddosRuleSetId(bulkCopyRequestRequest.getDdosRuleSetId())
                .qosRuleSetId(bulkCopyRequestRequest.getQosRuleSetId())
                .secureLogForwardingSetId(bulkCopyRequestRequest.getSecureLogForwardingSetId())
                .snmpRuleSetId(bulkCopyRequestRequest.getSnmpRuleSetId())
                .dnsProxyRuleSetId(bulkCopyRequestRequest.getDnsProxyRuleSetId())
                .steeringRuleSetId(bulkCopyRequestRequest.getSteeringRuleSetId())
                .copyServiceObjectsFlag(bulkCopyRequestRequest.getCopyServiceObjectsFlag())
                .copyAddressObjectsFlag(bulkCopyRequestRequest.getCopyAddressObjectsFlag())
                .copyAddressGroupObjectsFlag(bulkCopyRequestRequest.getCopyAddressGroupObjectsFlag())
                .copyUrlCategoryObjectsFlag(bulkCopyRequestRequest.getCopyUrlCategoryObjectsFlag());
    }

    private List<BulkCopyRequestSiteIdRequestV1> mapBulkApiDestinationSites(List<net.colt.sdwan.portal.model.BulkCopyRequestSiteIdRequestV1> destinationSites) {
        return destinationSites.stream()
                .map(siteRequest -> new BulkCopyRequestSiteIdRequestV1().siteId(siteRequest.getSiteId()))
                .toList();
    }
}
