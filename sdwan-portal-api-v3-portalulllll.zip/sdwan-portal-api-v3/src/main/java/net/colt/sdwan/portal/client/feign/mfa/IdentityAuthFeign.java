package net.colt.sdwan.portal.client.feign.mfa;

import net.colt.sdwan.portal.generated.identityaccess.controllers.AuthApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "identityAuthClient",
        url = "${sdwan.identity-access.api.baseurl}",
        configuration = IdentityAccessFeignConfiguration.class
)
public interface IdentityAuthFeign extends AuthApiApi {
}
