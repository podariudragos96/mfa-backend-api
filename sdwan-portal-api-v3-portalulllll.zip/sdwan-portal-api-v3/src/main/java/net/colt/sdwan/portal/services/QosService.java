package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.*;

import java.util.List;

public interface QosService {

    QoSPolicyPortalResponseV1 getQosPoliciesV1(String siteId);

    QoSPolicyPortalResponseV1 getAppQosPoliciesV1(String siteId);

    List<QoSPolicyPortalHistoryResponseV1> getAppQosPoliciesHistoryV2(String siteId);

    QoSPolicyPortalResponseV1 getAppQosPoliciesHistoryByIdV1(String siteId, String ruleSetId);

    CorrelationIdResponseV1 updateQosPoliciesV1(String siteId, QoSPolicyPortalRequestV1 netFlowRequestV1);

    CorrelationIdResponseV1 getQosPoliciesStatsV1(String siteId, String deviceId);

    CorrelationIdResponseV1 getAppQosPoliciesStatsV1(String siteId, String deviceId);

    CorrelationIdResponseV1 getQosMappingStatsV1(String siteId, String deviceId);

    QosBusinessClassesResponseV1 getQosBusinessClassesV1(String siteId);

    CorrelationIdResponseV1 updateQosBusinessClassesV1(String siteId, QoSBusinessClassesRequestV1 qoSBusinessClassesRequestV1);

    QoSInterfacesStatusResponseV1 getQosInterfacesStatusV1(String siteId);

    CorrelationIdResponseV1 updateQosInterfacesStatusV1(String siteId, QoSInterfacesStatusRequestV1 qoSInterfacesStatusRequestV1);

    CorrelationIdResponseV1 getQosInterfacesStats(String siteId, String deviceId, String interfaceId, String type);
}
