package net.colt.sdwan.portal.mappers;

import feign.FeignException;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.portal.client.feign.session.SessionApiFeign;
import net.colt.sdwan.portal.client.helper.TenantClientHelper;
import net.colt.sdwan.portal.client.model.customerapi.TenantResponseV1;
import net.colt.sdwan.portal.client.model.customerapi.UserStatus;
import net.colt.sdwan.portal.enums.COLTRoles;
import net.colt.sdwan.portal.model.CustomerPortalResponseV1;
import net.colt.sdwan.portal.model.SupportedLanguageV1;
import net.colt.sdwan.portal.model.TenantPortalFullResponseV1;
import net.colt.sdwan.portal.model.UserResponseV1;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.Role;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.CustomerService;
import net.colt.sdwan.portal.services.FeatureDetailsService;
import net.colt.sdwan.portal.services.ReleaseNotesService;
import net.colt.sdwan.session.api.generated.model.SdwanSessionResponseV1;
import net.colt.sdwan.session.api.generated.model.UserInfo;
import org.apache.commons.collections4.CollectionUtils;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.Objects.nonNull;
import static net.colt.sdwan.portal.security.TokenFilter.X_AUTH_TOKEN;

@RequiredArgsConstructor
@Component
@Slf4j
public class SdwanUserMapper {

    private final SessionApiFeign sessionApiFeign;
    private final CustomerService customerService;
    private final TenantClientHelper tenantClientHelper;
    private final ReleaseNotesService releaseNotesService;
    private final FeatureDetailsService featureDetailsService;
    private final ModelMapper modelMapper;

    public UserResponseV1 mapToResponse() {
        final UserAuth userAuth = AuthUserHelper.getAuthUser();
        log.debug("Retrieving userAuth details for: {}", userAuth.getUsername());
        final UserResponseV1 userResponse = doMapToResponse(userAuth);

        final RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();

        String token = null;

        if (requestAttributes != null) {
            final HttpServletRequest request = ((ServletRequestAttributes) requestAttributes).getRequest();
            token = request.getHeader(X_AUTH_TOKEN);
        }

        try {
            final SdwanSessionResponseV1 sessionResponseV1 = sessionApiFeign.getSdwanSessionV1(token).getBody();
            if (nonNull(sessionResponseV1)) {
                final UserInfo userInfo = sessionResponseV1.getSession().getUserInfo();
                userResponse.setIsSso(userInfo.getIsSso());
                userResponse.setSsoLogoutUrl(userInfo.getSsoLogoutUrl());
            }
        } catch (FeignException fe) {
            log.error("Error getting userAuth token", fe);
        }

        userResponse.setRoles(mapRoles(userAuth, userResponse));
        userResponse.setFeatures(featureDetailsService.findFeatureFlags(userAuth.getAccessibleTenantIds()));
        return userResponse;
    }

    private UserResponseV1 doMapToResponse(final UserAuth user) {
        UserResponseV1 userResponse = new UserResponseV1();
        userResponse
                .name(user.getName()).title(user.getTitle()).status(mapUserStatus(user.getStatus()))
                .username(user.getUsername()).releaseNotesLastUpdatedDt(releaseNotesService.getLastReleaseDateTime())
                .customisation(mapCustomization(user.getCustomisation()));
        if (nonNull(user.getPreferredLanguage())) {
            userResponse.setPreferredLanguage(SupportedLanguageV1.fromValue(user.getPreferredLanguage().name()));
        }

        List<TenantResponseV1> tenantResponse = tenantClientHelper.findAllByIdList(user.getAccessibleTenantIds());
        userResponse.setTenant(mapTenants(tenantResponse));

        return userResponse;
    }

    private List<TenantPortalFullResponseV1> mapTenants(List<TenantResponseV1> tenantResponse) {
        Map<Integer, CustomerPortalResponseV1> customerById = new HashMap<>();
        return tenantResponse.stream()
                .map(t -> modelMapper.map(t, TenantPortalFullResponseV1.class)
                        .customer(getCustomerById(t.getCustomerId(), customerById)))
                .toList();
    }

    private List<String> mapRoles(UserAuth user, UserResponseV1 userResponse) {
        List<String> roles = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(user.getRoles())) {
            boolean isWhitelabel;
            if (CollectionUtils.isNotEmpty(userResponse.getTenant())) {
                isWhitelabel = userResponse.getTenant().stream()
                        .anyMatch(tenant -> nonNull(tenant.getCustomer())
                                && nonNull(tenant.getCustomer().getIsWhitelabel())
                                && tenant.getCustomer().getIsWhitelabel());
            } else {
                isWhitelabel = false;
            }
            roles = user.getRoles()
                    .stream()
                    .map(Role::getName)
                    .filter(name -> !(COLTRoles.SD_WAN_INSTALL_MANAGER_ROLE.value().equals(name) && isWhitelabel) && name.startsWith("SD-WAN"))
                    .toList();
        }
        return roles;
    }

    private String mapCustomization(String customization) {
        String mappedCustomization = "";
        if (nonNull(customization)) {
            mappedCustomization = customization;
        }
        return mappedCustomization;
    }

    private String mapUserStatus(UserStatus userStatus) {
        String status = "";
        if (nonNull(userStatus)) {
            status = userStatus.name();
        }
        return status;
    }

    private CustomerPortalResponseV1 getCustomerById(Integer customerId, Map<Integer, CustomerPortalResponseV1> customerById) {
        return customerById.computeIfAbsent(customerId, id -> modelMapper.map(customerService.findById(id), CustomerPortalResponseV1.class));
    }
}
