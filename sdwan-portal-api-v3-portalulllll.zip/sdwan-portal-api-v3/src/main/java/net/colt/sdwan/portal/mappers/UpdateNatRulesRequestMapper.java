package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.model.DestinationNatRuleResponse;
import net.colt.sdwan.portal.client.model.NatRuleRequest;
import net.colt.sdwan.portal.client.model.NatRuleSet;
import net.colt.sdwan.portal.client.model.StaticNatRuleResponse;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.util.PortStringSerializer;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Component
public class UpdateNatRulesRequestMapper {

    public NatRuleRequest mapFromClientNatRules(final NatRulesRequestV1 natRulesRequest, final SiteResponseV1 siteResponse) {
        return NatRuleRequest.builder()
                .customerName(siteResponse.getNetworkId())
                .siteId(siteResponse.getId().toString())
                .natRuleSet(mapFromClientNatRuleSetList(natRulesRequest.getRuleSet()))
                .build();
    }

    private List<NatRuleSet> mapFromClientNatRuleSetList(final List<NatRuleSetRequestV1> natRuleSetResponses) {
        List<NatRuleSet> natRuleSets = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(natRuleSetResponses)) {
            natRuleSets = natRuleSetResponses.stream().map(this::mapFromClientNatRuleSet).toList();
        }
        return natRuleSets;
    }

    private NatRuleSet mapFromClientNatRuleSet(final NatRuleSetRequestV1 natRuleSetResponse) {
        return NatRuleSet.builder()
                .lastUpdated(LocalDateTime.now(Clock.systemUTC()).toString())
                .updatedBy(AuthUserHelper.getAuthUser().getUsername())
                .description(natRuleSetResponse.getDescription())
                .staticNatRuleResponseList(mapFromClientStaticNatRuleList(natRuleSetResponse.getStaticNatRules()))
                .destinationNatRuleResponseList(mapFromClientDestinationNatRuleList(natRuleSetResponse.getDestinationNatRules()))
                .build();
    }

    private List<StaticNatRuleResponse> mapFromClientStaticNatRuleList(final List<net.colt.sdwan.portal.model.StaticNatRuleRequestV1> staticNatRuleResponses) {
        List<StaticNatRuleResponse> staticNatRuleForRequest = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(staticNatRuleResponses)) {
            staticNatRuleForRequest = staticNatRuleResponses.stream().map(this::mapFromClientStaticNatRule).toList();
        }
        return staticNatRuleForRequest;
    }

    private StaticNatRuleResponse mapFromClientStaticNatRule(
            final StaticNatRuleRequestV1 staticNatRuleResponse) {
        StaticNatRuleResponse updateNatRuleResponse = StaticNatRuleResponse.builder()
                .name(staticNatRuleResponse.getName())
                .description(staticNatRuleResponse.getDescription())
                .sourceNetwork(staticNatRuleResponse.getSourceNetwork())
                .destinationNetwork(staticNatRuleResponse.getDestinationNetwork())
                .editable(true)
                .precedence(staticNatRuleResponse.getPrecedence())
                .privateIps(Collections.singletonList(staticNatRuleResponse.getIp().getLan()))
                .natIps(Collections.singletonList(staticNatRuleResponse.getIp().getNat()))
                .build();

        if (Objects.nonNull(staticNatRuleResponse.getIp().getRestrictedRemote())) {
            updateNatRuleResponse.setRestrictedRemoteIps(Collections.singletonList(staticNatRuleResponse.getIp().getRestrictedRemote()));
        } else {
            updateNatRuleResponse.setRestrictedRemoteIps(new ArrayList<>());
        }

        return updateNatRuleResponse;
    }

    private List<DestinationNatRuleResponse> mapFromClientDestinationNatRuleList(final List<net.colt.sdwan.portal.model.DestinationNatRuleRequestV1> destinationNatRuleResponseList) {
        List<DestinationNatRuleResponse> destinationNatRuleResponses = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(destinationNatRuleResponseList)) {
            destinationNatRuleResponses = destinationNatRuleResponseList.stream()
                    .map(this::mapFromClientDestinationNatRule)
                    .toList();
        }
        return destinationNatRuleResponses;
    }

    private DestinationNatRuleResponse mapFromClientDestinationNatRule(final DestinationNatRuleRequestV1 destinationNatRuleResponse) {
        return DestinationNatRuleResponse.builder()
                .name(destinationNatRuleResponse.getName())
                .description(destinationNatRuleResponse.getDescription())
                .editable(true)
                .sourceNetwork(destinationNatRuleResponse.getSourceNetwork())
                .destinationNetwork(destinationNatRuleResponse.getDestinationNetwork())
                .privateIps(mapLanIps(destinationNatRuleResponse.getIp()))
                .natIps(mapNatIps(destinationNatRuleResponse.getIp()))
                .privatePort(mapLanPort(destinationNatRuleResponse.getPort()))
                .publicPort(mapNatPort(destinationNatRuleResponse.getPort()))
                .precedence(destinationNatRuleResponse.getPrecedence())
                .protocol(mapProtocol(destinationNatRuleResponse.getProtocol()))
                .build();
    }

    private List<String> mapNatIps(DestinationNatIPResponseV1 ip) {
        List<String> ips = new ArrayList<>();
        if (Objects.nonNull(ip)) {
            ips.add(ip.getNat());
        }
        return ips;
    }

    private List<String> mapLanIps(DestinationNatIPResponseV1 ip) {
        List<String> ips = new ArrayList<>();
        if (Objects.nonNull(ip)) {
            ips.add(ip.getLan());
        }
        return ips;
    }

    private String mapLanPort(DestinationNatPortResponseV1 port) {
        String portStr = "";
        if (Objects.nonNull(port)) {
            portStr = PortStringSerializer.toRangeString(port.getLan());
        }
        return portStr;
    }

    private String mapNatPort(DestinationNatPortResponseV1 port) {
        String portStr = "";
        if (Objects.nonNull(port)) {
            portStr = PortStringSerializer.toRangeString(port.getNat());
        }
        return portStr;
    }

    private String mapProtocol(final DestinationNatRuleRequestV1.ProtocolEnum protocolEnum) {
        String protocol = "";
        if (!protocolEnum.equals(DestinationNatRuleRequestV1.ProtocolEnum.ANY)) {
            protocol = protocolEnum.name();
        }
        return protocol;
    }
}
