package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.InterfaceResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.generated.model.service.SiteTypeV1;
import net.colt.sdwan.portal.client.PolicyApiClient;
import net.colt.sdwan.portal.client.feign.qos.QosApiFeign;
import net.colt.sdwan.portal.enums.QosInterfacesCommandType;
import net.colt.sdwan.portal.mappers.QosMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.DeviceService;
import net.colt.sdwan.portal.services.InterfaceService;
import net.colt.sdwan.portal.services.QosService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.*;
import net.colt.sdwan.portal.validator.access.QosFeatureAccessValidator;
import net.colt.sdwan.qos.api.generated.model.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

import static java.util.Objects.nonNull;
import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.model.OnGoingActionV2.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class QosServiceImpl implements QosService {

    public static final String QOS_BUSINESS_CLASSES_REQUEST_NOT_ALLOWED = "This operation is not allowed since the site is mpls app qos enabled";
    public static final String QOS_NOT_ALLOWED_FOR_DEDICATED_GATEWAY_SITE = "Not Allowed for Dedicated Gateway Site";

    private final SitesService sitesService;
    private final DeviceService deviceService;
    private final InterfaceService interfaceService;
    private final PolicyApiClient policyApiClient;
    private final SiteResponseValidator siteResponseValidator;
    private final QosApiFeign qosApiFeign;
    private final QosPoliciesRequestValidator qosPoliciesRequestValidator;
    private final QosBusinessClassesRequestV1Validator qosBusinessClassesRequestV1Validator;
    private final QoSInterfacesStatusRequestV1Validator qoSInterfacesStatusRequestV1Validator;
    private final QosFeatureAccessValidator qosFeatureAccessValidator;
    private final QosMapper qosMapper;
    private final ModelMapper modelMapper;
    private final ResponseEntityValidator responseEntityValidator;

    @Override
    public QoSPolicyPortalResponseV1 getQosPoliciesV1(String siteId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        qosFeatureAccessValidator.validateAccess(siteResponse);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        ResponseEntity<QoSPolicyApiResponseV1> responseEntity = qosApiFeign.getQosPoliciesV1(
                siteResponse.getId().intValue(), siteResponse.getNetworkId());
        responseEntityValidator.checkResponseEntity(responseEntity, "qos");
        return qosMapper.mapQoSPolicyResponseV1(responseEntity.getBody());
    }

    @Override
    public QoSPolicyPortalResponseV1 getAppQosPoliciesV1(String siteId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        qosFeatureAccessValidator.validateAccess(siteResponse);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        ResponseEntity<QoSPolicyApiResponseV1> responseEntity = qosApiFeign.getAppQosPoliciesV1(
                siteResponse.getId().intValue(), siteResponse.getNetworkId());
        responseEntityValidator.checkResponseEntity(responseEntity, "qos");
        return qosMapper.mapQoSPolicyResponseV1(responseEntity.getBody());
    }

    @Override
    public List<QoSPolicyPortalHistoryResponseV1> getAppQosPoliciesHistoryV2(String siteId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        qosFeatureAccessValidator.validateAccess(siteResponse);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        ResponseEntity<List<QoSPolicyApiHistoryResponseV1>> responseEntity = qosApiFeign.getAppQosHistoryV2(
                siteResponse.getId().toString(), siteResponse.getNetworkId());
        responseEntityValidator.checkResponseEntity(responseEntity, "qos");
        List<QoSPolicyPortalHistoryResponseV1> qosResponses = new ArrayList<>();
        if (responseEntity.hasBody()) {
            return Arrays.asList(modelMapper.map((responseEntity.getBody()), QoSPolicyPortalHistoryResponseV1[].class));
        }
        return qosResponses;
    }

    @Override
    public QoSPolicyPortalResponseV1 getAppQosPoliciesHistoryByIdV1(String siteId, String ruleSetId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        qosFeatureAccessValidator.validateAccess(siteResponse);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        ResponseEntity<QoSPolicyApiResponseV1> responseEntity = qosApiFeign.getAppQosHistoryByIdV1(
                siteResponse.getId().toString(), siteResponse.getNetworkId(), ruleSetId);
        responseEntityValidator.checkResponseEntity(responseEntity, "qos");
        QoSPolicyPortalResponseV1 qosResponses = new QoSPolicyPortalResponseV1();
        if (responseEntity.hasBody()) {
            return modelMapper.map((responseEntity.getBody()), QoSPolicyPortalResponseV1.class);
        }
        return qosResponses;
    }

    @Override
    public CorrelationIdResponseV1 updateQosPoliciesV1(String siteId, QoSPolicyPortalRequestV1 qoSPolicyRequestV1) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        SiteTypeV1 siteType = SiteTypeV1.fromValue(siteResponse.getSiteType().getValue());
        if (siteType.equals(SiteTypeV1.DEDICATED_GATEWAY)) {
            throw new SdwanBadRequestException(QOS_NOT_ALLOWED_FOR_DEDICATED_GATEWAY_SITE);
        }
        qosFeatureAccessValidator.validateAccess(siteResponse);

        // Validation
        qosPoliciesRequestValidator.validateQoSRequest(qoSPolicyRequestV1.getQosRules(), siteResponse);

        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        List<String> deviceNames = new ArrayList<>();
        Map<String, String> interfaceZone = new HashMap<>();
        if (CollectionUtils.isNotEmpty(siteResponse.getDevices())) {
            siteResponse.getDevices().forEach(device -> {
                deviceNames.add(device.getResourceName());
                device.getInterfaces()
                        .forEach(interfaceResponse ->
                                interfaceZone.put(
                                        nonNull(interfaceResponse.getNetwork()) ?
                                                interfaceResponse.getNetwork()
                                                : interfaceResponse.getFriendlyName()
                                        , interfaceResponse.getZone()));
            });
        }
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);
        siteResponseValidator.hasValidSiteAndTenantValues(siteResponse);
        UserAuth userAuth = AuthUserHelper.getAuthUser();
        QoSPolicyApiRequestV1 qoSPolicyApiRequestV1 = modelMapper.map(qoSPolicyRequestV1, QoSPolicyApiRequestV1.class);
        qoSPolicyApiRequestV1.updatedBy(userAuth.getUsername());
        qoSPolicyApiRequestV1.updatedDt(LocalDateTime.now());
        qoSPolicyApiRequestV1.getQosRules().forEach(qoSPolicyRuleRequestV1 -> {
            if (StringUtils.isNotEmpty(qoSPolicyRuleRequestV1.getVpn())) {
                qoSPolicyRuleRequestV1.setZone(interfaceZone.get(qoSPolicyRuleRequestV1.getVpn()));
            }
        });

        try {
            sitesService.updateOngoingAction(siteId, MODIFYING_QOS_RULES);
            ResponseEntity<Void> responseEntity = qosApiFeign.updateAppQosPoliciesV1(
                    siteResponse.getId().intValue(), siteResponse.getNetworkId(),
                    userAuth.getUsername(), deviceNames, qoSPolicyApiRequestV1);
            responseEntityValidator.checkResponseEntity(responseEntity, "qos");
            return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
        } catch (Exception ex) {
            log.error("Update Qos Policy failed for site {}, because {}", siteId, ex.getMessage());
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }
    }

    @Override
    public CorrelationIdResponseV1 getQosPoliciesStatsV1(String siteId, String deviceId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        qosFeatureAccessValidator.validateAccess(siteResponse);
        net.colt.sdwan.generated.model.service.DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        ResponseEntity<Void> responseEntity = qosApiFeign.getQosPoliciesStatsV1(siteResponse.getNetworkId(), deviceResponse.getManagementIpv4(), AuthUserHelper.getAuthUser().getUsername());
        responseEntityValidator.checkResponseEntity(responseEntity, "qos");
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    @Override
    public CorrelationIdResponseV1 getAppQosPoliciesStatsV1(String siteId, String deviceId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        qosFeatureAccessValidator.validateAccess(siteResponse);
        net.colt.sdwan.generated.model.service.DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        ResponseEntity<Void> responseEntity = qosApiFeign.getAppQosPoliciesStatsV1(siteResponse.getNetworkId(), deviceResponse.getManagementIpv4(), AuthUserHelper.getAuthUser().getUsername());
        responseEntityValidator.checkResponseEntity(responseEntity, "qos");
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    @Override
    public CorrelationIdResponseV1 getQosMappingStatsV1(String siteId, String deviceId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        qosFeatureAccessValidator.validateAccess(siteResponse);
        net.colt.sdwan.generated.model.service.DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        ResponseEntity<Void> responseEntity = qosApiFeign.getQosMappingStatsV1(siteResponse.getNetworkId(), deviceResponse.getManagementIpv4(), AuthUserHelper.getAuthUser().getUsername());
        responseEntityValidator.checkResponseEntity(responseEntity, "qos");
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    /**
     * Execute Qos Interfaces command
     *
     * @param siteId      site to consider
     * @param deviceId    device to consider
     * @param interfaceId interface to consider
     * @returns CorrelationIdResponseV1 that will be useful when receiving the event with the response to this request
     */
    @Override
    public CorrelationIdResponseV1 getQosInterfacesStats(String siteId, String deviceId, String interfaceId, String type) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        qosFeatureAccessValidator.validateAccess(siteResponse);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        InterfaceResponseV1 interfaceResponse = interfaceService.getByDeviceIdAndInterfaceIdAndVerify(deviceId, interfaceId);

        ResponseEntity<?> responseEntity = null;
        if (!QosInterfacesCommandType.SUMMARY.getValue().equals(type)) {
            responseEntity = qosApiFeign.getQosInterfaceStatsV1(siteResponse.getNetworkId(), interfaceResponse.getName(), type, deviceResponse.getManagementIpv4(), AuthUserHelper.getAuthUser().getUsername());
        } else {
            responseEntity = policyApiClient.getDynamicStats(deviceResponse, siteResponse, interfaceResponse, "qos");
        }
        responseEntityValidator.checkResponseEntity(responseEntity, "qos");

        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    @Override
    public QosBusinessClassesResponseV1 getQosBusinessClassesV1(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        qosFeatureAccessValidator.validateAccess(siteResponse);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        final ResponseEntity<QosBusinessClassesApiResponseV1> responseEntity = qosApiFeign.getQosBusinessClassesV1(
                siteResponse.getId().intValue(), siteResponse.getNetworkId());
        responseEntityValidator.checkResponseEntity(responseEntity, "qos");
        return qosMapper.from(responseEntity.getBody(), siteResponse);
    }

    @Override
    public CorrelationIdResponseV1 updateQosBusinessClassesV1(String siteId, QoSBusinessClassesRequestV1 qoSBusinessClassesRequestV1) {

        // Site access permissions
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        qosFeatureAccessValidator.validateAccess(siteResponse);
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);

        // Site validations
        final SiteTypeV1 siteType = siteResponse.getSiteType();
        if (siteType.equals(SiteTypeV1.DEDICATED_GATEWAY)) {
            throw new SdwanBadRequestException(QOS_NOT_ALLOWED_FOR_DEDICATED_GATEWAY_SITE);
        }

        // Request validations
        validateQosBusinessClassesRequestAllowance(siteResponse);
        qosBusinessClassesRequestV1Validator.validateQosBusinessClassesRequestV1(qoSBusinessClassesRequestV1);

        // Operation execution
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        QosBusinessClassesApiRequestV1 qosBusinessClassesApiRequestV1 = qosMapper.from(qoSBusinessClassesRequestV1);
        try {
            sitesService.updateOngoingAction(siteId, MODIFYING_QOS_BUSINESS_CLASSES);
            ResponseEntity<Void> responseEntity = qosApiFeign.updateQosBusinessClassesV1(
                    siteResponse.getId().intValue(), siteResponse.getNetworkId(),
                    AuthUserHelper.getAuthUser().getUsername(), sitesService.getDeviceNamesFromSiteResponse(siteResponse),
                    qosBusinessClassesApiRequestV1);
            responseEntityValidator.checkResponseEntity(responseEntity, "qos");
            return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
        } catch (Exception ex) {
            log.error("Update Qos Business Classes failed for site {}, because {}", siteId, ex.getMessage());
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }

    }

    @Override
    public QoSInterfacesStatusResponseV1 getQosInterfacesStatusV1(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        qosFeatureAccessValidator.validateAccess(siteResponse);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        final ResponseEntity<QoSInterfacesStatusResponseApiV1> qosInterfacesStatus = qosApiFeign.getQosInterfacesStatusV1(siteResponse.getNetworkId(), siteId);
        responseEntityValidator.checkResponseEntity(qosInterfacesStatus, "qos");
        return qosMapper.from(qosInterfacesStatus.getBody());
    }

    @Override
    public CorrelationIdResponseV1 updateQosInterfacesStatusV1(String siteId, QoSInterfacesStatusRequestV1 qoSInterfacesStatusRequestV1) {
        // Site access permissions
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        qosFeatureAccessValidator.validateAccess(siteResponse);
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);

        // Site validations
        final SiteTypeV1 siteType = siteResponse.getSiteType();
        if (siteType.equals(SiteTypeV1.DEDICATED_GATEWAY)) {
            throw new SdwanBadRequestException(QOS_NOT_ALLOWED_FOR_DEDICATED_GATEWAY_SITE);
        }

        // Request validations
        qoSInterfacesStatusRequestV1Validator.validateInterfacesStatusRequestV1(siteResponse, qoSInterfacesStatusRequestV1);

        // Operation execution
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        final QoSInterfacesStatusRequestApiV1 qoSInterfacesStatusRequestApi = qosMapper.from(qoSInterfacesStatusRequestV1);
        try {
            sitesService.updateOngoingAction(siteId, MODIFYING_QOS_INTERFACES_STATUS);
            final ResponseEntity<Void> responseEntity = qosApiFeign.updateQosInterfacesStatusV1(
                    siteResponse.getNetworkId(),
                    siteResponse.getId().toString(),
                    AuthUserHelper.getAuthUser().getUsername(),
                    sitesService.getDeviceNamesFromSiteResponse(siteResponse),
                    qoSInterfacesStatusRequestApi);
            responseEntityValidator.checkResponseEntity(responseEntity, "qos");
            return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
        } catch (Exception ex) {
            log.error("Update Qos Interface Status failed for site {}, because {}", siteId, ex.getMessage());
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }
    }

    private void validateQosBusinessClassesRequestAllowance(SiteResponseV1 siteResponse) {
        if (Boolean.TRUE.equals(siteResponse.getSiteFeatures().getQos().getMplsQosEnabled())) {
            throw new SdwanBadRequestException(QOS_BUSINESS_CLASSES_REQUEST_NOT_ALLOWED);
        }
    }
}
