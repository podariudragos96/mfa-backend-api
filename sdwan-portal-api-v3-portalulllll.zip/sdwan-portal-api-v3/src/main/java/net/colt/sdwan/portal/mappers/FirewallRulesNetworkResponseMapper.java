package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.client.model.FirewallRulesNetworkApiResponse;
import net.colt.sdwan.portal.client.model.NetworkApiData;
import net.colt.sdwan.portal.model.FirewallRulesNetworkResponseV1;
import org.springframework.stereotype.Component;

import java.util.List;

import static net.colt.sdwan.portal.model.FirewallRulesActionV1.ALLOW;

@Component
public class FirewallRulesNetworkResponseMapper {

    public List<FirewallRulesNetworkResponseV1> mapFromNetworkApiResponse(final List<FirewallRulesNetworkApiResponse> networkApiResponses) {
        return networkApiResponses
                .stream()
                .map(FirewallRulesNetworkApiResponse::getData)
                .flatMap(List::stream)
                .map(NetworkApiData::getData)
                .flatMap(List::stream)
                .map(data -> new FirewallRulesNetworkResponseV1(data.getName(), ALLOW))
                .toList();
    }
}
