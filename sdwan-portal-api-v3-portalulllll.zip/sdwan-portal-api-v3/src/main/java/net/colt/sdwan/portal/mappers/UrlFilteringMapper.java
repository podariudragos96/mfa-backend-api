package net.colt.sdwan.portal.mappers;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.portal.model.URLFilteringProfileResponseV1;
import net.colt.sdwan.portal.model.URLFilteringProfileV1;
import net.colt.sdwan.security.api.generated.model.UrlFilteringProfileApiV1;
import net.colt.sdwan.security.api.generated.model.UrlFilteringProfilesApiRequestV1;
import net.colt.sdwan.security.api.generated.model.UrlFilteringProfilesApiResponseV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
@Component
@Slf4j
public class UrlFilteringMapper extends CommonMapper {

    private final ModelMapper modelMapper;

    public URLFilteringProfileResponseV1 from(UrlFilteringProfilesApiResponseV1 urlFilteringProfileResponseV1) {
        return modelMapper.map(urlFilteringProfileResponseV1, URLFilteringProfileResponseV1.class);
    }

    public UrlFilteringProfilesApiRequestV1 from(List<URLFilteringProfileV1> urLFilteringProfileV1) {
        final UrlFilteringProfilesApiRequestV1 urlFilteringProfilesApiRequest = new UrlFilteringProfilesApiRequestV1();

        if (!urLFilteringProfileV1.isEmpty()) {
            urLFilteringProfileV1.stream()
                    .map(urlFilteringProfile -> modelMapper.map(urlFilteringProfile, UrlFilteringProfileApiV1.class))
                    .forEach(urlFilteringProfilesApiRequest::addUrlFilteringProfilesItem);
        }
        return urlFilteringProfilesApiRequest;
    }
}
