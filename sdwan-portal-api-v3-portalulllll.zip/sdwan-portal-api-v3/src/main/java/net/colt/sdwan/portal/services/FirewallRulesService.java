package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.*;

import java.time.LocalDateTime;
import java.util.List;


public interface FirewallRulesService {
    List<FirewallRuleLogsResponseV1> getFirewallRulesLogsBySiteIdAndRuleName(
            String siteId, final String ruleName, final LocalDateTime startDate, final LocalDateTime endDate);

    CorrelationIdResponseV1 updateFirewallRulesBySiteIdV3(
            final String siteId, final FirewallRulesRequestV2 firewallRulesRequest);

    FirewallRuleSetResponseV2 getFirewallRulesBySiteIdV3(String siteId);

    List<FirewallRuleHistoryResponseV1> getFirewallRulesHistoryBySiteIdV1(final String siteId);

    FirewallRuleSetResponseV2 getFirewallRulesHistoryBySiteIdAndRuleSetIdV2(final String siteId, final String ruleSetId);
}