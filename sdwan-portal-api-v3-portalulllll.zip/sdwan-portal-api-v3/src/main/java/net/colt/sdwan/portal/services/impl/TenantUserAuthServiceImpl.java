package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanUnauthorizedException;
import net.colt.sdwan.portal.client.feign.customer.AuthenticateFeign;
import net.colt.sdwan.portal.client.model.customerapi.*;
import net.colt.sdwan.portal.mappers.UpdateUserRequestMapper;
import net.colt.sdwan.portal.services.TenantUserAuthService;
import net.colt.sdwan.portal.services.UserService;
import net.colt.sdwan.portal.util.TenantUsernameUtils;
import net.colt.sdwan.portal.validator.NovitasAccessRoleValidator;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@RequiredArgsConstructor
@Service
@Slf4j
public class TenantUserAuthServiceImpl implements TenantUserAuthService {

    private final ModelMapper modelMapper;
    private final AuthenticateFeign authenticateFeign;
    private final UserService userService;
    private final UpdateUserRequestMapper updateUserRequestMapper;

    @Override
    public TenantUserApiV1 authenticate(String domain, String username, String password) {
        final AuthenticateRequestV1 request = new AuthenticateRequestV1()
                .username(TenantUsernameUtils.extractUsernameIfRequired(username, domain))
                .password(password);

        final ResponseEntity<TenantUserApiV1> response = authenticateFeign.authenticateV1(domain, request);

        if (Objects.isNull(response) || !HttpStatus.OK.equals(response.getStatusCode())) {
            log.debug("Unauthorized attempt to access resources domain {}, password {}", domain, username);
            throw new SdwanUnauthorizedException("UNAUTHORIZED: domain " + domain + " and username " + username);
        }

        return response.getBody();
    }

    /**
     * Step 1. Authenticate user with TenantUser (domain, user, password)
     * Step 2. Find Tenant from customer-api from tenantId and username
     * Step 3. Check if the user has the needed roles to access resources
     * Step 4. Handle the user customer creation/update with tenant access permission
     *
     * @param domain   domain
     * @param username credentials
     * @param password credentials
     * @return the User if valid
     */
    @Override
    public UserResponseV3 doAuthentication(String domain, String username, String password) {
        UserResponseV3 user = null;
        // throw error if authentication failed
        final TenantUserApiV1 tenantUser = authenticate(domain, username, password);
        // if success find the user
        if (Objects.nonNull(tenantUser)) {
            // generate username to avoid username collision with colt online
            String generatedUsername = TenantUsernameUtils.generateUsername(username, domain);
            if (NovitasAccessRoleValidator.hasNovitasAccessRole(tenantUser)) {
                user = userService.getUserByUsernameAndDomain(generatedUsername, domain);

                if (Objects.nonNull(user)) {
                    updateUserInfo(user, Collections.singletonList(tenantUser.getTenantId()), tenantUser.getRoles());
                } else {
                    log.debug("Create new sdwan user: {}", generatedUsername);
                    user = userService.createUser(generatedUsername, tenantUser, domain, Collections.singletonList(tenantUser.getTenantId()));
                }
            } else {
                log.debug("Forbidden attempt to access resources: {}", generatedUsername);
                throw new AccessDeniedException("NO_NOVITAS_ACCESS_ROLE");
            }
        }

        return user;
    }

    private void updateUserInfo(final UserResponseV3 user, List<Integer> tenantIds, List<TenantRole> roles) {
        user.setAccessibleTenantIds(tenantIds);
        user.roles(roles.stream().map(TenantRole::getValue).toList());
        user.setLastLoggedInDt(LocalDateTime.now());

        final UpdateUserRequestV3 request = updateUserRequestMapper.mapFromResponse(user);
        // accessible tenant ids from accessibleTenantIds directly
        request.setOcns(null);
        userService.save(user.getUserId(), request);
    }

}
