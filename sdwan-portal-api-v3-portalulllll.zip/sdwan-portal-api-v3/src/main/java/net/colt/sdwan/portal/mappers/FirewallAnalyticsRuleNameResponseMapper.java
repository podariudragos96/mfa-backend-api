package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.client.model.FirewallRulesNamesData;
import net.colt.sdwan.portal.client.model.FirewallRulesNamesNetworkApiResponse;
import net.colt.sdwan.portal.model.FirewallAnalyticsDataResponseV1;
import net.colt.sdwan.portal.model.FirewallAnalyticsLabelV1;
import net.colt.sdwan.portal.model.FirewallAnalyticsMetricV1;
import net.colt.sdwan.portal.model.FirewallAnalyticsRuleNameResponseV1;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class FirewallAnalyticsRuleNameResponseMapper {

    public List<FirewallAnalyticsRuleNameResponseV1> mapFromResponseList(final FirewallRulesNamesNetworkApiResponse networkApiResponse) {
        return networkApiResponse.getData().stream().map(this::mapFromResponse).toList();
    }

    private FirewallAnalyticsRuleNameResponseV1 mapFromResponse(final FirewallRulesNamesData data) {
        return new FirewallAnalyticsRuleNameResponseV1()
                .data(mapData(data.getData()))
                .label(mapLabel(data.getLabel()))
                .metric(mapMetric(data.getMetric()));
    }

    private List<FirewallAnalyticsDataResponseV1> mapData(List<List<Long>> data) {
        return data.stream().map(dataItem -> new FirewallAnalyticsDataResponseV1().time(dataItem.get(0)).value(dataItem.get(1).doubleValue())).toList();
    }

    private FirewallAnalyticsLabelV1 mapLabel(final String label) {
        FirewallAnalyticsLabelV1 labelV1 = null;
        if (StringUtils.isNotEmpty(label)) {
            labelV1 = FirewallAnalyticsLabelV1.fromValue(label.toUpperCase());
        }
        return labelV1;
    }

    private FirewallAnalyticsMetricV1 mapMetric(final String metric) {
        FirewallAnalyticsMetricV1 labelV1 = null;
        if (StringUtils.isNotEmpty(metric)) {
            labelV1 = FirewallAnalyticsMetricV1.fromValue(metric.toUpperCase());
        }
        return labelV1;
    }
}
