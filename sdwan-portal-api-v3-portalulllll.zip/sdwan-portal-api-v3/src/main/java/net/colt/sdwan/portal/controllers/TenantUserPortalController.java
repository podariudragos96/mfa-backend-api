package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.TenantUserPortalApiApi;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.TenantUserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;

@RequiredArgsConstructor
@Controller
@PreAuthorize("hasAnyAuthority('SD-WANRWWLTenantRole')")
public class TenantUserPortalController implements TenantUserPortalApiApi {

    private final TenantUserService tenantUserService;

    @Override
    @SDWanAsyncMethod("/v1/tenant_user/{tenant_user_id}")
    public ResponseEntity<Void> editTenantUserV1(Integer tenantUserId, EditTenantUserPortalRequestV1 editTenantUserPortalRequestV1) {
        tenantUserService.editTenantUser(tenantUserId, editTenantUserPortalRequestV1);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<TenantUsersPortalResponseV1> getTenantUsersV1(TenantUsersCriteriaV1 criteria, Integer pageNumber, Integer pageSize) {
        return ResponseEntity.ok(tenantUserService.getTenantUsers(criteria,
                pageNumber, pageSize));
    }

    @Override
    @SDWanAsyncMethod("/v1/tenant_user/{tenant_user_id}")
    public ResponseEntity<Void> deleteTenantUserByIdV1(Integer tenantUserId) {
        tenantUserService.deleteTenantUserById(tenantUserId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    @SDWanAsyncMethod("/v1/tenant_user/{tenant_id}")
    public ResponseEntity<CreateTenantUserPortalResponseV1> addTenantUserV1(Integer tenantId, CreateTenantUserPortalRequestV1 createTenantUserPortalRequestV1) {
        return new ResponseEntity<>(tenantUserService.addTenantUser(tenantId, createTenantUserPortalRequestV1), HttpStatus.CREATED);
    }

}
