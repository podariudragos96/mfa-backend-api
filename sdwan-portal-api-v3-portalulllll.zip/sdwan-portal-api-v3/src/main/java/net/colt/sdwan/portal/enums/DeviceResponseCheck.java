package net.colt.sdwan.portal.enums;

public enum DeviceResponseCheck {
    DEVICE_NOT_FOUND("Device Not Found."),
    DEVICE_DETAILS_MISSING("Device Details Missing."),
    DEVICE_NOT_FOUND_WITH_NEXTGEN_FW("Device Not Found with NextGen Firewall."),
    CUSTOMER_ID_NOT_FOUND("Customer ID Not Found."),
    POLICY_CALL_FAILED("Policy Call Failed."),
    VALID("Valid.");

    private final String value;

    DeviceResponseCheck(String v) {
        value = v;
    }

    public String value() {
        return value;
    }
}
