package net.colt.sdwan.portal.database.entities;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "COUNTRY_DETAILS")
public class CountryDetails {

    @EmbeddedId
    private CountryLanguageId countryLanguageId;

    @Column(name = "COUNTRY_NAME")
    private String countryName;

    @Column(name = "LANGUAGE_NAME")
    private String languageName;

    @Column(name = "DEFAULT_CODE", columnDefinition = "varchar(5) default 'en'")
    private String defaultCode;

    /**
     * @return the countryLanguageId
     */
    public CountryLanguageId getCountryLanguageId() {
        return countryLanguageId;
    }

    /**
     * @param countryLanguageId the countryLanguageId to set
     */
    public void setCountryLanguageId(CountryLanguageId countryLanguageId) {
        this.countryLanguageId = countryLanguageId;
    }

    /**
     * @return the languageName
     */
    public String getLanguageName() {
        return languageName;
    }

    /**
     * @param languageName the languageName to set
     */
    public void setLanguageName(String languageName) {
        this.languageName = languageName;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getDefaultCode() {
        return defaultCode;
    }

    public void setDefaultCode(String defaultCode) {
        this.defaultCode = defaultCode;
    }
}
