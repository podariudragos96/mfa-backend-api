package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.client.model.ApplicationAnalytics;
import net.colt.sdwan.portal.client.model.NameData;
import net.colt.sdwan.portal.model.InterfaceApplicationAnalyticsResponseV1;
import net.colt.sdwan.portal.model.InterfaceApplicationAnalyticsTimeSeriesDataResponseV1;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ApplicationAnalyticsMapper extends CommonMapper {

    public InterfaceApplicationAnalyticsResponseV1 mapToResponse(final ApplicationAnalytics applicationAnalytics) {
        return new InterfaceApplicationAnalyticsResponseV1()
                .bwRx(mapToAnalyticsTimeSeries(applicationAnalytics.getBwRx()))
                .bwTx(mapToAnalyticsTimeSeries(applicationAnalytics.getBwTx()))
                .sessions(mapToAnalyticsTimeSeries(applicationAnalytics.getSessions()))
                .volumeRx(mapToAnalyticsTimeSeries(applicationAnalytics.getVolumeRx()))
                .volumeTx(mapToAnalyticsTimeSeries(applicationAnalytics.getVolumeTx()));
    }

    private List<InterfaceApplicationAnalyticsTimeSeriesDataResponseV1> mapToAnalyticsTimeSeries(List<NameData> sessions) {
        List<InterfaceApplicationAnalyticsTimeSeriesDataResponseV1> result = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(sessions)) {
            result = sessions.stream()
                    .map(this::mapToTimeSeriesData)
                    .toList();
        }
        return result;
    }

    private InterfaceApplicationAnalyticsTimeSeriesDataResponseV1 mapToTimeSeriesData(NameData nameData) {
        return new InterfaceApplicationAnalyticsTimeSeriesDataResponseV1()
                .appName(nameData.getAppName())
                .data(nameData.getData())
                .label(nameData.getLabel());
    }
}
