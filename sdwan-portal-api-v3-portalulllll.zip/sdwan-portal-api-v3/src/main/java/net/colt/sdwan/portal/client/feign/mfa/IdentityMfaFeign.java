package net.colt.sdwan.portal.client.feign.mfa;

import net.colt.sdwan.portal.generated.controllers.MfaApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "identityMfaClient",
        url = "${sdwan.identity-access.api.baseurl}",
        configuration = IdentityAccessFeignConfiguration.class
)
public interface IdentityMfaFeign extends MfaApiApi { }
