package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.feign.security.SecureLogForwardingApiFeign;
import net.colt.sdwan.portal.mappers.SecureLogForwardingMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.security.models.UserAuth;
import net.colt.sdwan.portal.services.DeviceService;
import net.colt.sdwan.portal.services.SecureLogForwardingService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SecureLogForwardingRequestValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.security.api.generated.model.LoggerType;
import net.colt.sdwan.security.api.generated.model.SecureLogForwardingApiRequestV1;
import net.colt.sdwan.security.api.generated.model.SecureLogForwardingApiResponseV1;
import net.colt.sdwan.security.api.generated.model.SecureLogForwardingHistoryApiResponseV1;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

import static java.util.Collections.emptyList;
import static java.util.Objects.nonNull;
import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.constant.SecureLogForwardingConstants.THREAT_FEATURE_AVAILABLE_ON_BRANCH_SITES;
import static net.colt.sdwan.portal.constant.SecurityConstants.SECURE_LOG_FORWARDING_PROFILES;
import static net.colt.sdwan.portal.model.OnGoingActionV2.MODIFYING_SECURE_LOG_FORWARDING;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;
import static net.colt.sdwan.portal.model.SiteTypeV1.BRANCH;
import static org.apache.commons.lang3.ObjectUtils.isNotEmpty;

@Service
@RequiredArgsConstructor
@Slf4j
public class SecureLogForwardingServiceImpl implements SecureLogForwardingService {

    private final SitesService sitesService;
    private final SecureLogForwardingApiFeign secureLogForwardingApiFeign;
    private final SecureLogForwardingMapper secureLogForwardingMapper;
    private final SiteResponseValidator siteResponseValidator;
    private final SecureLogForwardingRequestValidator secureLogForwardingRequestValidator;
    private final DeviceService deviceService;
    private final ResponseEntityValidator responseEntityValidator;

    @Override
    public CorrelationIdResponseV1 updateSecureLogForwardingV1(String siteId, SecureLogForwardingRequestV1 secureLogForwardingRequest) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        if (!BRANCH.toString().equalsIgnoreCase(siteResponse.getSiteType().getValue())) {
            throw new SdwanBadRequestException(THREAT_FEATURE_AVAILABLE_ON_BRANCH_SITES);
        }
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);

        secureLogForwardingRequestValidator.validateSecureLogForwardingRequest(secureLogForwardingRequest, siteResponse);

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final SecureLogForwardingApiRequestV1 secureLogForwardingApiRequestV1 = secureLogForwardingMapper.from(secureLogForwardingRequest);
        secureLogForwardingApiRequestV1.setUpdatedBy(AuthUserHelper.getAuthUser().getUsername());
        secureLogForwardingApiRequestV1.setUpdatedDt(LocalDateTime.now(ZoneOffset.UTC));

        final List<String> deviceNames = new ArrayList<>(sitesService.getDeviceNamesFromSiteResponse(siteResponse));
        UserAuth userAuth = AuthUserHelper.getAuthUser();
        try {
            sitesService.updateOngoingAction(siteId, MODIFYING_SECURE_LOG_FORWARDING);
            String loggingEventType = StringUtils.isNotEmpty(secureLogForwardingRequest.getLoggingEvent().name()) ? secureLogForwardingRequest.getLoggingEvent().toString() : FirewallLoggingEventTrigger.NEVER.toString();
            if (secureLogForwardingRequest.getEnabled()) {
                sitesService.updateLoggingProfile(siteId, LoggerType.SLF.toString(), loggingEventType);
            } else {
                sitesService.updateLoggingProfile(siteId, LoggerType.DEFAULT.toString(), loggingEventType);
            }

            final ResponseEntity<Void> responseEntity = secureLogForwardingApiFeign.updateSecureLogForwardingV1(siteResponse.getNetworkId(), siteId, deviceNames, userAuth.getUsername(), secureLogForwardingApiRequestV1);

            responseEntityValidator.checkResponseEntity(responseEntity, SECURE_LOG_FORWARDING_PROFILES);
            return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
        } catch (Exception ex) {
            log.error("Failed to update secure log forwarding", ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }
    }

    @Override
    public SecureLogForwardingResponseV1 getSecureLogForwardingV1(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (!BRANCH.toString().equalsIgnoreCase(siteResponse.getSiteType().getValue())) {
            throw new SdwanBadRequestException(THREAT_FEATURE_AVAILABLE_ON_BRANCH_SITES);
        }

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        final ResponseEntity<SecureLogForwardingApiResponseV1> secureLogForwardingResponseEntity =
                secureLogForwardingApiFeign.getSecureLogForwardingV1(siteResponse.getNetworkId(), siteResponse.getId().toString());
        responseEntityValidator.checkResponseEntity(secureLogForwardingResponseEntity, SECURE_LOG_FORWARDING_PROFILES);

        SecureLogForwardingApiResponseV1 body = secureLogForwardingResponseEntity.getBody();

        // this is here only for SLF rediscovery purpose
        updateLogProfileAndLogEvent(siteId, siteResponse, body);

        return secureLogForwardingMapper.from(body);

    }

    @Override
    public List<SecureLogForwardingHistoryResponseV1> getSecureLogForwardingHistoryBySiteIdV1(String siteId) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (!BRANCH.toString().equalsIgnoreCase(siteResponse.getSiteType().getValue())) {
            throw new SdwanBadRequestException(THREAT_FEATURE_AVAILABLE_ON_BRANCH_SITES);
        }

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaAnalyticsInstance());

        final ResponseEntity<List<SecureLogForwardingHistoryApiResponseV1>> secureLogForwardingHistoryResponseEntity =
                secureLogForwardingApiFeign.getSecureLogForwardingHistoryBySiteIdV1(siteResponse.getNetworkId(), siteResponse.getId().toString());
        responseEntityValidator.checkResponseEntity(secureLogForwardingHistoryResponseEntity, SECURE_LOG_FORWARDING_PROFILES);

        List<SecureLogForwardingHistoryApiResponseV1> body = secureLogForwardingHistoryResponseEntity.getBody();

        return nonNull(body) ? secureLogForwardingMapper.from(secureLogForwardingHistoryResponseEntity.getBody()) : emptyList();

    }

    @Override
    public SecureLogForwardingResponseV1 getSecureLogForwardingHistoryBySiteIdAndRuleSetIdV1(String siteId, String ruleSetId) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (!BRANCH.toString().equalsIgnoreCase(siteResponse.getSiteType().getValue())) {
            throw new SdwanBadRequestException(THREAT_FEATURE_AVAILABLE_ON_BRANCH_SITES);
        }

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());

        ResponseEntity<SecureLogForwardingApiResponseV1> secureLogForwardingHistoryByIdResponseEntity = secureLogForwardingApiFeign.getSecureLogForwardingHistoryBySiteIdAndRuleSetIdV1(
                siteResponse.getNetworkId(), siteResponse.getId().toString(), ruleSetId);
        responseEntityValidator.checkResponseEntity(secureLogForwardingHistoryByIdResponseEntity, SECURE_LOG_FORWARDING_PROFILES);

        SecureLogForwardingApiResponseV1 body = secureLogForwardingHistoryByIdResponseEntity.getBody();

        // this is here only for SLF rediscovery purpose
        updateLogProfileAndLogEvent(siteId, siteResponse, body);

        return secureLogForwardingMapper.from(body);
    }


    @Override
    public CorrelationIdResponseV1 getSecureLogForwardingStatisticsV1(String siteId, String deviceId, Integer collectorNumber) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        UserAuth authUser = AuthUserHelper.getAuthUser();
        net.colt.sdwan.generated.model.service.DeviceResponseV1 deviceResponse = deviceService.getFromSiteIfPresent(siteResponse, deviceId);
        ResponseEntity<Void> responseEntity = secureLogForwardingApiFeign.getCollectorStatisticsByNumberV1(
                siteResponse.getNetworkId(), siteResponse.getId().toString(), collectorNumber, authUser.getUsername(),
                deviceResponse.getManagementIpv4());
        responseEntityValidator.checkResponseEntity(responseEntity, SECURE_LOG_FORWARDING_PROFILES);
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    @Override
    public CorrelationIdResponseV1 getSecureLogForwardingStatusV1(String siteId, String deviceId, Integer collectorNumber) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        AuthUserHelper.getAuthUser().setVersaInstance(siteResponse.getVersaInstance());
        UserAuth authUser = AuthUserHelper.getAuthUser();
        net.colt.sdwan.generated.model.service.DeviceResponseV1 deviceResponse = deviceService.getFromSiteIfPresent(siteResponse, deviceId);
        ResponseEntity<Void> responseEntity = secureLogForwardingApiFeign.getCollectorStatusByNumberV1(
                siteResponse.getNetworkId(), siteResponse.getId().toString(), collectorNumber, authUser.getUsername(),
                deviceResponse.getManagementIpv4());
        responseEntityValidator.checkResponseEntity(responseEntity, SECURE_LOG_FORWARDING_PROFILES);
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

    private void updateLogProfileAndLogEvent(String siteId, SiteResponseV1 siteResponse, SecureLogForwardingApiResponseV1 body) {
        boolean slfEnabled = nonNull(body) && isNotEmpty(body.getLoggingEvent()) && siteResponse.getSiteFeatures().getSecurity().getLogging().getLoggingType() != null && !LoggerType.SLF.name().equals(siteResponse.getSiteFeatures().getSecurity().getLogging().getLoggingType()) && body.getEnabled();
        if (slfEnabled) {
            sitesService.updateLoggingProfile(siteId, LoggerType.SLF.toString(), body.getLoggingEvent().name());
        }
    }
}
