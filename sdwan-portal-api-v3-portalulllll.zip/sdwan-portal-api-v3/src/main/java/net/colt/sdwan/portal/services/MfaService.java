package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.FinalTokenResponseV1;
import net.colt.sdwan.portal.model.SendEmailRequestV1;
import net.colt.sdwan.portal.model.SendSmsRequestV1;
import net.colt.sdwan.portal.model.StartTotpSessionRequestV1;
import net.colt.sdwan.portal.model.StartTotpSessionResponseV1;
import net.colt.sdwan.portal.model.VerifyEmailRequestV1;
import net.colt.sdwan.portal.model.VerifySmsReqApiV1;
import net.colt.sdwan.portal.model.VerifyTotpRequestV1;

public interface MfaService {

    void sendMfaEmail(SendEmailRequestV1 req);

    FinalTokenResponseV1 verifyMfaEmail(VerifyEmailRequestV1 req);

    void sendMfaSms(SendSmsRequestV1 req);

    FinalTokenResponseV1 verifyMfaSms(VerifySmsReqApiV1 req);

    StartTotpSessionResponseV1 startTotpSession(StartTotpSessionRequestV1 req);

    FinalTokenResponseV1 verifyTotp(VerifyTotpRequestV1 req);

    void deleteTotpConfigs();
}
