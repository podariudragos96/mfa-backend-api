package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.model.service.CgwResponseV1;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.model.Status;
import net.colt.sdwan.portal.model.CloudGatewayDetailsV1;
import net.colt.sdwan.portal.model.DeviceResponseV1;
import net.colt.sdwan.portal.model.DeviceSpecificationV1;
import net.colt.sdwan.portal.model.InterfaceSummaryResponseV1;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static java.util.Objects.nonNull;

@RequiredArgsConstructor
@Component
public class DeviceResponseMapper extends CommonMapper {

    private final InterfaceSummaryResponseMapper interfaceSummaryResponseMapper;

    public DeviceResponseV1 mapToResponse(final net.colt.sdwan.generated.model.service.DeviceResponseV1 clientDeviceResponse,
                                          final List<CgwResponseV1> cgw, final String siteType, final String networkId) {
        InterfaceSummaryResponseV1 interfaceSummary = interfaceSummaryResponseMapper.mapFromList(clientDeviceResponse.getInterfaces(), networkId, siteType, cgw);
        return new DeviceResponseV1()
                .id(String.valueOf(clientDeviceResponse.getId()))
                .createdDt(clientDeviceResponse.getCreatedOn())
                .updatedDt(clientDeviceResponse.getLastUpdated())
                .cloudGatewayConfiguration(this.mapToResponseDetails(clientDeviceResponse, cgw))
                .friendlyName(clientDeviceResponse.getResourceName())
                .specification(mapToSpecification(clientDeviceResponse))
                .reachable(clientDeviceResponse.getReachable())
                .syncStatus(clientDeviceResponse.getSyncStatus())
                .resourceName(clientDeviceResponse.getResourceName())
                .status(mapToStatusEnum(clientDeviceResponse.getStatus()))
                .isCustomerManagedCertificateGenerated(clientDeviceResponse.getIsCustomerManagedCertificateGenerated())
                .isSelfSignedCertificateGenerated(clientDeviceResponse.getIsSelfSignedCertificateGenerated())
                .routingManagement(mapFromStringList(clientDeviceResponse.getManageRouting()))
                .isPrimary(clientDeviceResponse.getIsPrimary())
                .interfaces(interfaceSummary);
    }

    public List<DeviceResponseV1> mapToResponseList(SiteResponseV1 siteResponse) {
        List<net.colt.sdwan.generated.model.service.DeviceResponseV1> deviceResponses = siteResponse.getDevices().stream().toList();
        return deviceResponses.stream()
                .filter(device -> Status.ACTIVE.value().equalsIgnoreCase(device.getStatus().getValue()))
                .map(device -> mapToResponse(device, siteResponse.getCgw(), siteResponse.getSiteType().getValue(), siteResponse.getNetworkId()))
                .toList();
    }

    private CloudGatewayDetailsV1 mapToResponseDetails(final net.colt.sdwan.generated.model.service.DeviceResponseV1 clientDeviceResponse, List<CgwResponseV1> cgw) {
        Optional<CgwResponseV1> cgwDetails = cgw.stream().filter(c -> c.getCgwName().equals(clientDeviceResponse.getResourceName())).findAny();
        if (cgwDetails.isPresent()) {
            final CgwResponseV1 cgwResponseV1 = cgwDetails.get();
            return new CloudGatewayDetailsV1()
                    .gatewayFqdnName(cgwResponseV1.getCgwFqdnName())
                    .gatewayInterfaceName(cgwResponseV1.getCgwInterfaceName())
                    .gatewayName(cgwResponseV1.getCgwName())
                    .gatewayNode(cgwResponseV1.getCgwNode())
                    .cspAddress(cgwResponseV1.getCspAddress())
                    .cspAsNumber(cgwResponseV1.getCspAsNumber())
                    .cspBearerCircuitId(cgwResponseV1.getCspBearerCircuitId())
                    .cspLocation(cgwResponseV1.getCspLocation())
                    .cspMd5Authentication(cgwResponseV1.getCspMd5Authentication())
                    .cspName(cgwResponseV1.getCspName())
                    .cspPeeringInterface(cgwResponseV1.getCspPeeringInterface())
                    .cspPeeringIp(cgwResponseV1.getCspPeeringIp())
                    .cspServiceKey(cgwResponseV1.getCspBearerCircuitId())
                    .cvlanId(mapToInteger(cgwResponseV1.getCvlanId()))
                    .gatewayCvlanId(mapToInteger(cgwResponseV1.getGwCvlanId()))
                    .gatewayIpAddress(cgwResponseV1.getGwIpAddress())
                    .routingDomain(cgwResponseV1.getRoutingDomain())
                    .sdwanVpnId(cgwResponseV1.getSdwanVpnId())
                    .svlanId(mapToInteger(cgwResponseV1.getSvlanId()));
        }
        return new CloudGatewayDetailsV1();
    }

    private DeviceSpecificationV1 mapToSpecification(final net.colt.sdwan.generated.model.service.DeviceResponseV1 clientDeviceResponse) {
        return new DeviceSpecificationV1()
                .cpuCount(nonNull(clientDeviceResponse.getCpuCount()) ? clientDeviceResponse.getCpuCount().toString() : null)
                .diskCapacity(clientDeviceResponse.getDisk())
                .ram(clientDeviceResponse.getMemory())
                .serialNumber(clientDeviceResponse.getSerialNumber())
                .model(clientDeviceResponse.getModel())
                .softwareVersion(clientDeviceResponse.getSwVersion());
    }

    private DeviceResponseV1.StatusEnum mapToStatusEnum(net.colt.sdwan.generated.model.service.DeviceResponseV1.StatusEnum status) {
        DeviceResponseV1.StatusEnum statusEnum = null;
        if (nonNull(status)) {
            statusEnum = DeviceResponseV1.StatusEnum.fromValue(status.getValue());
        }
        return statusEnum;
    }

    public List<DeviceResponseV1.RoutingManagementEnum> mapFromStringList(final List<net.colt.sdwan.generated.model.service.DeviceResponseV1.ManageRoutingEnum> routingManagement) {
        List<DeviceResponseV1.RoutingManagementEnum> routingManagementEnumList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(routingManagement)) {
            routingManagementEnumList = routingManagement.stream()
                    .map(routing -> DeviceResponseV1.RoutingManagementEnum.fromValue(routing.getValue()))
                    .filter(Objects::nonNull)
                    .toList();
        }
        return routingManagementEnumList;
    }

}
