package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.feign.sitesettings.CustomObjectApiFeign;
import net.colt.sdwan.portal.mappers.ServiceObjectMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.security.AuthUserHelper;
import net.colt.sdwan.portal.services.ServiceObjectService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import net.colt.sdwan.portal.validator.access.CustomObjectValidator;
import net.colt.sdwan.sitesettings.api.generated.model.ServicesResponseApiV1;
import org.slf4j.MDC;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import static java.util.Objects.requireNonNull;
import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.portal.model.OnGoingActionV2.NONE;

@Service
@Slf4j
@RequiredArgsConstructor
public class ServiceObjectServiceImpl implements ServiceObjectService {

    private final SitesService sitesService;
    private final ServiceObjectMapper mapper;
    private final CustomObjectApiFeign customObjectApiFeign;
    private final SiteResponseValidator siteResponseValidator;
    private final ResponseEntityValidator responseEntityValidator;

    @Override
    public ServicesResponseV1 getCustomServicesV1(String siteId, ServiceObjectCriteria criteria, Integer pageNumber, Integer pageSize) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        CustomObjectValidator.validateAccess(siteResponse);
        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        final ResponseEntity<ServicesResponseApiV1> response = customObjectApiFeign.getServicesV1(
                Integer.valueOf(siteId), siteResponse.getNetworkId(), mapper.from(criteria),
                mapper.from(siteResponse.getSiteType()), pageNumber, pageSize, Pageable.unpaged());
        return mapper.from(response.getBody());
    }

    @Override
    public CorrelationIdResponseV1 updateCustomServicesV1(String siteId, ServicesRequestV1 servicesRequestV1) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        CustomObjectValidator.validateAccess(siteResponse);
        siteResponseValidator.validateSiteLockedAndEditable(siteResponse);

        requireNonNull(AuthUserHelper.getAuthUser()).setVersaInstance(siteResponse.getVersaInstance());
        try {
            sitesService.updateOngoingAction(siteId, OnGoingActionV2.MODIFYING_SERVICE_OBJECTS);

            final ResponseEntity<Void> responseEntity = customObjectApiFeign.updateServicesV1(
                    Integer.valueOf(siteId), siteResponse.getNetworkId(), AuthUserHelper.getAuthUser().getUsername(),
                    mapper.from(siteResponse.getSiteType()), sitesService.getDeviceNamesFromSiteResponse(siteResponse),
                    mapper.from(servicesRequestV1));
            responseEntityValidator.checkResponseEntity(responseEntity, "customObjectApiFeign.updateServicesV1");
        } catch (Exception ex) {
            log.error("Failed to updateCustomServicesV1 for siteId='{}'.", siteId, ex);
            sitesService.updateOngoingAction(siteId, NONE);
            throw ex;
        }
        return new CorrelationIdResponseV1().correlationId(MDC.get(CORRELATION_ID));
    }

}
