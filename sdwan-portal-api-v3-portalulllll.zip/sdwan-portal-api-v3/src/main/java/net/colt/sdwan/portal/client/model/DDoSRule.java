package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DDoSRule {

    @NotBlank(message = "name can't be null or blank.")
    @JsonProperty("name")
    private String name;

    @NotBlank(message = "description can't be null or blank.")
    @JsonProperty("description")
    private String description;


    @NotNull(message = "source-ip can't be null")
    @Size(min = 0, max = 1000, message = "Max Limit for source IP is 1000.")
    @JsonProperty("source-ip")
    private List<String> sourceIp;

    @NotNull(message = "source-negate can't be null")
    @JsonProperty("source-negate")
    private Boolean sourceNegate;

    @NotNull(message = "destination-ip can't be null")
    @Size(min = 0, max = 1000, message = "Max Limit for destination IP is 1000.")
    @JsonProperty("destination-ip")
    private List<String> destinationIp;

    @JsonProperty("destination-port")
    private String destinationPort;

    @NotNull(message = "action can't be null")
    @JsonProperty("action")
    private Action action;

    @NotNull(message = "protocol can't be null")
    @JsonProperty("protocol")
    private FloodProtocol protocol;

    @Valid
    @NotNull(message = "thresholds can't be null")
    @JsonProperty("thresholds")
    private DDoSRuleThresholds thresholds;

    @NotNull(message = "rule-enabled can't be null")
    @JsonProperty("rule-enabled")
    private Boolean ruleEnabled;

    @NotNull(message = "logging can't be null")
    @JsonProperty("logging")
    private Boolean logging;

    public void setSourceNegateToFalse() {
        this.sourceNegate = false;
    }

    public enum Action {PROTECTED, ALLOWED}

}
