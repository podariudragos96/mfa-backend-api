package net.colt.sdwan.portal.client;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import static net.colt.sdwan.common.logging.constant.LoggingLabels.CORRELATION_ID;
import static net.colt.sdwan.common.logging.constant.SDWANHeaders.X_LOG_CORRELATION_ID;

@Slf4j
@Component
public class AuthHeaderGenerator {

    @Value("${policy.api.username}")
    private String policyApiUsername;

    @Value("${policy.api.password}")
    private String policyApiPassword;

    @Value("${analytics.api.username}")
    private String analyticsApiUsername;

    @Value("${analytics.api.password}")
    private String analyticsApiPassword;

    public static HttpHeaders createHeaders(final String username, final String password) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(X_LOG_CORRELATION_ID, MDC.get(CORRELATION_ID));
        String basicAuthValue = getBasicAuthValue(username, password);
        httpHeaders.set(HttpHeaders.AUTHORIZATION, basicAuthValue);
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON.toString());
        return httpHeaders;
    }

    private static String getBasicAuthValue(final String username, final String password) {
        byte[] userPassBytes = username.concat(":")
                .concat(password)
                .getBytes(Charset.forName(StandardCharsets.US_ASCII.name()));
        final byte[] encodedAuth = Base64.getEncoder().encode(userPassBytes);
        return "Basic " + new String(encodedAuth);
    }

    public HttpHeaders createSDWANPolicyHeaders() {
        return createHeaders(policyApiUsername, policyApiPassword);
    }

    public HttpHeaders createSDWANAnalyticsHeaders() {
        return createHeaders(analyticsApiUsername, analyticsApiPassword);
    }
}
