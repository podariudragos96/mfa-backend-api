package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.generated.model.versa.sase.api.SiteToSiteTunnelsResponseApiV1;
import net.colt.sdwan.portal.client.feign.sase.SaseSiteToSiteTunnelFeign;
import net.colt.sdwan.portal.enums.SaseOperation;
import net.colt.sdwan.portal.mappers.SaseSiteToSiteTunnelMapper;
import net.colt.sdwan.portal.model.SaseSiteToSiteTunnelsResponseV1;
import net.colt.sdwan.portal.services.SaseSiteToSiteTunnelService;
import net.colt.sdwan.portal.validator.ResponseEntityValidator;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class SaseSiteToSiteTunnelServiceImpl implements SaseSiteToSiteTunnelService {

    private final SaseSiteToSiteTunnelFeign saseSiteToSiteTunnelFeign;
    private final SaseSiteToSiteTunnelMapper saseSiteToSiteTunnelMapper;
    private final ResponseEntityValidator responseEntityValidator;

    @Override
    public SaseSiteToSiteTunnelsResponseV1 getSiteToSiteTunnelsV1(String tenantUuid) {
        log.info("Getting Site to Site Tunnels via sase api for tenantUuid={}", tenantUuid);

        final ResponseEntity<SiteToSiteTunnelsResponseApiV1> response = saseSiteToSiteTunnelFeign
                .getSiteToSiteTunnelsV1(tenantUuid);
        responseEntityValidator.checkResponseEntity(response, SaseOperation.SITE_TO_SITE_TUNNELS_GET.getName());

        log.info("Get Site to Site Tunnels request completed successfully for tenantUuid={}.", tenantUuid);
        return saseSiteToSiteTunnelMapper.from(response.getBody());
    }

}
