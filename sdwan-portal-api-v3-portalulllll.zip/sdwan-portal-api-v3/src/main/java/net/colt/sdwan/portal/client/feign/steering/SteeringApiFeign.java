package net.colt.sdwan.portal.client.feign.steering;

import net.colt.sdwan.steering.api.generated.api.SteeringApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "steeringApiClient", url = "${sdwan.steering.api.baseurl}",
        configuration = SteeringApiFeignConfiguration.class)
public interface SteeringApiFeign extends SteeringApiApi {
}
