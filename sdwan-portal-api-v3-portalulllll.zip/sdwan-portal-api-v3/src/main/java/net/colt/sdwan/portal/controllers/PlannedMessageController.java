package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.PlannedMessageApiApi;
import net.colt.sdwan.portal.model.PlannedMessageCriteriaV1;
import net.colt.sdwan.portal.model.PlannedMessagesResponseV1;
import net.colt.sdwan.portal.services.PlannedMessageService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class PlannedMessageController implements PlannedMessageApiApi {

    private final PlannedMessageService service;

    @Override
    public ResponseEntity<PlannedMessagesResponseV1> getPlannedMessageV1(PlannedMessageCriteriaV1 criteria) {
        return ResponseEntity.ok(service.getPlannedMessage(criteria));
    }
}
