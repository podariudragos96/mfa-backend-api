package net.colt.sdwan.portal.client.feign.sitesettings;

import net.colt.sdwan.sitesettings.api.generated.api.CustomObjectApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(
        name = "CustomObjectApiClient",
        url = "${sdwan.site.settings.api.baseurl}",
        configuration = SiteSettingsApiFeignConfiguration.class)
public interface CustomObjectApiFeign extends CustomObjectApiApi {
}
