package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.model.versa.sase.api.InternetProtectionRulesRequestApiV1;
import net.colt.sdwan.generated.model.versa.sase.api.InternetProtectionRulesResponseApiV1;
import net.colt.sdwan.portal.model.InternetProtectionRulesRequestV1;
import net.colt.sdwan.portal.model.InternetProtectionRulesResponseV1;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SaseInternetProtectionRuleMapper {

    private final ModelMapper modelMapper;

    public InternetProtectionRulesResponseV1 from(InternetProtectionRulesResponseApiV1 response) {
        return modelMapper.map(response, InternetProtectionRulesResponseV1.class);
    }

    public InternetProtectionRulesRequestApiV1 from(InternetProtectionRulesRequestV1 request) {
        return modelMapper.map(request, InternetProtectionRulesRequestApiV1.class);
    }

}
