package net.colt.sdwan.portal.client.feign.service;

import net.colt.sdwan.generated.controller.service.DeviceApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "serviceApiDeviceClient", url = "${sdwan.service.api.base.url}", configuration = ServiceFeignConfiguration.class)
public interface ServiceApiDeviceFeign extends DeviceApi {

}