package net.colt.sdwan.portal.client.feign.coltonlinemock;

import feign.auth.BasicAuthRequestInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

public class ColtOnlineMockApiFeignConfiguration {

    protected String username;
    protected String password;

    public ColtOnlineMockApiFeignConfiguration(
            @Value("${sdwan.colt-online-mock.api.user}") String username,
            @Value("${sdwan.colt-online-mock.api.pwd}") String password) {
        this.username = username;
        this.password = password;
    }

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        return new BasicAuthRequestInterceptor(username, password);
    }
}
