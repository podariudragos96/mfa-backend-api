package net.colt.sdwan.portal.security.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import org.springframework.security.core.GrantedAuthority;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode
@ToString
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Role implements GrantedAuthority {

    private static final long serialVersionUID = 1L;
    private String name;
    private transient List<Permission> permissions;

    public Role(final String name) {
        this.name = name;
    }

    public String getAuthority() {
        return name;
    }
}
