package net.colt.sdwan.portal.security;

import net.colt.sdwan.portal.security.models.UserAuth;
import org.springframework.security.core.context.SecurityContextHolder;

public class AuthUserHelper {

    private AuthUserHelper() {
    }

    public static UserAuth getAuthUser() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof UserAuth) {
            return (UserAuth) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        }
        return null;
    }
}
