package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * The status of the user
 */
public enum UserStatus {

    ACTIVE("ACTIVE"),

    INACTIVE("INACTIVE"),

    ARCHIVED("ARCHIVED");

    private String value;

    UserStatus(String value) {
        this.value = value;
    }

    @JsonCreator
    public static UserStatus fromValue(String text) {
        for (UserStatus b : UserStatus.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        throw new IllegalArgumentException("Unexpected value '" + text + "'");
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }
}

