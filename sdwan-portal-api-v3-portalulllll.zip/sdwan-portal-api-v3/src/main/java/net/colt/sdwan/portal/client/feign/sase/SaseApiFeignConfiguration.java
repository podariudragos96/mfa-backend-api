package net.colt.sdwan.portal.client.feign.sase;

import feign.auth.BasicAuthRequestInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

public class SaseApiFeignConfiguration {

    protected String username;
    protected String password;

    public SaseApiFeignConfiguration(
            @Value("${sdwan.sase.api.user}") String username,
            @Value("${sdwan.sase.api.pwd}") String password) {
        this.username = username;
        this.password = password;
    }

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        return new BasicAuthRequestInterceptor(username, password);
    }
}
