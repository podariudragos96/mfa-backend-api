package net.colt.sdwan.portal.mappers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.model.versa.sase.api.*;
import net.colt.sdwan.portal.model.*;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SaseCatalogMapper {

    private final ModelMapper modelMapper;

    public SaseGeoIpCountriesCatalogResponseV1 from(GeoIpCountriesCatalogResponseApiV1 geoIpCountriesCatalogResponseApiV1) {
        return modelMapper.map(geoIpCountriesCatalogResponseApiV1, SaseGeoIpCountriesCatalogResponseV1.class);
    }

    public SaseUrlCategoriesCatalogResponseV1 from(UrlCategoriesCatalogResponseApiV1 urlCategoriesCatalogResponseApiV1) {
        return modelMapper.map(urlCategoriesCatalogResponseApiV1, SaseUrlCategoriesCatalogResponseV1.class);
    }

    public SaseUrlReputationsCatalogResponseV1 from(UrlReputationsCatalogResponseApiV1 urlReputationsCatalogResponseApiV1) {
        return modelMapper.map(urlReputationsCatalogResponseApiV1, SaseUrlReputationsCatalogResponseV1.class);
    }

    public SaseApplicationsCatalogResponseV1 from(ApplicationsCatalogResponseApiV1 applicationsCatalogResponseApiV1) {
        return modelMapper.map(applicationsCatalogResponseApiV1, SaseApplicationsCatalogResponseV1.class);
    }

    public SaseServicesCatalogResponseV1 from(ServicesCatalogResponseApiV1 servicesCatalogResponseApiV1) {
        return modelMapper.map(servicesCatalogResponseApiV1, SaseServicesCatalogResponseV1.class);
    }

    public SaseSecurityProfilesCatalogResponseV1 from(SecurityProfilesCatalogResponseApiV1 securityProfilesCatalogResponseApiV1) {
        return modelMapper.map(securityProfilesCatalogResponseApiV1, SaseSecurityProfilesCatalogResponseV1.class);
    }

    public SaseStaticZonesCatalogResponseV1 from(StaticZonesCatalogResponseApiV1 staticZonesCatalogResponseApiV1) {
        return modelMapper.map(staticZonesCatalogResponseApiV1, SaseStaticZonesCatalogResponseV1.class);
    }

    public SaseApplicationCategoriesCatalogResponseV1 from(ApplicationCategoriesCatalogResponseApiV1 applicationCategoriesCatalogResponseApiV1) {
        return modelMapper.map(applicationCategoriesCatalogResponseApiV1, SaseApplicationCategoriesCatalogResponseV1.class);
    }

    public SaseApplicationGroupsCatalogResponseV1 from(ApplicationGroupsCatalogResponseApiV1 applicationGroupsCatalogResponseApiV1) {
        return modelMapper.map(applicationGroupsCatalogResponseApiV1, SaseApplicationGroupsCatalogResponseV1.class);
    }

    public EndpointProtectionsCatalogResponseV1 from(EndpointProtectionsCatalogResponseApiV1 endpointProtectionsCatalogResponseApiV1) {
        return modelMapper.map(endpointProtectionsCatalogResponseApiV1, EndpointProtectionsCatalogResponseV1.class);
    }

    public OperatingSystemsCatalogResponseV1 from(OperatingSystemsCatalogResponseApiV1 operatingSystemsCatalogResponseApiV1) {
        return modelMapper.map(operatingSystemsCatalogResponseApiV1, OperatingSystemsCatalogResponseV1.class);
    }

    public ApplicationsCatalogResponseV1 from(SaseApplicationsCatalogResponseApiV1 saseApplicationsCatalogResponseApiV1) {
        return modelMapper.map(saseApplicationsCatalogResponseApiV1, ApplicationsCatalogResponseV1.class);
    }

}
