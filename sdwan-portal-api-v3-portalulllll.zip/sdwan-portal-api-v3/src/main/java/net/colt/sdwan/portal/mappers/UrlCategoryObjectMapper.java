package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.portal.model.UrlCategoriesRequestV1;
import net.colt.sdwan.portal.model.UrlCategoriesResponseV1;
import net.colt.sdwan.portal.model.UrlCategoryObjectCriteria;
import net.colt.sdwan.sitesettings.api.generated.model.UrlCategoriesRequestApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.UrlCategoriesResponseApiV1;
import net.colt.sdwan.sitesettings.api.generated.model.UrlCategoryObjectCriteriaApi;
import org.mapstruct.Mapper;

@Mapper
public interface UrlCategoryObjectMapper {

    UrlCategoryObjectCriteriaApi from(UrlCategoryObjectCriteria criteria);

    UrlCategoriesResponseV1 from(UrlCategoriesResponseApiV1 response);

    UrlCategoriesRequestApiV1 from(UrlCategoriesRequestV1 request);

}
