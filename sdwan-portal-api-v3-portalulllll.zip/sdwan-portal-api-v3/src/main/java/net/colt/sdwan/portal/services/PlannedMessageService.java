package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.PlannedMessageCriteriaV1;
import net.colt.sdwan.portal.model.PlannedMessagesResponseV1;

public interface PlannedMessageService {

    PlannedMessagesResponseV1 getPlannedMessage(PlannedMessageCriteriaV1 criteria);
}
