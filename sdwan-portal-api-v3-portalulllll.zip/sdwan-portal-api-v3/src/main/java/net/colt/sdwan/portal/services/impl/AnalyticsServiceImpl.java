package net.colt.sdwan.portal.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.data.criteria.filter.LongFilter;
import net.colt.sdwan.common.exceptions.exception.SdwanBadRequestException;
import net.colt.sdwan.common.exceptions.exception.SdwanException;
import net.colt.sdwan.common.exceptions.exception.SdwanNotFoundException;
import net.colt.sdwan.common.exceptions.exception.SdwanUnprocessableEntityException;
import net.colt.sdwan.generated.model.service.DeviceResponseV1;
import net.colt.sdwan.generated.model.service.InterfaceResponseV1;
import net.colt.sdwan.generated.model.service.SiteCriteria;
import net.colt.sdwan.generated.model.service.SiteResponseV1;
import net.colt.sdwan.portal.client.AnalyticsApiClient;
import net.colt.sdwan.portal.client.ServiceApiClient;
import net.colt.sdwan.portal.client.model.*;
import net.colt.sdwan.portal.mappers.DdosAnalyticsMapper;
import net.colt.sdwan.portal.mappers.InterfaceAnalyticsMapper;
import net.colt.sdwan.portal.mappers.InterfaceQOSAnalyticsMapper;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.services.AnalyticsService;
import net.colt.sdwan.portal.services.DeviceService;
import net.colt.sdwan.portal.services.InterfaceService;
import net.colt.sdwan.portal.services.SitesService;
import net.colt.sdwan.portal.validator.NetworkValidator;
import net.colt.sdwan.portal.validator.SiteResponseValidator;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static net.colt.sdwan.portal.constant.AnalyticsConstants.ANALYTIC_ONLY_AVAILABLE_FOR_CLOUD_GATEWAY_SITES;
import static net.colt.sdwan.portal.constant.ErrorMessageConstants.*;
import static net.colt.sdwan.portal.util.CGWUtil.isBranchOrDedicatedGateway;
import static net.colt.sdwan.portal.util.CGWUtil.isCloudGateway;
import static org.apache.commons.collections4.CollectionUtils.isNotEmpty;
import static org.apache.commons.lang3.ObjectUtils.notEqual;

@RequiredArgsConstructor
@Service
@Slf4j
public class AnalyticsServiceImpl implements AnalyticsService {

    private final AnalyticsApiClient analyticsApiClient;
    private final SiteResponseValidator siteResponseValidator;
    private final NetworkValidator networkValidator;
    private final SitesService sitesService;
    private final DeviceService deviceService;
    private final InterfaceService interfaceService;
    private final InterfaceAnalyticsMapper interfaceAnalyticsMapper;
    private final InterfaceQOSAnalyticsMapper interfaceQOSAnalyticsMapper;
    private final DdosAnalyticsMapper ddosAnalyticsMapper;
    private final ServiceApiClient serviceApiClient;

    /**
     * @param siteId
     * @param deviceId
     * @param interfaceId
     * @param startDate
     * @param endDate
     * @return
     */
    @Override
    public InterfaceAnalyticsTimeSeriesDataResponseV2 getInterfaceAnalyticsBySiteIdAndDeviceIdAndInterfaceId(String siteId, String deviceId, String interfaceId, LocalDateTime startDate, LocalDateTime endDate) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);

        siteResponseValidator.hasValidSiteAndDeviceValues(siteResponse);
        try {
            List<AnalyticsTimeSeriesData> timeSeries = analyticsApiClient.getTimeSeries(siteResponse, deviceResponse, startDate, endDate, false);
            InterfaceAnalyticsTimeSeriesDataResponseV2 dataResponse = new InterfaceAnalyticsTimeSeriesDataResponseV2();
            InterfaceResponseV1 interfaceResponse = interfaceService.getApiInterfaceAndVerify(interfaceId);
            InterfaceAnalyticsTimeSeriesDataResponseV2 interfaceAnalyticsTimeSeriesDataResponse = interfaceAnalyticsMapper.mapFromApiResponse(timeSeries, deviceResponse.getResourceName(), interfaceResponse.getCircuitName()).orElse(dataResponse);

            if (Boolean.TRUE.equals(interfaceResponse.getDiaEnabled()) || Boolean.TRUE.equals(siteResponse.getSiteFeatures().getZscaler().getZscalerEnabled()) || Boolean.TRUE.equals(siteResponse.getSiteFeatures().getSase().getIsEnabled())) {
                List<AnalyticsTimeSeriesData> diaTimeSeries = analyticsApiClient.getTimeSeries(siteResponse, deviceResponse, startDate, endDate, true)
                        .stream().filter(interfaceName -> interfaceName.getCircuitName().equals(interfaceResponse.getCircuitName()))
                        .toList();
                interfaceAnalyticsTimeSeriesDataResponse.getZones().add(interfaceAnalyticsMapper.getInterfaceAnalyticsZoneResponse("DIA", diaTimeSeries));
            }

            return interfaceAnalyticsTimeSeriesDataResponse;
        } catch (SdwanException ex) {
            log.error("Failed to get InterfaceAnalytics", ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND && Optional.ofNullable(ex.getProblemDetailWithCause().getDetail()).stream().noneMatch(errorDetail -> errorDetail.contains(interfaceId))) {
                return new InterfaceAnalyticsTimeSeriesDataResponseV2();
            }
            throw ex;
        }
    }

    /**
     * @param siteId      the site id for which we are making the request
     * @param deviceId    the device id for which we are making the request
     * @param interfaceId
     * @param startDate
     * @param endDate
     * @return
     */
    @Override
    public InterfaceAnalyticsTableDataResponseV1 getInterfaceAnalyticsTabularFormatBySiteIdAndDeviceIdV1(String siteId, String deviceId, String interfaceId, LocalDateTime startDate, LocalDateTime endDate) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        siteResponseValidator.hasValidSiteAndDeviceValues(siteResponse);

        final InterfaceAnalyticsTableResponse interfaceAnalyticsTableResponse =
                analyticsApiClient.getInterfaceAnalyticsTableResponse(siteResponse, deviceResponse, startDate, endDate, false);

        final InterfaceResponseV1 interfaceResponse = interfaceService.getApiInterfaceAndVerify(interfaceId);

        final InterfaceAnalyticsTableDataResponseV1 responseV1 =
                interfaceAnalyticsMapper.mapFromApiTableResponse(interfaceAnalyticsTableResponse, interfaceResponse.getCircuitName());

        if (Boolean.TRUE.equals(interfaceResponse.getDiaEnabled())
                || Boolean.TRUE.equals(siteResponse.getSiteFeatures().getSase().getIsEnabled())) {
            final InterfaceAnalyticsTableResponse diaAnalytics =
                    analyticsApiClient.getInterfaceAnalyticsTableResponse(siteResponse, deviceResponse, startDate, endDate, true);

            if (isNotEmpty(diaAnalytics.getInterfaces())) {
                final InterfaceAnalyticsRowResponse objectWithNullFields = new InterfaceAnalyticsRowResponse();
                final InterfaceAnalyticsRowResponse diaInterfaceFiltered = diaAnalytics.getInterfaces().stream()
                        .filter(rowResponse ->
                                Objects.equals(rowResponse.getAccessCircuit(), interfaceResponse.getCircuitName()))
                        .findFirst()
                        .orElse(objectWithNullFields);

                if (notEqual(diaInterfaceFiltered, objectWithNullFields)) {
                    responseV1.getZones()
                            .add(interfaceAnalyticsMapper.getTableRowResponse(diaInterfaceFiltered, "DIA"));
                }
            }
        }
        return responseV1;
    }

    /**
     * @param siteId      the site id for which we are making the request
     * @param deviceId    the device id for which we are making the request
     * @param interfaceId
     * @return
     */
    @Override
    public InterfaceQOSAnalyticsTimeSeriesDataResponseV1 getInterfaceQOSAnalyticsBySiteIdAndDeviceIdAndInterfaceId(String siteId, String deviceId, String interfaceId, LocalDateTime startDate, LocalDateTime endDate) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);

        siteResponseValidator.hasValidSiteAndDeviceValues(siteResponse);
        try {
            List<QOSAnalyticsTimeSeriesData> timeSeries = analyticsApiClient.getQOSTimeSeries(siteResponse, deviceResponse, startDate, endDate);
            InterfaceResponseV1 interfaceResponse = interfaceService.getApiInterfaceAndVerify(interfaceId);
            return interfaceQOSAnalyticsMapper
                    .mapFromQOSApiResponse(timeSeries, deviceResponse.getResourceName(), interfaceResponse.getCircuitName())
                    .orElse(new InterfaceQOSAnalyticsTimeSeriesDataResponseV1());
        } catch (SdwanException ex) {
            log.error("Failed to get Interface QOS Analytics", ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND && Optional.ofNullable(ex.getProblemDetailWithCause().getDetail()).stream().noneMatch(errorDetail -> errorDetail.contains(interfaceId))) {
                return new InterfaceQOSAnalyticsTimeSeriesDataResponseV1();
            }
            throw ex;
        }
    }

    /**
     * @param siteId
     * @param deviceId
     * @param interfaceId
     * @param startDate
     * @param endDate
     * @param count
     * @param applications
     * @return
     */
    @Override
    public InterfaceApplicationAnalyticsResponseV1 getInterfaceApplicationAnalyticsBySiteIdAndDeviceIdAndInterfaceId(
            String siteId, String deviceId, String interfaceId, LocalDateTime startDate, LocalDateTime endDate, Integer count, List<String> applications) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        InterfaceResponseV1 interfaceResponse = interfaceService.getByDeviceAndInterfaceIdAndVerify(deviceResponse, interfaceId);

        siteResponseValidator.hasValidSiteAndDeviceValues(siteResponse);
        try {
            ApplicationAnalytics applicationAnalytics = analyticsApiClient.getApplicationsAnalytics(siteResponse, deviceResponse, interfaceResponse, startDate, endDate, count, applications);
            return new ModelMapper().map(applicationAnalytics, InterfaceApplicationAnalyticsResponseV1.class);
        } catch (SdwanException ex) {
            log.error("Failed to get Interface Application Analytics", ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new InterfaceApplicationAnalyticsResponseV1();
            }
            throw ex;
        }
    }

    @Override
    public InterfaceApplicationAnalyticsTableResponseV1 getInterfaceApplicationAnalyticsTabularFormatBySiteIdAndDeviceIdAndInterfaceId(
            String siteId, String deviceId, String interfaceId, LocalDateTime startDate, LocalDateTime endDate, Integer count, List<String> applications) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        InterfaceResponseV1 interfaceResponse = interfaceService.getByDeviceAndInterfaceIdAndVerify(deviceResponse, interfaceId);

        siteResponseValidator.hasValidSiteAndDeviceValues(siteResponse);
        try {
            InterfaceApplicationAnalyticsTableResponse response = analyticsApiClient.getApplicationsAnalyticsTable(
                    siteResponse, deviceResponse, interfaceResponse, startDate, endDate, count, applications);
            return new ModelMapper().map(response, InterfaceApplicationAnalyticsTableResponseV1.class);
        } catch (SdwanException ex) {
            log.error("Failed to get Interface Application Analytics", ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new InterfaceApplicationAnalyticsTableResponseV1();
            }
            throw ex;
        }
    }

    @Override
    public DdosAnalyticsTimeSeriesResponseV1 getDdosAnalyticsTimeSeriesBySiteId(
            String siteId, LocalDateTime startDate, LocalDateTime endDate) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        DDoSRulesTimeSeries dDoSRulesTimeSeries = new DDoSRulesTimeSeries();
        if (isNotEmpty(siteResponse.getDevices())) {
            final List<String> deviceNames = siteResponse.getDevices().stream()
                    .map(DeviceResponseV1::getResourceName)
                    .toList();
            dDoSRulesTimeSeries = analyticsApiClient.getDdosAnalyticsTimeSeries(
                    siteResponse, deviceNames, startDate, endDate);
        }
        return ddosAnalyticsMapper.mapToTimeSeriesResponse(dDoSRulesTimeSeries);
    }


    @Override
    public SlaMetricsTimeSeriesDataResponseV1 getSlaMetricsTimeSeriesBySiteIdAndDeviceId(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, String remoteDeviceId, String interfaceId, Integer count) {

        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);

        String remoteDeviceName = null;
        if (remoteDeviceId != null) {
            DeviceResponseV1 remoteDevice = deviceService.getApiDeviceAndVerify(remoteDeviceId);
            remoteDeviceName = remoteDevice.getResourceName();
        }

        String interfaceCircuitName = null;
        if (interfaceId != null) {
            InterfaceResponseV1 interfacesResponse = interfaceService.getByDeviceAndInterfaceIdAndVerify(deviceResponse, interfaceId);
            interfaceCircuitName = interfacesResponse.getCircuitName();
        }

        siteResponseValidator.hasValidSiteAndDeviceValues(siteResponse);

        try {
            SlaMetricsTimeSeriesDataResponse slaMetricsTimeSeries = analyticsApiClient.getSlaMetricsTimeSeries(siteResponse, deviceResponse, remoteDeviceName, interfaceCircuitName, startDate, endDate, count);
            return new ModelMapper().map(slaMetricsTimeSeries, SlaMetricsTimeSeriesDataResponseV1.class);
        } catch (SdwanException ex) {
            log.error("Failed to get Sla Metrics Time Series", ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new SlaMetricsTimeSeriesDataResponseV1();
            }
            throw ex;
        }
    }

    @Override
    public SlaMetricsTableDataResponseV1 getSlaMetricsTableDataBySiteIdAndDeviceId(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, String remoteDeviceId, String interfaceId, Integer count) {

        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);

        String remoteDeviceName = null;
        if (remoteDeviceId != null) {
            DeviceResponseV1 remoteDevice = deviceService.getApiDeviceAndVerify(remoteDeviceId);
            remoteDeviceName = remoteDevice.getResourceName();
        }

        String interfaceCircuitName = null;
        if (interfaceId != null) {
            InterfaceResponseV1 interfacesResponse = interfaceService.getByDeviceAndInterfaceIdAndVerify(deviceResponse, interfaceId);
            interfaceCircuitName = interfacesResponse.getCircuitName();
        }

        siteResponseValidator.hasValidSiteAndDeviceValues(siteResponse);


        try {
            SlaMetricsTableDataResponse slaMetricsTableData = analyticsApiClient.getSlaMetricsTableData(siteResponse, deviceResponse, remoteDeviceName, interfaceCircuitName, startDate, endDate, count);
            return new ModelMapper().map(slaMetricsTableData, SlaMetricsTableDataResponseV1.class);
        } catch (SdwanException ex) {
            log.error(FAILED_TO_GET_SLA_METRICS_TABLE_DATA, ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new SlaMetricsTableDataResponseV1();
            }
            throw ex;
        }
    }

    @Override
    public FirewallRulesAnalyticsTableDataResponseV1 getFirewallRulesAnalyticsTableDataByNetworkId(String networkId, LocalDateTime startDate, LocalDateTime endDate, String deviceId, Integer count) {
        networkValidator.validateNetworkId(networkId);

        String deviceName = null;
        if (deviceId != null) {
            DeviceResponseV1 deviceResponse = deviceService.getApiDeviceAndVerify(deviceId);
            deviceName = deviceResponse.getResourceName();
        }
        SiteResponseV1 site = getSiteByNetworkId(networkId);
        try {
            return analyticsApiClient.getFirewallRulesAnalyticsTableDataByNetworkId(site, deviceName, startDate, endDate, count);
        } catch (SdwanException ex) {
            log.error(FAILED_TO_GET_SLA_METRICS_TABLE_DATA, ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new FirewallRulesAnalyticsTableDataResponseV1();
            }
            throw ex;
        }
    }

    @Override
    public FirewallZonesAnalyticsTableDataResponseV1 getFirewallZonesAnalyticsTableDataByNetworkId(String networkId, LocalDateTime startDate, LocalDateTime endDate, String deviceId, Integer count) {
        networkValidator.validateNetworkId(networkId);

        String deviceName = null;
        if (deviceId != null) {
            DeviceResponseV1 deviceResponse = deviceService.getApiDeviceAndVerify(deviceId);
            deviceName = deviceResponse.getResourceName();
        }
        SiteResponseV1 site = getSiteByDeviceId(deviceId);

        if (!isCloudGateway(site.getSiteType().getValue())) {
            throw new SdwanUnprocessableEntityException(ANALYTIC_ONLY_AVAILABLE_FOR_CLOUD_GATEWAY_SITES);
        }

        try {
            FirewallZonesAnalyticsTableDataResponseV1 response = analyticsApiClient.getFirewallZonesAnalyticsTableDataByNetworkId(site, deviceName, startDate, endDate, count);
            convertFirewallZonesTabularPtviToSdwan(response.getFirewallZonesAnalytics());
            return response;
        } catch (SdwanException ex) {
            log.error(FAILED_TO_GET_FIREWALL_ZONES_ANALYTICS, ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new FirewallZonesAnalyticsTableDataResponseV1();
            }
            throw ex;
        }
    }

    @Override
    public FirewallRulesAnalyticsTimeSeriesDataResponseV1 getFirewallRulesAnalyticsTimeSeriesByNetworkId(String networkId, LocalDateTime startDate, LocalDateTime endDate, String deviceId, Integer count) {
        networkValidator.validateNetworkId(networkId);

        String deviceName = null;
        if (deviceId != null) {
            DeviceResponseV1 deviceResponse = deviceService.getApiDeviceAndVerify(deviceId);
            deviceName = deviceResponse.getResourceName();
        }

        SiteResponseV1 site = getSiteByNetworkId(networkId);
        try {
            return analyticsApiClient.getFirewallRulesAnalyticsTimeSeriesByNetworkId(site, deviceName, startDate, endDate, count);
        } catch (SdwanException ex) {
            log.error(FAILED_TO_GET_SLA_METRICS_TABLE_DATA, ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new FirewallRulesAnalyticsTimeSeriesDataResponseV1();
            }
            throw ex;
        }
    }


    @Override
    public FirewallZonesAnalyticsTimeSeriesDataResponseV1 getFirewallZonesAnalyticsTimeSeriesByNetworkId(String networkId, LocalDateTime startDate, LocalDateTime endDate, String deviceId, Integer count) {
        networkValidator.validateNetworkId(networkId);

        String deviceName = null;
        if (deviceId != null) {
            DeviceResponseV1 deviceResponse = deviceService.getApiDeviceAndVerify(deviceId);
            deviceName = deviceResponse.getResourceName();
        }

        SiteResponseV1 site = getSiteByDeviceId(deviceId);

        if (!isCloudGateway(site.getSiteType().getValue())) {
            throw new SdwanUnprocessableEntityException(ANALYTIC_ONLY_AVAILABLE_FOR_CLOUD_GATEWAY_SITES);
        }

        try {
            FirewallZonesAnalyticsTimeSeriesDataResponseV1 response = analyticsApiClient.getFirewallZonesAnalyticsTimeSeriesByNetworkId(site, deviceName, startDate, endDate, count);
            convertFirewallZonesTimeSeriesPtviToSdwan(response);
            return response;
        } catch (SdwanException ex) {
            log.error(FAILED_TO_GET_FIREWALL_ZONES_ANALYTICS, ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new FirewallZonesAnalyticsTimeSeriesDataResponseV1();
            }
            throw ex;
        }
    }

    @Override
    public TopUsageResponseV1 getTopAccessCircuitsByNetworkId(String networkId, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        networkValidator.validateNetworkId(networkId);

        SiteResponseV1 site = getSiteByNetworkId(networkId);

        try {
            return analyticsApiClient.getTopAccessCircuitsByNetworkId(site, startDate, endDate, count);
        } catch (SdwanException ex) {
            log.error("Failed to get Top Access Circuits", ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new TopUsageResponseV1();
            }
            throw ex;
        }
    }

    @Override
    public TopUsageResponseV1 getTopDevicesByNetworkId(String networkId, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        networkValidator.validateNetworkId(networkId);

        SiteResponseV1 site = getSiteByNetworkId(networkId);

        try {
            return analyticsApiClient.getTopDevicesByNetworkId(site, startDate, endDate, count);
        } catch (SdwanException ex) {
            log.error("Failed to get Top Devices", ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new TopUsageResponseV1();
            }
            throw ex;
        }
    }

    @Override
    public UsageByPathAnalyticsTableDataResponseV1 getUsageByPathAnalyticsTableDataBySiteIdAndDeviceId(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, String remoteDeviceId, String interfaceId, Integer count) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);

        String remoteDeviceName = null;
        if (remoteDeviceId != null) {
            DeviceResponseV1 remoteDevice = deviceService.getApiDeviceAndVerify(remoteDeviceId);
            remoteDeviceName = remoteDevice.getResourceName();
        }
        String interfaceCircuitName = null;
        if (interfaceId != null) {
            InterfaceResponseV1 interfacesResponse = interfaceService.getByDeviceAndInterfaceIdAndVerify(deviceResponse, interfaceId);
            interfaceCircuitName = interfacesResponse.getCircuitName();
        }

        siteResponseValidator.hasValidSiteAndDeviceValues(siteResponse);

        try {
            return analyticsApiClient.getUsageByPathAnalyticsTableDataBySiteIdAndDeviceId(siteResponse, deviceResponse, remoteDeviceName, interfaceCircuitName, startDate, endDate, count);
        } catch (SdwanException ex) {
            log.error("Failed to get Usage by Path Analytics", ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new UsageByPathAnalyticsTableDataResponseV1();
            }
            throw ex;
        }
    }

    @Override
    public UsageByPathAnalyticsTimeSeriesDataResponseV1 getUsageByPathAnalyticsTimeSeriesBySiteIdAndDeviceId(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, String remoteDeviceId, String interfaceId, Integer count) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);

        String remoteDeviceName = null;
        if (remoteDeviceId != null) {
            DeviceResponseV1 remoteDevice = deviceService.getApiDeviceAndVerify(remoteDeviceId);
            remoteDeviceName = remoteDevice.getResourceName();
        }

        String interfaceCircuitName = null;
        if (interfaceId != null) {
            InterfaceResponseV1 interfacesResponse = interfaceService.getByDeviceAndInterfaceIdAndVerify(deviceResponse, interfaceId);
            interfaceCircuitName = interfacesResponse.getCircuitName();
        }

        siteResponseValidator.hasValidSiteAndDeviceValues(siteResponse);


        try {
            return analyticsApiClient.getUsageByPathAnalyticsTimeSeriesBySiteIdAndDeviceId(siteResponse, deviceResponse, remoteDeviceName, interfaceCircuitName, startDate, endDate, count);
        } catch (SdwanException ex) {
            log.error("Failed to get Usage by Path Analytics", ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new UsageByPathAnalyticsTimeSeriesDataResponseV1();
            }
            throw ex;
        }
    }

    @Override
    public UsersAnalyticsTableDataResponseV1 getUsersAnalyticsTableDataBySiteIdAndDeviceId(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, String interfaceId, Integer count) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);

        String interfaceCircuitName = null;
        if (interfaceId != null) {
            InterfaceResponseV1 interfacesResponse = interfaceService.getByDeviceAndInterfaceIdAndVerify(deviceResponse, interfaceId);
            interfaceCircuitName = interfacesResponse.getCircuitName();
        }

        siteResponseValidator.hasValidSiteAndDeviceValues(siteResponse);

        try {
            return analyticsApiClient.getUsersAnalyticsTableDataBySiteIdAndDeviceId(siteResponse, deviceResponse, interfaceCircuitName, startDate, endDate, count);
        } catch (SdwanException ex) {
            log.error(FAILED_TO_GET_USERS_ANALYTICS, ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new UsersAnalyticsTableDataResponseV1();
            }
            throw ex;
        }
    }

    @Override
    public UsersAnalyticsTimeSeriesDataResponseV1 getUsersAnalyticsTimeSeriesBySiteIdAndDeviceId(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, String interfaceId, Integer count) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);

        String interfaceCircuitName = null;
        if (interfaceId != null) {
            InterfaceResponseV1 interfacesResponse = interfaceService.getByDeviceAndInterfaceIdAndVerify(deviceResponse, interfaceId);
            interfaceCircuitName = interfacesResponse.getCircuitName();
        }

        siteResponseValidator.hasValidSiteAndDeviceValues(siteResponse);

        try {
            return analyticsApiClient.getUsersAnalyticsTimeSeriesBySiteIdAndDeviceId(siteResponse, deviceResponse, interfaceCircuitName, startDate, endDate, count);
        } catch (SdwanException ex) {
            log.error(FAILED_TO_GET_USERS_ANALYTICS, ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new UsersAnalyticsTimeSeriesDataResponseV1();
            }
            throw ex;
        }
    }

    private SiteResponseV1 getSiteByNetworkId(String networkId) {
        return sitesService.getAllByUserTenants().stream()
                .filter(site -> site.getNetworkId().equals(networkId))
                .findFirst()
                .orElseThrow(() -> new SdwanNotFoundException("No valid site found for this networkId " + networkId));
    }


    private SiteResponseV1 getSiteByDeviceId(String deviceId) {
        LongFilter deviceIdFilter = new LongFilter();
        deviceIdFilter.setEquals(Long.valueOf(deviceId));
        SiteCriteria siteCriteria = new SiteCriteria();
        siteCriteria.setDeviceId(deviceIdFilter);

        List<SiteResponseV1> sites = serviceApiClient.getSiteDetailsByCriteria(siteCriteria);

        if (sites == null || sites.isEmpty()) {
            throw new SdwanBadRequestException("Cannot find site to device");
        }

        return sites.get(0);
    }

    @Override
    public List<AntivirusDetectionEventResponseV1> getAntivirusDetectionEvents(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        try {
            return analyticsApiClient.getAntivirusDetectionEvents(siteResponse, deviceResponse, startDate, endDate, count);
        } catch (SdwanException ex) {
            log.error("Failed to get device antivirus detection events", ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new ArrayList<>();
            }
            throw ex;
        }
    }

    @Override
    public List<SystemAnalyticsTimeSeriesResponseV1> getSystemTimeSeriesAnalytics(String siteId, String deviceId, LocalDateTime startDt, LocalDateTime endDt) {
        SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (!isBranchOrDedicatedGateway(siteResponse.getSiteType().getValue())) {
            throw new SdwanBadRequestException("This analytic is only available for Branch Sites");
        }

        DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        try {
            return analyticsApiClient.getSystemSeriesAnalytics(siteResponse, deviceResponse, startDt, endDt);
        } catch (SdwanException ex) {
            log.error("Failed to get System Timeseries analytics", ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new ArrayList<>();
            }
            throw ex;
        }
    }

    @Override
    public List<VulnerabilityDetectionEventResponseV1> getVulnerabilityDetectionEvents(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        try {
            return analyticsApiClient.getVulnerabilityDetectionEvents(siteResponse, deviceResponse, startDate, endDate, count);
        } catch (SdwanException ex) {
            log.error("Failed to get device idp vulnerability detection events", ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new ArrayList<>();
            }
            throw ex;
        }
    }

    @Override
    public List<IPFilteringDetectionEventResponseV1> getIpFilteringDetectionEvents(String siteId, String deviceId, LocalDateTime startDate, LocalDateTime endDate, Integer count) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);
        final DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);
        try {
            return analyticsApiClient.getIpFilteringDetectionEvents(siteResponse, deviceResponse, startDate, endDate, count);
        } catch (SdwanException ex) {
            log.error("Failed to get device ip filtering detection events", ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new ArrayList<>();
            }
            throw ex;
        }
    }

    @Override
    public VrfTimeSeriesAnalyticsResponseV1 getVrfTimeSeriesAnalytics(
            String siteId,
            String deviceId,
            LocalDateTime startDate,
            LocalDateTime endDate,
            String interfaceId,
            Integer count) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (!isCloudGateway(siteResponse.getSiteType().getValue())) {
            throw new SdwanUnprocessableEntityException(ANALYTIC_ONLY_AVAILABLE_FOR_CLOUD_GATEWAY_SITES);
        }

        final DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);

        String interfaceCircuitName = null;
        if (interfaceId != null) {
            InterfaceResponseV1 interfacesResponse = interfaceService.getByDeviceAndInterfaceIdAndVerify(deviceResponse, interfaceId);
            interfaceCircuitName = interfacesResponse.getCircuitName();
        }

        try {
            return analyticsApiClient.getVrfTimeSeriesAnalytics(siteResponse, deviceResponse, interfaceCircuitName, startDate, endDate, count);
        } catch (SdwanException ex) {
            log.error("Failed to get VRF Analytics", ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new VrfTimeSeriesAnalyticsResponseV1();
            }
            throw ex;
        }
    }

    @Override
    public VrfTableDataAnalyticsResponseV1 getVrfTableDataAnalytics(
            String siteId,
            String deviceId,
            LocalDateTime startDate,
            LocalDateTime endDate,
            String interfaceId,
            Integer count) {
        final SiteResponseV1 siteResponse = sitesService.getApiSiteAndVerify(siteId);

        if (!isCloudGateway(siteResponse.getSiteType().getValue())) {
            throw new SdwanUnprocessableEntityException(ANALYTIC_ONLY_AVAILABLE_FOR_CLOUD_GATEWAY_SITES);
        }

        final DeviceResponseV1 deviceResponse = deviceService.getFromSiteAndValidate(siteResponse, deviceId);

        String interfaceCircuitName = null;
        if (interfaceId != null) {
            InterfaceResponseV1 interfacesResponse = interfaceService.getByDeviceAndInterfaceIdAndVerify(
                    deviceResponse, interfaceId);
            interfaceCircuitName = interfacesResponse.getCircuitName();
        }

        try {
            return analyticsApiClient.getVrfTableDataAnalytics(
                    siteResponse, deviceResponse, interfaceCircuitName, startDate, endDate, count);
        } catch (SdwanException ex) {
            log.error(FAILED_TO_GET_USERS_ANALYTICS, ex);
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                return new VrfTableDataAnalyticsResponseV1();
            }
            throw ex;
        }
    }

    private void convertFirewallZonesTabularPtviToSdwan(List<FirewallZonesAnalyticsRowDataResponseV1> firewallZonesAnalyticsRowDataResponseV1s) {
        if (firewallZonesAnalyticsRowDataResponseV1s != null) {
            for (FirewallZonesAnalyticsRowDataResponseV1 analytics : firewallZonesAnalyticsRowDataResponseV1s) {
                if (analytics.getZone().equals("ptvi")) {
                    analytics.setZone("SDWAN");
                }
            }
        }
    }

    private void convertFirewallZonesTimeSeriesPtviToSdwan(FirewallZonesAnalyticsTimeSeriesDataResponseV1 response) {
        if (response != null) {
            convertFirewallZonesTimeSeriesPtviToSdwan(response.getBandwidth(), "name");
            convertFirewallZonesTimeSeriesPtviToSdwan(response.getBwRx(), "name");
            convertFirewallZonesTimeSeriesPtviToSdwan(response.getBwTx(), "name");
            convertFirewallZonesTimeSeriesPtviToSdwan(response.getDuration(), "name");
            convertFirewallZonesTimeSeriesPtviToSdwan(response.getSessions(), "name");
            convertFirewallZonesTimeSeriesPtviToSdwan(response.getVolumeRx(), "name");
            convertFirewallZonesTimeSeriesPtviToSdwan(response.getVolumeTx(), "name");

        }
    }

    private void convertFirewallZonesTimeSeriesPtviToSdwan(List<?> data, String propertyName) {
        // Terrible solution but since no parent object or interface, this is the quickest way to go
        if (data != null) {
            try {
                PropertyDescriptor pd;
                for (Object analytics : data) {
                    pd = new PropertyDescriptor(propertyName, analytics.getClass());
                    Method getter = pd.getReadMethod();
                    if (getter.invoke(analytics) != null && getter.invoke(analytics).equals("ptvi")) {
                        Method setter = pd.getWriteMethod();
                        setter.invoke(analytics, "SDWAN");
                    }
                }
            } catch (IntrospectionException | InvocationTargetException | IllegalAccessException e) {
                log.error("Error converting PTVI to SDWAN", e);
            }
        }
    }
}
