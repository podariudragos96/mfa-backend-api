package net.colt.sdwan.portal.services;

import net.colt.sdwan.portal.model.SaseTaskResponseV1;
import net.colt.sdwan.portal.model.SaseTasksResponseV1;

public interface SaseTaskService {

    SaseTasksResponseV1 getTasksV1(String tenantUuid, Integer pageNumber, Integer pageSize);

    SaseTaskResponseV1 getTaskV1(String tenantUuid, String taskUuid);

}
