package net.colt.sdwan.portal.client.feign;

import feign.auth.BasicAuthRequestInterceptor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.colt.sdwan.common.data.criteria.config.AbstractCriteriaApiFeignConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

@Slf4j
@RequiredArgsConstructor
public class PlannedMessageApiFeignConfiguration extends AbstractCriteriaApiFeignConfiguration {

    private final Environment env;

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        return new BasicAuthRequestInterceptor(env.getProperty("sdwan.system.api.user"), env.getProperty("sdwan.system.api.pwd"));
    }
}
