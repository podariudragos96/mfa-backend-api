package net.colt.sdwan.portal.controllers;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.SiteApiApi;
import net.colt.sdwan.portal.model.CorrelationIdResponseV1;
import net.colt.sdwan.portal.model.SiteRequestV1;
import net.colt.sdwan.portal.model.SiteResponseV3;
import net.colt.sdwan.portal.security.annotation.SDWanAsyncMethod;
import net.colt.sdwan.portal.services.SitesService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

import static org.springframework.http.HttpStatus.OK;

@RequiredArgsConstructor
@Controller
public class SitesController implements SiteApiApi {

    private final SitesService sitesService;

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<List<SiteResponseV3>> getAllSitesV3() {
        return new ResponseEntity<>(sitesService.getAllSitesV3(), OK);
    }

    @Override
    public ResponseEntity<SiteResponseV3> getSiteBySiteIdV3(String siteId) {
        return new ResponseEntity<>(sitesService.getSiteBySiteIdV3(siteId), OK);
    }

    @Override
    @SDWanAsyncMethod
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<CorrelationIdResponseV1> rediscoverBySiteIdV1(String siteId) {
        return ResponseEntity.ok(sitesService.rediscoverBySiteId(siteId));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole','SD-WANRWFirewallRole')")
    public ResponseEntity<Void> updateSiteWithStatusOrFriendlyNameV1(String siteId, @RequestBody SiteRequestV1 body) {
        sitesService.updateSiteWithStatusOrFriendlyName(siteId, body);
        return new ResponseEntity<>(OK);
    }
}
