package net.colt.sdwan.portal.mappers;

import net.colt.sdwan.metadata.api.generated.model.MetadataCriteriaApi;
import net.colt.sdwan.metadata.api.generated.model.UrlCategoriesResponseV1;
import net.colt.sdwan.portal.model.MetadataCriteria;
import net.colt.sdwan.portal.model.UrlPredefinedCategoriesResponseV1;
import org.mapstruct.Mapper;

@Mapper
public interface UrlCategoryDetailsMapper {

    MetadataCriteriaApi from(MetadataCriteria criteria);

    UrlPredefinedCategoriesResponseV1 from(final UrlCategoriesResponseV1 urlCategoriesResponseV1);

}
