package net.colt.sdwan.portal.controllers;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import net.colt.sdwan.portal.generated.controllers.SaseApiApi;
import net.colt.sdwan.portal.model.*;
import net.colt.sdwan.portal.services.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;


@Controller
@RequiredArgsConstructor
public class SaseController implements SaseApiApi {

    private final SaseTenantService saseTenantService;
    private final SaseSamlAuthenticationProfileService saseSamlAuthenticationProfileService;
    private final SaseTaskService saseTaskService;
    private final SaseSecureAccessClientProfileService saseSecureAccessClientProfileService;
    private final SaseInternetProtectionRuleService saseInternetProtectionRuleService;
    private final SaseSecureAccessClientRuleService saseSecureAccessClientRuleService;
    private final SaseSiteToSiteTunnelService saseSiteToSiteTunnelService;
    private final SaseCatalogService saseCatalogService;

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SaseTenantResponseV1> getTenantV1(String networkId) {
        return ResponseEntity.of(saseTenantService.getTenantV1(networkId));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SaseSamlAuthenticationProfilesResponseV1> getSamlAuthenticationProfilesV1(String tenantUuid) {
        return ResponseEntity.ok(saseSamlAuthenticationProfileService.getSamlAuthenticationProfilesV1(tenantUuid));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateSamlAuthenticationProfileV1(String tenantUuid,String samlUuid,
            @Valid @RequestBody SaseSamlAuthenticationProfileRequestV1 saseSamlAuthenticationProfileRequestV1) {
        return ResponseEntity.ok(saseSamlAuthenticationProfileService.updateSamlAuthenticationProfileV1(
                tenantUuid, samlUuid, saseSamlAuthenticationProfileRequestV1));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SaseTasksResponseV1> getTasksV1(String tenantUuid, Integer pageNumber, Integer pageSize) {
        return ResponseEntity.ok(saseTaskService.getTasksV1(tenantUuid, pageNumber, pageSize));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SaseTaskResponseV1> getTaskV1(String tenantUuid, String taskUuid) {
        return ResponseEntity.ok(saseTaskService.getTaskV1(tenantUuid, taskUuid));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SecureAccessClientProfilesResponseV1> getSecureAccessClientProfilesV1(String tenantUuid) {
        return ResponseEntity.ok(saseSecureAccessClientProfileService.getSecureAccessClientProfilesV1(tenantUuid));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateSecureAccessClientProfilesV1(String tenantUuid,
            @RequestBody SecureAccessClientProfilesRequestV1 secureAccessClientProfilesRequestV1) {
        return ResponseEntity.ok(saseSecureAccessClientProfileService.updateSecureAccessClientProfilesV1(tenantUuid, secureAccessClientProfilesRequestV1));
    }

    /*
     * Site to Site Tunnels
     */
    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SaseSiteToSiteTunnelsResponseV1> getSiteToSiteTunnelsV1(String tenantUuid) {
        return ResponseEntity.ok(saseSiteToSiteTunnelService.getSiteToSiteTunnelsV1(tenantUuid));
    }

    /*
     * Internet Protection Rules
     */
    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<InternetProtectionRulesResponseV1> getInternetProtectionRulesV1(String tenantUuid) {
        return ResponseEntity.ok(saseInternetProtectionRuleService.getInternetProtectionRulesV1(tenantUuid));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateInternetProtectionRulesV1(String tenantUuid,
            @RequestBody InternetProtectionRulesRequestV1 internetProtectionRulesRequestV1) {
        return ResponseEntity.ok(saseInternetProtectionRuleService.updateInternetProtectionRulesV1(tenantUuid, internetProtectionRulesRequestV1));
    }

    /*
     * Secure Access Client Rules
     */
    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SaseSecureAccessClientRulesResponseV1> getSecureAccessClientRulesV1(String tenantUuid) {
        return ResponseEntity.ok(saseSecureAccessClientRuleService.getSecureAccessClientRulesV1(tenantUuid));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadWriteRole')")
    public ResponseEntity<CorrelationIdResponseV1> updateSecureAccessClientRulesV1(String tenantUuid,
                                                                                   SaseSecureAccessClientRulesRequestV1 saseSecureAccessClientRulesRequestV1) {
        return ResponseEntity.ok(saseSecureAccessClientRuleService.updateSecureAccessClientRulesV1(tenantUuid, saseSecureAccessClientRulesRequestV1));
    }

    /*
     * Catalogs
     */
    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SaseGeoIpCountriesCatalogResponseV1> getGeoIpCountriesV1(String tenantUuid) {
        return ResponseEntity.ok(saseCatalogService.getGeoIpCountriesV1(tenantUuid));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SaseUrlCategoriesCatalogResponseV1> getPredefinedUrlCategoriesV1(String tenantUuid) {
        return ResponseEntity.ok(saseCatalogService.getUrlCategoriesV1(tenantUuid));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SaseUrlReputationsCatalogResponseV1> getUrlReputationsV1(String tenantUuid) {
        return ResponseEntity.ok(saseCatalogService.getUrlReputationsV1(tenantUuid));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SaseApplicationsCatalogResponseV1> getApplicationsV1(String tenantUuid) {
        return ResponseEntity.ok(saseCatalogService.getApplicationsV1(tenantUuid));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SaseApplicationCategoriesCatalogResponseV1> getApplicationCategoriesV1(String tenantUuid) {
        return ResponseEntity.ok(saseCatalogService.getApplicationCategoriesV1(tenantUuid));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SaseApplicationGroupsCatalogResponseV1> getApplicationGroupsV1(String tenantUuid) {
        return ResponseEntity.ok(saseCatalogService.getApplicationGroupsV1(tenantUuid));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SaseServicesCatalogResponseV1> getServicesV1(String tenantUuid) {
        return ResponseEntity.ok(saseCatalogService.getServicesV1(tenantUuid));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SaseSecurityProfilesCatalogResponseV1> getSecurityProfilesV1(String tenantUuid) {
        return ResponseEntity.ok(saseCatalogService.getSecurityProfilesV1(tenantUuid));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<SaseStaticZonesCatalogResponseV1> getStaticZonesV1() {
        return ResponseEntity.ok(saseCatalogService.getStaticZonesV1());
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<EndpointProtectionsCatalogResponseV1> getEndpointProtectionsV1(String tenantUuid) {
        return ResponseEntity.ok(saseCatalogService.getEndpointProtectionsV1(tenantUuid));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<OperatingSystemsCatalogResponseV1> getOperatingSystemsV1(String tenantUuid) {
        return ResponseEntity.ok(saseCatalogService.getOperatingSystemsV1(tenantUuid));
    }

    @Override
    @PreAuthorize("hasAnyAuthority('SD-WANReadOnlyRole','SD-WANReadWriteRole')")
    public ResponseEntity<ApplicationsCatalogResponseV1> getSaseApplicationsV1(String tenantUuid) {
        return ResponseEntity.ok(saseCatalogService.getSaseApplicationsV1(tenantUuid));
    }

}
