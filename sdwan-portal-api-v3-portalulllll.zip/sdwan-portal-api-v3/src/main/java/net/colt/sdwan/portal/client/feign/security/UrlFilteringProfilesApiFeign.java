package net.colt.sdwan.portal.client.feign.security;

import net.colt.sdwan.security.api.generated.api.UrlFilteringApiApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "urlFilteringProfilesApiClient", url = "${sdwan.security.api.baseurl}",
        configuration = SecurityApiFeignConfiguration.class)
public interface UrlFilteringProfilesApiFeign extends UrlFilteringApiApi {
}
