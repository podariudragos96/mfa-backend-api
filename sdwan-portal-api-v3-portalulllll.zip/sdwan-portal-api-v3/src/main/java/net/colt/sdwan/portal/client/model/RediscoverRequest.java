package net.colt.sdwan.portal.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RediscoverRequest {

    @JsonProperty("customer_name")
    private String customerName;

    @JsonProperty("status")
    private String status;

    @JsonProperty("device_name")
    private String deviceName;

    @JsonProperty("site_id")
    private Integer siteId;
}
