package net.colt.sdwan.identity.controller;

import net.colt.sdwan.generated.model.identityaccess.UserApiV1;
import net.colt.sdwan.identity.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserControllerTest {

    @Test
    void addUserV1_shouldReturn201AndBody() {
        UserService svc = mock(UserService.class);
        UserController c = new UserController(svc);

        UserApiV1 u = new UserApiV1();
        when(svc.createUser(eq("g1"), eq(u))).thenReturn(u);

        ResponseEntity<UserApiV1> r = c.addUserV1("g1", u);
        assertEquals(201, r.getStatusCodeValue());
        assertSame(u, r.getBody());
    }

    @Test
    void usersLookupV1_shouldReturnList() {
        UserService svc = mock(UserService.class);
        UserController c = new UserController(svc);

        when(svc.listUsers("g1")).thenReturn(List.of(new UserApiV1()));

        ResponseEntity<List<UserApiV1>> r = c.usersLookupV1("g1");
        assertEquals(200, r.getStatusCodeValue());
        assertEquals(1, r.getBody().size());
    }

    @Test
    void deleteUserByIdV1_shouldReturn204() {
        UserService svc = mock(UserService.class);
        UserController c = new UserController(svc);

        ResponseEntity<Void> r = c.deleteUserByIdV1("g1", "alice");
        assertEquals(204, r.getStatusCodeValue());
        verify(svc).deleteUser("g1", "alice");
    }

}
