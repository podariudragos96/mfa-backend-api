package net.colt.sdwan.identity.service.impl;

import net.colt.sdwan.generated.model.identityaccess.*;
import net.colt.sdwan.identity.dto.Attempt;
import net.colt.sdwan.identity.service.DirectGrantService;
import net.colt.sdwan.identity.service.SmsService;
import net.colt.sdwan.identity.service.UserService;
import net.colt.sdwan.identity.util.EmailSender;
import net.colt.sdwan.identity.util.PendingMfaStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.*;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.RealmRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.mockito.ArgumentCaptor;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class AuthFlowServiceImplTest {

    private Keycloak keycloak;
    private DirectGrantService dgs;
    private PendingMfaStore store;
    private EmailSender emailSender;
    private SmsService smsService;
    private UserService userService;

    private AuthFlowServiceImpl svc;

    @BeforeEach
    void setup() {
        keycloak = mock(Keycloak.class);
        dgs = mock(DirectGrantService.class);
        store = new PendingMfaStore();
        emailSender = mock(EmailSender.class);
        smsService = mock(SmsService.class);
        userService = mock(UserService.class);

        svc = new AuthFlowServiceImpl(keycloak, dgs, store, emailSender, smsService, userService);
    }

    private void stubUserFoundAcrossRealms(
            String realmName,
            String userId,
            UserRepresentation rep,
            List<CredentialRepresentation> creds
    ) {
        RealmsResource realms = mock(RealmsResource.class);
        when(keycloak.realms()).thenReturn(realms);

        RealmRepresentation rr = new RealmRepresentation();
        rr.setRealm(realmName);
        when(realms.findAll()).thenReturn(List.of(rr));

        RealmResource realm = mock(RealmResource.class);
        UsersResource users = mock(UsersResource.class);
        UserResource ur = mock(UserResource.class);

        when(realms.realm(realmName)).thenReturn(realm);
        when(realm.users()).thenReturn(users);

        UserRepresentation found = new UserRepresentation();
        found.setId(userId);
        found.setUsername(rep.getUsername());
        when(users.search(eq(rep.getUsername()), eq(true))).thenReturn(List.of(found));

        when(users.get(userId)).thenReturn(ur);
        when(ur.toRepresentation()).thenReturn(rep);
        when(ur.credentials()).thenReturn(creds);

        when(keycloak.realms().realm(realmName)).thenReturn(realm);
        when(realm.users().get(userId)).thenReturn(ur);
    }

    @Test
    void authLogin_shouldReturn400_whenSessionIdBlank() {
        LoginRequestApiV1 req = new LoginRequestApiV1();
        req.setSessionId("   ");
        req.setUsername("alice");
        req.setPassword("pw");

        ResponseEntity<LoginResponseApiV1> resp = svc.authLogin(req, true);
        assertEquals(400, resp.getStatusCodeValue());
    }

    @Test
    void authLogin_shouldReturn404_whenUserNotFoundAcrossRealms() {
        RealmsResource realms = mock(RealmsResource.class);
        when(keycloak.realms()).thenReturn(realms);
        when(realms.findAll()).thenReturn(List.of());

        LoginRequestApiV1 req = new LoginRequestApiV1();
        req.setSessionId("sid-1");
        req.setUsername("alice");
        req.setPassword("pw");

        ResponseEntity<LoginResponseApiV1> resp = svc.authLogin(req, true);
        assertEquals(404, resp.getStatusCodeValue());
    }

    @Test
    void authLogin_shouldReturn401_whenInvalidCredentials() {
        UserRepresentation rep = new UserRepresentation();
        rep.setUsername("alice");
        rep.setEmail("alice@example.com");
        rep.setEmailVerified(true);

        stubUserFoundAcrossRealms("realmA", "uid1", rep, List.of());

        when(dgs.validateCredentialsDetailed(eq("realmA"), eq("alice"), eq("pw"), isNull(), isNull()))
                .thenReturn(new DirectGrantServiceImpl.DagResult(false, "invalid_grant", "Invalid user credentials"));

        LoginRequestApiV1 req = new LoginRequestApiV1();
        req.setSessionId("sid-1");
        req.setUsername("alice");
        req.setPassword("pw");

        ResponseEntity<LoginResponseApiV1> resp = svc.authLogin(req, true);
        assertEquals(401, resp.getStatusCodeValue());
    }

    @Test
    void authLogin_shouldReturnProfileInfoAndStoreAttempt_bySessionId() {
        UserRepresentation rep = new UserRepresentation();
        rep.setUsername("alice");
        rep.setEmail("alice@example.com");
        rep.setEmailVerified(true);
        rep.setAttributes(Map.of("phone_number", List.of("+40123456789")));

        CredentialRepresentation otpCred = new CredentialRepresentation();
        otpCred.setType("otp");
        otpCred.setId("cred-otp-1");

        stubUserFoundAcrossRealms("realmA", "uid1", rep, List.of(otpCred));

        when(dgs.validateCredentialsDetailed(eq("realmA"), eq("alice"), eq("pw"), isNull(), isNull()))
                .thenReturn(new DirectGrantServiceImpl.DagResult(true, null, null));

        LoginRequestApiV1 req = new LoginRequestApiV1();
        req.setSessionId("sid-1");
        req.setUsername("alice");
        req.setPassword("pw");

        ResponseEntity<LoginResponseApiV1> resp = svc.authLogin(req, true);
        assertEquals(200, resp.getStatusCodeValue());

        LoginResponseApiV1 body = resp.getBody();
        assertNotNull(body);
        assertEquals("sid-1", body.getSessionId());
        assertTrue(Boolean.TRUE.equals(body.getMfaRequired()));

        assertNotNull(body.getProfileInfo());
        assertNotNull(body.getProfileInfo().getEmail());
        assertTrue(Boolean.TRUE.equals(body.getProfileInfo().getEmail().getEnabled()));
        assertTrue(Boolean.TRUE.equals(body.getProfileInfo().getEmail().getActive()));

        assertNotNull(body.getProfileInfo().getSms());
        assertTrue(Boolean.TRUE.equals(body.getProfileInfo().getSms().getEnabled()));

        assertNotNull(body.getProfileInfo().getOtp());
        assertTrue(Boolean.TRUE.equals(body.getProfileInfo().getOtp().getEnabled()));

        Attempt stored = store.getBySessionId("sid-1");
        assertNotNull(stored);
        assertEquals("realmA", stored.getRealm());
        assertEquals("alice", stored.getUsername());
        assertEquals("uid1", stored.getUserId());
    }

    @Test
    void emailOtp_shouldSendAndVerify_usingCapturedCode() {
        UserRepresentation rep = new UserRepresentation();
        rep.setUsername("alice");
        rep.setEmail("alice@example.com");
        rep.setEmailVerified(true);

        stubUserFoundAcrossRealms("realmA", "uid1", rep, List.of());

        when(dgs.validateCredentialsDetailed(eq("realmA"), eq("alice"), eq("pw"), isNull(), isNull()))
                .thenReturn(new DirectGrantServiceImpl.DagResult(true, null, null));

        LoginRequestApiV1 login = new LoginRequestApiV1();
        login.setSessionId("sid-otp");
        login.setUsername("alice");
        login.setPassword("pw");

        ResponseEntity<LoginResponseApiV1> loginResp = svc.authLogin(login, true);
        assertEquals(200, loginResp.getStatusCodeValue());
        assertNotNull(store.getBySessionId("sid-otp"));

        SendEmailReqApiV1 send = new SendEmailReqApiV1();
        send.setSessionId("sid-otp");

        ResponseEntity<AuthMfaEmailSend200Response> sendResp = svc.sendEmailOtp(send);
        assertEquals(200, sendResp.getStatusCodeValue());
        assertNotNull(sendResp.getBody());
        assertTrue(Boolean.TRUE.equals(sendResp.getBody().getSent()));

        ArgumentCaptor<String> otpCaptor = ArgumentCaptor.forClass(String.class);
        verify(emailSender, times(1)).sendOtp(eq("alice@example.com"), otpCaptor.capture());
        String otpCode = otpCaptor.getValue();
        assertNotNull(otpCode);
        assertFalse(otpCode.isBlank());

        VerifyEmailReqApiV1 verify = new VerifyEmailReqApiV1();
        verify.setSessionId("sid-otp");
        verify.setCode(otpCode);

        when(userService.getUser(anyString(), anyString())).thenReturn(new UserApiV1("id", "username", "email", "firstName", "lastName", "pass", "phone", "group", true));

        ResponseEntity<VerifyOtpProfileResponseApiV1> verifyResp = svc.verifyEmailOtp(verify);
        assertEquals(200, verifyResp.getStatusCodeValue());
    }

    @Test
    void deleteTotp_shouldRemoveOtpCredential() {
        UserRepresentation rep = new UserRepresentation();
        rep.setUsername("alice");

        CredentialRepresentation otpCred = new CredentialRepresentation();
        otpCred.setType("otp");
        otpCred.setId("cred-1");

        stubUserFoundAcrossRealms("realmA", "uid1", rep, List.of(otpCred));

        store.saveForSessionId("sid-del", "realmA", "alice", "uid1", "pw");

        DeleteTotpRequestApiV1 del = new DeleteTotpRequestApiV1();
        del.setSessionId("sid-del");

        RealmResource realm = keycloak.realms().realm("realmA");
        UserResource ur = realm.users().get("uid1");

        ResponseEntity<Void> resp = svc.deleteTotp(del);
        assertEquals(200, resp.getStatusCodeValue());

        verify(ur, times(1)).removeCredential("cred-1");
    }

    @Test
    void smsOtp_shouldSend_andReturnSentTrueBasedOnSmsService() {
        UserRepresentation rep = new UserRepresentation();
        rep.setUsername("alice");
        rep.setEmail("alice@example.com");
        rep.setEmailVerified(true);
        rep.setAttributes(Map.of("phone_number", List.of("+40123456789")));

        stubUserFoundAcrossRealms("realmA", "uid1", rep, List.of());

        when(dgs.validateCredentialsDetailed(eq("realmA"), eq("alice"), eq("pw"), isNull(), isNull()))
                .thenReturn(new DirectGrantServiceImpl.DagResult(true, null, null));

        when(smsService.wasSmsSent()).thenReturn(true);

        LoginRequestApiV1 login = new LoginRequestApiV1();
        login.setSessionId("sid-sms");
        login.setUsername("alice");
        login.setPassword("pw");

        ResponseEntity<LoginResponseApiV1> loginResp = svc.authLogin(login, true);
        assertEquals(200, loginResp.getStatusCodeValue());

        SendSmsReqApiV1 send = new SendSmsReqApiV1();
        send.setSessionId("sid-sms");

        ResponseEntity<AuthMfaEmailSend200Response> sendResp = svc.sendSmsOtp(send);
        assertEquals(200, sendResp.getStatusCodeValue());
        assertNotNull(sendResp.getBody());
        assertTrue(Boolean.TRUE.equals(sendResp.getBody().getSent()));

        verify(smsService, times(1)).sendSms(
                eq("+40123456789"),
                eq(""),
                anyString(),
                eq("otp.code"),
                eq(java.util.Locale.ENGLISH)
        );
    }

}
