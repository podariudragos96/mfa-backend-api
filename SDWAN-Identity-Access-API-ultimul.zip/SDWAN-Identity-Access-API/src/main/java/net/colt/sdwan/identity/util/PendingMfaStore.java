package net.colt.sdwan.identity.util;

import net.colt.sdwan.identity.dto.Attempt;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class PendingMfaStore {

    /**
     * Everything is keyed by session_id.
     * session_id is created by Portal and passed to Identity-Access to identify the auth flow.
     */
    private final Map<String, Attempt> attemptsBySessionId = new ConcurrentHashMap<>();

    /**
     * Used only for browser TOTP session callback flow if you ever re-add it:
     * state -> session_id
     */
    private final Map<String, String> stateToSessionId = new ConcurrentHashMap<>();

    private static final Duration SESSION_TTL = Duration.ofMinutes(10);

    public void saveForSessionId(String sessionId, String realm, String username, String userId, String passwordOrNull) {
        String key = keySession(sessionId);
        if (key == null) return;

        Instant now = Instant.now();
        Attempt attempt = Attempt.builder()
                .sessionId(key)
                .realm(realm)
                .username(username)
                .userId(userId)
                .password(passwordOrNull)
                .createdAt(now)
                .expiresAt(now.plus(SESSION_TTL))
                .otpHash(null)
                .otpExpiresAt(null)
                .otpVerified(false)
                .otpAttempts(0)
                .build();

        attemptsBySessionId.put(key, attempt);
    }

    public Attempt getBySessionId(String sessionId) {
        String key = keySession(sessionId);
        if (key == null) return null;

        Attempt a = attemptsBySessionId.get(key);
        if (a == null) return null;

        if (a.getExpiresAt() != null && Instant.now().isAfter(a.getExpiresAt())) {
            attemptsBySessionId.remove(key);
            return null;
        }
        return a;
    }

    public void removeBySessionId(String sessionId) {
        String key = keySession(sessionId);
        if (key != null) attemptsBySessionId.remove(key);
    }

    public void putStateMapping(String state, String sessionId) {
        if (state == null || state.isBlank()) return;
        String sid = keySession(sessionId);
        if (sid == null) return;
        stateToSessionId.put(state, sid);
    }

    public String getSessionIdByState(String state) {
        if (state == null || state.isBlank()) return null;
        return stateToSessionId.get(state);
    }

    private String keySession(String sessionId) {
        if (sessionId == null) return null;
        String trimmed = sessionId.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
