package net.colt.sdwan.identity.controller;

import lombok.RequiredArgsConstructor;
import net.colt.sdwan.generated.controller.identityaccess.UserApiApi;
import net.colt.sdwan.generated.model.identityaccess.UserApiV1;
import net.colt.sdwan.generated.model.identityaccess.UserCreateEditRequestApiV1;
import net.colt.sdwan.identity.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class UserController implements UserApiApi {

    private final UserService userService;

    @Override
    public ResponseEntity<UserApiV1> addUserV1(
            @NotNull @PathVariable("user_group_id") String userGroupId,
            @Valid @RequestBody(required = false) @Nullable UserCreateEditRequestApiV1 userApiV1
    ) {
        return ResponseEntity.status(201).body(userService.createUser(userGroupId, userApiV1));
    }

    @Override
    public ResponseEntity<List<UserApiV1>> usersLookupV1(
            @NotNull @PathVariable("user_group_id") String userGroupId
    ) {
        return ResponseEntity.ok(userService.listUsers(userGroupId));
    }

    @Override
    public ResponseEntity<Void> deleteUserByIdV1(
            @NotNull @PathVariable("user_group_id") String userGroupId,
            @NotNull @PathVariable("user_id") String userId
    ) {
        userService.deleteUser(userGroupId, userId);
        return ResponseEntity.noContent().build();
    }

    @Override
    public ResponseEntity<UserApiV1> getUserByIdV1(
            @NotNull @PathVariable("user_group_id") String userGroupId,
            @NotNull @PathVariable("user_id") String userId
    ) {
        return ResponseEntity.ok(userService.getUser(userGroupId, userId));
    }

    @Override
    public ResponseEntity<UserApiV1> updateUserV1(
            @NotNull @PathVariable("user_group_id") String userGroupId,
            @NotNull @PathVariable("user_id") String userId,
            @Valid @RequestBody(required = false) @Nullable UserCreateEditRequestApiV1 userApiV1
    ) {
        return ResponseEntity.ok(userService.updateUser(userGroupId, userId, userApiV1));
    }
}