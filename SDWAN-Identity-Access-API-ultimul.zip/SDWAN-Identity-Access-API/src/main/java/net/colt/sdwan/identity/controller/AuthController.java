package net.colt.sdwan.identity.controller;

import jakarta.validation.Valid;
import net.colt.sdwan.generated.controller.identityaccess.AuthApiApi;
import net.colt.sdwan.generated.controller.identityaccess.MfaApiApi;
import net.colt.sdwan.generated.model.identityaccess.*;
import net.colt.sdwan.identity.service.AuthFlowService;
import net.colt.sdwan.identity.util.EmailSender;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.NativeWebRequest;

import java.util.Optional;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class AuthController implements AuthApiApi, MfaApiApi {

    private final AuthFlowService authFlowService;

    public AuthController(AuthFlowService authFlowService, EmailSender emailSender) {
        this.authFlowService = authFlowService;
    }

    @Override
    public Optional<NativeWebRequest> getRequest() {
        return AuthApiApi.super.getRequest();
    }

    @Override
    public ResponseEntity<LoginResponseApiV1> authLogin(
            @Valid @RequestBody LoginRequestApiV1 loginRequestApiV1,
            @Valid @RequestParam(value = "mfaEnabled", required = false, defaultValue = "true") Boolean mfaEnabled
    ) {
        return authFlowService.authLogin(loginRequestApiV1, mfaEnabled);
    }

    @Override
    public ResponseEntity<AuthMfaEmailSend200Response> authMfaEmailSend(@Valid @RequestBody SendEmailReqApiV1 req) {
        return authFlowService.sendEmailOtp(req);
    }

    @Override
    public ResponseEntity<VerifyOtpProfileResponseApiV1> authMfaEmailVerify(@Valid @RequestBody VerifyEmailReqApiV1 req) {
        return authFlowService.verifyEmailOtp(req);
    }

    @Override
    public ResponseEntity<AuthMfaEmailSend200Response> authMfaSmsSend(@Valid @RequestBody SendSmsReqApiV1 req) {
        return authFlowService.sendSmsOtp(req);
    }

    @Override
    public ResponseEntity<VerifyOtpProfileResponseApiV1> authMfaSmsVerify(@Valid @RequestBody VerifySmsReqApiV1 req) {
        return authFlowService.verifySmsOtp(req);
    }

    @Override
    public ResponseEntity<StartTotpSessionResponseApiV1> authMfaTotpStartSession(@Valid @RequestBody StartTotpSessionRequestApiV1 req) {
        return authFlowService.startTotpSession(req);
    }

    @Override
    public ResponseEntity<VerifyOtpProfileResponseApiV1> authMfaTotpVerify(@Valid @RequestBody VerifyTotpRequestApiV1 req) {
        return authFlowService.verifyTotp(req);
    }

    @Override
    public ResponseEntity<Void> authMfaTotpDelete(@RequestBody(required = false) @Nullable DeleteTotpRequestApiV1 req) {
        return authFlowService.deleteTotp(req);
    }

    @Override
    public ResponseEntity<AuthProfileSetEmail200Response> authProfileSetEmail(@Valid @RequestBody SetEmailRequestApiV1 req) {
        return authFlowService.profileSetEmail(req);
    }

    @Override
    public ResponseEntity<AuthProfileVerifyEmail200Response> authProfileVerifyEmail(@Valid @RequestBody SendEmailReqApiV1 req) {
        return authFlowService.profileVerifyEmail(req);
    }

    @Override
    public ResponseEntity<AuthMfaEmailSend200Response> forgotPasswordV1(ForgotPasswordRequestApiV1 forgotPasswordRequestApiV1) {
        return authFlowService.sendEmailOtp(forgotPasswordRequestApiV1);
    }

    @Override
    public ResponseEntity<Void> resetPasswordV1(@Nullable ResetPasswordRequestApiV1 resetPasswordRequestApiV1) {
        return authFlowService.resetPasswordV1(resetPasswordRequestApiV1);
    }
}
