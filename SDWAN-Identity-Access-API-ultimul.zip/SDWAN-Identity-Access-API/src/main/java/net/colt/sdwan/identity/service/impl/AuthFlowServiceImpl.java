package net.colt.sdwan.identity.service.impl;

import net.colt.sdwan.generated.model.identityaccess.*;
import net.colt.sdwan.identity.dto.Attempt;
import net.colt.sdwan.identity.service.AuthFlowService;
import net.colt.sdwan.identity.service.DirectGrantService;
import net.colt.sdwan.identity.service.SmsService;
import net.colt.sdwan.identity.service.UserService;
import net.colt.sdwan.identity.util.EmailSender;
import net.colt.sdwan.identity.util.OtpUtil;
import net.colt.sdwan.identity.util.PendingMfaStore;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.RealmRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.openapitools.jackson.nullable.JsonNullable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.*;

@Service
public class AuthFlowServiceImpl implements AuthFlowService {

    private static final Duration OTP_TTL = Duration.ofMinutes(5);
    private static final int MAX_OTP_ATTEMPTS = 5;

    private final Keycloak keycloak;
    private final DirectGrantService dgs;
    private final PendingMfaStore store;
    private final EmailSender emailSender;
    private final SmsService smsService;
    private final UserService userService;

    public AuthFlowServiceImpl(Keycloak keycloak,
                               DirectGrantService dgs,
                               PendingMfaStore store,
                               EmailSender emailSender,
                               SmsService smsService,
                               UserService userService) {
        this.keycloak = keycloak;
        this.dgs = dgs;
        this.store = store;
        this.emailSender = emailSender;
        this.smsService = smsService;
        this.userService = userService;
    }

    @Override
    public ResponseEntity<LoginResponseApiV1> authLogin(LoginRequestApiV1 req, Boolean mfaEnabled) {
        String sessionId = safe(req.getSessionId());
        String username = safe(req.getUsername());
        String password = Optional.ofNullable(req.getPassword()).orElse("");

        if (sessionId.isBlank() || username.isBlank()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        FoundUser found = findUserByUsernameExactAcrossRealms(username);
        if (found == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        String realmName = found.realm;
        String userId = found.userId;

        DirectGrantServiceImpl.DagResult dag = dgs.validateCredentialsDetailed(realmName, username, password, null, null);
        if (!dag.ok()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        MfaProfileApiV1 profile = buildMfaProfile(sessionId, username);

        boolean effectiveMfaEnabled = Boolean.TRUE.equals(mfaEnabled) && !Boolean.TRUE.equals(req.getMfaDisabled());
        boolean userHasTotp = profile.getOtp() != null && Boolean.TRUE.equals(profile.getOtp().getEnabled());
        String passwordToStore = (effectiveMfaEnabled && userHasTotp) ? password : null;

        store.saveForSessionId(sessionId, realmName, username, userId, passwordToStore);

        LoginResponseApiV1 resp = LoginResponseApiV1.builder()
                .sessionId(sessionId)
                .mfaRequired(effectiveMfaEnabled)
                .username(JsonNullable.of(username))
                .mfaProfile(profile)
                .build();

        return ResponseEntity.ok(resp);
    }

    @Override
    public ResponseEntity<AuthMfaEmailSend200Response> sendEmailOtp(SendEmailReqApiV1 req) {
        Attempt a = attemptFromSession(req.getSessionId());
        if (a == null) return ResponseEntity.badRequest().body(new AuthMfaEmailSend200Response().sent(false));

        UserRepresentation rep = userRep(a);
        String email = safe(rep.getEmail());

        if (email.isBlank() || !Boolean.TRUE.equals(rep.isEmailVerified())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new AuthMfaEmailSend200Response().sent(false));
        }

        String code = OtpUtil.generate6Digits();
        String hash = OtpUtil.hashForSession(a.getSessionId(), code);

        a.setOtpHash(hash);
        a.setOtpExpiresAt(Instant.now().plus(OTP_TTL));
        a.setOtpVerified(false);
        a.setOtpAttempts(0);

        emailSender.sendOtp(email, code);
        return ResponseEntity.ok(new AuthMfaEmailSend200Response().sent(true));
    }

    @Override
    public ResponseEntity<AuthMfaEmailSend200Response> sendEmailOtp(ForgotPasswordRequestApiV1 req) {

    }

    @Override
    public ResponseEntity<VerifyOtpProfileResponseApiV1> verifyEmailOtp(VerifyEmailReqApiV1 req) {
        Attempt a = attemptFromSession(req.getSessionId());
        if (a == null) return ResponseEntity.badRequest().build();

        String code = safe(req.getCode());
        if (code.isBlank()) return ResponseEntity.badRequest().build();

        if (a.getOtpHash() == null || a.getOtpExpiresAt() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        if (Instant.now().isAfter(a.getOtpExpiresAt())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        if (a.getOtpAttempts() >= MAX_OTP_ATTEMPTS) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        a.setOtpAttempts(a.getOtpAttempts() + 1);

        String expected = a.getOtpHash();
        String provided = OtpUtil.hashForSession(a.getSessionId(), code);

        if (!OtpUtil.constantTimeEquals(expected, provided)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        a.setOtpVerified(true);
        return ResponseEntity.ok(buildVerifyOtpProfileResponseFromUsername(a.getUsername()));
    }

    @Override
    public ResponseEntity<AuthMfaEmailSend200Response> sendSmsOtp(SendSmsReqApiV1 req) {
        Attempt a = attemptFromSession(req.getSessionId());
        if (a == null) return ResponseEntity.badRequest().body(new AuthMfaEmailSend200Response().sent(false));

        UserRepresentation rep = userRep(a);
        String phone = extractPhoneNumber(rep);

        if (phone == null || phone.isBlank()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new AuthMfaEmailSend200Response().sent(false));
        }

        String code = OtpUtil.generate6Digits();
        String hash = OtpUtil.hashForSession(a.getSessionId(), code);

        a.setOtpHash(hash);
        a.setOtpExpiresAt(Instant.now().plus(OTP_TTL));
        a.setOtpVerified(false);
        a.setOtpAttempts(0);

        smsService.sendSms(phone, "", code, "otp.code", Locale.ENGLISH);

        boolean sent = smsService.wasSmsSent();
        return ResponseEntity.ok(new AuthMfaEmailSend200Response().sent(sent));
    }

    @Override
    public ResponseEntity<VerifyOtpProfileResponseApiV1> verifySmsOtp(VerifySmsReqApiV1 req) {
        Attempt a = attemptFromSession(req.getSessionId());
        if (a == null) return ResponseEntity.badRequest().build();

        String code = safe(req.getCode());
        if (code.isBlank()) return ResponseEntity.badRequest().build();

        if (a.getOtpHash() == null || a.getOtpExpiresAt() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        if (Instant.now().isAfter(a.getOtpExpiresAt())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        if (a.getOtpAttempts() >= MAX_OTP_ATTEMPTS) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        a.setOtpAttempts(a.getOtpAttempts() + 1);

        String expected = a.getOtpHash();
        String provided = OtpUtil.hashForSession(a.getSessionId(), code);

        if (!OtpUtil.constantTimeEquals(expected, provided)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        a.setOtpVerified(true);
        return ResponseEntity.ok(buildVerifyOtpProfileResponseFromUsername(a.getUsername()));
    }

    @Override
    public ResponseEntity<StartTotpSessionResponseApiV1> startTotpSession(StartTotpSessionRequestApiV1 req) {
        Attempt a = attemptFromSession(req.getSessionId());
        if (a == null) return ResponseEntity.badRequest().build();

        return ResponseEntity.status(HttpStatus.NOT_IMPLEMENTED).build();
    }

    @Override
    public ResponseEntity<VerifyOtpProfileResponseApiV1> verifyTotp(VerifyTotpRequestApiV1 req) {
        Attempt a = attemptFromSession(req.getSessionId());
        if (a == null) return ResponseEntity.badRequest().build();

        String code = safe(req.getCode());
        if (code.isBlank()) return ResponseEntity.badRequest().build();

        if (a.getPassword() == null || a.getPassword().isBlank()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        boolean ok = validateTotpWithDirectGrant(a.getRealm(), a.getUsername(), a.getPassword(), code);
        if (!ok) return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();

        a.setOtpVerified(true);
        return ResponseEntity.ok(buildVerifyOtpProfileResponseFromUsername(a.getUsername()));
    }

    @Override
    public ResponseEntity<Void> deleteTotp(DeleteTotpRequestApiV1 req) {
        Attempt a = attemptFromSession(req.getSessionId());
        if (a == null) return ResponseEntity.badRequest().build();

        RealmResource rr = keycloak.realms().realm(a.getRealm());
        UserResource ur = rr.users().get(a.getUserId());

        List<CredentialRepresentation> creds = ur.credentials();
        for (CredentialRepresentation c : creds) {
            if ("otp".equalsIgnoreCase(c.getType()) && c.getId() != null) {
                ur.removeCredential(c.getId());
            }
        }

        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<AuthProfileSetEmail200Response> profileSetEmail(SetEmailRequestApiV1 req) {
        Attempt a = attemptFromSession(req.getSessionId());
        if (a == null) return ResponseEntity.badRequest().body(new AuthProfileSetEmail200Response().updated(false));

        String email = safe(req.getEmail());
        if (email.isBlank() || !email.contains("@")) {
            return ResponseEntity.badRequest().body(new AuthProfileSetEmail200Response().updated(false));
        }

        RealmResource rr = keycloak.realms().realm(a.getRealm());
        UserResource ur = rr.users().get(a.getUserId());

        UserRepresentation rep = ur.toRepresentation();
        rep.setEmail(email);
        rep.setEmailVerified(false);
        ur.update(rep);

        return ResponseEntity.ok(new AuthProfileSetEmail200Response().updated(true));
    }

    @Override
    public ResponseEntity<AuthProfileVerifyEmail200Response> profileVerifyEmail(SendEmailReqApiV1 req) {
        Attempt a = attemptFromSession(req.getSessionId());
        if (a == null) return ResponseEntity.badRequest().body(new AuthProfileVerifyEmail200Response().emailSent(false));

        UserRepresentation rep = userRep(a);
        String email = safe(rep.getEmail());
        if (email.isBlank()) {
            return ResponseEntity.badRequest().body(new AuthProfileVerifyEmail200Response().emailSent(false));
        }

        String code = OtpUtil.generate6Digits();
        String hash = OtpUtil.hashForSession(a.getSessionId(), code);

        a.setOtpHash(hash);
        a.setOtpExpiresAt(Instant.now().plus(OTP_TTL));
        a.setOtpVerified(false);
        a.setOtpAttempts(0);

        emailSender.sendOtp(email, code);

        return ResponseEntity.ok(new AuthProfileVerifyEmail200Response().emailSent(true));
    }

    private Attempt attemptFromSession(String sessionId) {
        String sid = safe(sessionId);
        if (sid.isBlank()) return null;
        return store.getBySessionId(sid);
    }

    private UserRepresentation userRep(Attempt a) {
        RealmResource rr = keycloak.realms().realm(a.getRealm());
        UserResource ur = rr.users().get(a.getUserId());
        return ur.toRepresentation();
    }

    @Override
    public MfaProfileApiV1 buildMfaProfile(String sessionId, String userName) {
        FoundUser found = findUserByUsernameExactAcrossRealms(userName);
        if (found == null) {
            return MfaProfileApiV1.builder().build();
        }

        String realmName = found.realm;
        String userId = found.userId;


        RealmResource rr = keycloak.realms().realm(realmName);
        UserResource ur = rr.users().get(userId);
        UserRepresentation rep = ur.toRepresentation();

        String email = safe(rep.getEmail());
        boolean emailExisting = !email.isBlank();
        boolean emailVerified = Boolean.TRUE.equals(rep.isEmailVerified());

        String phone = extractPhoneNumber(rep);
        boolean phoneExisting = phone != null && !phone.isBlank();

        boolean otpSet = userHasTotp(realmName, userId);

        MfaMethodApiV1 emailMethod = MfaMethodApiV1.builder()
                .enabled(emailExisting)
                .active(emailExisting && emailVerified)
                .value(emailExisting ? email : null)
                .build();

        MfaMethodApiV1 smsMethod = MfaMethodApiV1.builder()
                .enabled(phoneExisting)
                .active(phoneExisting)
                .value(phoneExisting ? phone : null)
                .build();

        MfaMethodApiV1 otpMethod = MfaMethodApiV1.builder()
                .enabled(otpSet)
                .active(otpSet)
                .value(null)
                .build();

        return MfaProfileApiV1.builder()
                .sessionId(sessionId)
                .email(emailMethod)
                .sms(smsMethod)
                .otp(otpMethod)
                .build();
    }

    private boolean userHasTotp(String realm, String userId) {
        RealmResource rr = keycloak.realms().realm(realm);
        UserResource ur = rr.users().get(userId);
        List<CredentialRepresentation> creds = ur.credentials();
        for (CredentialRepresentation c : creds) {
            if ("otp".equalsIgnoreCase(c.getType())) return true;
        }
        return false;
    }

    private String extractPhoneNumber(UserRepresentation rep) {
        Map<String, List<String>> attrs = rep.getAttributes();
        if (attrs == null) return null;
        List<String> vals = attrs.get("phone_number");
        if (vals == null || vals.isEmpty()) return null;
        return vals.get(0);
    }

    private boolean validateTotpWithDirectGrant(String realm, String username, String password, String totp) {
        DirectGrantServiceImpl.DagResult dag = dgs.validateCredentialsDetailed(realm, username, password, null, null);
        return dag.ok();
    }

    private FoundUser findUserByUsernameExactAcrossRealms(String username) {
        List<RealmRepresentation> realms = keycloak.realms().findAll();

        for (RealmRepresentation r : realms) {
            RealmResource rr = keycloak.realms().realm(r.getRealm());

            List<UserRepresentation> users = rr.users().search(username, true);
            if (users == null) continue;

            for (UserRepresentation u : users) {
                if (u.getUsername() != null && u.getUsername().equalsIgnoreCase(username)) {
                    return new FoundUser(r.getRealm(), u.getId());
                }
            }
        }
        return null;
    }

    private VerifyOtpProfileResponseApiV1 buildVerifyOtpProfileResponseFromUsername(String username) {
        FoundUser foundUser = findUserByUsernameExactAcrossRealms(username);
        UserApiV1 userApiV1 = userService.getUser(foundUser.realm, foundUser.userId);

        VerifyOtpProfileResponseApiV1 verifyOtpProfileResponseApiV1 = new VerifyOtpProfileResponseApiV1();

        verifyOtpProfileResponseApiV1.setUserId(foundUser.userId);
        verifyOtpProfileResponseApiV1.setUsername(userApiV1.getUsername());
        verifyOtpProfileResponseApiV1.setEmail(userApiV1.getMfaProfile().getEmail().getValue());

        return verifyOtpProfileResponseApiV1;
    }

    private static String safe(String s) {
        return s == null ? "" : s.trim();
    }

    private static class FoundUser {
        private final String realm;
        private final String userId;

        private FoundUser(String realm, String userId) {
            this.realm = realm;
            this.userId = userId;
        }
    }
}
